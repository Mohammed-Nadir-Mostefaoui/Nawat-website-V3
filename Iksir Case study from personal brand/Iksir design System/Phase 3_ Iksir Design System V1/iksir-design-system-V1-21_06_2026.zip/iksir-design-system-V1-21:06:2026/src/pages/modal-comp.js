import { pageHeader } from '../utils/render.js';
import { SIZING } from '../data/sizing.js';

/* ── icons ────────────────────────────────────────────────── */
const ICO_CHECK = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`;
const ICO_WARN  = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;
const ICO_TRASH = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>`;
const ICO_CLOSE = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;
const CB_CHECK  = `<svg width="11" height="11" viewBox="0 0 14 14" fill="none" stroke="#430098" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.0 7.0 L5.6 10.6 L12.0 3.4"/></svg>`;

/* ── variant config ───────────────────────────────────────── */
const VARIANTS = {
  default: {
    icon:        ICO_CHECK,
    iconBg:      'var(--modal-featured-icon-bg-default)',
    iconBorder:  'var(--modal-featured-icon-border-default)',
    iconColor:   'var(--modal-featured-icon-icon-default)',
    actionLabel: 'Save changes',
    actionClass: 'btn btn-primary',
  },
  warning: {
    icon:        ICO_WARN,
    iconBg:      'var(--modal-featured-icon-bg-warning)',
    iconBorder:  'var(--modal-featured-icon-border-warning)',
    iconColor:   'var(--modal-featured-icon-icon-warning)',
    actionLabel: 'Save changes',
    actionClass: 'btn btn-primary',
  },
  destructive: {
    icon:        ICO_TRASH,
    iconBg:      'var(--modal-featured-icon-bg-destructive)',
    iconBorder:  'var(--modal-featured-icon-border-destructive)',
    iconColor:   'var(--modal-featured-icon-icon-destructive)',
    actionLabel: 'Delete data',
    actionClass: 'btn btn-destructive',
  },
};

/* ── builders ─────────────────────────────────────────────── */
function modalCard(closeId, variant, opts = {}) {
  const {
    title       = 'Changes made successfully',
    description = 'This blog post has been published. Team members will be able to edit this post and republish changes.',
    hasCheckbox = false,
    width       = 560,
    interactive = false,
  } = opts;

  const v   = VARIANTS[variant];
  const clk = interactive ? `onclick="modalClose('${closeId}')"` : '';

  const cancelBtn = `<button ${clk} class="btn btn-secondary-gray">Cancel</button>`;

  const actionBtn = `<button class="${v.actionClass}">${v.actionLabel}</button>`;

  const checkbox = hasCheckbox ? `<label style="display:inline-flex;align-items:center;gap:8px;cursor:pointer">
    <div class="cb-box-wrap" style="width:16px;height:16px">
      <input class="cb-input" type="checkbox">
      <div class="cb-box" style="width:16px;height:16px;border-radius:4px">
        <span class="cb-icon" style="width:11px;height:11px">${CB_CHECK}</span>
      </div>
    </div>
    <span style="font-family:Inter,sans-serif;font-size:14px;color:var(--content-secondary)">Don't show this again</span>
  </label>` : '';

  return `<div style="width:${width}px;max-width:100%;background:var(--modal-container-bg);border:1px solid var(--modal-container-border);border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.10)">
    <div style="display:flex;align-items:flex-start;justify-content:space-between;padding:24px 24px 0">
      <div style="display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:9999px;background:${v.iconBg};border:1px solid ${v.iconBorder};color:${v.iconColor};flex-shrink:0">
        ${v.icon}
      </div>
      <button ${clk}
        style="display:flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:8px;border:none;background:transparent;color:var(--modal-header-close-default);cursor:pointer;flex-shrink:0"
        onmouseenter="this.style.background='var(--modal-header-close-bg-hover)';this.style.color='var(--modal-header-close-hover)'"
        onmouseleave="this.style.background='transparent';this.style.color='var(--modal-header-close-default)'">${ICO_CLOSE}</button>
    </div>
    <div style="padding:8px 24px 24px">
      <p style="font-family:var(--font-display);font-size:18px;font-weight:600;line-height:1.4;color:var(--modal-header-text-title);margin:0 0 8px">${title}</p>
      <p style="font-family:Inter,sans-serif;font-size:14px;line-height:1.6;color:var(--modal-header-text-description);margin:0">${description}</p>
    </div>
    <div style="height:1px;background:var(--modal-divider)"></div>
    <div style="display:flex;align-items:center;justify-content:${hasCheckbox ? 'space-between' : 'flex-end'};gap:12px;padding:12px 24px">
      ${checkbox}
      <div style="display:flex;align-items:center;gap:12px">${cancelBtn}${actionBtn}</div>
    </div>
  </div>`;
}

function modalOverlay(id, variant, opts = {}) {
  return `<div id="modal-overlay-${id}"
    style="display:none;position:fixed;inset:0;background:var(--modal-overlay-bg);z-index:9000;align-items:center;justify-content:center;padding:24px"
    onclick="modalClose('${id}')">
    <div onclick="event.stopPropagation()">
      ${modalCard(id, variant, { ...opts, interactive: true })}
    </div>
  </div>`;
}

function openBtn(id, label = 'Open modal') {
  return `<button onclick="modalOpen('${id}')"
    style="display:inline-flex;align-items:center;gap:6px;padding:0 12px;height:28px;border-radius:6px;border:1px solid var(--border-default);background:var(--background-surface);font-family:Inter,sans-serif;font-size:12px;font-weight:500;color:var(--content-primary);cursor:pointer">
    ${label}
  </button>`;
}

function tRow(t, i) {
  const bg = i % 2 === 0 ? 'background:var(--background-subtle);' : '';
  const vc = t.val >= 9999 ? '9999px' : t.val + 'px';
  return `<tr style="${bg}border-bottom:1px solid var(--border-subtle)">
    <td style="padding:10px 16px"><code class="tok-name">${t.token}</code></td>
    <td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'${vc}')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">${t.ref}<span class="tok-alias-copied">${vc}</span></span></td>
    <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${t.use}</td>
  </tr>`;
}

/* ── page ─────────────────────────────────────────────────── */
export default function modalComp() {
  return pageHeader('Components', 'Modal', 'Focused overlay dialog for confirmations, alerts, and short forms. Three icon variants (default, warning, destructive) and three sizes.', [
    { val: '3',  label: 'Icon variants' },
    { val: '3',  label: 'Sizes' },
    { val: String(SIZING.modal.length), label: 'Size tokens' },
  ]) + `<div class="page-body">

  <!-- VARIANTS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Variants</h2></div>
    <p class="doc-section-desc">Three icon variants for different severity levels, plus an optional footer checkbox for recurring confirmations.</p>

    <!-- DEFAULT -->
    <div class="doc-variant-block">
      <div class="btn-section-toolbar"><h3 class="doc-variant-title">Default</h3></div>
      <p class="doc-section-desc">Standard confirmation modal. Featured icon uses the brand purple palette. Primary action confirms; secondary cancels and closes the modal.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Brand purple icon — confirmation</span>
          <div class="inp-demo-controls">${openBtn('modal-default')}</div>
        </div>
        <div class="inp-demo-stage" style="padding:32px">
          ${modalCard('modal-default', 'default')}
        </div>
      </div>
    </div>

    <!-- WARNING -->
    <div class="doc-variant-block">
      <div class="btn-section-toolbar"><h3 class="doc-variant-title">Warning</h3></div>
      <p class="doc-section-desc">Use when the action could have unintended side-effects but is not irreversible. Featured icon uses the amber warning palette.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Amber icon — caution</span>
          <div class="inp-demo-controls">${openBtn('modal-warning')}</div>
        </div>
        <div class="inp-demo-stage" style="padding:32px">
          ${modalCard('modal-warning', 'warning')}
        </div>
      </div>
    </div>

    <!-- DESTRUCTIVE -->
    <div class="doc-variant-block">
      <div class="btn-section-toolbar"><h3 class="doc-variant-title">Destructive</h3></div>
      <p class="doc-section-desc">Use for irreversible actions such as deleting records. Featured icon uses the red danger palette and the primary action button is destructive.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Red icon — irreversible action</span>
          <div class="inp-demo-controls">${openBtn('modal-destructive')}</div>
        </div>
        <div class="inp-demo-stage" style="padding:32px">
          ${modalCard('modal-destructive', 'destructive')}
        </div>
      </div>
    </div>

    <!-- WITH CHECKBOX -->
    <div class="doc-variant-block">
      <div class="btn-section-toolbar"><h3 class="doc-variant-title">With checkbox</h3></div>
      <p class="doc-section-desc">Footer variant with an opt-out checkbox on the left. Used for recurring confirmations where the user may choose to suppress future appearances.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Don't show this again — checkbox in footer</span>
          <div class="inp-demo-controls">${openBtn('modal-checkbox')}</div>
        </div>
        <div class="inp-demo-stage" style="padding:32px">
          ${modalCard('modal-checkbox', 'default', { hasCheckbox: true })}
        </div>
      </div>
    </div>
  </div>

  <!-- SIZES -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Sizes</h2></div>
    <p class="doc-section-desc">Three widths: SM (400px) for short confirmations, MD (560px) as the default, LG (720px) for modals with longer content or form fields.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">SM · MD · LG</span>
        <div class="inp-demo-controls">
          ${openBtn('modal-sm', 'Open SM')}
          ${openBtn('modal-md', 'Open MD')}
          ${openBtn('modal-lg', 'Open LG')}
        </div>
      </div>
      <div class="inp-demo-stage" style="padding:32px;display:flex;flex-direction:column;gap:24px;align-items:flex-start">
        <div>
          <p style="font-family:Inter,sans-serif;font-size:11px;font-weight:600;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em;margin:0 0 10px">SM — 400 px</p>
          ${modalCard('modal-sm', 'default', { width: 400 })}
        </div>
        <div>
          <p style="font-family:Inter,sans-serif;font-size:11px;font-weight:600;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em;margin:0 0 10px">MD — 560 px</p>
          ${modalCard('modal-md', 'default', { width: 560 })}
        </div>
        <div>
          <p style="font-family:Inter,sans-serif;font-size:11px;font-weight:600;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em;margin:0 0 10px">LG — 720 px</p>
          ${modalCard('modal-lg', 'default', { width: 720 })}
        </div>
      </div>
    </div>
  </div>

  <!-- COMPONENT TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <p class="doc-section-desc">All sizing values bound to the <code>Components</code> collection. Hover to preview the value, click to copy.</p>
    <div class="card" style="overflow:hidden;margin-bottom:16px">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Aliases → (hover for value, click to copy)</th><th>Usage</th></tr></thead>
        <tbody>${SIZING.modal.map(tRow).join('')}</tbody>
      </table>
    </div>
  </div>

  <!-- PROPS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
    <table class="prop-table">
      <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
      <tbody>
        <tr><td><span class="prop-name">open</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Controls visibility. Managed externally — the modal never closes itself.</td></tr>
        <tr><td><span class="prop-name">onClose</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Called when the user clicks the X button, Cancel, or the overlay backdrop.</td></tr>
        <tr><td><span class="prop-name">variant</span></td><td><span class="prop-type">"default" | "warning" | "destructive"</span></td><td><span class="prop-default">"default"</span></td><td>Sets the featured icon palette and action button style.</td></tr>
        <tr><td><span class="prop-name">size</span></td><td><span class="prop-type">"sm" | "md" | "lg"</span></td><td><span class="prop-default">"md"</span></td><td>Controls the modal container width (400 / 560 / 720 px).</td></tr>
        <tr><td><span class="prop-name">title</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Heading text rendered in the modal body. Required.</td></tr>
        <tr><td><span class="prop-name">description</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Supporting paragraph below the title.</td></tr>
        <tr><td><span class="prop-name">actionLabel</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">"Confirm"</span></td><td>Label for the primary action button.</td></tr>
        <tr><td><span class="prop-name">onAction</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Called when the primary action button is clicked.</td></tr>
        <tr><td><span class="prop-name">checkboxLabel</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>If provided, renders a checkbox on the left side of the footer with this label.</td></tr>
        <tr><td><span class="prop-name">onCheckboxChange</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Called with the new boolean value when the footer checkbox changes.</td></tr>
      </tbody>
    </table>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use modals sparingly — only for actions that require the user's immediate attention or an explicit decision before continuing.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use modals for non-critical notifications or status messages. Use a Toast or inline feedback instead to avoid interrupting the user's flow.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Match the variant to the severity of the action. Use <strong>default</strong> for confirmations, <strong>warning</strong> for side-effects, and <strong>destructive</strong> only for irreversible deletions.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't stack modals. Opening a second modal on top of an existing one creates a confusing stack that is hard to dismiss and disorients the user.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Always provide a clear way to dismiss: the X button, the Cancel action, and clicking the overlay should all close the modal without committing any changes.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't put long forms or complex workflows inside a modal. If the content requires scrolling, consider a full-page view or a side sheet instead.</div></div>
    </div>
  </div>

  </div>

  <!-- LIVE OVERLAY MODALS ─────────────────────────────────── -->
  ${modalOverlay('modal-default',     'default')}
  ${modalOverlay('modal-warning',     'warning')}
  ${modalOverlay('modal-destructive', 'destructive')}
  ${modalOverlay('modal-checkbox',    'default', { hasCheckbox: true })}
  ${modalOverlay('modal-sm', 'default', { width: 400 })}
  ${modalOverlay('modal-md', 'default', { width: 560 })}
  ${modalOverlay('modal-lg', 'default', { width: 720 })}`;
}
