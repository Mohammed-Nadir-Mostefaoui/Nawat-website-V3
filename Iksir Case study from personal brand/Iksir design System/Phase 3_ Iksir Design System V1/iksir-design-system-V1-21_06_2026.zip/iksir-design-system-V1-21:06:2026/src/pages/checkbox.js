import { pageHeader } from '../utils/render.js';

export default function() {
  return pageHeader('Components', 'Checkbox', 'Three types — Checkbox, Radio, and Check circle. Four states, two sizes, label and supporting text combinations — 144 variants, all fully interactive.') + `<div class="page-body">


    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Types & States</h2></div>
      <p class="doc-section-desc">Three types — Checkbox, Radio, and Check circle. All start <strong>unchecked</strong>. Click anywhere on the control to toggle. Hover to see the hover state. Use dropdowns to force a specific state or switch type/size.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Click to toggle · hover to see hover state</span>
          <div class="inp-demo-controls"><span class="inp-demo-meta">Type</span><select class="inp-state-select" id="sel-cb-main-type" onchange="cbState('main-type')"><option value="Checkbox"selected>Checkbox</option><option value="Radio">Radio</option><option value="Check circle">Check circle</option></select><span class="inp-demo-meta">Checked</span><select class="inp-state-select" id="sel-cb-main-checked" onchange="cbState('main-checked')"><option value="Unchecked"selected>Unchecked</option><option value="Checked">Checked</option></select><span class="inp-demo-meta">State</span><select class="inp-state-select" id="sel-cb-main-state" onchange="cbState('main-state')"><option value="Default"selected>Default</option><option value="Hover">Hover</option><option value="Focused">Focused</option><option value="Disabled">Disabled</option></select><span class="inp-demo-meta">Size</span><select class="inp-state-select" id="sel-cb-main-size" onchange="cbState('main-size')"><option value="SM">SM</option><option value="MD"selected>MD</option></select></div>
        </div>
        <div class="inp-demo-stage">
          <label class="cb-wrap" id="cb-wrap-main">
      <div class="cb-box-wrap" style="width:20px;height:20px">
        <input class="cb-input" type="checkbox" id="cb-inp-main"
               style="width:20px;height:20px"/>
        <div class="cb-box" id="cb-box-main"
             style="width:20px;height:20px;border-radius:6px">
          <span class="cb-icon" id="cb-icon-main"
                style="width:14px;height:14px">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="var(--brand-primary)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.0 7.0 L5.6 10.6 L12.0 3.4"/></svg>
          </span>
        </div>
      </div>
      <div>
        <p class="cb-label-text">Remember me</p>

      </div>
    </label>
        </div>
        <div class="inp-state-strip">
          <div class="inp-state-item"><div class="inp-state-dot" style="background:#FFFFFF;border:1px solid #E9EAEB"></div>Default unchecked</div>
          <div class="inp-state-item"><div class="inp-state-dot" style="background:#F7F4FB;border:1px solid #8E66C1"></div>Hover / checked</div>
          <div class="inp-state-item"><div class="inp-state-dot" style="background:#FFFFFF;border:1px solid #C7B3E0;box-shadow:0 0 0 3px #F7F4FB"></div>Focused unchecked</div>
          <div class="inp-state-item"><div class="inp-state-dot" style="background:#430098;border-radius:50%"></div>Check circle checked</div>
          <div class="inp-state-item"><div class="inp-state-dot" style="background:#FAFAFA;border:1px solid #E6E6E6"></div>Disabled</div>
        </div>
      </div>
    </div>


    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">With supporting text</h2></div>
      <p class="doc-section-desc">Optional second line below the label. Label: <code>Text/Label MD</code> (Inter 500 16px/24px). Supporting: <code>Text/Body MD</code> (Inter 400 16px/24px) with 2px gap. Click to toggle.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Click to toggle · hover to see hover state</span>
          <div class="inp-demo-controls"><span class="inp-demo-meta">Checked</span><select class="inp-state-select" id="sel-cb-supp-checked" onchange="cbState('supp-checked')"><option value="Unchecked"selected>Unchecked</option><option value="Checked">Checked</option></select><span class="inp-demo-meta">State</span><select class="inp-state-select" id="sel-cb-supp-state" onchange="cbState('supp-state')"><option value="Default"selected>Default</option><option value="Hover">Hover</option><option value="Focused">Focused</option><option value="Disabled">Disabled</option></select></div>
        </div>
        <div class="inp-demo-stage">
          <label class="cb-wrap" id="cb-wrap-supp">
      <div class="cb-box-wrap" style="width:20px;height:20px">
        <input class="cb-input" type="checkbox" id="cb-inp-supp"
               style="width:20px;height:20px"/>
        <div class="cb-box" id="cb-box-supp"
             style="width:20px;height:20px;border-radius:6px">
          <span class="cb-icon" id="cb-icon-supp"
                style="width:14px;height:14px">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="var(--brand-primary)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.0 7.0 L5.6 10.6 L12.0 3.4"/></svg>
          </span>
        </div>
      </div>
      <div>
        <p class="cb-label-text">Remember me</p>
        <p class="cb-supporting-text">Save my login details for next time.</p>
      </div>
    </label>
        </div>
        <div class="inp-state-strip">
          <div class="inp-state-item"><div class="inp-state-dot" style="background:#FFFFFF;border:1px solid #E9EAEB"></div>Default unchecked</div>
          <div class="inp-state-item"><div class="inp-state-dot" style="background:#F7F4FB;border:1px solid #8E66C1"></div>Hover / checked</div>
          <div class="inp-state-item"><div class="inp-state-dot" style="background:#FFFFFF;border:1px solid #C7B3E0;box-shadow:0 0 0 3px #F7F4FB"></div>Focused unchecked</div>
          <div class="inp-state-item"><div class="inp-state-dot" style="background:#430098;border-radius:50%"></div>Check circle checked</div>
          <div class="inp-state-item"><div class="inp-state-dot" style="background:#FAFAFA;border:1px solid #E6E6E6"></div>Disabled</div>
        </div>
      </div>
    </div>

    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Sizes</h2></div>
      <p class="doc-section-desc">Two sizes — SM (16px) and MD (20px). Click each to toggle. Hover to see the hover state.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar"><span class="inp-demo-title">Both sizes — start unchecked · click to toggle · hover for hover state</span></div>
        <div class="inp-multi-stage">

      <div class="inp-multi-cell">
        <label class="cb-wrap">
          <div class="cb-box-wrap" style="width:16px;height:16px">
            <input class="cb-input" type="checkbox" style="width:16px;height:16px"/>
            <div class="cb-box" style="width:16px;height:16px;border-radius:4px">
              <span class="cb-icon" style="width:12px;height:12px"><svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="var(--brand-primary)" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"><path d="M1.7 6.0 L4.8 9.1 L10.3 2.9"/></svg></span>
            </div>
          </div>
          <div><p class="cb-label-text" style="font-size:14px">Remember me</p></div>
        </label>
        <span class="inp-multi-label">SM — 16×16px · radius 4px · icon 12px</span>
      </div>

      <div class="inp-multi-cell">
        <label class="cb-wrap">
          <div class="cb-box-wrap" style="width:20px;height:20px">
            <input class="cb-input" type="checkbox" style="width:20px;height:20px"/>
            <div class="cb-box" style="width:20px;height:20px;border-radius:6px">
              <span class="cb-icon" style="width:14px;height:14px"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="var(--brand-primary)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.0 7.0 L5.6 10.6 L12.0 3.4"/></svg></span>
            </div>
          </div>
          <div><p class="cb-label-text" style="font-size:16px">Remember me</p></div>
        </label>
        <span class="inp-multi-label">MD — 20×20px · radius 6px · icon 14px</span>
      </div>
        </div>
      </div>
    </div>

    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Usage example</h2></div>
      <p class="doc-section-desc">All items start unchecked. Click any to toggle. Tab to focus, Space to toggle — fully keyboard accessible.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar"><span class="inp-demo-title">Checkbox group — all unchecked · click to toggle</span></div>
        <div class="inp-demo-stage" style="padding:32px">
          <div style="width:100%;max-width:380px;display:flex;flex-direction:column;gap:16px">
            <p style="margin:0 0 4px;font-size:14px;font-weight:600;color:var(--content-secondary);font-family:var(--font-body)">Notification preferences</p>

        <label class="cb-wrap" style="width:100%">
          <div class="cb-box-wrap" style="width:20px;height:20px">
            <input class="cb-input" type="checkbox" style="width:20px;height:20px"/>
            <div class="cb-box" style="width:20px;height:20px;border-radius:6px">
              <span class="cb-icon" style="width:14px;height:14px"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="var(--brand-primary)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.0 7.0 L5.6 10.6 L12.0 3.4"/></svg></span>
            </div>
          </div>
          <div style="padding-top:2px">
            <p class="cb-label-text">Product updates</p>
            <p class="cb-supporting-text">Get notified about product updates.</p>
          </div>
        </label>
        <label class="cb-wrap" style="width:100%">
          <div class="cb-box-wrap" style="width:20px;height:20px">
            <input class="cb-input" type="checkbox" style="width:20px;height:20px"/>
            <div class="cb-box" style="width:20px;height:20px;border-radius:6px">
              <span class="cb-icon" style="width:14px;height:14px"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="var(--brand-primary)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.0 7.0 L5.6 10.6 L12.0 3.4"/></svg></span>
            </div>
          </div>
          <div style="padding-top:2px">
            <p class="cb-label-text">Weekly digest</p>
            <p class="cb-supporting-text">Receive a weekly summary of activity.</p>
          </div>
        </label>
        <label class="cb-wrap" style="width:100%">
          <div class="cb-box-wrap" style="width:20px;height:20px">
            <input class="cb-input" type="checkbox" style="width:20px;height:20px"/>
            <div class="cb-box" style="width:20px;height:20px;border-radius:6px">
              <span class="cb-icon" style="width:14px;height:14px"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="var(--brand-primary)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.0 7.0 L5.6 10.6 L12.0 3.4"/></svg></span>
            </div>
          </div>
          <div style="padding-top:2px">
            <p class="cb-label-text">Security alerts</p>
            <p class="cb-supporting-text">Be alerted about account security events.</p>
          </div>
        </label>
        <label class="cb-wrap" style="width:100%">
          <div class="cb-box-wrap" style="width:20px;height:20px">
            <input class="cb-input" type="checkbox" style="width:20px;height:20px"/>
            <div class="cb-box" style="width:20px;height:20px;border-radius:6px">
              <span class="cb-icon" style="width:14px;height:14px"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="var(--brand-primary)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.0 7.0 L5.6 10.6 L12.0 3.4"/></svg></span>
            </div>
          </div>
          <div style="padding-top:2px">
            <p class="cb-label-text">Marketing emails</p>
            <p class="cb-supporting-text">Receive news, promotions, and updates.</p>
          </div>
        </label>
          </div>
        </div>
      </div>
    </div>

    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Color tokens</h2></div>
      <p class="doc-section-desc">19 semantic tokens in <code>Tokens</code> under <code>checkbox/*</code>. Hover to preview, click to copy.</p>
      <div class="card" style="overflow:hidden;margin-bottom:16px"><table class="tok-table"><thead><tr><th>Token</th><th>Aliases → (hover for value, click to copy)</th><th>Usage</th></tr></thead><tbody><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/bg-default</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#FFFFFF')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#FFFFFF;border:1px solid #E1E1E1;"></span>background/surface<span class="tok-alias-copied">#FFFFFF</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Unchecked default fill</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/bg-hover</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#F7F4FB')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#F7F4FB;"></span>brand/primary-subtle<span class="tok-alias-copied">#F7F4FB</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Hover fill</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/bg-checked</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#F7F4FB')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#F7F4FB;"></span>brand/primary-subtle<span class="tok-alias-copied">#F7F4FB</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Checked fill</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/bg-circle-checked</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#430098')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#430098;"></span>brand/primary<span class="tok-alias-copied">#430098</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Check circle fill when checked</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/bg-disabled</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#FAFAFA')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#FAFAFA;border:1px solid #E1E1E1;"></span>Grey/Grey-10<span class="tok-alias-copied">#FAFAFA</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Disabled fill</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/border-default</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#E9EAEB')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#E9EAEB;"></span>Grey/Grey-50<span class="tok-alias-copied">#E9EAEB</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Unchecked default border</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/border-checked</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#8E66C1')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#8E66C1;"></span>Purple/Purple-60<span class="tok-alias-copied">#8E66C1</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Checked / hover border</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/border-focused</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#C7B3E0')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#C7B3E0;"></span>Purple/Purple-30<span class="tok-alias-copied">#C7B3E0</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Focused unchecked border</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/border-disabled</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#E6E6E6')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#E6E6E6;"></span>Grey/Grey-40<span class="tok-alias-copied">#E6E6E6</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Disabled border</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/focus-ring</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#F7F4FB')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#F7F4FB;"></span>Purple/Purple-5<span class="tok-alias-copied">#F7F4FB</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Focus ring — 4px spread</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/icon-default</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#430098')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#430098;"></span>brand/primary<span class="tok-alias-copied">#430098</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Check icon</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/icon-disabled</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#E6E6E6')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#E6E6E6;"></span>Grey/Grey-40<span class="tok-alias-copied">#E6E6E6</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Check icon when disabled</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/icon-on-brand</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#FFFFFF')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#FFFFFF;border:1px solid #E1E1E1;"></span>background/surface<span class="tok-alias-copied">#FFFFFF</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">White icon inside Check circle</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/radio-dot</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#430098')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#430098;"></span>brand/primary<span class="tok-alias-copied">#430098</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Radio inner dot</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/radio-dot-disabled</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#E6E6E6')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#E6E6E6;"></span>Grey/Grey-40<span class="tok-alias-copied">#E6E6E6</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Radio dot when disabled</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/label</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#191919')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#191919;"></span>content/primary<span class="tok-alias-copied">#191919</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Label — Inter 500 16px/24px</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/label-disabled</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#BABABA')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#BABABA;"></span>content/disabled<span class="tok-alias-copied">#BABABA</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Label when disabled</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/supporting</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#757575')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#757575;"></span>content/secondary<span class="tok-alias-copied">#757575</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Supporting — Inter 400 16px/24px</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">checkbox/supporting-disabled</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'#BABABA')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')"><span class="tok-alias-dot" style="background:#BABABA;"></span>content/disabled<span class="tok-alias-copied">#BABABA</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Supporting when disabled</td></tr></tbody></table></div>
    </div>

    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Size tokens</h2></div>
      <p class="doc-section-desc">14 sizing tokens in <code>Components</code> under <code>component/checkbox/*</code>.</p>
      <div class="card" style="overflow:hidden;margin-bottom:16px"><table class="tok-table"><thead><tr><th>Token</th><th>Aliases → (hover for value, click to copy)</th><th>Usage</th></tr></thead><tbody><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/checkbox/size/sm</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'16px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/16<span class="tok-alias-copied">16px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Box width & height — SM</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/checkbox/size/md</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'20px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/20<span class="tok-alias-copied">20px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Box width & height — MD</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/checkbox/radius/sm</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'4px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/4<span class="tok-alias-copied">4px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Checkbox radius — SM</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/checkbox/radius/md</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'6px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/6<span class="tok-alias-copied">6px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Checkbox radius — MD</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/checkbox/gap</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'12px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/12<span class="tok-alias-copied">12px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Gap: box → label</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/checkbox/label-gap</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'2px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/2<span class="tok-alias-copied">2px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Label → supporting gap</td></tr></tbody></table></div>
    </div>

    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
      <table class="prop-table">
        <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
        <tbody>
          <tr><td><span class="prop-name">type</span></td><td><span class="prop-type">"Checkbox"|"Radio"|"Check circle"</span></td><td><span class="prop-default">"Checkbox"</span></td><td>Visual and behavioral type.</td></tr>
          <tr><td><span class="prop-name">size</span></td><td><span class="prop-type">"sm"|"md"</span></td><td><span class="prop-default">"md"</span></td><td>Box size — 16px or 20px.</td></tr>
          <tr><td><span class="prop-name">checked</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Whether the control is selected.</td></tr>
          <tr><td><span class="prop-name">disabled</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Prevents interaction.</td></tr>
          <tr><td><span class="prop-name">label</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Label text.</td></tr>
          <tr><td><span class="prop-name">supportingText</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Second line below the label.</td></tr>
          <tr><td><span class="prop-name">onChange</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Change handler.</td></tr>
        </tbody>
      </table>
    </div>

    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
      <div class="do-dont">
        <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use <strong>Checkbox</strong> for multi-select — multiple items can be chosen simultaneously.</div></div>
        <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use Checkbox for mutually exclusive options — use Radio instead.</div></div>
        <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use <strong>Check circle</strong> for feature lists and confirmations where brand fill signals completion.</div></div>
        <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't trigger immediate actions on check — submit state changes via a button.</div></div>
        <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Match size to adjacent inputs — SM with SM, MD with MD.</div></div>
        <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't omit the label. Use <code>aria-label</code> when a visible label isn't possible.</div></div>
      </div>
    </div>

  </div>`;
}
