import { pageHeader } from '../utils/render.js';

/* ─── Every token name, organized by group ───────────────────────────────
   Order and grouping mirrors tokens.css exactly.
   The page reads live values from getComputedStyle at render time,
   so this list is the only thing that needs updating when tokens change.
   ─────────────────────────────────────────────────────────────────────── */
const GROUPS = [
  /* ── Layer 2 · Semantic ── */
  { label: 'brand/', tokens: ['--brand-primary','--brand-primary-hover','--brand-primary-active','--brand-primary-focus','--brand-primary-disabled','--brand-primary-muted','--brand-primary-subtle','--brand-secondary'] },
  { label: 'content/', tokens: ['--content-primary','--content-secondary','--content-tertiary','--content-disabled','--content-inverse','--content-on-brand'] },
  { label: 'icon/', tokens: ['--icon-default','--icon-muted','--icon-brand','--icon-on-brand','--icon-success','--icon-warning','--icon-danger'] },
  { label: 'background/', tokens: ['--background-page','--background-surface','--background-subtle','--background-raised','--background-overlay','--background-brand','--background-brand-subtle'] },
  { label: 'border/ + focus', tokens: ['--border-default','--border-subtle','--border-strong','--border-brand','--border-focus','--border-danger','--focus-width','--focus-offset'] },
  { label: 'status/success', tokens: ['--status-success-content','--status-success-bg','--status-success-border'] },
  { label: 'status/warning', tokens: ['--status-warning-content','--status-warning-bg','--status-warning-border'] },
  { label: 'status/danger', tokens: ['--status-danger-content','--status-danger-bg','--status-danger-border','--status-danger-bg-hover','--status-danger-bg-active','--status-danger-border-hover','--status-danger-border-active'] },
  { label: 'status/info', tokens: ['--status-info-content','--status-info-bg','--status-info-border'] },

  /* ── Layer 3 · Component colour tokens ── */
  { label: 'button/primary/', tokens: ['--button-primary-bg-default','--button-primary-bg-hover','--button-primary-bg-active','--button-primary-bg-focused','--button-primary-bg-disabled','--button-primary-text-default','--button-primary-text-disabled','--button-primary-icon-default','--button-primary-icon-hover','--button-primary-icon-active','--button-primary-icon-focused','--button-primary-icon-disabled','--button-primary-border-focused'] },
  { label: 'button/secondary-color/', tokens: ['--button-secondary-color-bg-default','--button-secondary-color-bg-hover','--button-secondary-color-bg-active','--button-secondary-color-bg-focused','--button-secondary-color-bg-disabled','--button-secondary-color-text-default','--button-secondary-color-text-hover','--button-secondary-color-text-active','--button-secondary-color-text-disabled','--button-secondary-color-icon-default','--button-secondary-color-icon-hover','--button-secondary-color-icon-active','--button-secondary-color-icon-focused','--button-secondary-color-icon-disabled','--button-secondary-color-border-default','--button-secondary-color-border-hover','--button-secondary-color-border-active','--button-secondary-color-border-focused','--button-secondary-color-border-disabled'] },
  { label: 'button/secondary-gray/', tokens: ['--button-secondary-gray-bg-default','--button-secondary-gray-bg-hover','--button-secondary-gray-bg-focused','--button-secondary-gray-bg-disabled','--button-secondary-gray-text-default','--button-secondary-gray-text-hover','--button-secondary-gray-text-disabled','--button-secondary-gray-icon-default','--button-secondary-gray-icon-hover','--button-secondary-gray-icon-active','--button-secondary-gray-icon-focused','--button-secondary-gray-icon-disabled','--button-secondary-gray-border-default','--button-secondary-gray-border-hover','--button-secondary-gray-border-focused','--button-secondary-gray-border-disabled'] },
  { label: 'button/tertiary-color/', tokens: ['--button-tertiary-color-bg-hover','--button-tertiary-color-bg-active','--button-tertiary-color-text-default','--button-tertiary-color-text-disabled','--button-tertiary-color-icon-default','--button-tertiary-color-icon-hover','--button-tertiary-color-icon-active','--button-tertiary-color-icon-focused','--button-tertiary-color-icon-disabled'] },
  { label: 'button/tertiary-gray/', tokens: ['--button-tertiary-gray-bg-hover','--button-tertiary-gray-bg-active','--button-tertiary-gray-text-default','--button-tertiary-gray-text-hover','--button-tertiary-gray-text-disabled','--button-tertiary-gray-icon-default','--button-tertiary-gray-icon-hover','--button-tertiary-gray-icon-active','--button-tertiary-gray-icon-focused','--button-tertiary-gray-icon-disabled'] },
  { label: 'button/link-color/', tokens: ['--button-link-color-text-default','--button-link-color-text-hover','--button-link-color-text-disabled','--button-link-color-icon-default','--button-link-color-icon-hover','--button-link-color-icon-active','--button-link-color-icon-focused','--button-link-color-icon-disabled'] },
  { label: 'button/link-gray/', tokens: ['--button-link-gray-text-default','--button-link-gray-text-hover','--button-link-gray-text-disabled','--button-link-gray-icon-default','--button-link-gray-icon-hover','--button-link-gray-icon-active','--button-link-gray-icon-focused','--button-link-gray-icon-disabled'] },
  { label: 'button/destructive/', tokens: ['--button-destructive-bg-default','--button-destructive-bg-hover','--button-destructive-bg-disabled','--button-destructive-text-default','--button-destructive-text-disabled','--button-destructive-icon-default','--button-destructive-icon-hover','--button-destructive-icon-active','--button-destructive-icon-focused','--button-destructive-icon-disabled','--button-destructive-border-default','--button-destructive-border-hover','--button-destructive-border-disabled'] },
  { label: 'input/', tokens: ['--input-icon','--input-icon-focus','--input-icon-error','--input-text-placeholder','--input-text-value','--input-label-default','--input-label-focus','--input-label-disabled','--input-hint','--input-hint-error','--input-bg-default','--input-border-default','--input-border-hover','--input-border-focus','--input-border-error'] },
  { label: 'toggle/', tokens: ['--toggle-thumb-bg-default','--toggle-thumb-bg-disabled','--toggle-track-bg-on','--toggle-track-bg-off','--toggle-track-bg-on-hover','--toggle-track-bg-off-hover','--toggle-track-bg-disabled','--toggle-track-border-off','--toggle-track-border-off-hover','--toggle-track-border-disabled','--toggle-text-label','--toggle-text-supporting','--toggle-text-label-disabled','--toggle-text-supporting-disabled','--toggle-focus-ring'] },
  { label: 'checkbox/', tokens: ['--checkbox-bg-default','--checkbox-bg-hover','--checkbox-bg-checked','--checkbox-bg-circle-checked','--checkbox-bg-disabled','--checkbox-border-default','--checkbox-border-checked','--checkbox-border-focused','--checkbox-border-disabled','--checkbox-focus-ring','--checkbox-icon-default','--checkbox-icon-disabled','--checkbox-icon-on-brand','--checkbox-radio-dot','--checkbox-radio-dot-disabled','--checkbox-label','--checkbox-label-disabled','--checkbox-supporting','--checkbox-supporting-disabled'] },
  { label: 'badge/', tokens: ['--badge-default-bg','--badge-default-text','--badge-default-border','--badge-default-icon','--badge-secondary-bg','--badge-secondary-text','--badge-secondary-border','--badge-secondary-icon','--badge-destructive-bg','--badge-destructive-text','--badge-destructive-border','--badge-destructive-icon','--badge-outline-bg','--badge-outline-text','--badge-outline-border','--badge-outline-icon','--badge-ghost-bg','--badge-ghost-text','--badge-ghost-border','--badge-ghost-icon'] },
  { label: 'tooltip/', tokens: ['--tooltip-bg','--tooltip-title','--tooltip-supporting'] },
  { label: 'breadcrumb/', tokens: ['--breadcrumb-text-default','--breadcrumb-text-hover','--breadcrumb-text-active','--breadcrumb-icon-default','--breadcrumb-icon-hover','--breadcrumb-icon-active','--breadcrumb-separator'] },
  { label: 'tab/badge/', tokens: ['--tab-badge-bg-default','--tab-badge-bg-hover','--tab-badge-bg-active','--tab-badge-bg-disabled','--tab-badge-text-default','--tab-badge-text-hover','--tab-badge-text-active','--tab-badge-text-disabled'] },
  { label: 'tab/underline/', tokens: ['--tab-underline-container-border','--tab-underline-item-bg-default','--tab-underline-item-bg-hover','--tab-underline-item-bg-active','--tab-underline-item-bg-disabled','--tab-underline-item-text-default','--tab-underline-item-text-hover','--tab-underline-item-text-active','--tab-underline-item-text-disabled','--tab-underline-item-icon-default','--tab-underline-item-icon-hover','--tab-underline-item-icon-active','--tab-underline-item-icon-disabled','--tab-underline-indicator-default','--tab-underline-indicator-hover','--tab-underline-indicator-active','--tab-underline-indicator-disabled'] },
  { label: 'tab/line/', tokens: ['--tab-line-container-border','--tab-line-item-bg-default','--tab-line-item-bg-hover','--tab-line-item-bg-active','--tab-line-item-bg-disabled','--tab-line-item-text-default','--tab-line-item-text-hover','--tab-line-item-text-active','--tab-line-item-text-disabled','--tab-line-item-icon-default','--tab-line-item-icon-hover','--tab-line-item-icon-active','--tab-line-item-icon-disabled','--tab-line-indicator-default','--tab-line-indicator-hover','--tab-line-indicator-active','--tab-line-indicator-disabled'] },
  { label: 'tab/button-border/', tokens: ['--tab-button-border-container-bg','--tab-button-border-container-border','--tab-button-border-item-bg-default','--tab-button-border-item-bg-hover','--tab-button-border-item-bg-active','--tab-button-border-item-bg-disabled','--tab-button-border-item-text-default','--tab-button-border-item-text-hover','--tab-button-border-item-text-active','--tab-button-border-item-text-disabled','--tab-button-border-item-icon-default','--tab-button-border-item-icon-hover','--tab-button-border-item-icon-active','--tab-button-border-item-icon-disabled'] },
  { label: 'tab/button-gray/', tokens: ['--tab-button-gray-container-bg','--tab-button-gray-item-bg-default','--tab-button-gray-item-bg-hover','--tab-button-gray-item-bg-active','--tab-button-gray-item-bg-disabled','--tab-button-gray-item-text-default','--tab-button-gray-item-text-hover','--tab-button-gray-item-text-active','--tab-button-gray-item-text-disabled','--tab-button-gray-item-icon-default','--tab-button-gray-item-icon-hover','--tab-button-gray-item-icon-active','--tab-button-gray-item-icon-disabled'] },
  { label: 'tab/button-brand/', tokens: ['--tab-button-brand-container-bg','--tab-button-brand-item-bg-default','--tab-button-brand-item-bg-hover','--tab-button-brand-item-bg-active','--tab-button-brand-item-bg-disabled','--tab-button-brand-item-text-default','--tab-button-brand-item-text-hover','--tab-button-brand-item-text-active','--tab-button-brand-item-text-disabled','--tab-button-brand-item-icon-default','--tab-button-brand-item-icon-hover','--tab-button-brand-item-icon-active','--tab-button-brand-item-icon-disabled'] },
  { label: 'counter/filled/', tokens: ['--counter-filled-bg-default','--counter-filled-bg-hover','--counter-filled-bg-active','--counter-filled-bg-disabled','--counter-filled-text-default','--counter-filled-text-hover','--counter-filled-text-active','--counter-filled-text-disabled'] },
  { label: 'counter/filled-gray/', tokens: ['--counter-filled-gray-bg-default','--counter-filled-gray-bg-hover','--counter-filled-gray-bg-active','--counter-filled-gray-bg-disabled','--counter-filled-gray-text-default','--counter-filled-gray-text-hover','--counter-filled-gray-text-active','--counter-filled-gray-text-disabled'] },
  { label: 'counter/ghost/', tokens: ['--counter-ghost-bg-default','--counter-ghost-bg-hover','--counter-ghost-bg-active','--counter-ghost-bg-disabled','--counter-ghost-text-default','--counter-ghost-text-hover','--counter-ghost-text-active','--counter-ghost-text-disabled'] },
  { label: 'counter/outline/', tokens: ['--counter-outline-bg-default','--counter-outline-bg-hover','--counter-outline-bg-active','--counter-outline-bg-disabled','--counter-outline-text-default','--counter-outline-text-hover','--counter-outline-text-active','--counter-outline-text-disabled','--counter-outline-border-default','--counter-outline-border-hover','--counter-outline-border-active','--counter-outline-border-disabled'] },
  { label: 'toast/', tokens: ['--toast-bg','--toast-text-title','--toast-text-description','--toast-icon-default','--toast-icon-success','--toast-icon-warning','--toast-icon-error','--toast-icon-loading','--toast-close-default','--toast-close-hover','--toast-action-bg-default','--toast-action-bg-hover','--toast-action-text-default','--toast-action-text-hover','--toast-action-text-disabled','--toast-action-border-default','--toast-action-border-hover'] },
  { label: 'modal/', tokens: ['--modal-overlay-bg','--modal-divider','--modal-container-bg','--modal-container-border','--modal-container-shadow','--modal-header-text-title','--modal-header-text-description','--modal-header-close-default','--modal-header-close-hover','--modal-header-close-bg-hover','--modal-featured-icon-icon-default','--modal-featured-icon-icon-warning','--modal-featured-icon-icon-destructive','--modal-featured-icon-bg-default','--modal-featured-icon-bg-warning','--modal-featured-icon-bg-destructive','--modal-featured-icon-border-default','--modal-featured-icon-border-warning','--modal-featured-icon-border-destructive'] },
  { label: 'avatar/', tokens: ['--avatar-image-bg','--avatar-image-border-default','--avatar-image-border-hover','--avatar-image-border-focused','--avatar-text-bg-default','--avatar-text-bg-hover','--avatar-text-bg-focused','--avatar-text-color-default','--avatar-text-color-hover','--avatar-text-color-focused','--avatar-text-border-default','--avatar-text-border-hover','--avatar-text-border-focused','--avatar-placeholder-bg-default','--avatar-placeholder-bg-hover','--avatar-placeholder-bg-focused','--avatar-placeholder-icon-default','--avatar-placeholder-icon-hover','--avatar-placeholder-icon-focused','--avatar-placeholder-border-default','--avatar-placeholder-border-hover','--avatar-placeholder-border-focused','--avatar-status-online-bg','--avatar-status-online-border','--avatar-focus-ring'] },
  { label: 'pagination/', tokens: ['--pagination-container-bg','--pagination-container-border','--pagination-ellipsis','--pagination-info-text','--pagination-button-bg-default','--pagination-button-bg-hover','--pagination-button-bg-active','--pagination-button-bg-disabled','--pagination-button-text-default','--pagination-button-text-hover','--pagination-button-text-active','--pagination-button-text-disabled','--pagination-button-border-default','--pagination-button-border-hover','--pagination-button-border-active','--pagination-button-border-disabled'] },
  { label: 'select/', tokens: ['--select-field-bg-default','--select-field-bg-disabled','--select-field-border-default','--select-field-border-hover','--select-field-border-focus','--select-field-border-error','--select-field-border-disabled','--select-field-placeholder-default','--select-field-value-default','--select-field-value-disabled','--select-field-label-default','--select-field-label-focus','--select-field-label-disabled','--select-field-hint-default','--select-field-hint-error','--select-field-focus-ring-default','--select-chevron-default','--select-chevron-focus','--select-chevron-disabled','--select-icon-default','--select-icon-hover','--select-icon-focus','--select-icon-disabled','--select-icon-error','--select-dropdown-bg','--select-dropdown-border','--select-option-bg-default','--select-option-bg-hover','--select-option-bg-disabled','--select-option-text-default','--select-option-text-hover','--select-option-text-focus','--select-option-text-disabled','--select-option-check-icon-default','--select-option-check-icon-hover','--select-option-check-icon-focus','--select-option-check-icon-disabled'] },
  { label: 'dropdown/', tokens: ['--dropdown-panel-bg','--dropdown-panel-border','--dropdown-option-bg-default','--dropdown-option-bg-hover','--dropdown-option-bg-focus','--dropdown-option-bg-disabled','--dropdown-option-text-default','--dropdown-option-text-hover','--dropdown-option-text-focus','--dropdown-option-text-disabled','--dropdown-option-supporting-default','--dropdown-option-supporting-hover','--dropdown-option-supporting-focus','--dropdown-option-supporting-disabled','--dropdown-option-icon-default','--dropdown-option-icon-hover','--dropdown-option-icon-focus','--dropdown-option-icon-disabled','--dropdown-option-check-icon-default','--dropdown-option-check-icon-hover','--dropdown-option-check-icon-focus','--dropdown-option-check-icon-disabled'] },
  { label: 'sidebar/', tokens: ['--sidebar-container-bg','--sidebar-container-border','--sidebar-divider','--sidebar-item-bg-default','--sidebar-item-bg-hover','--sidebar-item-bg-active-closed','--sidebar-item-bg-active-opened','--sidebar-item-bg-disabled','--sidebar-item-text-default','--sidebar-item-text-hover','--sidebar-item-text-active','--sidebar-item-text-disabled','--sidebar-item-icon-default','--sidebar-item-icon-hover','--sidebar-item-icon-active','--sidebar-item-icon-disabled','--sidebar-item-chevron-default','--sidebar-item-chevron-hover','--sidebar-item-chevron-active','--sidebar-sub-item-bg-default','--sidebar-sub-item-bg-hover','--sidebar-sub-item-bg-active','--sidebar-sub-item-bg-disabled','--sidebar-sub-item-text-default','--sidebar-sub-item-text-hover','--sidebar-sub-item-text-active','--sidebar-sub-item-text-disabled','--sidebar-sub-item-icon-default','--sidebar-sub-item-icon-hover','--sidebar-sub-item-icon-active','--sidebar-sub-item-icon-disabled'] },
  { label: 'divider/', tokens: ['--divider-divider'] },

  /* ── Component sizing tokens ── */
  { label: 'component/button/', tokens: ['--component-button-height-sm','--component-button-height-md','--component-button-height-lg','--component-button-padding-x-sm','--component-button-padding-x-md','--component-button-padding-x-lg','--component-button-gap','--component-button-gap-sm','--component-button-gap-md','--component-button-gap-lg','--component-button-icon-size-sm','--component-button-icon-size-md','--component-button-icon-size-lg','--component-button-radius','--component-button-border-width','--component-button-focus-ring','--component-button-focus-width','--component-button-focus-offset'] },
  { label: 'component/input/', tokens: ['--component-input-height-sm','--component-input-height-md','--component-input-height-lg','--component-input-padding-x-sm','--component-input-padding-x-md','--component-input-padding-x-lg','--component-input-gap','--component-input-icon-size-sm','--component-input-icon-size-md','--component-input-icon-size-lg','--component-input-radius'] },
  { label: 'component/checkbox/', tokens: ['--component-checkbox-size-sm','--component-checkbox-size-md','--component-checkbox-radius-sm','--component-checkbox-radius-md','--component-checkbox-gap','--component-checkbox-label-gap','--component-checkbox-focus-ring-spread','--component-checkbox-icon-size-sm','--component-checkbox-icon-size-md','--component-checkbox-radio-dot-sm','--component-checkbox-radio-dot-md'] },
  { label: 'component/badge/', tokens: ['--component-badge-height-sm','--component-badge-height-md','--component-badge-padding-x-sm','--component-badge-padding-x-md','--component-badge-gap','--component-badge-dot-sm','--component-badge-dot-md','--component-badge-icon-size-sm','--component-badge-icon-size-md','--component-badge-radius'] },
  { label: 'component/toggle/', tokens: ['--component-toggle-track-width-sm','--component-toggle-track-width-md','--component-toggle-track-height-sm','--component-toggle-track-height-md','--component-toggle-thumb-size-sm','--component-toggle-thumb-size-md','--component-toggle-thumb-inset','--component-toggle-track-radius','--component-toggle-track-border-width','--component-toggle-gap-sm','--component-toggle-gap-md','--component-toggle-focus-ring-spread'] },
  { label: 'component/tab/', tokens: ['--component-tab-height','--component-tab-padding-x','--component-tab-gap','--component-tab-icon-size','--component-tab-badge-gap','--component-tab-indicator-height','--component-tab-radius','--component-tab-border-width','--component-tab-item-gap','--component-tab-container-padding'] },
  { label: 'component/table/', tokens: ['--component-table-header-height','--component-table-header-padding-x','--component-table-header-gap','--component-table-row-height','--component-table-cell-padding-x','--component-table-cell-gap','--component-table-border-width','--component-table-radius','--component-table-footer-height','--component-table-footer-padding-x','--component-table-checkbox-column-width'] },
  { label: 'component/modal/', tokens: ['--component-modal-width-sm','--component-modal-width-md','--component-modal-width-lg','--component-modal-radius','--component-modal-border-width','--component-modal-padding-x','--component-modal-header-padding-y','--component-modal-body-padding-y','--component-modal-footer-padding-y','--component-modal-header-gap','--component-modal-footer-gap','--component-modal-close-size','--component-modal-featured-icon-size','--component-modal-featured-icon-radius'] },
  { label: 'component/avatar/', tokens: ['--component-avatar-size-xs','--component-avatar-size-sm','--component-avatar-size-md','--component-avatar-size-lg','--component-avatar-size-xl','--component-avatar-size-2xl','--component-avatar-radius','--component-avatar-border-width','--component-avatar-status-size-sm','--component-avatar-status-size-md','--component-avatar-status-border-width'] },
  { label: 'component/pagination/', tokens: ['--component-pagination-button-size','--component-pagination-button-radius','--component-pagination-button-border-width','--component-pagination-gap','--component-pagination-container-height','--component-pagination-container-padding-x','--component-pagination-container-radius','--component-pagination-container-border-width'] },
  { label: 'component/toast/', tokens: ['--component-toast-padding-x','--component-toast-padding-y','--component-toast-gap','--component-toast-title-gap','--component-toast-action-gap','--component-toast-radius','--component-toast-border-width','--component-toast-icon-size','--component-toast-close-size'] },
  { label: 'component/select/', tokens: ['--component-select-field-height-sm','--component-select-field-height-md','--component-select-field-height-lg','--component-select-field-padding-x-sm','--component-select-field-padding-x-md','--component-select-field-padding-x-lg','--component-select-field-gap','--component-select-field-radius','--component-select-dropdown-radius','--component-select-dropdown-max-height'] },
  { label: 'component/dropdown/', tokens: ['--component-dropdown-panel-radius','--component-dropdown-panel-padding-y','--component-dropdown-panel-max-height','--component-dropdown-option-height-sm','--component-dropdown-option-height-md','--component-dropdown-option-height-lg','--component-dropdown-option-padding-x-sm','--component-dropdown-option-gap'] },
  { label: 'component/sidebar/', tokens: ['--component-sidebar-width','--component-sidebar-padding-x','--component-sidebar-padding-y','--component-sidebar-item-height','--component-sidebar-item-radius','--component-sidebar-item-padding-x','--component-sidebar-item-gap','--component-sidebar-item-icon-size','--component-sidebar-item-width','--component-sidebar-sub-item-height','--component-sidebar-sub-item-indent','--component-sidebar-sub-item-width'] },
  { label: 'component/breadcrumb/', tokens: ['--component-breadcrumb-gap-sm','--component-breadcrumb-icon-size-sm','--component-breadcrumb-separator-size-sm'] },
  { label: 'component/counter/', tokens: ['--component-counter-size-sm','--component-counter-size-md','--component-counter-padding-x','--component-counter-radius','--component-counter-border-width'] },

  /* ── Non-colour tokens ── */
  { label: 'spacing/', tokens: ['--spacing-0','--spacing-2','--spacing-4','--spacing-6','--spacing-8','--spacing-10','--spacing-12','--spacing-14','--spacing-16','--spacing-20','--spacing-24','--spacing-28','--spacing-32','--spacing-36','--spacing-40','--spacing-48','--spacing-56','--spacing-64','--spacing-80','--spacing-96','--spacing-120','--spacing-160'] },
  { label: 'radius/', tokens: ['--radius-0','--radius-2','--radius-4','--radius-6','--radius-8','--radius-12','--radius-16','--radius-20','--radius-24','--radius-32','--radius-xs','--radius-sm','--radius-md','--radius-lg','--radius-xl','--radius-full'] },
  { label: 'elevation/', tokens: ['--elevation-1','--elevation-2','--elevation-3','--elevation-4'] },
  { label: 'icon-size/', tokens: ['--icon-size-sm','--icon-size-md','--icon-size-lg'] },
  { label: 'typography/', tokens: ['--font-display','--font-body','--font-mono','--lh-tight','--lh-snug','--lh-normal','--lh-relaxed'] },
];

/* ── count total tokens ─── */
const TOTAL = GROUPS.reduce((s, g) => s + g.tokens.length, 0);

export default function exportPage() {
  /* Embed the groups definition as JSON so the runtime script can use it */
  const groupsJson = JSON.stringify(GROUPS.map(g => ({ label: g.label, tokens: g.tokens })));

  return pageHeader('Resources', 'CSS Export', `Ready-to-copy CSS custom properties, read live from the loaded stylesheet — always in sync with tokens.css.`, [
    { val: String(TOTAL), label: 'Tokens exported' },
    { val: String(GROUPS.length), label: 'Groups' },
    { val: 'Live', label: 'Sync status' },
  ]) + `<div class="page-body">

  <div class="doc-section">
    <div class="doc-section-header">
      <h2 class="doc-section-title">CSS Custom Properties</h2>
      <span class="doc-section-badge" id="exp-mode-badge">Light mode</span>
    </div>
    <p class="doc-section-desc" style="margin-bottom:16px">Values are read from <code>getComputedStyle(document.documentElement)</code> at render time — they always match whatever is in <code>tokens.css</code>. Switch the app's theme and revisit this page to get the dark-mode export.</p>

    <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
      <span id="exp-sync-dot" style="width:7px;height:7px;border-radius:50%;background:#16A34A;flex-shrink:0;box-shadow:0 0 0 3px rgba(22,163,74,0.18)"></span>
      <span id="exp-sync-label" style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-secondary)">Synced — reading live values from the loaded stylesheet</span>
    </div>

    <div class="code-block" style="position:relative">
      <button class="code-copy" id="exp-copy-btn" onclick="expCopy()">Copy</button>
      <pre id="exp-pre" style="font-family:var(--font-mono);font-size:11px;line-height:1.7;overflow:auto;max-height:600px;margin:0;padding:16px 0 16px 16px;white-space:pre">Generating…</pre>
    </div>
  </div>

  <script>
    (function() {
      var groups = ${groupsJson};
      var cs = getComputedStyle(document.documentElement);

      function readToken(name) {
        return cs.getPropertyValue(name).trim();
      }

      function pad(str, len) {
        while (str.length < len) str += ' ';
        return str;
      }

      var lines = [];
      lines.push('/* Iksir Design System — CSS Custom Properties');
      lines.push('   Source: tokens.css (read live via getComputedStyle)');
      lines.push('   Total: ${TOTAL} tokens across ${GROUPS.length} groups');
      lines.push('   ================================================= */');
      lines.push('');
      lines.push(':root {');

      groups.forEach(function(group) {
        lines.push('');
        lines.push('  /* ── ' + group.label + ' ' + '─'.repeat(Math.max(2, 44 - group.label.length)) + ' */');
        var maxLen = group.tokens.reduce(function(m, t) { return Math.max(m, t.length); }, 0);
        group.tokens.forEach(function(name) {
          var val = readToken(name);
          if (!val) val = '/* not found */';
          lines.push('  ' + pad(name + ':', maxLen + 2) + ' ' + val + ';');
        });
      });

      lines.push('');
      lines.push('}');

      var pre = document.getElementById('exp-pre');
      if (pre) pre.textContent = lines.join('\\n');

      /* update mode badge */
      var badge = document.getElementById('exp-mode-badge');
      if (badge) {
        var bg = readToken('--background-page');
        var isDark = bg && (bg.includes('1') || bg.includes('0') || bg.includes('2')) && !bg.includes('fb') && !bg.includes('ff') && !bg.includes('FA');
        badge.textContent = isDark ? 'Dark mode' : 'Light mode';
      }
    })();

    function expCopy() {
      var pre = document.getElementById('exp-pre');
      if (!pre) return;
      navigator.clipboard.writeText(pre.textContent).then(function() {
        var btn = document.getElementById('exp-copy-btn');
        if (btn) { btn.textContent = '✓ Copied'; setTimeout(function() { btn.textContent = 'Copy'; }, 2000); }
      });
    }
  </script>

  <div class="doc-section">
    <h2 class="doc-section-title" style="margin-bottom:12px">How to use</h2>
    <div class="grid-2">
      <div class="rule-card accent">
        <div class="rule-card-title">Paste into your global stylesheet</div>
        <div class="rule-card-body">Copy the output and paste it inside a <code>:root { }</code> block at the top of your project's global CSS file. All tokens become available as custom properties across your entire codebase.</div>
      </div>
      <div class="rule-card">
        <div class="rule-card-title">Reference by name in components</div>
        <div class="rule-card-body">Use tokens by name: <code>color: var(--brand-primary)</code>, <code>border-radius: var(--radius-lg)</code>. Never hardcode hex values — always go through a semantic token so the system stays mode-switchable.</div>
      </div>
      <div class="rule-card">
        <div class="rule-card-title">Export stays in sync automatically</div>
        <div class="rule-card-body">This page reads values from the live stylesheet at render time. Any change to <code>tokens.css</code> is instantly reflected here — no manual copy-paste between files required.</div>
      </div>
      <div class="rule-card accent">
        <div class="rule-card-title">Dark mode export</div>
        <div class="rule-card-body">Toggle the app to Dark mode using the theme switcher, then return to this page. The exported values will reflect the dark-mode token values, ready to wrap in a <code>[data-theme=dark]</code> selector.</div>
      </div>
    </div>
  </div>

  </div>`;
}
