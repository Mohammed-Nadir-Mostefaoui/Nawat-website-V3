import { pageHeader } from '../utils/render.js';

export default function responsive() {
  return pageHeader(
    'Platform',
    'Responsive Strategy',
    'How Iksir components adapt across mobile and desktop breakpoints — layout rules, column grids, and surface-specific guidance.'
  ) + `<div class="page-body">

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">The two-surface model</h2>
      </div>
      <p class="doc-section-desc">Iksir does not use a single responsive system that scales continuously. Instead it has two discrete surfaces — <strong>Mobile</strong> and <strong>Desktop</strong> — each with its own component set, layout grid, and navigation pattern. Tablet is not yet designed.</p>
      <div class="grid-2" style="margin-top:16px">
        <div class="rule-card accent">
          <div class="rule-card-title">Mobile (< 768px)</div>
          <div class="rule-card-body">Single-column layout. Bottom tab navigation. FAB for primary actions. Stack-push navigation for detail views. 16px side padding. Touch targets minimum 44px.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Desktop (≥ 1280px)</div>
          <div class="rule-card-body">Sidebar navigation (collapsible). Content area with 12-column grid at 1440px canvas. Hover states. Keyboard navigation. No FAB — primary actions in page headers.</div>
        </div>
      </div>
      <div class="rule-card" style="margin-top:12px">
        <div class="rule-card-title">Tablet (768px–1279px) — not yet designed</div>
        <div class="rule-card-body">This range is a placeholder. When tablet design begins, it will adapt mobile navigation patterns (bottom bar or side drawer) with a 2-column content grid. Do not attempt to design for this range before guidance is published here.</div>
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Mobile layout grid</h2>
      </div>
      <p class="doc-section-desc">Mobile uses a simple fluid layout — not a fixed column grid. Content fills available width with fixed side padding.</p>
      <div style="margin-top:16px;border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden">
        <div style="display:grid;grid-template-columns:1fr 1fr 2fr;background:var(--background-subtle);padding:10px 16px;gap:12px">
          ${['Property','Value','Notes'].map(h => `<div style="font-size:11px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em">${h}</div>`).join('')}
        </div>
        ${[
          ['Canvas width','390px','Design at this width. Content adapts to actual device width.'],
          ['Side padding','16px each side','Inner margin for content. Never reduce below 12px.'],
          ['Content width','358px','390 - 32 = 358px usable content area on design canvas.'],
          ['Column structure','1 column (fluid)','Mobile is single-column by default.'],
          ['2-column exception','≥ 180px per column','Allowed for short-form inputs side by side (e.g., qty + unit).'],
          ['Card gap','12px','Vertical gap between stacked cards or list rows.'],
          ['Section gap','24px','Vertical gap between logical content sections.'],
        ].map(([prop, value, notes], i) => `
        <div style="display:grid;grid-template-columns:1fr 1fr 2fr;padding:10px 16px;gap:12px;${i < 6 ? 'border-top:1px solid var(--border-subtle)' : ''}">
          <div style="font-size:12px;font-weight:600;color:var(--content-primary)">${prop}</div>
          <div style="font-family:var(--font-mono);font-size:11px;color:var(--brand-primary)">${value}</div>
          <div style="font-size:12px;color:var(--content-secondary)">${notes}</div>
        </div>`).join('')}
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Desktop layout grid</h2>
      </div>
      <p class="doc-section-desc">Desktop uses a 12-column grid at a 1440px canvas. The sidebar occupies a fixed slice; content fills the remainder.</p>
      <div style="margin-top:16px;border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden">
        <div style="display:grid;grid-template-columns:1fr 1fr 2fr;background:var(--background-subtle);padding:10px 16px;gap:12px">
          ${['Property','Value','Notes'].map(h => `<div style="font-size:11px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em">${h}</div>`).join('')}
        </div>
        ${[
          ['Canvas width','1440px','Design canvas. Minimum supported desktop width: 1280px.'],
          ['Sidebar width','240px (expanded)','Collapses to 64px (icon-only). Controlled by user preference.'],
          ['Content area','max-width: 1140px','With 240px sidebar and 60px padding.'],
          ['Columns','12','Standard 12-col grid in the content area.'],
          ['Column gap','24px','Gutter between columns.'],
          ['Content padding','32px each side','Outer padding inside the content area.'],
        ].map(([prop, value, notes], i) => `
        <div style="display:grid;grid-template-columns:1fr 1fr 2fr;padding:10px 16px;gap:12px;${i < 5 ? 'border-top:1px solid var(--border-subtle)' : ''}">
          <div style="font-size:12px;font-weight:600;color:var(--content-primary)">${prop}</div>
          <div style="font-family:var(--font-mono);font-size:11px;color:var(--brand-primary)">${value}</div>
          <div style="font-size:12px;color:var(--content-secondary)">${notes}</div>
        </div>`).join('')}
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Cross-surface component rules</h2>
      </div>
      <p class="doc-section-desc">Components that exist on both surfaces have surface-specific properties.</p>
      <div class="grid-2" style="margin-top:16px">
        <div class="rule-card accent">
          <div class="rule-card-title">Do not share mobile components on desktop</div>
          <div class="rule-card-body">Bottom Tab Nav, FAB, Bottom Sheet, and Numeric Keypad are mobile-only. They have no desktop equivalent. Do not attempt to render them at desktop breakpoints — use the appropriate desktop pattern instead.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Shared tokens, different values</div>
          <div class="rule-card-body">Both surfaces use the same semantic token names (e.g., <code>component/button/height</code>). The mobile collection resolves to 44px; the desktop collection resolves to 36px. Switching collection = surface change.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Typography scale is identical</div>
          <div class="rule-card-body">Mobile and desktop share the same type scale tokens (Display, Heading, Body, Caption). Font sizes do not change per breakpoint. Adjust layout and density, not type size.</div>
        </div>
        <div class="rule-card accent">
          <div class="rule-card-title">Colour tokens are fully shared</div>
          <div class="rule-card-body">Every colour token (including mobile-specific ones like <code>nav/tab/*</code>) exists in both Light and Dark mode in a single variable collection. Surface (mobile vs desktop) does not affect colour. Theme (light vs dark) does.</div>
        </div>
      </div>
    </div>

  </div>`;
}
