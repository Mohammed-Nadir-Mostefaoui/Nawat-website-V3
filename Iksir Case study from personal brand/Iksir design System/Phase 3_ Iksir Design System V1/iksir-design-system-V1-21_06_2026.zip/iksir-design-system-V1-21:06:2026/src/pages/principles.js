import { pageHeader } from '../utils/render.js';

const PRINCIPLES = [
  {
    n: '01',
    title: 'Token-first',
    body: 'Every visual decision — color, spacing, radius — is a named token. Components never hardcode values. This makes the system maintainable, themeable, and safe to refactor at any scale.',
    color: '#430098',
    bg: '#F7F4FB',
    border: '#D9CCEA',
    visual: `
      <div style="display:flex;flex-direction:column;gap:6px">
        ${[['brand/primary','#430098'],['content/primary','#191919'],['radius/lg','8px'],['spacing/16','16px']].map(([k,v])=>`
        <div style="display:flex;align-items:center;gap:8px">
          <div style="width:14px;height:14px;border-radius:3px;background:${v === '#430098' ? '#430098' : v === '#191919' ? '#191919' : 'transparent'};border:${['8px','16px'].includes(v)?'1.5px dashed #D9CCEA':'none'};flex-shrink:0"></div>
          <code style="font-family:monospace;font-size:10px;color:#430098;background:#EDE8F8;padding:1px 5px;border-radius:4px">${k}</code>
          <span style="font-family:monospace;font-size:10px;color:#6E6E73;margin-left:auto">${v}</span>
        </div>`).join('')}
        <div style="margin-top:4px;padding:6px 8px;border-radius:7px;background:rgba(67,0,152,0.06);border:1px dashed #C7B3E0;font-family:monospace;font-size:10px;color:#6933AD;text-align:center">vs. hardcoded <span style="text-decoration:line-through;opacity:.5">#430098</span></div>
      </div>`,
  },
  {
    n: '02',
    title: 'Semantic over primitive',
    body: 'Use brand/primary, not #430098. Semantic names express intent, not implementation. When the brand colour changes, one primitive update ripples everywhere automatically.',
    color: '#0550AE',
    bg: '#EFF6FF',
    border: '#BFDBFE',
    visual: `
      <div style="display:flex;flex-direction:column;gap:8px">
        <div style="display:flex;align-items:stretch;gap:0;border-radius:8px;overflow:hidden;border:1px solid #BFDBFE">
          <div style="flex:1;padding:10px;background:#EFF6FF">
            <div style="font-family:monospace;font-size:9px;font-weight:700;color:#0550AE;margin-bottom:6px;text-transform:uppercase;letter-spacing:.05em">Primitives</div>
            ${[['purple-100','#430098'],['purple-90','#561AA2'],['purple-80','#6933AD']].map(([n,h])=>`
            <div style="display:flex;align-items:center;gap:5px;margin-bottom:3px">
              <div style="width:10px;height:10px;border-radius:2px;background:${h}"></div>
              <span style="font-family:monospace;font-size:9px;color:#1e40af">${n}</span>
            </div>`).join('')}
          </div>
          <div style="width:1px;background:#BFDBFE"></div>
          <div style="flex:1;padding:10px;background:#fff">
            <div style="font-family:monospace;font-size:9px;font-weight:700;color:#0550AE;margin-bottom:6px;text-transform:uppercase;letter-spacing:.05em">Semantic</div>
            ${[['brand/primary','→ purple-100'],['brand/hover','→ purple-90'],['brand/active','→ purple-80']].map(([n,ref])=>`
            <div style="margin-bottom:3px">
              <span style="font-family:monospace;font-size:9px;color:#0550AE;font-weight:600">${n}</span><br>
              <span style="font-family:monospace;font-size:8px;color:#93C5FD">${ref}</span>
            </div>`).join('')}
          </div>
        </div>
        <div style="font-family:Inter,sans-serif;font-size:10px;color:#6E6E73;text-align:center">Change the primitive → everything updates</div>
      </div>`,
  },
  {
    n: '03',
    title: 'Two modes from day one',
    body: 'Light and Dark are not an afterthought. Every semantic token carries both values. The moment a component uses brand/primary instead of a hex, it automatically supports both modes.',
    color: '#16A34A',
    bg: '#F0FDF4',
    border: '#BBF7D0',
    visual: `
      <div style="display:flex;gap:6px">
        <div style="flex:1;border-radius:10px;overflow:hidden;border:1px solid #BBF7D0">
          <div style="background:#fff;padding:8px 10px">
            <div style="font-family:monospace;font-size:9px;font-weight:700;color:#16A34A;margin-bottom:6px">☀ Light</div>
            <div style="display:flex;flex-direction:column;gap:4px">
              <div style="height:8px;border-radius:3px;background:#430098;width:70%"></div>
              <div style="height:6px;border-radius:3px;background:#191919;width:90%"></div>
              <div style="height:6px;border-radius:3px;background:#E1E1E1;width:80%"></div>
              <div style="margin-top:4px;height:24px;border-radius:6px;background:#430098;display:flex;align-items:center;justify-content:center">
                <div style="height:5px;width:28px;border-radius:2px;background:#fff"></div>
              </div>
            </div>
          </div>
        </div>
        <div style="flex:1;border-radius:10px;overflow:hidden;border:1px solid #166534">
          <div style="background:#111;padding:8px 10px">
            <div style="font-family:monospace;font-size:9px;font-weight:700;color:#4ade80;margin-bottom:6px">🌙 Dark</div>
            <div style="display:flex;flex-direction:column;gap:4px">
              <div style="height:8px;border-radius:3px;background:#B774FF;width:70%"></div>
              <div style="height:6px;border-radius:3px;background:#F5F5F5;width:90%"></div>
              <div style="height:6px;border-radius:3px;background:#333;width:80%"></div>
              <div style="margin-top:4px;height:24px;border-radius:6px;background:#B774FF;display:flex;align-items:center;justify-content:center">
                <div style="height:5px;width:28px;border-radius:2px;background:#000"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div style="margin-top:6px;font-family:Inter,sans-serif;font-size:10px;color:#6E6E73;text-align:center">Same tokens · one mode switch</div>`,
  },
  {
    n: '04',
    title: 'Speed over perfection',
    body: 'Small team, fast product. Tokens cover 95% of cases clearly. Escape hatches exist for the 5% that need deviation — the system is a tool, not a cage.',
    color: '#B45309',
    bg: '#FFF7ED',
    border: '#FED7AA',
    visual: `
      <div style="display:flex;flex-direction:column;gap:6px">
        <div style="display:flex;align-items:center;gap:8px">
          <div style="flex:1;height:8px;border-radius:20px;background:linear-gradient(90deg,#16A34A 0%,#16A34A 70%,#E5E7EB 70%)"></div>
          <span style="font-family:monospace;font-size:10px;color:#B45309;font-weight:700;flex-shrink:0">95%</span>
        </div>
        <div style="font-family:Inter,sans-serif;font-size:10px;color:#6E6E73">Covered by tokens — fast, consistent, zero decisions needed.</div>
        <div style="margin-top:4px;display:flex;align-items:center;gap:8px">
          <div style="flex:1;height:8px;border-radius:20px;background:linear-gradient(90deg,#B45309 0%,#B45309 5%,#E5E7EB 5%)"></div>
          <span style="font-family:monospace;font-size:10px;color:#B45309;font-weight:700;flex-shrink:0">5%</span>
        </div>
        <div style="font-family:Inter,sans-serif;font-size:10px;color:#6E6E73">Escape hatches — documented deviation, never silent hardcoding.</div>
        <div style="margin-top:6px;padding:6px 10px;border-radius:7px;background:#FFF7ED;border:1px solid #FED7AA;font-family:monospace;font-size:10px;color:#B45309">/* intentional override — one-off promo banner */</div>
      </div>`,
  },
  {
    n: '05',
    title: 'Scale names, not component names',
    body: 'radius/lg not radius/button. Scale names stay neutral and reusable across any component. Component-named tokens create coupling and force token proliferation.',
    color: '#7C3AED',
    bg: '#F5F3FF',
    border: '#DDD6FE',
    visual: `
      <div style="display:flex;flex-direction:column;gap:6px">
        <div style="padding:8px 10px;border-radius:8px;background:#FFF1F2;border:1px solid #FECDD3">
          <div style="font-family:monospace;font-size:9px;font-weight:700;color:#D8192C;margin-bottom:5px">✗ Component-named</div>
          ${['--radius-button: 8px','--radius-card: 8px','--radius-input: 8px','--radius-modal: 12px'].map(t=>`<div style="font-family:monospace;font-size:9px;color:#E87580;margin-bottom:1px">${t}</div>`).join('')}
          <div style="font-family:Inter,sans-serif;font-size:9px;color:#E87580;margin-top:4px">4 tokens, same value — duplicated</div>
        </div>
        <div style="padding:8px 10px;border-radius:8px;background:#F5F3FF;border:1px solid #DDD6FE">
          <div style="font-family:monospace;font-size:9px;font-weight:700;color:#7C3AED;margin-bottom:5px">✓ Scale-named</div>
          ${['--radius-lg: 8px','--radius-xl: 12px'].map(t=>`<div style="font-family:monospace;font-size:9px;color:#7C3AED;margin-bottom:1px">${t}</div>`).join('')}
          <div style="font-family:Inter,sans-serif;font-size:9px;color:#7C3AED;margin-top:4px">2 tokens, used anywhere</div>
        </div>
      </div>`,
  },
  {
    n: '06',
    title: 'Document everything',
    body: 'Every token has a description. Every component has a prop table, token map, and do/don\'t. Undocumented decisions get reinvented incorrectly by the next person who touches them.',
    color: '#D8192C',
    bg: '#FFF1F2',
    border: '#FECDD3',
    visual: `
      <div style="display:flex;flex-direction:column;gap:5px">
        ${[
          ['Token','Name, value, usage, and Figma variable path','✓'],
          ['Component','Props, states, variants, token map','✓'],
          ['Do / Don\'t','Visual rule with concrete example','✓'],
          ['Changelog','Every breaking change recorded','✓'],
        ].map(([label, desc, check])=>`
        <div style="display:flex;align-items:flex-start;gap:8px;padding:6px 8px;border-radius:6px;background:rgba(216,25,44,0.04);border:1px solid #FECDD3">
          <span style="width:14px;height:14px;border-radius:50%;background:#D8192C;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px">
            <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
          </span>
          <div>
            <div style="font-family:Inter,sans-serif;font-size:10px;font-weight:600;color:#D8192C">${label}</div>
            <div style="font-family:Inter,sans-serif;font-size:9px;color:#6E6E73;line-height:1.4">${desc}</div>
          </div>
        </div>`).join('')}
      </div>`,
  },
];

export default function principles() {
  return `<div style="padding:40px 48px 0">
    <div style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:20px;background:#F7F4FB;border:1px solid #D9CCEA;font-family:Inter,sans-serif;font-size:11px;font-weight:600;color:#430098;margin-bottom:16px">
      <span style="width:6px;height:6px;border-radius:50%;background:#430098;display:inline-block"></span>
      Get Started
    </div>
    <h1 style="font-family:var(--font-display);font-size:36px;font-weight:900;color:var(--content-primary);letter-spacing:-1.2px;line-height:1.05;margin:0 0 12px">Six principles.<br>Every decision follows them.</h1>
    <p style="font-family:Inter,sans-serif;font-size:15px;color:var(--content-secondary);line-height:1.65;max-width:520px;margin:0 0 0">These aren't aspirational guidelines — they're the constraints behind every token name, every component API, and every pattern in the system.</p>
  </div>

  <div class="page-body" style="padding-top:32px">

  <style>
    @keyframes pr-card-in { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
    .pr-card { animation: pr-card-in 0.35s ease both; }
  </style>

  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px">
    ${PRINCIPLES.map((p, i) => `
    <div class="pr-card" style="animation-delay:${i * 0.06}s;border-radius:18px;overflow:hidden;border:1px solid ${p.border};background:${p.bg}">

      <!-- card header -->
      <div style="padding:22px 22px 16px;border-bottom:1px solid ${p.border}">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:12px">
          <div>
            <span style="font-family:var(--font-mono);font-size:10px;font-weight:700;color:${p.color};opacity:.6;letter-spacing:.08em">${p.n}</span>
            <h3 style="font-family:var(--font-display);font-size:19px;font-weight:800;color:${p.color};letter-spacing:-.5px;line-height:1.1;margin:2px 0 0">${p.title}</h3>
          </div>
          <div style="width:36px;height:36px;border-radius:10px;background:${p.color};display:flex;align-items:center;justify-content:center;flex-shrink:0;opacity:.15;font-family:var(--font-mono);font-size:14px;font-weight:900;color:${p.color}"></div>
        </div>
        <p style="font-family:Inter,sans-serif;font-size:13px;color:var(--content-secondary);line-height:1.65;margin:0">${p.body}</p>
      </div>

      <!-- visual area -->
      <div style="padding:16px 20px">
        ${p.visual}
      </div>

    </div>`).join('')}
  </div>

  <!-- bottom quote -->
  <div style="margin-top:48px;padding:32px 40px;border-radius:18px;background:linear-gradient(135deg,#F7F4FB 0%,#EFF6FF 100%);border:1px solid #D9CCEA;position:relative;overflow:hidden">
    <div style="position:absolute;top:-20px;left:24px;font-family:var(--font-display);font-size:120px;font-weight:900;color:#430098;opacity:.05;line-height:1;pointer-events:none">"</div>
    <div style="position:relative">
      <p style="font-family:var(--font-display);font-size:20px;font-weight:700;color:var(--content-primary);line-height:1.45;letter-spacing:-.3px;margin:0 0 16px;max-width:600px">A design system is a product for your product. It should enable speed without sacrificing consistency — and scale without requiring constant maintenance.</p>
      <div style="display:flex;align-items:center;gap:10px">
        <div style="width:28px;height:28px;border-radius:50%;background:#430098;display:flex;align-items:center;justify-content:center;font-family:Inter,sans-serif;font-size:10px;font-weight:700;color:#fff">IK</div>
        <span style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-tertiary)">Iksir Design System · v1.0</span>
      </div>
    </div>
  </div>

  </div>`;
}
