import { pageHeader } from '../utils/render.js';

/* ── callout badge ──────────────────────────────────────────── */
function badge(n) {
  return `<span style="display:inline-flex;align-items:center;justify-content:center;width:19px;height:19px;border-radius:50%;background:#430098;color:#fff;font-family:Inter,sans-serif;font-size:10px;font-weight:700;flex-shrink:0;vertical-align:middle;line-height:1">${n}</span>`;
}

/* ── callout legend grid ────────────────────────────────────── */
function legend(items) {
  return `<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px;margin-top:16px">
    ${items.map(([n, comp, desc]) => `
      <div style="display:flex;gap:10px;align-items:flex-start;padding:10px 12px;border-radius:8px;border:1px solid #EBEBEB;background:#FAFAFA">
        ${badge(n)}
        <div>
          <div style="font-family:Inter,sans-serif;font-size:11px;font-weight:700;color:#191919;margin-bottom:2px">${comp}</div>
          <div style="font-family:Inter,sans-serif;font-size:11px;color:#757575;line-height:1.4">${desc}</div>
        </div>
      </div>`).join('')}
  </div>`;
}

/* ── screen label ───────────────────────────────────────────── */
function screenLabel(step, title, desc) {
  return `<div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
    <div style="display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:50%;background:#430098;color:#fff;font-family:Inter,sans-serif;font-size:12px;font-weight:700;flex-shrink:0">${step}</div>
    <div>
      <div style="font-family:var(--font-display);font-size:14px;font-weight:700;color:#191919;margin-bottom:2px">${title}</div>
      <div style="font-family:Inter,sans-serif;font-size:12px;color:#757575">${desc}</div>
    </div>
  </div>`;
}

/* ── screenshot frame ───────────────────────────────────────── */
function screen(src, alt) {
  return `<div style="border-radius:12px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,0.10);border:1px solid #E0E0E0">
    <img src="${src}" alt="${alt}" style="display:block;width:100%;height:auto">
  </div>`;
}

/* ── component pill ─────────────────────────────────────────── */
function compPill(name, page) {
  return `<span onclick="navigate('${page}')" style="display:inline-flex;align-items:center;gap:4px;padding:3px 9px;border-radius:9999px;background:#F7F4FB;border:1px solid #D9CCEA;font-family:Inter,sans-serif;font-size:11px;font-weight:600;color:#430098;cursor:pointer" onmouseenter="this.style.background='#ECE6F5'" onmouseleave="this.style.background='#F7F4FB'">${name}</span>`;
}

/* ════════════════════════════════════════════════════════════
   PAGE EXPORT
════════════════════════════════════════════════════════════ */
export default function templates() {
  return pageHeader(
    'Patterns',
    'Templates',
    'Real ERP screens from the Iksir Référentiel module — showing how design system components combine in production to form complete user flows.'
  ) + `<div class="page-body">

    <!-- ── intro ──────────────────────────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Context</h2>
      </div>
      <p class="doc-section-desc">These screens are from the <strong>Référentiel → Produits</strong> module of Iksir — the inventory master data section where users manage products and their sub-components (composants). The two flows documented here cover a complete create-and-link journey and involve most of the component library.</p>
      <div class="grid-2" style="margin-top:16px">
        <div class="rule-card accent">
          <div class="rule-card-title">Products</div>
          <div class="rule-card-body">Listing, searching, and creating products in the ERP catalogue. Covers table patterns, form layout, and validation states.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Composants</div>
          <div class="rule-card-body">Linking sub-components (nested products) to a parent product via a modal. Covers empty states, modal flow, and success feedback.</div>
        </div>
      </div>
    </div>

    <!-- ══════════════════════════════════════════════════════
         PRODUCTS SECTION
    ══════════════════════════════════════════════════════ -->
    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Products</h2>
        <span class="doc-section-badge">2 screens</span>
      </div>
      <p class="doc-section-desc">The products module opens on a searchable data table. Clicking "+ Créer" transitions to the creation form — a collapsible-section layout that progressively reveals complexity.</p>

      <!-- Screen 1 -->
      <div style="margin-top:32px">
        ${screenLabel('1', 'Liste des produits', 'The default landing screen — a paginated data table with search and quick actions.')}
        ${screen('/screenshots/screen-01-products-list.png', 'Liste des produits')}
        ${legend([
          ['1', 'Navigation sidebar', 'Collapsible sections with active state. Référentiel is expanded; Produits sub-item is active (purple, semibold).'],
          ['2', 'Breadcrumb', 'Two-level trail: module › sub-module. Last crumb is purple to mark current location.'],
          ['3', 'Search input', 'Leading-icon input variant. Placeholder describes what is searchable.'],
          ['4', 'Button — Primary', '"+ Créer" opens the creation form. Only one primary action visible at a time.'],
          ['5', 'Table', 'Headers with sort indicators. Cells: plain text (code, name, price, qty), colored text for unit, icon actions (link + delete).'],
          ['6', 'Pagination', 'Numeric page strip with per-page select and prev/next controls. Active page uses brand border.'],
        ])}
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:16px">
          <span style="font-family:Inter,sans-serif;font-size:11px;color:#A3A3A3;align-self:center">Components used →</span>
          ${compPill('Table', 'table')}
          ${compPill('Pagination', 'pagination')}
          ${compPill('Input', 'input')}
          ${compPill('Button', 'button')}
          ${compPill('Breadcrumb', 'breadcrumb')}
        </div>
      </div>

      <div class="doc-divider"></div>

      <!-- Screen 2 -->
      <div style="margin-top:32px">
        ${screenLabel('2', 'Créer un produit — Informations de base', 'The creation form uses collapsible sections to group fields. The save button stays disabled until required fields are filled.')}
        ${screen('/screenshots/screen-02-products-create.png', 'Créer un produit')}
        ${legend([
          ['1', 'Back arrow + page title', 'Back arrow returns to the list without a modal confirmation at this stage.'],
          ['2', 'Button — Primary (disabled)', 'Sauvegarder is disabled until all required fields pass validation. Uses brand/primary-disabled token.'],
          ['3', 'Collapsible section header', 'Accordion-style sections using chevron. "Informations de base" is expanded by default.'],
          ['4', 'Input — filled state', 'Nom de produit filled with a long product name, stretches to full width.'],
          ['5', 'Select — filled', 'Catégorie, Comportement, Unité de mesure all filled, in a 3-column grid.'],
          ['6', 'Image upload area', 'Dashed-border dropzone. Shows placeholder when empty.'],
          ['7', 'Checkbox group', 'Vendable, Commandable, Retournable — independent boolean flags in horizontal layout.'],
          ['8', 'Collapsed sections', 'Composants and Palettisation collapsed to reduce visual load.'],
        ])}
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:16px">
          <span style="font-family:Inter,sans-serif;font-size:11px;color:#A3A3A3;align-self:center">Components used →</span>
          ${compPill('Input', 'input')}
          ${compPill('Select', 'select')}
          ${compPill('Checkbox', 'checkbox')}
          ${compPill('Button', 'button')}
        </div>
      </div>
    </div>

    <!-- ══════════════════════════════════════════════════════
         COMPOSANTS SECTION
    ══════════════════════════════════════════════════════ -->
    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Components</h2>
        <span class="doc-section-badge">3 screens</span>
      </div>
      <p class="doc-section-desc">The Composants section lets users link existing products as sub-components with a quantity. The flow is a three-step micro-interaction: expand → modal → confirmation.</p>

      <!-- Screen 3 -->
      <div style="margin-top:32px">
        ${screenLabel('3', 'Composants — empty state', 'When expanded with no linked composants, the section shows a dashed "+ Ajouter un composant" affordance.')}
        ${screen('/screenshots/screen-03-composants-empty.png', 'Composants empty state')}
        ${legend([
          ['1', 'Collapsible section — expanded', 'Same accordion pattern as Informations de base. User manually expands to review or add composants.'],
          ['2', 'Dashed add button', 'Full-width dashed-border button acts as an empty-state affordance — more subtle than a solid primary since this action is secondary.'],
        ])}
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:16px">
          <span style="font-family:Inter,sans-serif;font-size:11px;color:#A3A3A3;align-self:center">Components used →</span>
          ${compPill('Button — Ghost', 'button')}
        </div>
      </div>

      <div class="doc-divider"></div>

      <!-- Screen 4 -->
      <div style="margin-top:32px">
        ${screenLabel('4', 'Ajouter un composant — modal', 'Clicking the dashed button opens a focused modal. Background dims. The form collects a product reference and quantity.')}
        ${screen('/screenshots/screen-04-composants-modal.png', 'Ajouter un composant modal')}
        ${legend([
          ['1', 'Modal overlay', 'Semi-transparent dark overlay scopes attention to the dialog. Click-outside closes.'],
          ['2', 'Modal — structure', 'Header (title + close ×), scrollable body, sticky footer with action buttons.'],
          ['3', 'Select — Produit', 'Searchable select for finding a product by name.'],
          ['4', 'Input — Quantité', 'Required numeric field. Red asterisk communicates requirement.'],
          ['5', 'Button — Cancel + Ajouter', 'Cancel uses secondary-gray (low emphasis). Ajouter is primary but disabled until both fields are filled.'],
        ])}
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:16px">
          <span style="font-family:Inter,sans-serif;font-size:11px;color:#A3A3A3;align-self:center">Components used →</span>
          ${compPill('Modal', 'modal')}
          ${compPill('Select', 'select')}
          ${compPill('Input', 'input')}
          ${compPill('Button', 'button')}
        </div>
      </div>

      <div class="doc-divider"></div>

      <!-- Screen 5 -->
      <div style="margin-top:32px">
        ${screenLabel('5', 'After adding — chip + toast', 'On confirm, the modal closes, the composant appears as a chip, and a success toast slides in from the bottom-right.')}
        ${screen('/screenshots/screen-05-composants-added.png', 'Composant added with toast')}
        ${legend([
          ['1', 'Composant chip', 'Product thumbnail + name + quantity. × button removes it. Scales as more composants are added.'],
          ['2', '+ add button', 'After the first composant, the dashed full-width button becomes a compact icon button.'],
          ['3', 'Toast — success', 'Auto-dismisses after 3 s. Dark background provides contrast. Green check signals success without reading the label.'],
          ['4', 'Button — Primary (enabled)', 'With at least one composant the form is valid — Sauvegarder transitions from disabled to active brand purple.'],
        ])}
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:16px">
          <span style="font-family:Inter,sans-serif;font-size:11px;color:#A3A3A3;align-self:center">Components used →</span>
          ${compPill('Toast', 'toast')}
          ${compPill('Button', 'button')}
          ${compPill('Badge', 'badge')}
        </div>
      </div>
    </div>

    <!-- ── design decisions ────────────────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Key design decisions</h2>
      </div>
      <p class="doc-section-desc">Recurring patterns across both flows that reflect the design system's principles.</p>
      <div class="grid-2">
        <div class="rule-card accent">
          <div class="rule-card-title">Progressive disclosure via collapsible sections</div>
          <div class="rule-card-body">The creation form has three sections. Only the first is expanded by default — this reduces perceived complexity without hiding critical fields.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Disabled save until valid</div>
          <div class="rule-card-body">The primary action button stays disabled (brand/primary-disabled token) until all required fields are filled, preventing premature submission.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Modal for contextual sub-tasks</div>
          <div class="rule-card-body">Adding a composant is a sub-task within the product creation flow. A modal keeps the user in context without losing unsaved form state.</div>
        </div>
        <div class="rule-card accent">
          <div class="rule-card-title">Toast for non-blocking feedback</div>
          <div class="rule-card-body">Success feedback uses a toast (auto-dismiss, bottom-right) rather than an inline banner — the form stays visible and usable immediately after confirmation.</div>
        </div>
      </div>
    </div>

  </div>`;
}
