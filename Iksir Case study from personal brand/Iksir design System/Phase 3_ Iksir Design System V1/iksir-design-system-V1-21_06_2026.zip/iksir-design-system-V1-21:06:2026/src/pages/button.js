import { pageHeader } from '../utils/render.js';

export default function button() {
  return pageHeader('Components', 'Button', 'The foundational interactive element. 8 hierarchies × 3 sizes × 4 icon types × 5 states — 450 variants. Fully token-bound. Heights: 32/36/40px.') + `<div class="page-body">


    <!-- HIERARCHY -->
    <div class="doc-section">
      <h2 class="doc-section-title">Hierarchy</h2>
      <p class="doc-section-desc">Eight levels from highest to lowest emphasis — each maps to a distinct token set. Only one Primary should be visible per screen at a time.</p>

    <div class="doc-variant-block">
      <div class="btn-section-toolbar">
        <h3 class="doc-variant-title">Primary</h3>
      </div>
      <p class="doc-section-desc">The highest-emphasis action. Use for the single most important action on a screen — Save, Submit, Create. Only one primary button should be visible at a time.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Primary button</span>
          <div class="inp-demo-controls">
            <span class="inp-demo-meta">State</span>
            <select class="inp-state-select" id="sel-btn-primary" onchange="btnState('primary',this.value)"><option value="Default"selected>Default</option><option value="Hover">Hover</option><option value="Active">Active</option><option value="Focused">Focused</option><option value="Disabled">Disabled</option></select>
          </div>
        </div>
        <div class="inp-demo-stage" id="stage-btn-primary">
          <div style="display:flex;align-items:center;justify-content:center;min-height:60px">
            <button id="btn-primary" class="btn btn-primary" onclick="this.blur()">Save changes</button>
          </div>
        </div>
        <div class="btn-tokens-strip"><div class="btn-token-item"><div class="btn-token-swatch" style="background:#430098;"></div><div><div class="btn-token-name">brand/primary</div><div class="btn-token-label">Background</div></div></div><div class="btn-token-item"><div class="btn-token-swatch" style="background:#561AA2;"></div><div><div class="btn-token-name">brand/primary-hover</div><div class="btn-token-label">Hover</div></div></div><div class="btn-token-item"><div class="btn-token-swatch" style="background:#FFFFFF;border:1px solid #E1E1E1;"></div><div><div class="btn-token-name">content/on-brand</div><div class="btn-token-label">Text</div></div></div><div class="btn-token-item"><div class="btn-token-swatch" style="background:#6933AD;"></div><div><div class="btn-token-name">border/focus</div><div class="btn-token-label">Focus ring</div></div></div></div>
      </div>
    </div>

    <div class="doc-variant-block">
      <div class="btn-section-toolbar">
        <h3 class="doc-variant-title">Secondary color</h3>
      </div>
      <p class="doc-section-desc">Medium-emphasis action. Pairs with primary for secondary actions — Cancel, Edit, View details. Uses brand color as border and text.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Secondary color button</span>
          <div class="inp-demo-controls">
            <span class="inp-demo-meta">State</span>
            <select class="inp-state-select" id="sel-btn-secondary" onchange="btnState('secondary',this.value)"><option value="Default"selected>Default</option><option value="Hover">Hover</option><option value="Active">Active</option><option value="Focused">Focused</option><option value="Disabled">Disabled</option></select>
          </div>
        </div>
        <div class="inp-demo-stage" id="stage-btn-secondary">
          <div style="display:flex;align-items:center;justify-content:center;min-height:60px">
            <button id="btn-secondary" class="btn btn-secondary" onclick="this.blur()">View details</button>
          </div>
        </div>
        <div class="btn-tokens-strip"><div class="btn-token-item"><div class="btn-token-swatch" style="background:#430098;"></div><div><div class="btn-token-name">brand/primary</div><div class="btn-token-label">Border</div></div></div><div class="btn-token-item"><div class="btn-token-swatch" style="background:#430098;"></div><div><div class="btn-token-name">brand/primary</div><div class="btn-token-label">Text</div></div></div><div class="btn-token-item"><div class="btn-token-swatch" style="background:#ECE6F5;"></div><div><div class="btn-token-name">brand/primary-muted</div><div class="btn-token-label">Hover bg</div></div></div></div>
      </div>
    </div>

    <div class="doc-variant-block">
      <div class="btn-section-toolbar">
        <h3 class="doc-variant-title">Secondary gray</h3>
      </div>
      <p class="doc-section-desc">Medium-emphasis action in a neutral tone. Use when the brand color would compete with nearby elements.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Secondary gray button</span>
          <div class="inp-demo-controls">
            <span class="inp-demo-meta">State</span>
            <select class="inp-state-select" id="sel-btn-secondary-gray" onchange="btnState('secondary-gray',this.value)"><option value="Default"selected>Default</option><option value="Hover">Hover</option><option value="Active">Active</option><option value="Focused">Focused</option><option value="Disabled">Disabled</option></select>
          </div>
        </div>
        <div class="inp-demo-stage" id="stage-btn-secondary-gray">
          <div style="display:flex;align-items:center;justify-content:center;min-height:60px">
            <button id="btn-secondary-gray" class="btn btn-secondary-gray" onclick="this.blur()">Cancel</button>
          </div>
        </div>
        <div class="btn-tokens-strip"><div class="btn-token-item"><div class="btn-token-swatch" style="background:#E1E1E1;"></div><div><div class="btn-token-name">border/default</div><div class="btn-token-label">Border</div></div></div><div class="btn-token-item"><div class="btn-token-swatch" style="background:#191919;"></div><div><div class="btn-token-name">content/primary</div><div class="btn-token-label">Text</div></div></div><div class="btn-token-item"><div class="btn-token-swatch" style="background:#F6F6F6;"></div><div><div class="btn-token-name">background/subtle</div><div class="btn-token-label">Hover bg</div></div></div></div>
      </div>
    </div>

    <div class="doc-variant-block">
      <div class="btn-section-toolbar">
        <h3 class="doc-variant-title">Tertiary color</h3>
      </div>
      <p class="doc-section-desc">Low-emphasis action. No border, no background — just the label and icon. Use for supplementary or repeated actions.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Tertiary color button</span>
          <div class="inp-demo-controls">
            <span class="inp-demo-meta">State</span>
            <select class="inp-state-select" id="sel-btn-ghost" onchange="btnState('ghost',this.value)"><option value="Default"selected>Default</option><option value="Hover">Hover</option><option value="Active">Active</option><option value="Focused">Focused</option><option value="Disabled">Disabled</option></select>
          </div>
        </div>
        <div class="inp-demo-stage" id="stage-btn-ghost">
          <div style="display:flex;align-items:center;justify-content:center;min-height:60px">
            <button id="btn-ghost" class="btn btn-ghost" onclick="this.blur()">Learn more</button>
          </div>
        </div>
        <div class="btn-tokens-strip"><div class="btn-token-item"><div class="btn-token-swatch" style="background:#430098;"></div><div><div class="btn-token-name">brand/primary</div><div class="btn-token-label">Text</div></div></div><div class="btn-token-item"><div class="btn-token-swatch" style="background:#ECE6F5;"></div><div><div class="btn-token-name">brand/primary-muted</div><div class="btn-token-label">Hover bg</div></div></div></div>
      </div>
    </div>

    <div class="doc-variant-block">
      <div class="btn-section-toolbar">
        <h3 class="doc-variant-title">Tertiary gray</h3>
      </div>
      <p class="doc-section-desc">Lowest-emphasis neutral action. Inline or toolbar actions where color would distract.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Tertiary gray button</span>
          <div class="inp-demo-controls">
            <span class="inp-demo-meta">State</span>
            <select class="inp-state-select" id="sel-btn-tertiary-gray" onchange="btnState('tertiary-gray',this.value)"><option value="Default"selected>Default</option><option value="Hover">Hover</option><option value="Active">Active</option><option value="Focused">Focused</option><option value="Disabled">Disabled</option></select>
          </div>
        </div>
        <div class="inp-demo-stage" id="stage-btn-tertiary-gray">
          <div style="display:flex;align-items:center;justify-content:center;min-height:60px">
            <button id="btn-tertiary-gray" class="btn btn-tertiary-gray" onclick="this.blur()">Dismiss</button>
          </div>
        </div>
        <div class="btn-tokens-strip"><div class="btn-token-item"><div class="btn-token-swatch" style="background:#757575;"></div><div><div class="btn-token-name">content/secondary</div><div class="btn-token-label">Text</div></div></div><div class="btn-token-item"><div class="btn-token-swatch" style="background:#F6F6F6;"></div><div><div class="btn-token-name">background/subtle</div><div class="btn-token-label">Hover bg</div></div></div></div>
      </div>
    </div>

    <div class="doc-variant-block">
      <div class="btn-section-toolbar">
        <h3 class="doc-variant-title">Destructive</h3>
      </div>
      <p class="doc-section-desc">For irreversible actions only — delete, remove, revoke access. Always confirm before executing.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Destructive button</span>
          <div class="inp-demo-controls">
            <span class="inp-demo-meta">State</span>
            <select class="inp-state-select" id="sel-btn-destructive" onchange="btnState('destructive',this.value)"><option value="Default"selected>Default</option><option value="Hover">Hover</option><option value="Active">Active</option><option value="Focused">Focused</option><option value="Disabled">Disabled</option></select>
          </div>
        </div>
        <div class="inp-demo-stage" id="stage-btn-destructive">
          <div style="display:flex;align-items:center;justify-content:center;min-height:60px">
            <button id="btn-destructive" class="btn btn-destructive" onclick="this.blur()">Delete account</button>
          </div>
        </div>
        <div class="btn-tokens-strip"><div class="btn-token-item"><div class="btn-token-swatch" style="background:#FFF2F4;"></div><div><div class="btn-token-name">status/danger-bg</div><div class="btn-token-label">Background</div></div></div><div class="btn-token-item"><div class="btn-token-swatch" style="background:#E04756;"></div><div><div class="btn-token-name">status/danger-border</div><div class="btn-token-label">Border</div></div></div><div class="btn-token-item"><div class="btn-token-swatch" style="background:#D8192C;"></div><div><div class="btn-token-name">status/danger-content</div><div class="btn-token-label">Text</div></div></div><div class="btn-token-item"><div class="btn-token-swatch" style="background:#FBE8EA;"></div><div><div class="btn-token-name">status/danger-bg-hover</div><div class="btn-token-label">Hover bg</div></div></div></div>
      </div>
    </div>

    <div class="doc-variant-block">
      <div class="btn-section-toolbar">
        <h3 class="doc-variant-title">Link color</h3>
      </div>
      <p class="doc-section-desc">Inline text link — navigates or opens a panel. No background, no border. Underline on hover.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Link color button</span>
          <div class="inp-demo-controls">
            <span class="inp-demo-meta">State</span>
            <select class="inp-state-select" id="sel-btn-link-color" onchange="btnState('link-color',this.value)"><option value="Default"selected>Default</option><option value="Hover">Hover</option><option value="Active">Active</option><option value="Focused">Focused</option><option value="Disabled">Disabled</option></select>
          </div>
        </div>
        <div class="inp-demo-stage" id="stage-btn-link-color">
          <div style="display:flex;align-items:center;justify-content:center;min-height:60px">
            <button id="btn-link-color" class="btn btn-link-color" onclick="this.blur()">View documentation →</button>
          </div>
        </div>
        <div class="btn-tokens-strip"><div class="btn-token-item"><div class="btn-token-swatch" style="background:#430098;"></div><div><div class="btn-token-name">brand/primary</div><div class="btn-token-label">Text</div></div></div></div>
      </div>
    </div>

    <div class="doc-variant-block">
      <div class="btn-section-toolbar">
        <h3 class="doc-variant-title">Link gray</h3>
      </div>
      <p class="doc-section-desc">Neutral inline text link. Use in footers, secondary nav, or anywhere brand color would be excessive.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Link gray button</span>
          <div class="inp-demo-controls">
            <span class="inp-demo-meta">State</span>
            <select class="inp-state-select" id="sel-btn-link-gray" onchange="btnState('link-gray',this.value)"><option value="Default"selected>Default</option><option value="Hover">Hover</option><option value="Active">Active</option><option value="Focused">Focused</option><option value="Disabled">Disabled</option></select>
          </div>
        </div>
        <div class="inp-demo-stage" id="stage-btn-link-gray">
          <div style="display:flex;align-items:center;justify-content:center;min-height:60px">
            <button id="btn-link-gray" class="btn btn-link-gray" onclick="this.blur()">Terms of service</button>
          </div>
        </div>
        <div class="btn-tokens-strip"><div class="btn-token-item"><div class="btn-token-swatch" style="background:#757575;"></div><div><div class="btn-token-name">content/secondary</div><div class="btn-token-label">Text</div></div></div></div>
      </div>
    </div>

    </div><!-- /Hierarchy doc-section -->

    <!-- SIZES -->
    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Sizes</h2></div>
      <p class="doc-section-desc">Three sizes to match component density. SM for compact UIs, MD as the default, LG for prominent CTAs. Label font scales — 12/14/16px. Heights: 32/36/40px.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar"><span class="inp-demo-title">All sizes are interactive</span></div>
        <div class="inp-multi-stage">
          <div class="inp-multi-cell">
            <button class="btn btn-primary btn-sm">Small</button>
            <span class="inp-multi-label">SM — 32px · 12px</span>
          </div>
          <div class="inp-multi-cell">
            <button class="btn btn-primary">Medium</button>
            <span class="inp-multi-label">MD — 36px · 14px</span>
          </div>
          <div class="inp-multi-cell">
            <button class="btn btn-primary btn-lg">Large</button>
            <span class="inp-multi-label">LG — 40px · 16px</span>
          </div>
        </div>
      </div>
    </div>

    <!-- ICON TYPES -->
    <div class="doc-section">
      <h2 class="doc-section-title">Icon types</h2>
      <p class="doc-section-desc">Leading, trailing, and icon-only placements across all hierarchies. Use a hierarchy selector to preview any combination.</p>

    <div class="doc-variant-block">
      <div class="btn-section-toolbar"><h3 class="doc-variant-title">Icon leading</h3></div>
      <p class="doc-section-desc">Icon before the label. Use when the icon reinforces the action — Save, Search, Add. Icon color matches the label token.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Icon leading</span>
          <div class="inp-demo-controls">
            <span class="inp-demo-meta">Hierarchy</span>
            <select class="inp-state-select" id="sel-btn-icon-lead-hier" onchange="btnState('icon-lead-hier',this.value)"><option value="Primary"selected>Primary</option><option value="Secondary color">Secondary color</option><option value="Secondary gray">Secondary gray</option><option value="Ghost">Ghost</option><option value="Tertiary gray">Tertiary gray</option><option value="Destructive">Destructive</option></select>
            <span class="inp-demo-meta">State</span>
            <select class="inp-state-select" id="sel-btn-icon-lead" onchange="btnState('icon-lead',this.value)"><option value="Default"selected>Default</option><option value="Hover">Hover</option><option value="Active">Active</option><option value="Focused">Focused</option><option value="Disabled">Disabled</option></select>
          </div>
        </div>
        <div class="inp-demo-stage" id="stage-btn-icon-lead">
          <div style="display:flex;align-items:center;justify-content:center;min-height:60px">
            <button id="btn-icon-lead" class="btn btn-primary" onclick="this.blur()"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg> Add member</button>
          </div>
        </div>
      </div>
    </div>

    <div class="doc-variant-block">
      <div class="btn-section-toolbar"><h3 class="doc-variant-title">Icon trailing</h3></div>
      <p class="doc-section-desc">Icon after the label. Use for directional cues — next step, external link, expand.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Icon trailing</span>
          <div class="inp-demo-controls">
            <span class="inp-demo-meta">Hierarchy</span>
            <select class="inp-state-select" id="sel-btn-icon-trail-hier" onchange="btnState('icon-trail-hier',this.value)"><option value="Primary"selected>Primary</option><option value="Secondary color">Secondary color</option><option value="Secondary gray">Secondary gray</option><option value="Ghost">Ghost</option><option value="Tertiary gray">Tertiary gray</option><option value="Destructive">Destructive</option></select>
            <span class="inp-demo-meta">State</span>
            <select class="inp-state-select" id="sel-btn-icon-trail" onchange="btnState('icon-trail',this.value)"><option value="Default"selected>Default</option><option value="Hover">Hover</option><option value="Active">Active</option><option value="Focused">Focused</option><option value="Disabled">Disabled</option></select>
          </div>
        </div>
        <div class="inp-demo-stage" id="stage-btn-icon-trail">
          <div style="display:flex;align-items:center;justify-content:center;min-height:60px">
            <button id="btn-icon-trail" class="btn btn-primary" onclick="this.blur()">Continue <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></button>
          </div>
        </div>
      </div>
    </div>

    <div class="doc-variant-block">
      <div class="btn-section-toolbar"><h3 class="doc-variant-title">Icon only</h3></div>
      <p class="doc-section-desc">Square button with no label. Always include an <code>aria-label</code> for accessibility. Use a tooltip to surface the action name.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Icon only</span>
          <div class="inp-demo-controls">
            <span class="inp-demo-meta">Hierarchy</span>
            <select class="inp-state-select" id="sel-btn-icon-only-hier" onchange="btnState('icon-only-hier',this.value)"><option value="Primary"selected>Primary</option><option value="Secondary color">Secondary color</option><option value="Secondary gray">Secondary gray</option><option value="Ghost">Ghost</option><option value="Tertiary gray">Tertiary gray</option><option value="Destructive">Destructive</option></select>
            <span class="inp-demo-meta">State</span>
            <select class="inp-state-select" id="sel-btn-icon-only" onchange="btnState('icon-only',this.value)"><option value="Default"selected>Default</option><option value="Hover">Hover</option><option value="Active">Active</option><option value="Focused">Focused</option><option value="Disabled">Disabled</option></select>
          </div>
        </div>
        <div class="inp-demo-stage" id="stage-btn-icon-only">
          <div style="display:flex;align-items:center;justify-content:center;min-height:60px">
            <button id="btn-icon-only" class="btn btn-primary btn-icon-only" aria-label="Download" onclick="this.blur()"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></button>
          </div>
        </div>
      </div>
    </div>
    </div><!-- /Icon types doc-section -->

    <!-- COMPONENT TOKENS -->
    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
      <p class="doc-section-desc">All spacing, sizing, and radius values bound to the <code>Components</code> collection — semantic aliases from <code>Spacing</code> primitives. Hover to preview the value, click to copy.</p>
      <div class="card" style="overflow:hidden;margin-bottom:16px"><table class="tok-table"><thead><tr><th>Token</th><th>Aliases → (hover for value, click to copy)</th><th>Usage</th></tr></thead><tbody><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/button/height/sm</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'32px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/32<span class="tok-alias-copied">32px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Button height — SM</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/button/height/md</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'36px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/36<span class="tok-alias-copied">36px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Button height — MD (default)</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/button/height/lg</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'40px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/40<span class="tok-alias-copied">40px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Button height — LG</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/button/padding-x/sm</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'12px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/12<span class="tok-alias-copied">12px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Horizontal padding — SM</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/button/padding-x/md</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'16px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/16<span class="tok-alias-copied">16px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Horizontal padding — MD</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/button/padding-x/lg</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'20px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/20<span class="tok-alias-copied">20px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Horizontal padding — LG</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/button/gap</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'6px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/6<span class="tok-alias-copied">6px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Gap between icon and label</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/button/radius</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'8px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/8<span class="tok-alias-copied">8px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Border radius → radius/lg</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/button/icon-size/sm</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'16px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">icon/size/sm<span class="tok-alias-copied">16px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Icon size — SM</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/button/icon-size/md</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'20px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">icon/size/md<span class="tok-alias-copied">20px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Icon size — MD</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/button/icon-size/lg</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'24px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">icon/size/lg<span class="tok-alias-copied">24px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Icon size — LG</td></tr><tr style="border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/button/focus-width</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'2px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/2<span class="tok-alias-copied">2px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Focus ring stroke width</td></tr><tr style="background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)"><td style="padding:10px 16px"><code class="tok-name">component/button/focus-offset</code></td><td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'2px')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">spacing/2<span class="tok-alias-copied">2px</span></span></td><td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">Focus ring offset</td></tr></tbody></table></div>
    </div>

    <!-- PROPS -->
    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
      <table class="prop-table">
        <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
        <tbody>
          <tr><td><span class="prop-name">hierarchy</span></td><td><span class="prop-type">"primary"|"secondary"|"secondary-gray"|"ghost"|"tertiary-gray"|"destructive"|"link-color"|"link-gray"</span></td><td><span class="prop-default">"primary"</span></td><td>Visual weight and color intent.</td></tr>
          <tr><td><span class="prop-name">size</span></td><td><span class="prop-type">"sm"|"md"|"lg"</span></td><td><span class="prop-default">"md"</span></td><td>Height, padding, and font size scale.</td></tr>
          <tr><td><span class="prop-name">icon</span></td><td><span class="prop-type">"none"|"leading"|"trailing"|"only"</span></td><td><span class="prop-default">"none"</span></td><td>Icon position relative to the label.</td></tr>
          <tr><td><span class="prop-name">disabled</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Prevents interaction, applies 50% opacity.</td></tr>
          <tr><td><span class="prop-name">onClick</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Click handler callback.</td></tr>
          <tr><td><span class="prop-name">children</span></td><td><span class="prop-type">ReactNode</span></td><td><span class="prop-default">—</span></td><td>Button label content.</td></tr>
        </tbody>
      </table>
    </div>

    <!-- DO / DON'T -->
    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
      <div class="do-dont">
        <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use only one Primary button per screen. It signals the single most important action — multiple primaries dilute hierarchy.</div></div>
        <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use the Destructive hierarchy for non-destructive actions like Cancel. Use Secondary gray instead.</div></div>
        <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Match button size to adjacent form inputs — SM with SM, MD with MD. Mismatched sizes create visual tension.</div></div>
        <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use icon-only buttons without an <code>aria-label</code>. Screen readers need a text alternative.</div></div>
        <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use Link buttons for navigation inside prose or secondary contextual actions — not for form submissions.</div></div>
        <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't mix more than 2 button hierarchies in the same action group. Stick to Primary + Secondary or Secondary + Tertiary.</div></div>
      </div>
    </div>

  </div>`;
}
