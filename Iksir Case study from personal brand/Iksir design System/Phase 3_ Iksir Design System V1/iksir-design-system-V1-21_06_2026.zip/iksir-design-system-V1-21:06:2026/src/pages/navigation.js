import { pageHeader } from '../utils/render.js';

/* ── icons ──────────────────────────────────────────────── */
const CHV_DOWN  = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="6 9 12 15 18 9"/></svg>`;
const CHV_RIGHT = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>`;
const BACK      = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="15 18 9 12 15 6"/></svg>`;
const ICON_PKG  = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>`;
const ICON_ORD  = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`;
const ICON_REP  = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>`;
const ICON_SET  = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/></svg>`;
const ICON_BELL = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>`;
const ICON_SRCH = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`;
const ICON_PLUS = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`;
const ICON_LINK = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>`;
const ICON_TRASH= `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>`;

/* ── static sidebar helpers ──────────────────────────────── */
function sidebarItem({ label, icon = '', active = false, indent = false } = {}) {
  return `<div style="display:flex;align-items:center;gap:8px;padding:${indent?'6px 12px 6px 36px':'8px 12px'};border-radius:8px;cursor:pointer;background:${active?'var(--brand-primary-subtle)':'transparent'};color:${active?'var(--brand-primary)':'var(--content-secondary)'};font-family:Inter,sans-serif;font-size:13px;font-weight:${active?700:500};transition:background .1s" onmouseenter="if(!${active})this.style.background='var(--background-subtle)'" onmouseleave="if(!${active})this.style.background='transparent'">
    ${icon?`<span style="flex-shrink:0;width:16px;display:flex;justify-content:center">${icon}</span>`:''}
    ${indent?`<span style="width:6px;height:6px;border-radius:50%;background:${active?'var(--brand-primary)':'var(--border-default)'};flex-shrink:0"></span>`:''}
    <span style="flex:1">${label}</span>
    ${active?`<span style="width:3px;height:16px;background:var(--brand-primary);border-radius:9999px;flex-shrink:0"></span>`:''}
  </div>`;
}

function sidebarGroup({ label, icon, items = [], open = false } = {}) {
  return `<div>
    <div style="display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:8px;cursor:pointer;color:var(--content-secondary);font-family:Inter,sans-serif;font-size:13px;font-weight:500" onmouseenter="this.style.background='var(--background-subtle)'" onmouseleave="this.style.background='transparent'">
      <span style="flex-shrink:0;width:16px;display:flex;justify-content:center">${icon}</span>
      <span style="flex:1">${label}</span>
      <span style="color:var(--content-tertiary);transform:${open?'rotate(0)':'rotate(-90deg)'};transition:transform .2s">${CHV_DOWN}</span>
    </div>
    ${open ? `<div style="margin-top:2px">${items.map(item => sidebarItem({ ...item, indent: true })).join('')}</div>` : ''}
  </div>`;
}

function sidebar({ collapsed = false, activeItem = 'produits' } = {}) {
  if (collapsed) {
    return `
    <div style="width:56px;background:var(--background-default);border-right:1px solid var(--border-subtle);padding:12px 8px;display:flex;flex-direction:column;gap:8px;align-items:center;flex-shrink:0">
      <div style="height:36px;width:36px;display:flex;align-items:center;justify-content:center;border-radius:8px;margin-bottom:8px">
        <div style="width:28px;height:28px;border-radius:6px;background:var(--brand-primary)"></div>
      </div>
      ${[ICON_PKG,ICON_ORD,ICON_REP,ICON_SET].map((ic,i) => `<div title="Section" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:8px;cursor:pointer;color:${i===0?'var(--brand-primary)':'var(--content-tertiary)'};background:${i===0?'var(--brand-primary-subtle)':'transparent'}" onmouseenter="this.style.background='var(--background-subtle)'" onmouseleave="this.style.background='${i===0?'var(--brand-primary-subtle)':'transparent'}'">${ic}</div>`).join('')}
    </div>`;
  }
  return `
  <div style="width:220px;background:var(--background-default);border-right:1px solid var(--border-subtle);padding:16px 8px;display:flex;flex-direction:column;gap:4px;flex-shrink:0;overflow:hidden">
    <div style="display:flex;align-items:center;gap:10px;padding:8px 8px 16px;border-bottom:1px solid var(--border-subtle);margin-bottom:8px">
      <div style="width:28px;height:28px;border-radius:6px;background:var(--brand-primary);flex-shrink:0"></div>
      <span style="font-family:var(--font-display);font-size:13px;font-weight:700;color:var(--content-primary)">Iksir ERP</span>
    </div>
    <div style="font-family:Inter,sans-serif;font-size:10px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.08em;padding:4px 12px;margin-bottom:2px">Référentiel</div>
    ${sidebarGroup({
      label: 'Produits', icon: ICON_PKG, open: true,
      items: [
        { label: 'Liste des produits', active: activeItem === 'produits' },
        { label: 'Catégories', active: activeItem === 'categories' },
      ]
    })}
    ${sidebarGroup({ label: 'Commandes', icon: ICON_ORD, open: false, items: [] })}
    <div style="font-family:Inter,sans-serif;font-size:10px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.08em;padding:8px 12px 4px;margin-top:4px">Analytique</div>
    ${sidebarItem({ label: 'Rapports', icon: ICON_REP })}
    ${sidebarItem({ label: 'Paramètres', icon: ICON_SET })}
  </div>`;
}

function breadcrumb(items = []) {
  return `<div style="display:flex;align-items:center;gap:4px;font-family:Inter,sans-serif;font-size:12px">
    ${items.map((item, i) => `
    ${i > 0 ? `<span style="color:var(--content-tertiary)">${CHV_RIGHT}</span>` : ''}
    <span style="color:${i === items.length-1 ? 'var(--brand-primary)' : 'var(--content-secondary)'};font-weight:${i === items.length-1 ? 600 : 400};cursor:${i < items.length-1 ? 'pointer' : 'default'}" ${i<items.length-1?`onmouseenter="this.style.color='var(--content-primary)'" onmouseleave="this.style.color='var(--content-secondary)'"`:''}>${item}</span>`).join('')}
  </div>`;
}

function tabBar(tabs = [], active = 0) {
  return `<div style="display:flex;gap:0;border-bottom:1px solid var(--border-subtle)">
    ${tabs.map((t, i) => `<div style="padding:10px 16px;font-family:Inter,sans-serif;font-size:13px;font-weight:${i===active?700:500};color:${i===active?'var(--brand-primary)':'var(--content-secondary)'};border-bottom:${i===active?'2px solid var(--brand-primary)':'2px solid transparent'};cursor:pointer;margin-bottom:-1px;white-space:nowrap" onmouseenter="if(${i!==active})this.style.color='var(--content-primary)'" onmouseleave="if(${i!==active})this.style.color='var(--content-secondary)'">${t}</div>`).join('')}
  </div>`;
}

function swatch(color, name, lbl) {
  const light = ['#FFFFFF','#F7F4FB','#F6F6F6'].includes(color);
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${color};${light?'border:1px solid #E1E1E1':''}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${lbl}</div></div></div>`;
}

/* ── interactive page content builders ───────────────────── */
const NAV_PRODUCTS = [
  { code:'PRD-001', name:'Palette bois standard',  cat:'Contenants',   catColor:'var(--brand-primary)',  catBg:'var(--brand-primary-subtle)', qty:'342',   price:'12.50' },
  { code:'PRD-002', name:'Film étirable 20µm',      cat:'Consommables', catColor:'#0550AE', catBg:'#EFF6FF', qty:'1 840', price:'4.20' },
  { code:'PRD-003', name:'Carton simple cannelure', cat:'Emballage',    catColor:'#16A34A', catBg:'#F0FDF4', qty:'6 230', price:'0.85' },
  { code:'PRD-004', name:'Étiquette thermique A6',  cat:'Consommables', catColor:'#0550AE', catBg:'#EFF6FF', qty:'94',    price:'18.00' },
];

function _statCard(value, label, trend = '') {
  return `<div style="background:var(--background-default);border:1px solid var(--border-subtle);border-radius:10px;padding:14px 16px;display:flex;flex-direction:column;gap:4px">
    <div style="font-family:var(--font-mono);font-size:22px;font-weight:700;color:var(--content-primary);line-height:1">${value}</div>
    <div style="font-size:11px;color:var(--content-secondary)">${label}</div>
    ${trend?`<div style="font-size:10px;color:#16A34A;margin-top:2px">${trend}</div>`:''}
  </div>`;
}

function _navContentProduits() {
  return `
  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px">
    ${_statCard('247','Produits actifs','▲ +8 ce mois')}
    ${_statCard('12','Catégories','')}
    ${_statCard('48 370 €','Valeur en stock','▲ +3.2%')}
  </div>
  <div style="border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden;background:var(--background-default)">
    <table style="width:100%;border-collapse:collapse">
      <thead>
        <tr>
          <th style="padding:8px 12px;background:var(--background-subtle);text-align:left;font-family:Inter,sans-serif;font-size:10px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em;white-space:nowrap">Code</th>
          <th style="padding:8px 12px;background:var(--background-subtle);text-align:left;font-family:Inter,sans-serif;font-size:10px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em">Nom du produit</th>
          <th style="padding:8px 12px;background:var(--background-subtle);text-align:left;font-family:Inter,sans-serif;font-size:10px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em;width:110px">Catégorie</th>
          <th style="padding:8px 12px;background:var(--background-subtle);text-align:right;font-family:Inter,sans-serif;font-size:10px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em;width:72px">Stock</th>
          <th style="padding:8px 12px;background:var(--background-subtle);width:60px"></th>
        </tr>
      </thead>
      <tbody>
        ${NAV_PRODUCTS.map((p,i)=>`
        <tr style="transition:background .12s" onmouseenter="this.style.background='var(--background-subtle)'" onmouseleave="this.style.background=''">
          <td style="padding:9px 12px;${i<NAV_PRODUCTS.length-1?'border-bottom:1px solid var(--border-subtle)':''}"><code style="font-size:11px;font-family:var(--font-mono);color:var(--content-tertiary)">${p.code}</code></td>
          <td style="padding:9px 12px;font-family:Inter,sans-serif;font-size:12px;font-weight:500;color:var(--content-primary);${i<NAV_PRODUCTS.length-1?'border-bottom:1px solid var(--border-subtle)':''}">${p.name}</td>
          <td style="padding:9px 12px;${i<NAV_PRODUCTS.length-1?'border-bottom:1px solid var(--border-subtle)':''}">
            <span style="display:inline-flex;padding:0 6px;height:18px;border-radius:9999px;font-family:Inter,sans-serif;font-size:10px;font-weight:600;color:${p.catColor};background:${p.catBg};align-items:center">${p.cat}</span>
          </td>
          <td style="padding:9px 12px;font-family:var(--font-mono);font-size:12px;font-weight:600;color:var(--content-primary);text-align:right;${i<NAV_PRODUCTS.length-1?'border-bottom:1px solid var(--border-subtle)':''}">${p.qty}</td>
          <td style="padding:6px 8px;text-align:right;${i<NAV_PRODUCTS.length-1?'border-bottom:1px solid var(--border-subtle)':''}">
            <button style="width:24px;height:24px;display:inline-flex;align-items:center;justify-content:center;background:none;border:none;cursor:pointer;border-radius:5px;color:var(--content-tertiary)" onmouseenter="this.style.background='var(--background-subtle)';this.style.color='var(--content-secondary)'" onmouseleave="this.style.background='none';this.style.color='var(--content-tertiary)'">${ICON_LINK}</button>
            <button style="width:24px;height:24px;display:inline-flex;align-items:center;justify-content:center;background:none;border:none;cursor:pointer;border-radius:5px;color:var(--content-tertiary)" onmouseenter="this.style.background='#FFF0F0';this.style.color='#D8192C'" onmouseleave="this.style.background='none';this.style.color='var(--content-tertiary)'">${ICON_TRASH}</button>
          </td>
        </tr>`).join('')}
      </tbody>
    </table>
  </div>`;
}

function _navContentCommandes() {
  const orders = [
    { id:'CMD-2847', supplier:'Fournisseur Alpha',  status:'En cours',  sc:'#0550AE', sb:'#EFF6FF', items:3,  total:'48.50 €',  date:"Aujourd'hui" },
    { id:'CMD-2846', supplier:'Emballages Pro SARL',status:'Livrée',    sc:'#16A34A', sb:'#F0FDF4', items:12, total:'127.80 €', date:'Hier' },
    { id:'CMD-2845', supplier:'Stock Direct',       status:'En retard', sc:'var(--status-danger-content)', sb:'var(--status-danger-bg)', items:2,  total:'22.00 €',  date:'Il y a 3 j' },
  ];
  return `
  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px">
    ${_statCard('18','Commandes actives','')}
    ${_statCard('6','En cours','')}
    ${_statCard('2','En retard','')}
  </div>
  <div style="display:flex;flex-direction:column;gap:8px">
    ${orders.map(o=>`
    <div style="background:var(--background-default);border:1px solid var(--border-subtle);border-radius:10px;padding:12px 16px;display:flex;align-items:center;gap:12px;cursor:pointer;transition:box-shadow .12s" onmouseenter="this.style.boxShadow='0 2px 8px rgba(0,0,0,.06)'" onmouseleave="this.style.boxShadow='none'">
      <code style="font-family:var(--font-mono);font-size:11px;color:var(--content-tertiary);white-space:nowrap;width:72px;flex-shrink:0">${o.id}</code>
      <div style="flex:1;min-width:0">
        <div style="font-family:Inter,sans-serif;font-size:13px;font-weight:600;color:var(--content-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${o.supplier}</div>
        <div style="font-family:Inter,sans-serif;font-size:11px;color:var(--content-tertiary);margin-top:2px">${o.items} articles · ${o.date}</div>
      </div>
      <div style="font-family:var(--font-mono);font-size:13px;font-weight:600;color:var(--content-primary);white-space:nowrap">${o.total}</div>
      <span style="display:inline-flex;padding:0 8px;height:20px;align-items:center;border-radius:9999px;font-family:Inter,sans-serif;font-size:11px;font-weight:600;color:${o.sc};background:${o.sb};flex-shrink:0">${o.status}</span>
    </div>`).join('')}
  </div>`;
}

function _navContentRapports() {
  const bars = [45,62,38,71,55,80,68];
  return `
  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px">
    ${_statCard('127 420 €','CA ce mois','▲ +12.4%')}
    ${_statCard('1 284','Commandes','▲ +6.1%')}
    ${_statCard('92.4%','Taux livraison','▼ -0.8%')}
  </div>
  <div style="background:var(--background-default);border:1px solid var(--border-subtle);border-radius:10px;padding:16px 20px">
    <div style="font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--content-secondary);margin-bottom:14px">Commandes par jour — cette semaine</div>
    <div style="display:flex;align-items:flex-end;gap:6px;height:70px">
      ${bars.map((h,i)=>`<div style="flex:1;background:${i===5?'var(--brand-primary)':'var(--brand-primary-subtle)'};border-radius:4px 4px 0 0;height:${h}%;transition:opacity .15s" onmouseenter="this.style.opacity='.75'" onmouseleave="this.style.opacity='1'" title="${h} commandes"></div>`).join('')}
    </div>
    <div style="display:flex;gap:6px;margin-top:6px;border-top:1px solid var(--border-subtle);padding-top:8px">
      ${['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'].map((d,i)=>`<div style="flex:1;font-family:Inter,sans-serif;font-size:10px;color:${i===5?'var(--brand-primary)':'var(--content-tertiary)'};text-align:center;font-weight:${i===5?700:400}">${d}</div>`).join('')}
    </div>
  </div>`;
}

function _navContentSettings() {
  const sections = [
    { icon: ICON_SET,  title:'Général',      desc:'Infos société, fuseau horaire, devise' },
    { icon: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
      title:'Utilisateurs',  desc:'Comptes, rôles et permissions' },
    { icon: ICON_LINK, title:'Intégrations', desc:'API REST, webhooks, connecteurs' },
    { icon: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`,
      title:'Sécurité',      desc:'2FA, sessions actives, journaux' },
  ];
  return `
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
    ${sections.map(s=>`
    <div style="background:var(--background-default);border:1px solid var(--border-subtle);border-radius:10px;padding:14px 16px;cursor:pointer;display:flex;align-items:flex-start;gap:12px;transition:box-shadow .12s" onmouseenter="this.style.boxShadow='0 2px 8px rgba(0,0,0,.06)'" onmouseleave="this.style.boxShadow='none'">
      <div style="width:32px;height:32px;border-radius:8px;background:var(--brand-primary-subtle);display:flex;align-items:center;justify-content:center;color:var(--brand-primary);flex-shrink:0">${s.icon}</div>
      <div>
        <div style="font-family:Inter,sans-serif;font-size:13px;font-weight:600;color:var(--content-primary);margin-bottom:3px">${s.title}</div>
        <div style="font-family:Inter,sans-serif;font-size:11px;color:var(--content-secondary);line-height:1.4">${s.desc}</div>
      </div>
    </div>`).join('')}
  </div>`;
}

/* ════════════════════════════════════════════════════════════ */
export default function navigation() {
  return pageHeader('Patterns', 'Navigation', 'Sidebar structure, breadcrumbs, in-page tabs, and header slots — the full navigation layer of the Iksir ERP desktop interface.') + `<div class="page-body">

  <style>
    @keyframes nav-content-in { from { opacity:0; transform:translateY(4px) } to { opacity:1; transform:translateY(0) } }
    .nav-tab-content { animation: nav-content-in 0.18s ease; }
  </style>

  <!-- LIVE INTERACTIVE SHELL -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Live — click to navigate</h2></div>
    <p class="doc-section-desc">A fully interactive ERP shell. Click sidebar items to switch pages. Click group headers to collapse/expand. Click the tabs to switch sections. Click the collapse button to toggle icon-only rail mode.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Interactive ERP navigation shell</span></div>

      <div class="inp-demo-stage" style="padding:0;min-height:520px;overflow:hidden;border-radius:0 0 8px 8px;display:flex;flex-direction:column;align-items:stretch">

        <!-- ── Top bar ──────────────────────────────────────── -->
        <div style="height:48px;background:var(--background-default);border-bottom:1px solid var(--border-subtle);display:flex;align-items:center;padding:0 20px;gap:16px;flex-shrink:0">
          <div id="nav-breadcrumb" style="flex:1;display:flex;align-items:center;gap:4px;font-family:Inter,sans-serif;font-size:12px;color:var(--content-secondary)">
            <span>Référentiel</span>
            <span style="color:var(--border-default);margin:0 1px">›</span>
            <span style="color:var(--brand-primary);font-weight:600">Produits</span>
          </div>
          <div style="display:flex;align-items:center;gap:6px">
            <button style="width:30px;height:30px;display:flex;align-items:center;justify-content:center;background:transparent;border:1px solid var(--border-subtle);border-radius:7px;cursor:pointer;color:var(--content-tertiary);transition:all .12s" onmouseenter="this.style.background='var(--background-subtle)';this.style.color='var(--content-secondary)'" onmouseleave="this.style.background='transparent';this.style.color='var(--content-tertiary)'">${ICON_SRCH}</button>
            <button style="position:relative;width:30px;height:30px;display:flex;align-items:center;justify-content:center;background:transparent;border:1px solid var(--border-subtle);border-radius:7px;cursor:pointer;color:var(--content-tertiary);transition:all .12s" onmouseenter="this.style.background='var(--background-subtle)';this.style.color='var(--content-secondary)'" onmouseleave="this.style.background='transparent';this.style.color='var(--content-tertiary)'">${ICON_BELL}<span style="position:absolute;top:6px;right:6px;width:6px;height:6px;border-radius:50%;background:#E04756;border:1.5px solid var(--background-default)"></span></button>
            <div style="width:1px;height:18px;background:var(--border-subtle);margin:0 2px"></div>
            <span style="font-family:Inter,sans-serif;font-size:11px;color:var(--content-tertiary);background:var(--background-subtle);padding:3px 8px;border-radius:9999px;border:1px solid var(--border-subtle)">Admin</span>
            <div style="width:28px;height:28px;border-radius:50%;background:var(--brand-primary);display:flex;align-items:center;justify-content:center;font-family:Inter,sans-serif;font-size:9px;font-weight:700;color:var(--content-on-brand);cursor:pointer;flex-shrink:0">MN</div>
          </div>
        </div>

        <div style="display:flex;flex:1;overflow:hidden">

          <!-- ── Sidebar ────────────────────────────────────── -->
          <div id="nav-sidebar" data-collapsed="false" data-active="produits" style="width:220px;flex-shrink:0;background:var(--background-default);border-right:1px solid var(--border-subtle);display:flex;flex-direction:column;transition:width 0.22s cubic-bezier(0.4,0,0.2,1);overflow:hidden">
            <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 12px 10px;flex-shrink:0;border-bottom:1px solid var(--border-subtle);margin-bottom:4px">
              <div style="display:flex;align-items:center;gap:8px;overflow:hidden">
                <div style="width:24px;height:24px;border-radius:5px;background:var(--brand-primary);flex-shrink:0"></div>
                <span id="nav-logo" style="font-family:var(--font-display);font-size:14px;font-weight:900;color:var(--content-primary);letter-spacing:-0.3px;white-space:nowrap;transition:opacity .15s">Iksir ERP</span>
              </div>
              <button id="nav-collapse-btn" onclick="navToggleCollapse()" style="width:24px;height:24px;border-radius:6px;border:1px solid var(--border-subtle);background:transparent;cursor:pointer;color:var(--content-tertiary);display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .12s,transform .22s" title="Collapse sidebar" onmouseenter="this.style.background='var(--background-subtle)'" onmouseleave="this.style.background='transparent'">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="15 18 9 12 15 6"/></svg>
              </button>
            </div>
            <div id="nav-scroll" style="flex:1;overflow-y:auto;padding:4px 8px 8px">

              <!-- Group: Référentiel -->
              <div id="nav-grp-wrap-0">
                <div id="nav-grp-hdr-0" onclick="navToggleGroup(0)" style="display:flex;align-items:center;justify-content:space-between;padding:8px 6px 4px;cursor:pointer;user-select:none;border-radius:6px;transition:opacity .12s" onmouseenter="this.style.opacity='.6'" onmouseleave="this.style.opacity='1'">
                  <span id="nav-grp-lbl-0" style="font-family:Inter,sans-serif;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--content-tertiary)">Référentiel</span>
                  <span id="nav-grp-chv-0" style="color:var(--content-tertiary);transition:transform 0.2s;display:flex">${CHV_DOWN}</span>
                </div>
                <div id="nav-grp-0">
                  ${[['produits','Produits',ICON_PKG],['commandes','Commandes',ICON_ORD]].map(([id,lbl,ic])=>`
                  <div id="nav-item-${id}" data-navid="${id}" onclick="navGo('${id}')"
                    style="display:flex;align-items:center;gap:8px;padding:7px 8px;border-radius:8px;cursor:pointer;background:${'produits'===id?'var(--brand-primary-subtle)':'transparent'};color:${'produits'===id?'var(--brand-primary)':'var(--content-secondary)'};font-family:Inter,sans-serif;font-size:13px;font-weight:${'produits'===id?600:500};transition:background .12s;position:relative"
                    onmouseenter="if(this.dataset.navid!==document.getElementById('nav-sidebar').dataset.active)this.style.background='var(--background-subtle)'"
                    onmouseleave="if(this.dataset.navid!==document.getElementById('nav-sidebar').dataset.active)this.style.background='transparent'">
                    <span id="nav-ic-${id}" style="flex-shrink:0;width:16px;display:flex;justify-content:center">${ic}</span>
                    <span id="nav-lbl-${id}" class="nav-item-label" style="flex:1">${lbl}</span>
                    <span id="nav-ind-${id}" style="position:absolute;right:0;top:50%;transform:translateY(-50%);width:3px;height:16px;background:var(--brand-primary);border-radius:2px 0 0 2px;${'produits'===id?'':'display:none'}"></span>
                  </div>`).join('')}
                </div>
              </div>

              <!-- Group: Opérations -->
              <div id="nav-grp-wrap-1" style="margin-top:4px">
                <div id="nav-grp-hdr-1" onclick="navToggleGroup(1)" style="display:flex;align-items:center;justify-content:space-between;padding:8px 6px 4px;cursor:pointer;user-select:none;border-radius:6px;transition:opacity .12s" onmouseenter="this.style.opacity='.6'" onmouseleave="this.style.opacity='1'">
                  <span id="nav-grp-lbl-1" style="font-family:Inter,sans-serif;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--content-tertiary)">Opérations</span>
                  <span id="nav-grp-chv-1" style="color:var(--content-tertiary);transition:transform 0.2s;display:flex">${CHV_DOWN}</span>
                </div>
                <div id="nav-grp-1">
                  ${[['rapports','Rapports',ICON_REP],['settings','Paramètres',ICON_SET]].map(([id,lbl,ic])=>`
                  <div id="nav-item-${id}" data-navid="${id}" onclick="navGo('${id}')"
                    style="display:flex;align-items:center;gap:8px;padding:7px 8px;border-radius:8px;cursor:pointer;background:transparent;color:var(--content-secondary);font-family:Inter,sans-serif;font-size:13px;font-weight:500;transition:background .12s;position:relative"
                    onmouseenter="if(this.dataset.navid!==document.getElementById('nav-sidebar').dataset.active)this.style.background='var(--background-subtle)'"
                    onmouseleave="if(this.dataset.navid!==document.getElementById('nav-sidebar').dataset.active)this.style.background='transparent'">
                    <span id="nav-ic-${id}" style="flex-shrink:0;width:16px;display:flex;justify-content:center">${ic}</span>
                    <span id="nav-lbl-${id}" class="nav-item-label" style="flex:1">${lbl}</span>
                    <span id="nav-ind-${id}" style="position:absolute;right:0;top:50%;transform:translateY(-50%);width:3px;height:16px;background:var(--brand-primary);border-radius:2px 0 0 2px;display:none"></span>
                  </div>`).join('')}
                </div>
              </div>

            </div>
          </div>

          <!-- ── Content area ───────────────────────────────── -->
          <div style="flex:1;display:flex;flex-direction:column;overflow:hidden;background:var(--background-subtle)">

            <!-- Page header (white) -->
            <div id="nav-page-header" style="background:var(--background-default);border-bottom:1px solid var(--border-subtle);flex-shrink:0">
              <div style="padding:14px 20px 0;display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
                <div id="nav-page-title" style="font-family:var(--font-display);font-size:18px;font-weight:800;color:var(--content-primary)">Produits</div>
                <div style="display:flex;align-items:center;gap:8px">
                  <div style="display:flex;align-items:center;gap:6px;padding:0 10px;height:30px;border:1px solid var(--border-default);border-radius:7px;background:var(--background-default);width:160px">
                    <span style="color:var(--content-tertiary);display:flex;flex-shrink:0">${ICON_SRCH}</span>
                    <span style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-tertiary)">Rechercher…</span>
                  </div>
                  <button id="nav-create-btn" style="display:flex;align-items:center;gap:5px;padding:0 12px;height:30px;border-radius:7px;background:var(--brand-primary);border:none;cursor:pointer;font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--content-on-brand);white-space:nowrap;transition:background .15s" onmouseenter="this.style.background='var(--brand-primary-hover)'" onmouseleave="this.style.background='var(--brand-primary)'">${ICON_PLUS} Créer un produit</button>
                </div>
              </div>
              <div id="nav-tabs" data-active="0" style="display:flex;padding:0 20px">
                ${[['Tous les produits','all'],['Stock','stock'],['Catégories','cats'],['Historique','hist']].map(([lbl,tid],ti)=>`
                <div data-tabid="${tid}" onclick="navTab(${ti})"
                  style="padding:8px 14px;font-family:Inter,sans-serif;font-size:12px;cursor:pointer;white-space:nowrap;transition:color .12s,border-color .12s;${ti===0?'color:var(--brand-primary);font-weight:600;border-bottom:2px solid var(--brand-primary);':'color:var(--content-secondary);font-weight:500;border-bottom:2px solid transparent;'}"
                  onmouseenter="if(${ti}!==parseInt(document.getElementById('nav-tabs').dataset.active))this.style.color='var(--content-primary)'"
                  onmouseleave="if(${ti}!==parseInt(document.getElementById('nav-tabs').dataset.active))this.style.color='var(--content-secondary)'"
                >${lbl}</div>`).join('')}
              </div>
            </div>

            <!-- Page body -->
            <div id="nav-content" class="nav-tab-content" style="flex:1;padding:16px 20px;display:flex;flex-direction:column;gap:12px;overflow-y:auto">
              ${_navContentProduits()}
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
    var _navOpen = [true, true];
    var _navActive = 'produits';

    var _navPages = {
      produits:  { title:'Produits',   crumb:['Référentiel','Produits'],  tabs:['Tous les produits','Stock','Catégories','Historique'], btn:'Créer un produit' },
      commandes: { title:'Commandes',  crumb:['Référentiel','Commandes'], tabs:['Toutes','En cours','Livrées','Annulées'],              btn:'Créer une commande' },
      rapports:  { title:'Rapports',   crumb:['Opérations','Rapports'],   tabs:["Vue d'ensemble",'Ventes','Stock'],                    btn:'Exporter' },
      settings:  { title:'Paramètres', crumb:['Opérations','Paramètres'], tabs:['Général','Utilisateurs','Intégrations'],              btn:'' },
    };

    var _navBodyMap = {
      produits:  ${JSON.stringify(_navContentProduits())},
      commandes: ${JSON.stringify(_navContentCommandes())},
      rapports:  ${JSON.stringify(_navContentRapports())},
      settings:  ${JSON.stringify(_navContentSettings())},
    };

    function navGo(id) {
      _navActive = id;
      var sidebar = document.getElementById('nav-sidebar');
      if (sidebar) sidebar.dataset.active = id;

      ['produits','commandes','rapports','settings'].forEach(function(nid) {
        var el  = document.getElementById('nav-item-' + nid);
        var ind = document.getElementById('nav-ind-'  + nid);
        if (!el) return;
        var isActive = (nid === id);
        el.style.background = isActive ? 'var(--brand-primary-subtle)' : 'transparent';
        el.style.color      = isActive ? 'var(--brand-primary)'        : 'var(--content-secondary)';
        el.style.fontWeight = isActive ? '600' : '500';
        if (ind) ind.style.display = isActive ? '' : 'none';
      });

      var pg = _navPages[id];
      if (!pg) return;

      var titleEl = document.getElementById('nav-page-title');
      if (titleEl) titleEl.textContent = pg.title;

      var createBtn = document.getElementById('nav-create-btn');
      if (createBtn) {
        if (pg.btn) {
          createBtn.style.display = 'flex';
          createBtn.childNodes[createBtn.childNodes.length-1].textContent = ' ' + pg.btn;
        } else {
          createBtn.style.display = 'none';
        }
      }

      var bc = document.getElementById('nav-breadcrumb');
      if (bc) bc.innerHTML = pg.crumb.map(function(c,i) {
        return (i < pg.crumb.length-1)
          ? '<span style="color:var(--content-secondary)">'+c+'</span><span style="color:var(--border-default);margin:0 1px">›</span>'
          : '<span style="color:var(--brand-primary);font-weight:600">'+c+'</span>';
      }).join('');

      var tabsEl = document.getElementById('nav-tabs');
      if (tabsEl) {
        tabsEl.dataset.active = '0';
        tabsEl.innerHTML = pg.tabs.map(function(lbl, ti) {
          return '<div data-tabid="t'+ti+'" onclick="navTab('+ti+')" style="padding:8px 14px;font-family:Inter,sans-serif;font-size:12px;cursor:pointer;white-space:nowrap;transition:color .12s,border-color .12s;'+(ti===0?'color:var(--brand-primary);font-weight:600;border-bottom:2px solid var(--brand-primary);':'color:var(--content-secondary);font-weight:500;border-bottom:2px solid transparent;')+'" onmouseenter="if('+ti+'!==parseInt(document.getElementById(\'nav-tabs\').dataset.active))this.style.color=\'var(--content-primary)\'" onmouseleave="if('+ti+'!==parseInt(document.getElementById(\'nav-tabs\').dataset.active))this.style.color=\'var(--content-secondary)\'">'+lbl+'</div>';
        }).join('');
      }

      var content = document.getElementById('nav-content');
      if (content) {
        content.classList.remove('nav-tab-content');
        void content.offsetWidth;
        content.classList.add('nav-tab-content');
        content.innerHTML = _navBodyMap[id] || '<div style="font-family:Inter,sans-serif;font-size:13px;color:var(--content-tertiary);padding:16px 0">Contenu de <strong style=\'color:var(--content-primary)\'>'+pg.title+'</strong></div>';
      }
    }

    function navTab(ti) {
      var tabsEl = document.getElementById('nav-tabs');
      if (!tabsEl) return;
      tabsEl.dataset.active = String(ti);
      Array.from(tabsEl.children).forEach(function(tab, i) {
        var isActive = (i === ti);
        tab.style.color       = isActive ? 'var(--brand-primary)'                : 'var(--content-secondary)';
        tab.style.fontWeight  = isActive ? '600'                                 : '500';
        tab.style.borderBottom= isActive ? '2px solid var(--brand-primary)'      : '2px solid transparent';
      });
      var content = document.getElementById('nav-content');
      if (content && ti > 0) {
        var pg = _navPages[_navActive];
        var tabName = pg && pg.tabs[ti] ? pg.tabs[ti] : 'Onglet '+(ti+1);
        content.classList.remove('nav-tab-content');
        void content.offsetWidth;
        content.classList.add('nav-tab-content');
        content.innerHTML = '<div style="padding:24px 0;display:flex;flex-direction:column;align-items:center;gap:8px;color:var(--content-tertiary)"><div style="font-family:Inter,sans-serif;font-size:13px">Contenu de l\'onglet <strong style=\'color:var(--content-primary)\'>'+tabName+'</strong></div></div>';
      } else if (content && ti === 0) {
        content.classList.remove('nav-tab-content');
        void content.offsetWidth;
        content.classList.add('nav-tab-content');
        content.innerHTML = _navBodyMap[_navActive] || '';
      }
    }

    function navToggleGroup(gi) {
      _navOpen[gi] = !_navOpen[gi];
      var body = document.getElementById('nav-grp-' + gi);
      var chv  = document.getElementById('nav-grp-chv-' + gi);
      if (body) {
        if (_navOpen[gi]) {
          body.style.display = '';
          body.style.maxHeight = '200px';
          body.style.opacity = '1';
        } else {
          body.style.maxHeight = '0';
          body.style.opacity = '0';
          setTimeout(function() { if (!_navOpen[gi]) body.style.display = 'none'; }, 200);
        }
        body.style.overflow = 'hidden';
        body.style.transition = 'max-height 0.22s cubic-bezier(0.4,0,0.2,1), opacity 0.18s';
      }
      if (chv) chv.style.transform = _navOpen[gi] ? 'rotate(0deg)' : 'rotate(-90deg)';
    }

    function navToggleCollapse() {
      var sb = document.getElementById('nav-sidebar');
      if (!sb) return;
      var collapsed = sb.dataset.collapsed === 'true';
      collapsed = !collapsed;
      sb.dataset.collapsed = String(collapsed);
      sb.style.width = collapsed ? '52px' : '220px';
      var logo = document.getElementById('nav-logo');
      if (logo) { logo.style.opacity = collapsed ? '0' : '1'; logo.style.pointerEvents = collapsed ? 'none' : ''; }
      var btn = document.getElementById('nav-collapse-btn');
      if (btn) btn.style.transform = collapsed ? 'rotate(180deg)' : 'rotate(0deg)';
      document.querySelectorAll('.nav-item-label').forEach(function(el) { el.style.opacity = collapsed ? '0' : '1'; el.style.width = collapsed ? '0' : ''; el.style.overflow = 'hidden'; });
      document.querySelectorAll('[id^="nav-grp-lbl-"],[id^="nav-grp-chv-"]').forEach(function(el) { el.style.opacity = collapsed ? '0' : '1'; });
    }
  </script>

  <!-- SIDEBAR — EXPANDED -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Sidebar — expanded</h2></div>
    <p class="doc-section-desc">The primary navigation for the ERP web app. 220px wide, always on the left. Groups use 10px uppercase labels to separate domains. Items with sub-pages use accordion groups with a chevron. The active leaf item has a brand right-edge indicator (3×16px pill) and a brand-subtle background.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Sidebar — Produits active</span></div>
      <div class="inp-demo-stage" style="padding:0;display:flex;justify-content:flex-start;min-height:360px;overflow:hidden;border-radius:8px">
        ${sidebar({ activeItem: 'produits' })}
        <div style="flex:1;background:var(--background-subtle);display:flex;align-items:center;justify-content:center">
          <span style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-tertiary)">Content area</span>
        </div>
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#F7F4FB','brand/primary-subtle','Active item bg')}
        ${swatch('#430098','brand/primary','Active item text + indicator')}
        ${swatch('#FFFFFF','surface/default','Sidebar background')}
        ${swatch('#E1E1E1','border/subtle','Right edge separator')}
      </div>
    </div>
  </div>

  <!-- SIDEBAR — COLLAPSED -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Sidebar — collapsed</h2></div>
    <p class="doc-section-desc">Users can collapse the sidebar to a 52px icon-only rail to gain horizontal space. Labels are hidden; icon buttons show a tooltip on hover. The active section icon remains brand-coloured with a muted background.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Sidebar — collapsed to icon rail</span></div>
      <div class="inp-demo-stage" style="padding:0;display:flex;justify-content:flex-start;min-height:280px;overflow:hidden;border-radius:8px">
        ${sidebar({ collapsed: true })}
        <div style="flex:1;background:var(--background-subtle);display:flex;align-items:center;justify-content:center">
          <span style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-tertiary)">Content area</span>
        </div>
      </div>
    </div>
  </div>

  <!-- SIDEBAR TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Sidebar tokens</h2></div>
    <div style="margin-top:16px;border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden;background:var(--background-default)">
      <div style="display:grid;grid-template-columns:2fr 1fr 2fr;background:var(--background-subtle);padding:10px 16px;gap:12px">
        ${['Token','Value','Usage'].map(h=>`<div style="font-size:11px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em">${h}</div>`).join('')}
      </div>
      ${[
        ['nav/sidebar/width-expanded','220px','Expanded sidebar width'],
        ['nav/sidebar/width-collapsed','52px','Icon-rail width'],
        ['nav/sidebar/background','background/default','Sidebar fill'],
        ['nav/sidebar/border','border/subtle','Right separator'],
        ['nav/sidebar/item-height','36px','Clickable item height'],
        ['nav/sidebar/item-bg-active','brand/primary-subtle','Active item background'],
        ['nav/sidebar/item-text-active','brand/primary','Active item text'],
        ['nav/sidebar/indicator-width','3px','Active right-edge pill'],
        ['nav/sidebar/section-label-size','10px, Bold 700','Group label (uppercase)'],
        ['nav/sidebar/item-font-size','13px, Medium 500','Item label size'],
      ].map(([t,v,u],i) => `<div style="display:grid;grid-template-columns:2fr 1fr 2fr;padding:10px 16px;gap:12px;${i<9?'border-top:1px solid var(--border-subtle)':''}">
        <div style="font-family:var(--font-mono);font-size:11px;color:var(--brand-primary)">${t}</div>
        <div style="font-family:var(--font-mono);font-size:11px;color:var(--content-primary);font-weight:600">${v}</div>
        <div style="font-size:12px;color:var(--content-secondary)">${u}</div>
      </div>`).join('')}
    </div>
  </div>

  <!-- BREADCRUMB -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Breadcrumb</h2></div>
    <p class="doc-section-desc">Breadcrumbs appear at the top of every L1+ page, just below the sidebar (or inline with the page header). The current page crumb is always last — purple and non-clickable. Intermediate crumbs link back up the hierarchy.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Two-level and three-level examples</span></div>
      <div class="inp-demo-stage" style="padding:24px;display:flex;flex-direction:column;gap:16px">
        ${breadcrumb(['Référentiel', 'Produits'])}
        ${breadcrumb(['Référentiel', 'Produits', 'Palette bois standard'])}
        ${breadcrumb(['Référentiel', 'Commandes', 'CMD-2847', 'Modifier'])}
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#430098','brand/primary','Current crumb colour')}
        ${swatch('#757575','content/secondary','Parent crumb colour')}
      </div>
    </div>
    <div class="grid-2" style="margin-top:16px">
      <div class="rule-card accent"><div class="rule-card-title">Max 4 crumbs</div><div class="rule-card-body">Breadcrumbs longer than 4 levels truncate the middle with an ellipsis — keeping the root and the last 2 crumbs always visible.</div></div>
      <div class="rule-card"><div class="rule-card-title">No breadcrumb on L0 pages</div><div class="rule-card-body">Root-level pages (direct sidebar items) do not show a breadcrumb — the sidebar already communicates location.</div></div>
    </div>
  </div>

  <!-- IN-PAGE TABS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">In-page tabs</h2></div>
    <p class="doc-section-desc">Used to switch between sections of the same entity without navigating away — e.g., a product detail page with tabs for General info, Stock, and History. Tabs sit below the page header and above the content area.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Product detail — tab navigation</span></div>
      <div class="inp-demo-stage" style="padding:24px">
        <div style="max-width:600px;margin:0 auto">
          <div style="font-family:var(--font-display);font-size:16px;font-weight:700;color:var(--content-primary);margin-bottom:12px">Palette bois standard</div>
          ${tabBar(['Informations générales', 'Stock & Emplacements', 'Composants', 'Historique'], 0)}
          <div style="padding:20px 0;font-family:Inter,sans-serif;font-size:13px;color:var(--content-tertiary)">Contenu de l'onglet actif…</div>
        </div>
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#430098','brand/primary','Active tab text + underline')}
        ${swatch('#757575','content/secondary','Inactive tab text')}
        ${swatch('#E1E1E1','border/subtle','Tab bottom border')}
      </div>
    </div>
  </div>

  <!-- PAGE HEADER -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Page header</h2></div>
    <p class="doc-section-desc">Every content page has a top bar containing: a back arrow (on L1+ screens), the breadcrumb, and right-side utility buttons (notification bell, profile avatar). This bar is 48px tall and always visible.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Page header anatomy</span></div>
      <div class="inp-demo-stage" style="padding:20px">
        <div style="border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden;background:var(--background-default)">
          <div style="height:48px;background:var(--background-default);border-bottom:1px solid var(--border-subtle);display:flex;align-items:center;padding:0 20px;justify-content:space-between">
            <div style="display:flex;align-items:center;gap:10px">
              <button style="width:30px;height:30px;display:flex;align-items:center;justify-content:center;background:var(--background-subtle);border:1px solid var(--border-subtle);border-radius:7px;cursor:pointer;color:var(--content-secondary)">${BACK}</button>
              ${breadcrumb(['Référentiel', 'Produits', 'Créer un produit'])}
            </div>
            <div style="display:flex;align-items:center;gap:6px">
              <button style="width:30px;height:30px;display:flex;align-items:center;justify-content:center;background:transparent;border:1px solid var(--border-subtle);border-radius:7px;cursor:pointer;color:var(--content-tertiary)">${ICON_SRCH}</button>
              <button style="position:relative;width:30px;height:30px;display:flex;align-items:center;justify-content:center;background:transparent;border:1px solid var(--border-subtle);border-radius:7px;cursor:pointer;color:var(--content-tertiary)">${ICON_BELL}<span style="position:absolute;top:6px;right:6px;width:6px;height:6px;border-radius:50%;background:#E04756;border:1.5px solid var(--background-default)"></span></button>
              <div style="width:1px;height:18px;background:var(--border-subtle)"></div>
              <span style="font-family:Inter,sans-serif;font-size:11px;color:var(--content-tertiary);background:var(--background-subtle);padding:3px 8px;border-radius:9999px;border:1px solid var(--border-subtle)">Admin</span>
              <div style="width:28px;height:28px;border-radius:50%;background:var(--brand-primary);display:flex;align-items:center;justify-content:center;font-family:Inter,sans-serif;font-size:10px;font-weight:700;color:var(--content-on-brand)">MN</div>
            </div>
          </div>
          <div style="height:80px;background:var(--background-subtle);display:flex;align-items:center;justify-content:center">
            <span style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-tertiary)">Content area</span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- HIERARCHY MAP -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Navigation hierarchy</h2></div>
    <div style="margin-top:16px;border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden;background:var(--background-default)">
      <div style="display:grid;grid-template-columns:80px 1fr 2fr;background:var(--background-subtle);padding:10px 16px;gap:12px">
        ${['Level','Pattern','Signal'].map(h=>`<div style="font-size:11px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em">${h}</div>`).join('')}
      </div>
      ${[
        ['L0','Sidebar item (no group)','Active indicator pill. No breadcrumb. No back button.'],
        ['L0+','Sidebar group + sub-item','Sub-item shows dot indicator. Group chevron stays open.'],
        ['L1','Page push (back arrow)','Breadcrumb shows full path. Back arrow returns to L0.'],
        ['L1+','In-page tab','Breadcrumb static. Active tab underline shows current section.'],
        ['L2','Modal','No breadcrumb change. Modal header has its own title + close.'],
      ].map(([lv,pat,sig],i) => `<div style="display:grid;grid-template-columns:80px 1fr 2fr;padding:10px 16px;gap:12px;${i<4?'border-top:1px solid var(--border-subtle)':''}">
        <div style="font-family:var(--font-mono);font-size:11px;color:var(--brand-primary);font-weight:700">${lv}</div>
        <div style="font-size:12px;font-weight:600;color:var(--content-primary)">${pat}</div>
        <div style="font-size:12px;color:var(--content-secondary)">${sig}</div>
      </div>`).join('')}
    </div>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Keep sidebar groups to a maximum of 2 levels deep. Deeper nesting causes disorientation — restructure the IA instead.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use in-page tabs for L0 pages — tabs are for detail views where multiple sections of the same record exist.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Always expand the parent group when a child item is active — never show an active sub-item inside a collapsed group.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't mix navigation levels in the breadcrumb — it should always trace the actual route the user took, not a logical abstraction.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Persist the sidebar collapse preference in localStorage — users who prefer the icon rail should not lose that setting on page refresh.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't put actionable items (create, delete) in the sidebar — it is for navigation only. Actions belong in page headers and toolbars.</div></div>
    </div>
  </div>

  </div>`;
}
