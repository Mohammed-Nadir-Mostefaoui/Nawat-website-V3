import { pageHeader } from '../utils/render.js';

export default function elevation() {
  return pageHeader('Tokens', 'Elevation', 'Four shadow levels that define how surfaces stack — from the resting card to the overlay toast. Each level ships as a Figma Effect Style and a ready-to-use CSS box-shadow string.', [{val:'4',label:'Levels'},{val:'2',label:'Modes'}]) + `<div class="page-body">
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Levels</h2></div>
      <div class="elevation-grid">
        ${[
          { name:'Elevation/Card',     use:'Cards, list rows, sidebar panels.',         pair:'background/surface',  css:'0 1px 2px rgba(0,0,0,.06),\n0 1px 3px rgba(0,0,0,.04)',    shadow:'0 1px 3px rgba(0,0,0,.1)' },
          { name:'Elevation/Dropdown', use:'Dropdowns, tooltips, date pickers.',        pair:'background/raised',   css:'0 4px 8px rgba(0,0,0,.08),\n0 2px 4px rgba(0,0,0,.06)',    shadow:'0 4px 12px rgba(0,0,0,.15)' },
          { name:'Elevation/Modal',    use:'Modals, dialogs, drawers.',                 pair:'background/surface',  css:'0 8px 24px rgba(0,0,0,.10),\n0 4px 8px rgba(0,0,0,.08)',   shadow:'0 12px 32px rgba(0,0,0,.22)' },
          { name:'Elevation/Toast',    use:'Toasts, notifications, FABs.',             pair:'background/surface',  css:'0 16px 40px rgba(0,0,0,.14),\n0 6px 12px rgba(0,0,0,.10)', shadow:'0 20px 48px rgba(0,0,0,.28)' },
        ].map(e => `
          <div class="elevation-card">
            <div class="elevation-stage">
              <div class="elevation-surface" style="box-shadow:${e.shadow}">${e.name.replace('Elevation/','')}</div>
            </div>
            <div class="elevation-info">
              <div class="elevation-name">${e.name}</div>
              <div class="elevation-use">${e.use}</div>
              <div class="elevation-pair">↳ ${e.pair}</div>
              <div class="elevation-css-val">${e.css}</div>
            </div>
          </div>`).join('')}
      </div>
    </div>
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Architecture</h2></div>
      <div class="grid-2">
        <div class="rule-card accent">
          <div class="rule-card-title">Current: STRING + Effect Styles</div>
          <div class="rule-card-body">Figma doesn't support variable-bound effects yet. The Elevation collection stores CSS values as STRING tokens for dev handoff. Designers apply via the Styles panel (<code>Elevation/Card</code>, etc.).</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Future: variable-bound effects</div>
          <div class="rule-card-body">When Figma ships variable-bound effect styles, the STRING tokens map directly. Style names already match token names — migration is a single rebind per style. Zero renaming needed.</div>
        </div>
      </div>
    </div>
  </div>`;
}
