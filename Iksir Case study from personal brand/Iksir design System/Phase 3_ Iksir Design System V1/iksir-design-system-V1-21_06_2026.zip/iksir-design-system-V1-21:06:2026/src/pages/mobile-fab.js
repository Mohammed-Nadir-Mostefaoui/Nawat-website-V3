import { pageHeader } from '../utils/render.js';

export default function mobileFab() {
  return pageHeader(
    'Platform',
    'Floating Action Button',
    'Placement rules, token map, variants, and interaction guidelines for the FAB in Iksir mobile screens.'
  ) + `<div class="page-body">

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">What is a FAB?</h2>
      </div>
      <p class="doc-section-desc">The Floating Action Button (FAB) is the single highest-priority action on a screen. It floats above the content layer and stays fixed in the bottom-right corner. Task Master uses the FAB exclusively for "create new" actions — creating a task, starting a scan session, or opening a new order.</p>
      <div class="grid-2" style="margin-top:16px">
        <div class="rule-card accent">
          <div class="rule-card-title">One FAB per screen</div>
          <div class="rule-card-body">Never show two FABs simultaneously. If a screen has multiple primary actions, use a speed dial (expanded FAB with sub-actions) or move secondary actions to a bottom sheet triggered by the FAB.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Create / initiate actions only</div>
          <div class="rule-card-body">The FAB is for primary forward actions: "Create task", "Start scan", "Add order". It is not for editing, filtering, or navigating. Destructive actions (delete, archive) must never be in a FAB.</div>
        </div>
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Placement</h2>
      </div>
      <p class="doc-section-desc">The FAB sits in the bottom-right corner, above the tab bar and safe area. Position is fixed — it does not scroll with content.</p>
      <div class="grid-2" style="margin-top:16px">
        <div class="rule-card">
          <div class="rule-card-title">Horizontal position</div>
          <div class="rule-card-body">Right edge: <code>margin-right = 16px</code> from the screen edge (safe area side insets are 0 on iPhone 14, so this is from the physical edge).</div>
        </div>
        <div class="rule-card accent">
          <div class="rule-card-title">Vertical position</div>
          <div class="rule-card-body"><code>margin-bottom = 16px</code> above the tab bar. Stack: physical bottom → home indicator (34px) → tab bar (56px) → FAB margin (16px) → FAB (56px). Total from physical bottom: 162px.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">On screens without a tab bar</div>
          <div class="rule-card-body">If the screen suppresses the tab bar (e.g., a full-screen scan overlay), <code>margin-bottom</code> is 16px above the home indicator safe area only (not above tab bar height).</div>
        </div>
        <div class="rule-card accent">
          <div class="rule-card-title">Scroll behaviour</div>
          <div class="rule-card-body">FAB is sticky — it does not scroll. When the user scrolls down quickly, the FAB can shrink to an icon-only version (56→40px) to reduce occlusion. It re-expands when scrolling stops.</div>
        </div>
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Token map</h2>
      </div>
      <div style="margin-top:16px;border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden">
        <div style="display:grid;grid-template-columns:2fr 1fr 2fr;background:var(--background-subtle);padding:10px 16px;gap:12px">
          ${['Token','Value','Notes'].map(h => `<div style="font-size:11px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em">${h}</div>`).join('')}
        </div>
        ${[
          ['component/fab/size','56px','Touch target and visual size. Minimum — never smaller.'],
          ['component/fab/size-mini','40px','Collapsed state during active scroll.'],
          ['component/fab/icon-size','24px','Icon inside the FAB. Centred.'],
          ['component/fab/radius','9999px','Fully circular. Never use a fixed px radius.'],
          ['component/fab/shadow','Elevation/3','FAB always has elevation. Token maps to box-shadow.'],
          ['component/fab/bg','Brand/primary','Fill. Uses brand purple.'],
          ['component/fab/icon-color','White','Icon is always white on brand background.'],
          ['component/fab/margin-right','16px','From screen or safe-area edge.'],
          ['component/fab/margin-bottom','16px','From the bottom of the tab bar (or safe area if no tab bar).'],
        ].map(([token, value, notes], i) => `
        <div style="display:grid;grid-template-columns:2fr 1fr 2fr;padding:10px 16px;gap:12px;${i < 8 ? 'border-top:1px solid var(--border-subtle)' : ''}">
          <div style="font-family:var(--font-mono);font-size:11px;color:var(--brand-primary)">${token}</div>
          <div style="font-family:var(--font-mono);font-size:11px;color:var(--content-primary);font-weight:600">${value}</div>
          <div style="font-size:12px;color:var(--content-secondary)">${notes}</div>
        </div>`).join('')}
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">States</h2>
      </div>
      <div class="grid-2" style="margin-top:16px">
        <div class="rule-card">
          <div class="rule-card-title">Default</div>
          <div class="rule-card-body">56px circle, brand purple fill, white icon, Elevation/3 shadow. Resting state.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Pressed</div>
          <div class="rule-card-body">Scale 0.94. Shadow drops to Elevation/1. Background darkens by 8% (brand-primary-pressed token). Duration: 100ms ease-in-out.</div>
        </div>
        <div class="rule-card accent">
          <div class="rule-card-title">Loading</div>
          <div class="rule-card-body">Spinner replaces icon. FAB stays in place and is not tappable during loading. Use for async actions (e.g., saving a task to server). Spinner is white on brand background.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Scrolling (collapsed)</div>
          <div class="rule-card-body">40px circle, icon only (no label), same position. Transition: 200ms ease-out. Label fades out with opacity: 0 before size shrinks.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Disabled</div>
          <div class="rule-card-body">Avoid putting the FAB in a disabled state — if the action is not available, hide the FAB entirely. A grayed-out FAB with no tooltip creates confusion on mobile.</div>
        </div>
        <div class="rule-card accent">
          <div class="rule-card-title">Extended (label)</div>
          <div class="rule-card-body">When extra context helps (e.g., first-time user), the FAB can extend to show a label: [icon] [Label]. Pill shape, same height (56px). Shrinks to icon-only after first use (stored in local preferences).</div>
        </div>
      </div>
    </div>

  </div>`;
}
