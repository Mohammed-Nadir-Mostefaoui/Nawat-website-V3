import { pageHeader } from '../utils/render.js';

/* ── Chart colour palette ──────────────────────────────────── */
const C = {
  p1:  '#430098', // brand purple
  p2:  '#7B4DB7', // purple-70
  p3:  '#AF65FF', // light-purple-100
  p4:  '#D9CCEA', // purple-20
  g1:  '#148F47', // green
  a1:  '#E19614', // amber
  r1:  '#D8192C', // red
  b1:  '#0550AE', // blue
  muted: '#8C80A3',
};

/* ── Shared chart helpers ──────────────────────────────────── */
function hLine(y, w = 320, label = '', color = 'var(--border-subtle)') {
  return `<line x1="40" y1="${y}" x2="${40 + w}" y2="${y}" stroke="${color}" stroke-width="1"/>
  ${label ? `<text x="34" y="${y + 4}" text-anchor="end" font-size="9" fill="var(--content-tertiary)" font-family="var(--font-mono)">${label}</text>` : ''}`;
}

function xLabel(x, y, text) {
  return `<text x="${x}" y="${y}" text-anchor="middle" font-size="9" fill="var(--content-tertiary)" font-family="var(--font-mono)">${text}</text>`;
}

/* ── Line chart ────────────────────────────────────────────── */
function buildLinePath(pts, smooth = true) {
  if (!smooth) return 'M' + pts.map(([x,y]) => `${x},${y}`).join('L');
  let d = `M${pts[0][0]},${pts[0][1]}`;
  for (let i = 1; i < pts.length; i++) {
    const [x0,y0] = pts[i-1];
    const [x1,y1] = pts[i];
    const cx = (x0 + x1) / 2;
    d += ` C${cx},${y0} ${cx},${y1} ${x1},${y1}`;
  }
  return d;
}

function buildAreaPath(pts, baseline) {
  const line = buildLinePath(pts);
  return `${line} L${pts[pts.length-1][0]},${baseline} L${pts[0][0]},${baseline} Z`;
}

/* ── Donut helpers ─────────────────────────────────────────── */
function polarToXY(cx, cy, r, angle) {
  const rad = (angle - 90) * Math.PI / 180;
  return [cx + r * Math.cos(rad), cy + r * Math.sin(rad)];
}
function donutSlice(cx, cy, r, inner, startAngle, endAngle, color, id = '') {
  const [x1,y1] = polarToXY(cx, cy, r, startAngle);
  const [x2,y2] = polarToXY(cx, cy, r, endAngle);
  const [ix1,iy1] = polarToXY(cx, cy, inner, startAngle);
  const [ix2,iy2] = polarToXY(cx, cy, inner, endAngle);
  const large = endAngle - startAngle > 180 ? 1 : 0;
  return `<path d="M${x1},${y1} A${r},${r} 0 ${large} 1 ${x2},${y2} L${ix2},${iy2} A${inner},${inner} 0 ${large} 0 ${ix1},${iy1} Z"
    fill="${color}" ${id ? `id="${id}"` : ''} style="transition:opacity 0.15s"/>`;
}

/* ── Token swatch ──────────────────────────────────────────── */
function swatch(color, name, label) {
  return `<div class="btn-token-item">
    <div class="btn-token-swatch" style="background:${color}"></div>
    <div><div class="btn-token-name">${name}</div><div class="btn-token-label">${label}</div></div>
  </div>`;
}

/* ── Phone chrome wrapper ──────────────────────────────────── */
function phoneChromeWrap(inner, appTitle = 'Analytics') {
  return `<div style="width:280px;border-radius:40px;overflow:hidden;box-shadow:0 20px 48px rgba(0,0,0,0.22),0 0 0 1px rgba(0,0,0,0.08);flex-shrink:0">
    <div style="height:30px;background:var(--background-default);display:flex;align-items:center;justify-content:space-between;padding:0 18px">
      <span style="font-size:11px;font-weight:700;font-family:Inter,sans-serif;color:var(--content-primary)">9:41</span>
      <div style="display:flex;gap:4px;align-items:center;color:var(--content-primary)">
        <svg width="13" height="9" viewBox="0 0 24 18" fill="none"><rect x="0" y="6" width="4" height="12" rx="1" fill="currentColor" opacity="0.4"/><rect x="6" y="4" width="4" height="14" rx="1" fill="currentColor" opacity="0.6"/><rect x="12" y="1" width="4" height="17" rx="1" fill="currentColor" opacity="0.8"/><rect x="18" y="0" width="4" height="18" rx="1" fill="currentColor"/></svg>
        <svg width="15" height="9" viewBox="0 0 24 16" fill="none"><rect x="2" y="4" width="17" height="10" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M20 7v4a2 2 0 0 0 0-4z" fill="currentColor" opacity="0.5"/><rect x="4" y="6" width="11" height="6" rx="1" fill="currentColor"/></svg>
      </div>
    </div>
    <div style="height:44px;background:var(--background-default);border-bottom:1px solid var(--border-subtle);display:flex;align-items:center;padding:0 16px">
      <span style="font-family:var(--font-display);font-size:15px;font-weight:700;color:var(--content-primary)">${appTitle}</span>
    </div>
    <div style="background:var(--background-subtle);padding:16px;min-height:300px">
      ${inner}
    </div>
    <div style="height:16px;background:var(--background-subtle);display:flex;align-items:center;justify-content:center;padding-bottom:4px">
      <div style="width:100px;height:4px;border-radius:2px;background:var(--content-primary);opacity:0.2"></div>
    </div>
  </div>`;
}

/* ══════════════════════════════════════════════════════════════
   SECTION 1 — LINE CHART
══════════════════════════════════════════════════════════════ */
const LINE_DATA = [28, 42, 38, 55, 48, 67, 72, 60, 80, 74, 88, 95];
const LINE_MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const LINE_W = 320, LINE_H = 160, LINE_PAD = 40, LINE_TOP = 16, LINE_BOT = 28;
const LINE_Y0 = LINE_TOP, LINE_Y1 = LINE_H - LINE_BOT;
const LINE_X0 = LINE_PAD, LINE_X1 = LINE_PAD + LINE_W;

function linePts(data, xScale = 1) {
  const min = 0, max = 100;
  return data.map((v, i) => [
    LINE_X0 + (i / (data.length - 1)) * LINE_W * xScale,
    LINE_Y0 + (1 - (v - min) / (max - min)) * (LINE_Y1 - LINE_Y0)
  ]);
}

const LINE_SECONDARY = [18, 30, 25, 40, 35, 48, 52, 44, 58, 52, 64, 70];

function lineChartSVG(data, data2 = null, w = 380, compact = false) {
  const pts  = linePts(data);
  const path = buildLinePath(pts);
  const area = buildAreaPath(pts, LINE_Y1);
  const pts2  = data2 ? linePts(data2) : null;
  const path2 = pts2 ? buildLinePath(pts2) : '';
  const svgH  = compact ? 130 : LINE_H + 20;
  const scale = w / (LINE_W + LINE_PAD + 10);

  return `<svg viewBox="0 0 ${LINE_W + LINE_PAD + 10} ${svgH}" style="width:100%;height:auto;overflow:visible">
    <defs>
      <linearGradient id="lc-grad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${C.p1}" stop-opacity="0.18"/>
        <stop offset="100%" stop-color="${C.p1}" stop-opacity="0"/>
      </linearGradient>
    </defs>
    <!-- grid -->
    ${[0,25,50,75,100].map((v,i) => {
      const y = LINE_Y0 + (1 - v/100) * (LINE_Y1 - LINE_Y0);
      return hLine(y, LINE_W, compact ? '' : v+'%');
    }).join('')}
    <!-- x labels -->
    ${compact
      ? [0,3,6,9,11].map(i => xLabel(LINE_X0 + (i/(data.length-1))*LINE_W, LINE_Y1+14, LINE_MONTHS[i])).join('')
      : LINE_MONTHS.map((m,i) => xLabel(LINE_X0 + (i/(data.length-1))*LINE_W, LINE_Y1+14, m)).join('')
    }
    <!-- area fill -->
    <path d="${area}" fill="url(#lc-grad)"/>
    <!-- secondary line -->
    ${pts2 ? `<path d="${path2}" fill="none" stroke="${C.p3}" stroke-width="1.5" stroke-dasharray="4,3" stroke-linecap="round" stroke-linejoin="round" opacity="0.8"/>` : ''}
    <!-- primary line -->
    <path d="${path}" fill="none" stroke="${C.p1}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <!-- data points -->
    ${pts.map(([x,y], i) => `
      <circle cx="${x}" cy="${y}" r="3" fill="${C.p1}" stroke="white" stroke-width="1.5"
        style="cursor:pointer;transition:r 0.15s"
        onmouseenter="(function(el,e){
          el.setAttribute('r','5');
          var t=document.getElementById('lc-tt');
          if(t){t.style.display='block';t.style.left=(e.offsetX+8)+'px';t.style.top=(e.offsetY-32)+'px';t.querySelector('.lc-tt-val').textContent='${data[i]}%';t.querySelector('.lc-tt-label').textContent='${LINE_MONTHS[i]}';}})(this,event)"
        onmouseleave="(function(el){el.setAttribute('r','3');var t=document.getElementById('lc-tt');if(t)t.style.display='none';})(this)"
      />`).join('')}
    <!-- last point highlight -->
    <circle cx="${pts[pts.length-1][0]}" cy="${pts[pts.length-1][1]}" r="5" fill="${C.p1}" stroke="white" stroke-width="2"/>
  </svg>`;
}

function lineChartMobile() {
  const pts = LINE_DATA.slice(0,7).map((v,i) => [
    14 + i * 34,
    12 + (1 - v/100) * 80
  ]);
  const pathD = buildLinePath(pts);
  const areaD = buildAreaPath(pts, 92);
  return `<div style="background:var(--background-default);border-radius:12px;padding:12px">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">
      <div>
        <div style="font-size:10px;color:var(--content-tertiary);font-family:Inter,sans-serif">Total Orders</div>
        <div style="font-size:18px;font-weight:700;color:var(--content-primary);font-family:var(--font-display);line-height:1.1">+24.6%</div>
      </div>
      <div style="background:var(--status-success-bg);color:var(--status-success-content);font-size:9px;padding:2px 6px;border-radius:20px;font-weight:600;font-family:Inter,sans-serif">▲ 4.2%</div>
    </div>
    <svg viewBox="0 0 244 110" style="width:100%;height:auto;overflow:visible">
      <defs>
        <linearGradient id="mob-lc-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${C.p1}" stop-opacity="0.2"/>
          <stop offset="100%" stop-color="${C.p1}" stop-opacity="0"/>
        </linearGradient>
      </defs>
      ${[0,33,67,100].map(v => {
        const y = 12 + (1 - v/100) * 80;
        return `<line x1="14" y1="${y}" x2="230" y2="${y}" stroke="var(--border-subtle)" stroke-width="0.5"/>`;
      }).join('')}
      <path d="${areaD}" fill="url(#mob-lc-grad)"/>
      <path d="${pathD}" fill="none" stroke="${C.p1}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      ${pts.map(([x,y],i) => `<circle cx="${x}" cy="${y}" r="2.5" fill="${C.p1}" stroke="white" stroke-width="1.5"/>`).join('')}
      ${['Jan','Feb','Mar','Apr','May','Jun','Jul'].map((m,i) => `<text x="${14 + i*34}" y="105" text-anchor="middle" font-size="8" fill="var(--content-tertiary)" font-family="var(--font-mono)">${m}</text>`).join('')}
    </svg>
  </div>`;
}

/* ══════════════════════════════════════════════════════════════
   SECTION 2 — BAR CHART
══════════════════════════════════════════════════════════════ */
const BAR_CATS  = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
const BAR_DATA  = [44, 72, 58, 85, 66, 91, 48];
const BAR_DATA2 = [28, 55, 40, 60, 45, 74, 32];

function barChartSVG(grouped = false) {
  const W = 360, H = 160, PAD_L = 40, PAD_B = 26, TOP = 14;
  const chartW = W - PAD_L - 8;
  const chartH = H - PAD_B - TOP;
  const barGroupW = chartW / BAR_CATS.length;
  const barW = grouped ? barGroupW * 0.35 : barGroupW * 0.6;
  const gap  = grouped ? 2 : 0;

  const bars = BAR_CATS.map((cat, i) => {
    const gx = PAD_L + i * barGroupW + barGroupW / 2;
    const h1 = (BAR_DATA[i] / 100) * chartH;
    const h2 = grouped ? (BAR_DATA2[i] / 100) * chartH : 0;

    if (grouped) {
      const x1 = gx - barW - gap;
      const x2 = gx + gap;
      return `
        <rect x="${x1}" y="${TOP + chartH - h1}" width="${barW}" height="${h1}" rx="3" fill="${C.p1}" style="transition:opacity 0.15s"
          onmouseenter="this.style.opacity='0.8'" onmouseleave="this.style.opacity='1'"/>
        <rect x="${x2}" y="${TOP + chartH - h2}" width="${barW}" height="${h2}" rx="3" fill="${C.p3}" style="transition:opacity 0.15s"
          onmouseenter="this.style.opacity='0.8'" onmouseleave="this.style.opacity='1'"/>
      `;
    } else {
      const x = gx - barW / 2;
      return `<rect x="${x}" y="${TOP + chartH - h1}" width="${barW}" height="${h1}" rx="3" fill="${C.p1}" style="transition:opacity 0.15s"
        onmouseenter="this.style.opacity='0.8'" onmouseleave="this.style.opacity='1'"/>`;
    }
  });

  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto;overflow:visible">
    ${[0,25,50,75,100].map(v => {
      const y = TOP + chartH * (1 - v / 100);
      return hLine(y, W - PAD_L - 8, v+'%');
    }).join('')}
    ${BAR_CATS.map((c,i) => xLabel(PAD_L + i * barGroupW + barGroupW/2, H - 10, c)).join('')}
    ${bars.join('')}
  </svg>`;
}

function barChartMobile() {
  const cats = BAR_CATS.slice(0, 5);
  const data = BAR_DATA.slice(0, 5);
  const H = 100, W = 228, PAD_L = 28, PAD_B = 22, TOP = 8;
  const chartW = W - PAD_L - 4;
  const chartH = H - PAD_B - TOP;
  const barW_full = chartW / cats.length;
  const barW = barW_full * 0.55;

  return `<div style="background:var(--background-default);border-radius:12px;padding:12px">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
      <div style="font-size:11px;font-weight:600;color:var(--content-primary);font-family:Inter,sans-serif">Weekly Activity</div>
      <div style="font-size:9px;color:var(--content-tertiary);font-family:Inter,sans-serif">This week</div>
    </div>
    <svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto">
      ${[0,50,100].map(v => {
        const y = TOP + chartH * (1 - v/100);
        return `<line x1="${PAD_L}" y1="${y}" x2="${W-4}" y2="${y}" stroke="var(--border-subtle)" stroke-width="0.5"/>`;
      }).join('')}
      ${cats.map((c,i) => {
        const h = (data[i]/100)*chartH;
        const x = PAD_L + i*barW_full + barW_full/2 - barW/2;
        return `<rect x="${x}" y="${TOP+chartH-h}" width="${barW}" height="${h}" rx="2" fill="${C.p1}" opacity="${i===3?'1':'0.5'}"/>
        <text x="${PAD_L + i*barW_full + barW_full/2}" y="${H-8}" text-anchor="middle" font-size="8" fill="var(--content-tertiary)" font-family="var(--font-mono)">${c}</text>`;
      }).join('')}
    </svg>
  </div>`;
}

/* ══════════════════════════════════════════════════════════════
   SECTION 3 — DONUT CHART
══════════════════════════════════════════════════════════════ */
const DONUT_DATA = [
  { label: 'Delivered',  val: 42, color: C.p1 },
  { label: 'In Transit', val: 28, color: C.p3 },
  { label: 'Pending',    val: 18, color: C.a1 },
  { label: 'Failed',     val: 12, color: C.r1 },
];

/* Returns just the donut circle SVG — legend is rendered as HTML alongside it */
function donutChartSVG(size = 'md') {
  const configs = {
    sm: { cx:56, cy:56, r:44, inner:28, vw:112, vh:112, fs1:16, fs2:8 },
    md: { cx:80, cy:80, r:62, inner:40, vw:160, vh:160, fs1:22, fs2:9 },
    lg: { cx:96, cy:96, r:78, inner:50, vw:192, vh:192, fs1:26, fs2:10 },
  };
  const c = configs[size] || configs.md;
  const total = DONUT_DATA.reduce((s,d) => s + d.val, 0);
  let current = -90;
  const slices = DONUT_DATA.map((d, i) => {
    const sweep = (d.val / total) * 360;
    const start = current;
    current += sweep + 1.5;
    return donutSlice(c.cx, c.cy, c.r, c.inner, start, start + sweep, d.color, `donut-slice-${i}`);
  });
  return `<svg viewBox="0 0 ${c.vw} ${c.vh}" style="width:${c.vw}px;height:${c.vh}px;flex-shrink:0">
    ${slices.join('\n')}
    <text x="${c.cx}" y="${c.cy - 4}" text-anchor="middle" font-size="${c.fs1}" font-weight="700" fill="var(--content-primary)" font-family="var(--font-display)">100%</text>
    <text x="${c.cx}" y="${c.cy + c.fs2 + 4}" text-anchor="middle" font-size="${c.fs2}" fill="var(--content-tertiary)" font-family="Inter,sans-serif">Orders</text>
  </svg>`;
}

function donutLegendHTML() {
  return DONUT_DATA.map(d => `
    <div style="display:flex;align-items:center;gap:8px">
      <div style="width:10px;height:10px;border-radius:3px;background:${d.color};flex-shrink:0"></div>
      <div style="display:flex;flex-direction:column">
        <span style="font-size:12px;font-weight:600;color:var(--content-primary);font-family:Inter,sans-serif;white-space:nowrap">${d.label}</span>
        <span style="font-size:10px;color:var(--content-tertiary);font-family:var(--font-mono)">${d.val}%</span>
      </div>
    </div>`).join('');
}

function donutMobile() {
  const total = DONUT_DATA.reduce((s,d) => s + d.val, 0);
  let current = -90;
  const slices = DONUT_DATA.map(d => {
    const sweep = (d.val / total) * 360;
    const start = current;
    current += sweep + 1;
    return donutSlice(56, 56, 44, 28, start, start + sweep, d.color);
  });

  return `<div style="background:var(--background-default);border-radius:12px;padding:12px">
    <div style="font-size:11px;font-weight:600;color:var(--content-primary);margin-bottom:8px;font-family:Inter,sans-serif">Order Status</div>
    <div style="display:flex;align-items:center;gap:12px">
      <svg viewBox="0 0 112 112" style="width:88px;height:88px;flex-shrink:0">
        ${slices.join('\n')}
        <text x="56" y="52" text-anchor="middle" font-size="13" font-weight="700" fill="var(--content-primary)" font-family="var(--font-display)">42%</text>
        <text x="56" y="64" text-anchor="middle" font-size="8" fill="var(--content-tertiary)" font-family="Inter,sans-serif">on time</text>
      </svg>
      <div style="flex:1;display:flex;flex-direction:column;gap:5px">
        ${DONUT_DATA.map(d => `
          <div style="display:flex;align-items:center;gap:5px">
            <div style="width:7px;height:7px;border-radius:2px;background:${d.color};flex-shrink:0"></div>
            <span style="font-size:9px;color:var(--content-secondary);font-family:Inter,sans-serif;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${d.label}</span>
            <span style="font-size:9px;font-weight:600;color:var(--content-primary);font-family:var(--font-mono);flex-shrink:0">${d.val}%</span>
          </div>`).join('')}
      </div>
    </div>
  </div>`;
}

/* ══════════════════════════════════════════════════════════════
   SECTION 4 — AREA CHART
══════════════════════════════════════════════════════════════ */
const AREA_DATA  = [12, 18, 15, 24, 30, 26, 38, 42, 36, 52, 48, 60];
const AREA_DATA2 = [8,  12, 10, 16, 20, 18, 26, 30, 24, 36, 32, 44];

function areaChartSVG() {
  const W = 360, H = 150, PAD_L = 40, PAD_B = 28, TOP = 14;
  const cW = W - PAD_L - 8, cH = H - PAD_B - TOP;
  const maxVal = 70;

  function pts(data) {
    return data.map((v,i) => [
      PAD_L + (i/(data.length-1))*cW,
      TOP + (1 - v/maxVal) * cH
    ]);
  }

  const pts1 = pts(AREA_DATA);
  const pts2 = pts(AREA_DATA2);
  const path1 = buildLinePath(pts1);
  const path2 = buildLinePath(pts2);
  const area1 = buildAreaPath(pts1, TOP + cH);
  const area2 = buildAreaPath(pts2, TOP + cH);

  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto;overflow:visible">
    <defs>
      <linearGradient id="area-grad1" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${C.p1}" stop-opacity="0.22"/>
        <stop offset="100%" stop-color="${C.p1}" stop-opacity="0"/>
      </linearGradient>
      <linearGradient id="area-grad2" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${C.p3}" stop-opacity="0.18"/>
        <stop offset="100%" stop-color="${C.p3}" stop-opacity="0"/>
      </linearGradient>
    </defs>
    ${[0,25,50,75].map(v => {
      const y = TOP + cH * (1 - v/maxVal * (maxVal/75));
      return hLine(y, cW, Math.round(v * maxVal / 75) + '');
    }).join('')}
    ${LINE_MONTHS.map((m,i) => xLabel(PAD_L + (i/(AREA_DATA.length-1))*cW, H-8, m)).join('')}
    <path d="${area2}" fill="url(#area-grad2)"/>
    <path d="${area1}" fill="url(#area-grad1)"/>
    <path d="${path2}" fill="none" stroke="${C.p3}" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" opacity="0.8"/>
    <path d="${path1}" fill="none" stroke="${C.p1}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    ${pts1.map(([x,y]) => `<circle cx="${x}" cy="${y}" r="2.5" fill="${C.p1}" stroke="white" stroke-width="1.5"/>`).join('')}
  </svg>`;
}

/* ══════════════════════════════════════════════════════════════
   SECTION 5 — SPARKLINES
══════════════════════════════════════════════════════════════ */
function sparkline(data, color = C.p1, w = 80, h = 32) {
  const min = Math.min(...data), max = Math.max(...data);
  const pts = data.map((v, i) => [
    i / (data.length - 1) * w,
    h - 4 - ((v - min) / (max - min || 1)) * (h - 8)
  ]);
  const path = buildLinePath(pts, false);
  const area = buildAreaPath(pts, h);
  return `<svg viewBox="0 0 ${w} ${h}" style="width:${w}px;height:${h}px;flex-shrink:0">
    <defs>
      <linearGradient id="sp-grad-${color.replace('#','')}" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${color}" stop-opacity="0.18"/>
        <stop offset="100%" stop-color="${color}" stop-opacity="0"/>
      </linearGradient>
    </defs>
    <path d="${area}" fill="url(#sp-grad-${color.replace('#','')})" />
    <path d="${path}" fill="none" stroke="${color}" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <circle cx="${pts[pts.length-1][0]}" cy="${pts[pts.length-1][1]}" r="2.5" fill="${color}" stroke="white" stroke-width="1.5"/>
  </svg>`;
}

function sparkCard(title, value, change, positive, data, color) {
  const icon = positive ? '▲' : '▼';
  const changeColor = positive ? C.g1 : C.r1;
  return `<div style="background:var(--background-default);border:1px solid var(--border-subtle);border-radius:10px;padding:14px 16px;display:flex;align-items:center;justify-content:space-between;gap:16px;min-width:200px;flex:1">
    <div>
      <div style="font-size:11px;color:var(--content-tertiary);font-family:Inter,sans-serif;margin-bottom:4px">${title}</div>
      <div style="font-size:20px;font-weight:700;color:var(--content-primary);font-family:var(--font-display);line-height:1.1">${value}</div>
      <div style="font-size:11px;font-weight:500;margin-top:3px;font-family:Inter,sans-serif;color:${changeColor}">${icon} ${change}</div>
    </div>
    ${sparkline(data, color)}
  </div>`;
}

/* ══════════════════════════════════════════════════════════════
   SECTION 6 — STACKED BAR
══════════════════════════════════════════════════════════════ */
const STACK_WEEKS = ['W1','W2','W3','W4','W5','W6'];
const STACK_DATA = [
  [30,25,20,35,28,32], // Delivered
  [20,18,22,15,24,18], // In Transit
  [10,12,8,12,10,14],  // Pending
];
const STACK_COLORS = [C.p1, C.p3, C.a1];
const STACK_LABELS = ['Delivered','In Transit','Pending'];

function stackedBarSVG() {
  const W = 360, H = 160, PAD_L = 40, PAD_B = 26, TOP = 14;
  const cW = W - PAD_L - 8, cH = H - PAD_B - TOP;
  const maxStack = Math.max(...STACK_WEEKS.map((_,i) =>
    STACK_DATA.reduce((s,row) => s + row[i], 0)
  ));
  const barGroupW = cW / STACK_WEEKS.length;
  const barW = barGroupW * 0.6;

  const bars = STACK_WEEKS.map((w, i) => {
    let y = TOP + cH;
    return STACK_DATA.map((row, si) => {
      const h = (row[i] / maxStack) * cH;
      y -= h;
      return `<rect x="${PAD_L + i*barGroupW + barGroupW/2 - barW/2}" y="${y}" width="${barW}" height="${h}" rx="${si===0?'0 0 3 3':si===STACK_DATA.length-1?'3 3 0 0':'0'}" fill="${STACK_COLORS[si]}" style="transition:opacity 0.15s" onmouseenter="this.style.opacity='0.8'" onmouseleave="this.style.opacity='1'"/>`;
    }).reverse().join('');
  });

  const legend = STACK_LABELS.map((l,i) =>
    `<rect x="${40 + i*100}" y="2" width="8" height="8" rx="2" fill="${STACK_COLORS[i]}"/>
     <text x="${40 + i*100 + 12}" y="10" font-size="9" fill="var(--content-secondary)" font-family="Inter,sans-serif">${l}</text>`
  ).join('');

  return `<svg viewBox="0 0 ${W} ${H+18}" style="width:100%;height:auto;overflow:visible">
    ${[0,25,50,75,100].map(v => {
      const y = TOP + cH * (1 - v/100);
      return hLine(y, cW, Math.round(v * maxStack / 100) + '');
    }).join('')}
    ${STACK_WEEKS.map((w,i) => xLabel(PAD_L + i*barGroupW + barGroupW/2, H-8, w)).join('')}
    ${bars.join('')}
    ${legend}
  </svg>`;
}

/* ══════════════════════════════════════════════════════════════
   PAGE EXPORT
══════════════════════════════════════════════════════════════ */
export default function chartsPage() {
  return pageHeader('Patterns', 'Charts', 'Data visualisation components — line, bar, donut, area, and sparkline charts, all built with the design system\'s token palette. Includes mobile-first patterns for small-screen contexts.', [
    { val: '5',  label: 'Chart Types' },
    { val: '12', label: 'Color Tokens' },
    { val: '2',  label: 'Density Modes' },
  ]) + `<div class="page-body">

  <style>
    .chart-tt {
      position:absolute;display:none;background:var(--background-inverse);color:var(--content-inverse);
      padding:6px 10px;border-radius:6px;font-size:11px;font-family:Inter,sans-serif;
      pointer-events:none;z-index:100;box-shadow:0 4px 12px rgba(0,0,0,0.2);white-space:nowrap;
    }
    .chart-legend { display:flex;gap:16px;flex-wrap:wrap;margin-top:12px; }
    .chart-legend-item { display:flex;align-items:center;gap:6px;font-size:11px;color:var(--content-secondary);font-family:Inter,sans-serif; }
    .chart-legend-dot { width:10px;height:10px;border-radius:50%;flex-shrink:0; }
    .chart-section-inner { display:flex;gap:32px;align-items:flex-start;flex-wrap:wrap; }
    .chart-desktop-wrap { flex:1;min-width:280px; }
    .chart-mobile-wrap { display:flex;flex-direction:column;gap:12px;align-items:flex-start; }
    .chart-mobile-label { font-size:10px;font-weight:600;color:var(--content-tertiary);letter-spacing:0.06em;text-transform:uppercase;font-family:Inter,sans-serif;margin-bottom:4px; }
    .sparkline-grid { display:grid;grid-template-columns:1fr 1fr;gap:12px;width:100%; }
    /* Charts page: all demo stages stack vertically */
    .charts-stage { flex-direction:column !important;align-items:stretch !important; }
    .donut-layout { display:flex;align-items:center;gap:40px;flex-wrap:wrap;justify-content:center; }
    .donut-legend { display:flex;flex-direction:column;gap:14px; }
  </style>

  <!-- ── SECTION 1: Line Chart ─────────────────────────────── -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Line Chart</h2></div>
    <p class="doc-section-desc">Ideal for continuous data over time. Use a single line for one metric, or add a secondary dashed line for comparison. The area fill reinforces the primary series without competing with it.</p>

    <div class="inp-section-demo" style="overflow:visible">
      <div class="inp-demo-toolbar" style="border-radius:8px 8px 0 0">
        <span class="inp-demo-title">Monthly performance — hover points for detail</span>
        <div class="inp-demo-controls">
          <span class="inp-demo-meta">Series</span>
          <select class="inp-state-select" onchange="chartLineToggle(this.value)">
            <option value="single">Single</option>
            <option value="compare">Comparison</option>
          </select>
        </div>
      </div>
      <div class="inp-demo-stage charts-stage" style="padding:24px 20px;position:relative" id="line-chart-stage">
        <div id="lc-tt" class="chart-tt">
          <div class="lc-tt-label" style="opacity:0.7;font-size:10px"></div>
          <div class="lc-tt-val" style="font-weight:700"></div>
        </div>
        ${lineChartSVG(LINE_DATA)}
        <div class="chart-legend" id="line-legend">
          <div class="chart-legend-item"><div class="chart-legend-dot" style="background:${C.p1}"></div>Revenue</div>
        </div>
      </div>
    </div>

    <!-- Mobile -->
    <div class="doc-section-subsection" style="margin-top:24px">
      <h3 style="font-size:13px;font-weight:600;color:var(--content-secondary);margin:0 0 12px;font-family:Inter,sans-serif">Mobile variant</h3>
      <div class="chart-section-inner">
        <div class="chart-desktop-wrap">
          <p style="font-size:13px;color:var(--content-secondary);line-height:1.6;margin:0 0 12px;font-family:Inter,sans-serif">On mobile, charts live inside card components. Reduce axis labels to key intervals only, increase touch-target radius of data points to 6px minimum, and always pair the chart with a headline KPI number so the insight is instantly readable without reading the axes.</p>
          <div style="background:var(--background-subtle);border-radius:12px;padding:16px;font-size:12px;font-family:Inter,sans-serif;line-height:1.7;color:var(--content-secondary)">
            <div style="font-weight:600;color:var(--content-primary);margin-bottom:6px">Mobile guidelines</div>
            <div>• Show 3–7 data points max at base zoom</div>
            <div>• Headline KPI visible before chart</div>
            <div>• Axis labels: first + last + midpoint only</div>
            <div>• Touch target ≥ 44×44px per data point</div>
            <div>• Swipe horizontally to reveal more data</div>
          </div>
        </div>
        <div class="chart-mobile-wrap">
          <div class="chart-mobile-label">Mobile · 280px</div>
          ${phoneChromeWrap(lineChartMobile(), 'Analytics')}
        </div>
      </div>
    </div>
  </div>

  <!-- ── SECTION 2: Bar Chart ──────────────────────────────── -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Bar Chart</h2></div>
    <p class="doc-section-desc">Best for discrete category comparisons. The grouped variant allows direct comparison between two series per category. Bars use 3px top radius for a refined look; the brand purple drives the dominant series.</p>

    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">Daily activity — click a bar to highlight</span>
        <div class="inp-demo-controls">
          <span class="inp-demo-meta">Style</span>
          <select class="inp-state-select" onchange="chartBarToggle(this.value)">
            <option value="simple">Simple</option>
            <option value="grouped">Grouped</option>
          </select>
        </div>
      </div>
      <div class="inp-demo-stage charts-stage" style="padding:24px 20px" id="bar-chart-stage">
        ${barChartSVG(false)}
        <div class="chart-legend" id="bar-legend">
          <div class="chart-legend-item"><div class="chart-legend-dot" style="background:${C.p1}"></div>This week</div>
        </div>
      </div>
    </div>

    <!-- Stacked variant -->
    <div style="margin-top:24px">
      <h3 style="font-size:13px;font-weight:600;color:var(--content-secondary);margin:0 0 8px;font-family:Inter,sans-serif">Stacked variant</h3>
      <p class="doc-section-desc" style="margin-top:0">Use stacked bars when you need to show both the total and composition simultaneously. Limit stacks to 3 layers maximum to maintain legibility.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Order fulfillment — 6 weeks stacked</span>
        </div>
        <div class="inp-demo-stage charts-stage" style="padding:24px 20px">
          ${stackedBarSVG()}
        </div>
      </div>
    </div>

    <div class="doc-section-subsection" style="margin-top:24px">
      <h3 style="font-size:13px;font-weight:600;color:var(--content-secondary);margin:0 0 12px;font-family:Inter,sans-serif">Mobile variant</h3>
      <div class="chart-section-inner">
        <div class="chart-desktop-wrap">
          <p style="font-size:13px;color:var(--content-secondary);line-height:1.6;margin:0 0 12px;font-family:Inter,sans-serif">On mobile, reduce the number of visible bars to 5 and highlight the current day/period with full opacity while dimming others to 50%. This draws immediate attention to the most relevant data point without overwhelming the small screen.</p>
          <div style="background:var(--background-subtle);border-radius:12px;padding:16px;font-size:12px;font-family:Inter,sans-serif;line-height:1.7;color:var(--content-secondary)">
            <div style="font-weight:600;color:var(--content-primary);margin-bottom:6px">Mobile guidelines</div>
            <div>• Max 5 bars visible at once</div>
            <div>• Highlight current period at full opacity</div>
            <div>• Drop Y-axis labels, use tooltips instead</div>
            <div>• Horizontal scroll for additional data</div>
          </div>
        </div>
        <div class="chart-mobile-wrap">
          <div class="chart-mobile-label">Mobile · 280px</div>
          ${phoneChromeWrap(barChartMobile(), 'Activity')}
        </div>
      </div>
    </div>
  </div>

  <!-- ── SECTION 3: Donut Chart ────────────────────────────── -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Donut / Pie Chart</h2></div>
    <p class="doc-section-desc">Use for part-to-whole relationships with 2–5 segments. The hollow center reinforces the design system's light aesthetic and provides space for a summary metric. Always pair with a legend sorted by segment size.</p>

    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">Order status breakdown — hover segments to highlight</span>
        <div class="inp-demo-controls">
          <span class="inp-demo-meta">Size</span>
          <select class="inp-state-select" onchange="chartDonutToggle(this.value)">
            <option value="md">Medium</option>
            <option value="lg">Large</option>
            <option value="sm">Small</option>
          </select>
        </div>
      </div>
      <div class="inp-demo-stage charts-stage" style="padding:24px 32px" id="donut-chart-stage">
        <div class="donut-layout">
          <div id="donut-svg-wrap">${donutChartSVG('md')}</div>
          <div class="donut-legend">${donutLegendHTML()}</div>
        </div>
      </div>
    </div>

    <div class="doc-section-subsection" style="margin-top:24px">
      <h3 style="font-size:13px;font-weight:600;color:var(--content-secondary);margin:0 0 12px;font-family:Inter,sans-serif">Mobile variant</h3>
      <div class="chart-section-inner">
        <div class="chart-desktop-wrap">
          <p style="font-size:13px;color:var(--content-secondary);line-height:1.6;margin:0 0 12px;font-family:Inter,sans-serif">On mobile, reduce the donut diameter and move the legend to the right side of the chart in a single column, using compact spacing. This keeps the entire chart visible without scrolling, typically fitting within a 200px tall card.</p>
        </div>
        <div class="chart-mobile-wrap">
          <div class="chart-mobile-label">Mobile · 280px</div>
          ${phoneChromeWrap(donutMobile(), 'Orders')}
        </div>
      </div>
    </div>
  </div>

  <!-- ── SECTION 4: Area Chart ─────────────────────────────── -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Area Chart</h2></div>
    <p class="doc-section-desc">Area charts are effective for showing volume and comparing cumulative magnitudes between two series. Layer areas with low opacity so both remain visible. The lighter series uses <code>--light-purple-100</code> to create visual hierarchy without introducing a new hue.</p>

    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">Revenue vs. Target — two overlapping series</span>
      </div>
      <div class="inp-demo-stage charts-stage" style="padding:24px 20px">
        ${areaChartSVG()}
        <div class="chart-legend">
          <div class="chart-legend-item"><div class="chart-legend-dot" style="background:${C.p1}"></div>Actual Revenue</div>
          <div class="chart-legend-item"><div class="chart-legend-dot" style="background:${C.p3}"></div>Target</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ── SECTION 5: Sparklines ─────────────────────────────── -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Sparklines</h2></div>
    <p class="doc-section-desc">Compact inline trend indicators — no axes, no labels. Sparklines live inside metric cards and communicate direction and magnitude at a glance. Pair with a KPI headline and a percentage change badge.</p>

    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">KPI cards with inline sparklines</span>
      </div>
      <div class="inp-demo-stage charts-stage" style="padding:24px 20px">
        <div class="sparkline-grid">
          ${sparkCard('Total Orders',   '2,847',  '+12.4% vs last month', true,  [22,28,25,34,30,38,42,36,44,40,52,48], C.p1)}
          ${sparkCard('Delivery Rate',  '94.2%',  '+2.1% improvement',   true,  [82,84,80,86,88,84,90,88,92,90,94,94], C.g1)}
          ${sparkCard('Avg. Wait Time', '3.4 min','-0.8 min faster',     true,  [5.2,4.8,5.1,4.6,4.4,4.8,4.2,4.0,3.8,4.1,3.6,3.4], C.b1)}
          ${sparkCard('Failed Orders',  '158',    '+18 this month',      false, [90,85,92,88,96,100,94,102,108,98,112,118], C.r1)}
        </div>
      </div>
    </div>
  </div>

  <!-- ── SECTION 6: Color Tokens ───────────────────────────── -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Chart Color Tokens</h2></div>
    <p class="doc-section-desc">The chart palette is drawn from the design system's primitive token set, ensuring charts always look native to the product. Primary series always uses <code>--purple-100</code>. Secondary and additional series use lighter purples, then semantic colours for status-coded data.</p>

    <div style="margin-bottom:16px">
      <div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.06em;color:var(--content-tertiary);margin-bottom:8px;font-family:Inter,sans-serif">Series colours</div>
      <div class="btn-tokens-strip">
        ${swatch(C.p1,  '--purple-100',           'Series 1 / Primary')}
        ${swatch(C.p2,  '--purple-70',             'Series 2')}
        ${swatch(C.p3,  '--light-purple-100',       'Series 3')}
        ${swatch(C.p4,  '--purple-20',             'Series 4 / Muted')}
        ${swatch(C.g1,  '--green-100',             'Positive / Growth')}
        ${swatch(C.a1,  '--amber-80',              'Warning / Caution')}
        ${swatch(C.r1,  '--red-100',               'Negative / Decline')}
        ${swatch(C.b1,  '--avatar-color-blue',     'Info / Neutral')}
      </div>
    </div>

    <div>
      <div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.06em;color:var(--content-tertiary);margin-bottom:8px;font-family:Inter,sans-serif">Structural tokens</div>
      <div class="btn-tokens-strip">
        ${swatch('var(--border-subtle)',      '--border-subtle',      'Grid lines')}
        ${swatch('var(--background-subtle)', '--background-subtle',  'Chart background')}
        ${swatch('var(--content-tertiary)',  '--content-tertiary',   'Axis labels')}
        ${swatch('var(--background-inverse)','--background-inverse', 'Tooltips')}
      </div>
    </div>
  </div>

  <!-- ── SECTION 7: Usage guidelines ──────────────────────── -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Usage Guidelines</h2></div>
    <p class="doc-section-desc">Choosing the right chart type is as important as the visual design. These rules prevent common misuse patterns.</p>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;margin-top:8px">
      ${[
        { type:'Line', use:'Continuous time series, trends, forecasts', avoid:'Discrete categories, fewer than 4 data points' },
        { type:'Bar', use:'Category comparisons, rankings, distributions', avoid:'Too many categories (>12), part-to-whole' },
        { type:'Donut / Pie', use:'Part-to-whole with 2–5 segments', avoid:'More than 5 segments, precise comparisons' },
        { type:'Area', use:'Volume over time, cumulative comparisons', avoid:'Many overlapping series (>3), noisy data' },
        { type:'Sparkline', use:'Inline trend indicators inside dashboards/cards', avoid:'Standalone charts requiring axis context' },
        { type:'Stacked Bar', use:'Composition + total simultaneously', avoid:'More than 3 layers, small differences between layers' },
      ].map(g => `<div style="background:var(--background-default);border:1px solid var(--border-subtle);border-radius:10px;padding:16px">
        <div style="font-size:12px;font-weight:700;color:var(--content-primary);font-family:Inter,sans-serif;margin-bottom:8px">${g.type}</div>
        <div style="font-size:11px;color:var(--content-secondary);font-family:Inter,sans-serif;line-height:1.6">
          <div style="margin-bottom:4px"><span style="color:${C.g1};font-weight:600">✓ Use for: </span>${g.use}</div>
          <div><span style="color:${C.r1};font-weight:600">✗ Avoid: </span>${g.avoid}</div>
        </div>
      </div>`).join('')}
    </div>
  </div>

</div>`;
}
