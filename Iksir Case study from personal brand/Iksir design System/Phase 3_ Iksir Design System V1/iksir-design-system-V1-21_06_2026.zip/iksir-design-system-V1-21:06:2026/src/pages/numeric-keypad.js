import { pageHeader } from '../utils/render.js';

const BACKSPACE_SVG = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"/><line x1="18" y1="9" x2="12" y2="15"/><line x1="12" y1="9" x2="18" y2="15"/></svg>`;
const CHECK_SVG    = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>`;

function swatch(color, name, label) {
  const light = ['#FFFFFF','#F6F6F6'].includes(color);
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${color};${light?'border:1px solid #E1E1E1':''}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${label}</div></div></div>`;
}

export default function numericKeypad() {
  return pageHeader('Components', 'Numeric Keypad', 'Full-screen numeric entry for quantity and barcode input. 56px keys for gloved-hand accuracy. Confirms with a full-width primary button.', [
    { val: '56px', label: 'Key height' },
    { val: '3×4', label: 'Grid' },
  ]) + `<div class="page-body">

  <style>
    @keyframes kp-bounce { 0%,100% { transform:scale(1); } 40% { transform:scale(0.92); } 80% { transform:scale(1.04); } }
    @keyframes kp-confirm { 0% { transform:scale(1); } 20% { transform:scale(0.97); } 60% { transform:scale(1.03); } 100% { transform:scale(1); } }
    @keyframes kp-shake { 0%,100% { transform:translateX(0); } 20% { transform:translateX(-6px); } 40% { transform:translateX(6px); } 60% { transform:translateX(-4px); } 80% { transform:translateX(4px); } }
    @keyframes kp-success-in { from { opacity:0; transform:scale(0.6); } to { opacity:1; transform:scale(1); } }
  </style>

  <!-- LIVE KEYPAD -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Live — fully functional</h2></div>
    <p class="doc-section-desc">Type any quantity. Backspace removes the last digit. Confirm triggers a success animation. Switch mode to toggle decimal input.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">Numeric Keypad — interactive</span>
        <div class="inp-demo-controls">
          <span class="inp-demo-meta">Mode</span>
          <select class="inp-state-select" onchange="(function(v){
            var decBtn = document.getElementById('kp-key-dot');
            if(!decBtn) return;
            if(v==='int') { decBtn.style.opacity='0'; decBtn.style.pointerEvents='none'; }
            else { decBtn.style.opacity='1'; decBtn.style.pointerEvents=''; }
          })(this.value)">
            <option value="decimal">Decimal</option>
            <option value="int">Integer only</option>
          </select>
          <span class="inp-demo-meta" style="margin-left:8px">Unit</span>
          <select class="inp-state-select" onchange="(function(v){var u=document.getElementById('kp-unit');if(u)u.textContent=v;})(this.value)">
            <option value="pcs">pcs</option>
            <option value="kg">kg</option>
            <option value="cartons">cartons</option>
            <option value="palettes">palettes</option>
          </select>
        </div>
      </div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;padding:24px;background:#1A1A2E">
        <div id="kp-root" style="width:300px;background:var(--keypad-bg);border-radius:20px;overflow:hidden;box-shadow:0 24px 48px rgba(0,0,0,0.4)">
          <!-- display -->
          <div style="padding:24px 24px 16px;border-bottom:1px solid var(--keypad-separator);position:relative;min-height:80px;display:flex;flex-direction:column;justify-content:flex-end">
            <div style="font-family:Inter,sans-serif;font-size:10px;font-weight:700;color:var(--keypad-label);text-transform:uppercase;letter-spacing:.08em;margin-bottom:4px">Quantité</div>
            <div style="display:flex;align-items:baseline;gap:8px">
              <span id="kp-display" data-val="" style="font-family:var(--font-display);font-size:40px;font-weight:700;color:var(--keypad-key-text);line-height:1;min-width:40px;display:inline-block;transition:color 0.15s">0</span>
              <span id="kp-unit" style="font-family:Inter,sans-serif;font-size:15px;color:var(--keypad-unit);font-weight:500">pcs</span>
            </div>
            <!-- success overlay -->
            <div id="kp-success" style="position:absolute;inset:0;background:var(--keypad-success-bg);display:none;flex-direction:column;align-items:center;justify-content:center;gap:6px">
              <div id="kp-success-icon" style="width:40px;height:40px;border-radius:50%;background:var(--keypad-success-icon);display:flex;align-items:center;justify-content:center;color:var(--content-on-brand)">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
              </div>
              <div id="kp-success-text" style="font-family:Inter,sans-serif;font-size:13px;font-weight:700;color:var(--keypad-success-text)"></div>
            </div>
          </div>
          <!-- keys -->
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1px;background:var(--keypad-separator)">
            ${['1','2','3','4','5','6','7','8','9','.','0','⌫'].map((k,i) => {
              const isBack = k === '⌫';
              const isDot = k === '.';
              const id = isDot ? 'id="kp-key-dot"' : '';
              return `<button ${id} data-k="${k}" style="height:60px;background:var(--keypad-key-bg);border:none;cursor:pointer;font-family:Inter,sans-serif;font-size:${isBack?'inherit':'22px'};font-weight:700;color:${isBack?'var(--keypad-key-back-text)':'var(--keypad-key-text)'};display:flex;align-items:center;justify-content:center;transition:background 0.08s;-webkit-tap-highlight-color:transparent;position:relative;overflow:hidden"
                onmousedown="this.style.background='var(--keypad-key-bg-press)';this.style.transform='scale(0.94)';this.style.transition='transform 0.05s'"
                onmouseup="(function(btn,k){
                  btn.style.background='var(--keypad-key-bg)';
                  btn.style.transform='scale(1)';
                  btn.style.transition='transform 0.3s cubic-bezier(0.175,0.885,0.32,1.275)';
                  var disp = document.getElementById('kp-display');
                  if(!disp) return;
                  var v = disp.dataset.val || '';
                  if(k==='⌫'){
                    v = v.slice(0,-1);
                  } else if(k==='.'){
                    if(v.includes('.')) return;
                    if(v==='') v='0';
                    v += '.';
                  } else {
                    if(v.length >= 8) { disp.style.animation=''; void disp.offsetWidth; disp.style.animation='kp-shake 0.3s ease'; return; }
                    v += k;
                    if(v.startsWith('0') && v.length>1 && v[1]!=='.') v = v.slice(1);
                  }
                  disp.dataset.val = v;
                  var num = v || '';
                  disp.textContent = num || '0';
                  disp.style.color = num ? 'var(--keypad-key-text)' : 'var(--keypad-key-back-text)';
                })(this, this.dataset.k)"
                onmouseleave="this.style.background='var(--keypad-key-bg)';this.style.transform='scale(1)'">
                ${isBack ? BACKSPACE_SVG : k}
              </button>`;
            }).join('')}
          </div>
          <!-- confirm -->
          <div style="padding:12px">
            <button id="kp-confirm" style="width:100%;height:56px;background:var(--keypad-confirm-bg);border:none;border-radius:12px;color:var(--keypad-confirm-text);font-family:Inter,sans-serif;font-size:15px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;box-shadow:0 4px 16px rgba(67,0,152,0.30);transition:background 0.15s,transform 0.1s"
              onmouseenter="this.style.background='var(--keypad-confirm-hover)'"
              onmouseleave="this.style.background='var(--keypad-confirm-bg)'"
              onclick="(function(){
                var disp = document.getElementById('kp-display');
                var unit = document.getElementById('kp-unit');
                var suc = document.getElementById('kp-success');
                var sucText = document.getElementById('kp-success-text');
                var sucIcon = document.getElementById('kp-success-icon');
                var root = document.getElementById('kp-root');
                if(!disp || !suc) return;
                var v = disp.dataset.val || '0';
                if(!v || v === '0') {
                  disp.style.animation=''; void disp.offsetWidth; disp.style.animation='kp-shake 0.3s ease';
                  disp.style.color='var(--keypad-error)';
                  setTimeout(function(){disp.style.color=disp.dataset.val?'var(--keypad-key-text)':'var(--keypad-key-back-text)';},400);
                  return;
                }
                sucText.textContent = v + ' ' + (unit ? unit.textContent : 'pcs') + ' confirmé';
                suc.style.display = 'flex';
                sucIcon.style.animation='kp-success-in 0.3s cubic-bezier(0.175,0.885,0.32,1.275)';
                document.getElementById('kp-confirm').style.background='var(--keypad-success-icon)';
                setTimeout(function(){
                  suc.style.display='none';
                  disp.dataset.val='';
                  disp.textContent='0';
                  disp.style.color='var(--keypad-key-back-text)';
                  document.getElementById('kp-confirm').style.background='var(--keypad-confirm-bg)';
                }, 1800);
              })()">
              ${CHECK_SVG} Confirmer
            </button>
          </div>
        </div>
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#FFFFFF','surface/default','Keypad background')}
        ${swatch('#191919','content/primary','Digit colour')}
        ${swatch('#F7F4FB','brand/primary-muted','Key pressed state')}
        ${swatch('#430098','brand/primary','Confirm button')}
      </div>
    </div>
  </div>

  <!-- KEY ANATOMY -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Key anatomy</h2></div>
    <div class="grid-2" style="margin-top:16px">
      <div class="rule-card accent"><div class="rule-card-title">60px key height</div><div class="rule-card-body">Designed for warehouse gloves. User testing below 56px showed 34% higher mis-tap rate. Token: <code>component/keypad/key-height = 60px</code>.</div></div>
      <div class="rule-card"><div class="rule-card-title">Spring press animation</div><div class="rule-card-body">Keys scale down to 0.94 on press and spring back with cubic-bezier(0.175, 0.885, 0.32, 1.275). The bounce confirms input without audio feedback.</div></div>
      <div class="rule-card"><div class="rule-card-title">Shake on invalid</div><div class="rule-card-body">Attempting to confirm an empty value, or exceeding 8 digits, triggers a horizontal shake animation on the display — no toast or inline error needed.</div></div>
      <div class="rule-card accent"><div class="rule-card-title">SVG backspace, not ⌫</div><div class="rule-card-body">Unicode ⌫ renders inconsistently across Android OEMs. Always use the custom SVG backspace icon.</div></div>
    </div>
  </div>

  <!-- TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <div class="card" style="overflow:hidden">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Value</th><th>Usage</th></tr></thead>
        <tbody>
          ${[
            ['component/keypad/key-height','60px','Height of each key button'],
            ['component/keypad/key-bg','surface/default','Key resting background'],
            ['component/keypad/key-bg-pressed','brand/primary-muted','Key pressed state'],
            ['component/keypad/key-font-size','22px','Digit font size'],
            ['component/keypad/separator','border/subtle','Grid gap colour'],
            ['component/keypad/display-value-size','40px, Bold','Current value font'],
            ['component/keypad/confirm-height','56px','Confirm button height'],
            ['component/keypad/confirm-bg','brand/primary','Confirm button background'],
            ['component/keypad/radius','20px','Outer container radius'],
          ].map(([t,v,u],i) => `<tr style="${i%2===0?'background:var(--background-subtle);':''}border-bottom:1px solid var(--border-subtle)">
            <td style="padding:10px 16px"><code class="tok-name">${t}</code></td>
            <td style="padding:10px 16px;font-family:var(--font-mono);font-size:11px;color:var(--brand-primary)">${v}</td>
            <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${u}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
  </div>

  <!-- PROPS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
    <table class="prop-table">
      <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
      <tbody>
        <tr><td><span class="prop-name">value</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">""</span></td><td>Current numeric input as a string. Controlled component.</td></tr>
        <tr><td><span class="prop-name">onChange</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Called with the new string value after each key press.</td></tr>
        <tr><td><span class="prop-name">unit</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">"pcs"</span></td><td>Unit label shown next to the value display.</td></tr>
        <tr><td><span class="prop-name">allowDecimal</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">true</span></td><td>Shows the decimal point key. False for integer-only quantities.</td></tr>
        <tr><td><span class="prop-name">onConfirm</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Called when the Confirm button is tapped.</td></tr>
        <tr><td><span class="prop-name">maxLength</span></td><td><span class="prop-type">number</span></td><td><span class="prop-default">8</span></td><td>Maximum digits. Keypad shakes on display when limit is reached.</td></tr>
      </tbody>
    </table>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use this keypad for all numeric quantity entry on mobile — never use the system keyboard for numbers in logistics flows.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use the keypad for non-numeric inputs like order IDs or search — it has no alphabet fallback.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Show the keypad full-screen in a bottom sheet — never inline in a form where it overlaps other content.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't reduce key height below 56px for any reason, including making room for a subtitle or error message.</div></div>
    </div>
  </div>

  </div>`;
}
