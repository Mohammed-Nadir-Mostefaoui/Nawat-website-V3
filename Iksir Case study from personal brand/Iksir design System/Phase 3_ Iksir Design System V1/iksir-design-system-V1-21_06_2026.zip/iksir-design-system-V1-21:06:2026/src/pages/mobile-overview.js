import { pageHeader } from '../utils/render.js';

export default function mobileOverview() {
  return pageHeader(
    'Platform',
    'Mobile Overview',
    'Canvas standards, safe areas, breakpoints, and guiding principles for designing within the Iksir mobile layer.'
  ) + `<div class="page-body">

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">What is the mobile layer?</h2>
      </div>
      <p class="doc-section-desc">The Iksir mobile layer is an additive set of tokens, components, and patterns that sit on top of the existing Iksir design system. Nothing in the core system changes — mobile extends it. The primary source product is <strong>Task Master V.1.0</strong>, a warehouse logistics app with 350+ validated screens that defines all mobile UX patterns.</p>
      <div class="grid-2" style="margin-top:16px">
        <div class="rule-card accent">
          <div class="rule-card-title">Additive, not destructive</div>
          <div class="rule-card-body">Every mobile token, component, and page added here is new. No existing web tokens or components are changed. The three-layer primitive → semantic → component rule applies equally to mobile.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Token-first mobile</div>
          <div class="rule-card-body">Mobile-specific colours (nav/tab/*, fab/*, status/priority/*) and sizing (component/tab-bar/*, component/fab/*, component/avatar/*) all live in Iksir variable collections — not hardcoded values.</div>
        </div>
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Canvas standards</h2>
      </div>
      <p class="doc-section-desc">All mobile screens are designed at a canonical frame size with device-accurate safe areas. Use these frames as the base for every new mobile screen.</p>

      <div class="grid-2" style="margin-top:20px">
        <div class="card" style="padding:20px">
          <div style="font-family:var(--font-display);font-size:13px;font-weight:700;color:var(--brand-primary);margin-bottom:4px;text-transform:uppercase;letter-spacing:.06em;font-size:10px">Primary target</div>
          <div style="font-family:var(--font-display);font-size:22px;font-weight:700;color:var(--content-primary);margin-bottom:8px">390 × 844 px</div>
          <div style="font-size:12px;color:var(--content-secondary);line-height:1.6">iPhone 14 logical size. All components and spacing are specified at @1x relative to this canvas. This is the design source of truth — export at @2x / @3x for device delivery.</div>
          <div style="margin-top:12px;display:flex;flex-direction:column;gap:4px">
            ${[['Status bar','50 px'],['Home indicator','34 px'],['Side insets','0 px (safe on iPhone 14)'],['Content height','760 px (844 − 50 − 34)']].map(([k,v]) => `
            <div style="display:flex;justify-content:space-between;font-size:11px;padding:4px 0;border-bottom:1px solid var(--border-subtle)">
              <span style="color:var(--content-secondary)">${k}</span>
              <span style="font-weight:600;color:var(--content-primary);font-family:var(--font-mono)">${v}</span>
            </div>`).join('')}
          </div>
        </div>
        <div class="card" style="padding:20px">
          <div style="font-family:var(--font-display);font-size:10px;font-weight:700;color:var(--content-tertiary);margin-bottom:4px;text-transform:uppercase;letter-spacing:.06em">Secondary test size</div>
          <div style="font-family:var(--font-display);font-size:22px;font-weight:700;color:var(--content-primary);margin-bottom:8px">412 × 892 px</div>
          <div style="font-size:12px;color:var(--content-secondary);line-height:1.6">Android / Samsung-class device (what Task Master V.1.0 was originally designed at). Test your layouts at this size to catch overflow issues — the 22px width difference matters for grid-based layouts.</div>
          <div style="margin-top:12px;display:flex;flex-direction:column;gap:4px">
            ${[['Status bar','24 px (Android)'],['Navigation bar','48 px (gesture nav)'],['Side insets','0 px'],['Content height','820 px']].map(([k,v]) => `
            <div style="display:flex;justify-content:space-between;font-size:11px;padding:4px 0;border-bottom:1px solid var(--border-subtle)">
              <span style="color:var(--content-secondary)">${k}</span>
              <span style="font-weight:600;color:var(--content-primary);font-family:var(--font-mono)">${v}</span>
            </div>`).join('')}
          </div>
        </div>
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Safe area guide</h2>
      </div>
      <p class="doc-section-desc">Safe areas define the regions of the screen where interactive content must stay. Content behind safe areas (status bar, home indicator) is visible but must not be tappable.</p>
      <div class="grid-2" style="margin-top:16px">
        <div class="rule-card accent">
          <div class="rule-card-title">Always inset interactive content</div>
          <div class="rule-card-body">Bottom tab bar sits above the home indicator — add <code>padding-bottom: 34px</code> (home indicator) so the first tab item is never clipped. Use <code>env(safe-area-inset-bottom)</code> in CSS for dynamic handling.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Status bar can have colour</div>
          <div class="rule-card-body">The status bar region (top 50px) takes the background colour of the app header. It is not a no-go zone for colour — only for interactive tappable elements.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">FAB respects the indicator</div>
          <div class="rule-card-body">The Floating Action Button sits 16px above the safe-area bottom — not 16px from the physical screen edge. Token: <code>component/fab/margin-bottom = 16px</code> above the safe area inset.</div>
        </div>
        <div class="rule-card accent">
          <div class="rule-card-title">Scrollable content bleeds</div>
          <div class="rule-card-body">Scrollable list content can visually bleed behind the bottom tab bar to show depth. Only the last focusable item needs to have extra bottom padding so it's reachable when scrolled to the bottom.</div>
        </div>
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Breakpoints</h2>
      </div>
      <p class="doc-section-desc">Iksir defines three breakpoints. Mobile components are designed for the 390px breakpoint — they do not automatically reflow to tablet or desktop.</p>
      <div style="margin-top:16px;border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden">
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr 2fr;background:var(--background-subtle);padding:10px 16px;gap:12px">
          ${['Name','Width','Target','Notes'].map(h => `<div style="font-size:11px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em">${h}</div>`).join('')}
        </div>
        ${[
          ['Mobile','390 px','iPhone 14 / most Android','Design target. All mobile components sized for this width.'],
          ['Tablet','768 px','iPad mini / large Android','Not yet designed. Placeholder breakpoint for future.'],
          ['Desktop','1280 px','Web admin / laptop','Existing Iksir web components. 1440px design canvas.'],
        ].map(([name,width,target,notes], i) => `
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr 2fr;padding:12px 16px;gap:12px;${i < 2 ? 'border-bottom:1px solid var(--border-subtle)' : ''}">
          <div style="font-size:12px;font-weight:600;color:var(--content-primary)">${name}</div>
          <div style="font-family:var(--font-mono);font-size:12px;color:var(--brand-primary)">${width}</div>
          <div style="font-size:12px;color:var(--content-secondary)">${target}</div>
          <div style="font-size:12px;color:var(--content-tertiary)">${notes}</div>
        </div>`).join('')}
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Mobile design principles</h2>
      </div>
      <p class="doc-section-desc">These principles are derived from Task Master's production context — warehouse workers, gloved hands, fast-paced scanning environments.</p>
      <div class="grid-2">
        <div class="rule-card accent">
          <div class="rule-card-title">Touch-first data entry</div>
          <div class="rule-card-body">Minimum interactive touch target is 44×44px. Numeric keypad keys are 56px tall. FABs are 56px. Never rely on hover states — mobile has no hover.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Information hierarchy over decoration</div>
          <div class="rule-card-body">Priority tags, assignee stacks, and order numbers must be scannable at a glance. Colour coding (red/amber/green) is functional, not decorative. Never use colour as the only signal — pair with text.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Progressive disclosure</div>
          <div class="rule-card-body">Task cards collapse by default showing only the most critical info. Expand on tap. Bottom sheets reveal contextual actions without navigating away. The screen should never feel overwhelming.</div>
        </div>
        <div class="rule-card accent">
          <div class="rule-card-title">Dark mode from day one</div>
          <div class="rule-card-body">Low-light warehouse environments require dark mode. Every mobile token must have both Light and Dark values. Never add a mobile token without specifying both.</div>
        </div>
      </div>
    </div>

  </div>`;
}
