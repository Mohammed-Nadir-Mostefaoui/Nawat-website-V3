import { pageHeader } from '../utils/render.js';

/* ── SVG primitives ──────────────────────────────────────── */
const CHV_DOWN = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="6 9 12 15 18 9"/></svg>`;
const CHV_UP   = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="18 15 12 9 6 15"/></svg>`;
const CHECK    = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>`;
const WARN     = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--status-danger-content)" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;
const IMG_UP   = `<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>`;

/* ── tiny building blocks ────────────────────────────────── */
function label(text, required = false) {
  return `<div style="font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--content-primary);margin-bottom:5px">${text}${required ? `<span style="color:var(--status-danger-content);margin-left:2px">*</span>` : ''}</div>`;
}

function input({ placeholder = '', value = '', state = 'default', width = '100%' } = {}) {
  const styles = {
    default: 'border:1px solid var(--border-default);background:var(--background-default)',
    filled:  'border:1px solid var(--border-default);background:var(--background-default)',
    error:   'border:1px solid var(--input-border-error);background:var(--status-danger-bg)',
    focused: 'border:1px solid var(--brand-primary);background:var(--background-default);box-shadow:0 0 0 3px rgba(67,0,152,0.12)',
    disabled:'border:1px solid var(--border-subtle);background:var(--background-subtle);opacity:.6',
  };
  const trailing = state === 'error' ? `<span style="position:absolute;right:10px;top:50%;transform:translateY(-50%)">${WARN}</span>` : '';
  return `<div style="position:relative;width:${width}">
    <input readonly style="width:100%;box-sizing:border-box;height:40px;padding:0 ${state==='error'?'32px':'12px'} 0 12px;border-radius:8px;font-family:Inter,sans-serif;font-size:13px;color:var(--content-${value?'primary':'tertiary'});${styles[state]||styles.default};outline:none" placeholder="${placeholder}" value="${value}">
    ${trailing}
  </div>`;
}

function select({ label: lbl = 'Select...', value = '', state = 'default' } = {}) {
  const styles = {
    default: 'border:1px solid var(--border-default);background:var(--background-default)',
    filled:  'border:1px solid var(--border-default);background:var(--background-default)',
    error:   'border:1px solid var(--input-border-error);background:var(--status-danger-bg)',
  };
  return `<div style="position:relative">
    <div style="height:40px;padding:0 36px 0 12px;border-radius:8px;display:flex;align-items:center;font-family:Inter,sans-serif;font-size:13px;color:var(--content-${value?'primary':'tertiary'});${styles[state]||styles.default};cursor:pointer;user-select:none">${value || lbl}</div>
    <span style="position:absolute;right:10px;top:50%;transform:translateY(-50%);color:var(--content-tertiary);pointer-events:none">${CHV_DOWN}</span>
  </div>`;
}

function checkbox(checked = false, lbl = '') {
  return `<label style="display:inline-flex;align-items:center;gap:8px;cursor:pointer;user-select:none">
    <span style="width:16px;height:16px;border-radius:4px;border:1.5px solid ${checked?'var(--brand-primary)':'var(--border-default)'};background:${checked?'var(--brand-primary)':'var(--background-default)'};display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;color:var(--content-on-brand)">${checked?CHECK:''}</span>
    <span style="font-family:Inter,sans-serif;font-size:13px;color:var(--content-primary)">${lbl}</span>
  </label>`;
}

function helper(text, type = 'hint') {
  const color = type === 'error' ? 'var(--status-danger-content)' : 'var(--content-tertiary)';
  const icon  = type === 'error' ? `${WARN}&nbsp;` : '';
  return `<div style="display:flex;align-items:center;gap:4px;margin-top:5px;font-family:Inter,sans-serif;font-size:11px;color:${color}">${icon}${text}</div>`;
}

function fieldGroup(title, children, collapsed = false) {
  return `
  <div style="border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden;margin-bottom:0;background:var(--background-default)">
    <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 16px;background:var(--background-default);cursor:pointer;user-select:none">
      <span style="font-family:var(--font-display);font-size:13px;font-weight:700;color:var(--content-primary)">${title}</span>
      <span style="color:var(--content-tertiary)">${collapsed ? CHV_DOWN : CHV_UP}</span>
    </div>
    ${!collapsed ? `<div style="padding:16px;border-top:1px solid var(--border-subtle);display:flex;flex-direction:column;gap:16px;background:var(--background-default)">${children}</div>` : ''}
  </div>`;
}

function row(...cells) {
  return `<div style="display:grid;grid-template-columns:${cells.map(()=>'1fr').join(' ')};gap:12px">${cells.join('')}</div>`;
}

function field(labelText, control, required = false, hint = null, error = null) {
  return `<div>
    ${label(labelText, required)}
    ${control}
    ${error ? helper(error, 'error') : hint ? helper(hint) : ''}
  </div>`;
}

function swatch(color, name, lbl) {
  const light = ['#FFFFFF','#F6F6F6','#FFF2F4','#FFF8F8'].includes(color);
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${color};${light?'border:1px solid #E1E1E1':''}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${lbl}</div></div></div>`;
}

/* ════════════════════════════════════════════════════════════ */
export default function forms() {
  return pageHeader('Patterns', 'Forms', 'Layout rules, field composition, validation states, and collapsible sections — derived from the Iksir ERP product forms.') + `<div class="page-body">

  <style>
    @keyframes frm-error-shake { 0%,100%{transform:translateX(0)} 20%{transform:translateX(-5px)} 40%{transform:translateX(5px)} 60%{transform:translateX(-3px)} 80%{transform:translateX(3px)} }
    .frm-shake { animation: frm-error-shake 0.35s ease; }
    @keyframes frm-success-pop { from{opacity:0;transform:scale(0.8)} to{opacity:1;transform:scale(1)} }
    .frm-success-pop { animation: frm-success-pop 0.3s cubic-bezier(0.175,0.885,0.32,1.275); }
    @keyframes frm-accordion-open { from{opacity:0;transform:translateY(-4px)} to{opacity:1;transform:translateY(0)} }
    .frm-acc-body { animation: frm-accordion-open 0.2s ease; background: var(--background-default); }
    .frm-field-error input, .frm-field-error textarea { border-color:var(--input-border-error) !important; background:var(--status-danger-bg) !important; box-shadow:none !important; }
    .frm-field-success input { border-color:var(--status-success-border) !important; box-shadow:0 0 0 3px rgba(22,163,74,0.1) !important; }
  </style>

  <!-- LIVE INTERACTIVE FORM -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Live — type, validate, submit</h2></div>
    <p class="doc-section-desc">A real product creation form. Fields validate on blur. Click the section headers to collapse/expand them. Try submitting with empty required fields — the form shakes and scrolls to the first error.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">Créer un produit — form interactif</span>
        <div style="display:flex;align-items:center;gap:8px">
          <button onclick="frmReset()" style="padding:0 12px;height:30px;border-radius:7px;border:1px solid var(--border-default);background:transparent;cursor:pointer;font-family:Inter,sans-serif;font-size:12px;color:var(--content-secondary)">Réinitialiser</button>
          <button onclick="frmSubmit()" id="frm-save-btn" style="padding:0 14px;height:30px;border-radius:7px;background:var(--brand-primary);border:none;cursor:pointer;font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--content-on-brand);transition:background 0.15s" onmouseenter="this.style.background='var(--brand-primary-hover)'" onmouseleave="this.style.background='var(--brand-primary)'">Sauvegarder</button>
        </div>
      </div>
      <div class="inp-demo-stage" style="padding:20px">
        <div id="frm-success-banner" style="display:none;align-items:center;gap:10px;padding:12px 16px;border-radius:10px;background:var(--status-success-bg);border:1px solid var(--status-success-border);margin-bottom:16px">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--status-success-content)" stroke-width="2.5" stroke-linecap="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
          <span style="font-family:Inter,sans-serif;font-size:13px;font-weight:600;color:var(--status-success-content)">Produit créé avec succès !</span>
        </div>

        <div style="max-width:600px;margin:0 auto;display:flex;flex-direction:column;gap:10px">

          <!-- Section 1 — open -->
          <div class="frm-section" id="frm-sec-0">
            <div onclick="frmToggle(0)" style="display:flex;align-items:center;justify-content:space-between;padding:13px 16px;background:var(--background-default);border:1px solid var(--border-subtle);border-radius:10px;cursor:pointer;user-select:none;transition:background 0.12s" onmouseenter="this.style.background='var(--background-subtle)'" onmouseleave="this.style.background='var(--background-default)'">
              <span style="font-family:var(--font-display);font-size:13px;font-weight:700;color:var(--content-primary)">Informations de base</span>
              <span id="frm-chv-0" style="color:var(--content-tertiary);transition:transform 0.2s;display:flex">${CHV_UP}</span>
            </div>
            <div id="frm-body-0" class="frm-acc-body" style="border:1px solid var(--border-subtle);border-top:none;border-radius:0 0 10px 10px;padding:16px;display:flex;flex-direction:column;gap:14px">
              <div id="frm-field-nom" class="frm-field">
                <div style="font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--content-primary);margin-bottom:5px">Nom du produit <span style="color:var(--status-danger-content)">*</span></div>
                <input id="frm-nom" placeholder="Ex: Palette bois standard"
                  onfocus="this.style.borderColor='var(--brand-primary)';this.style.boxShadow='0 0 0 3px rgba(67,0,152,0.12)'"
                  onblur="frmValidate('nom')"
                  style="width:100%;box-sizing:border-box;height:40px;padding:0 12px;border-radius:8px;border:1px solid var(--border-default);font-family:Inter,sans-serif;font-size:13px;color:var(--content-primary);background:var(--background-default);outline:none;transition:border-color 0.15s,box-shadow 0.15s">
                <div id="frm-err-nom" style="display:none;margin-top:5px;font-family:Inter,sans-serif;font-size:11px;color:var(--status-danger-content);display:flex;align-items:center;gap:4px">${WARN}&nbsp;<span></span></div>
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
                <div id="frm-field-cat" class="frm-field">
                  <div style="font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--content-primary);margin-bottom:5px">Catégorie <span style="color:var(--status-danger-content)">*</span></div>
                  <select id="frm-cat" onchange="frmValidate('cat');frmFocusSel(this)" onblur="frmValidate('cat')"
                    style="width:100%;height:40px;padding:0 12px;border-radius:8px;border:1px solid var(--border-default);font-family:Inter,sans-serif;font-size:13px;color:var(--content-primary);background:var(--background-default);outline:none;cursor:pointer;transition:border-color 0.15s">
                    <option value="">Choisir…</option>
                    <option>Contenants</option><option>Consommables</option><option>Emballage</option><option>Matériel</option>
                  </select>
                  <div id="frm-err-cat" style="display:none;margin-top:5px;font-family:Inter,sans-serif;font-size:11px;color:var(--status-danger-content)">&nbsp;</div>
                </div>
                <div>
                  <div style="font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--content-primary);margin-bottom:5px">Comportement</div>
                  <select style="width:100%;height:40px;padding:0 12px;border-radius:8px;border:1px solid var(--border-default);font-family:Inter,sans-serif;font-size:13px;color:var(--content-primary);background:var(--background-default);outline:none;cursor:pointer">
                    <option>Stocké</option><option>Consommé</option><option>Produit fini</option>
                  </select>
                </div>
                <div>
                  <div style="font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--content-primary);margin-bottom:5px">Unité</div>
                  <select style="width:100%;height:40px;padding:0 12px;border-radius:8px;border:1px solid var(--border-default);font-family:Inter,sans-serif;font-size:13px;color:var(--content-primary);background:var(--background-default);outline:none;cursor:pointer">
                    <option>Unité</option><option>Kg</option><option>Litre</option><option>Rouleau</option><option>Lot 1000</option>
                  </select>
                </div>
              </div>
              <div>
                <div style="font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--content-primary);margin-bottom:5px">Description</div>
                <textarea id="frm-desc" placeholder="Description facultative…"
                  style="width:100%;box-sizing:border-box;height:68px;padding:10px 12px;border-radius:8px;border:1px solid var(--border-default);font-family:Inter,sans-serif;font-size:13px;color:var(--content-primary);background:var(--background-default);resize:none;outline:none;transition:border-color 0.15s"
                  onfocus="this.style.borderColor='var(--brand-primary)';this.style.boxShadow='0 0 0 3px rgba(67,0,152,0.12)'"
                  onblur="this.style.borderColor='var(--border-default)';this.style.boxShadow=''"></textarea>
              </div>
              <div style="display:flex;gap:24px">
                ${[['Vendable',true],['Commandable',false],['Retournable',true]].map(([lbl,checked],ci)=>`
                <label id="frm-chk-wrap-${ci}" style="display:inline-flex;align-items:center;gap:7px;cursor:pointer;user-select:none" onclick="frmToggleCheck(${ci})">
                  <span id="frm-chk-${ci}" data-checked="${checked}" style="width:16px;height:16px;border-radius:4px;border:1.5px solid ${checked?'var(--brand-primary)':'var(--border-default)'};background:${checked?'var(--brand-primary)':'var(--background-default)'};display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;color:var(--content-on-brand);transition:all 0.15s">
                    ${checked?CHECK:''}
                  </span>
                  <span style="font-family:Inter,sans-serif;font-size:13px;color:var(--content-primary)">${lbl}</span>
                </label>`).join('')}
              </div>
            </div>
          </div>

          <!-- Section 2 — collapsed -->
          <div class="frm-section" id="frm-sec-1">
            <div onclick="frmToggle(1)" style="display:flex;align-items:center;justify-content:space-between;padding:13px 16px;background:var(--background-default);border:1px solid var(--border-subtle);border-radius:10px;cursor:pointer;user-select:none;transition:background 0.12s" onmouseenter="this.style.background='var(--background-subtle)'" onmouseleave="this.style.background='var(--background-default)'">
              <span style="font-family:var(--font-display);font-size:13px;font-weight:700;color:var(--content-primary)">Tarification</span>
              <span id="frm-chv-1" style="color:var(--content-tertiary);transition:transform 0.2s;display:flex">${CHV_DOWN}</span>
            </div>
            <div id="frm-body-1" style="display:none"></div>
          </div>

          <!-- Section 3 — collapsed -->
          <div class="frm-section" id="frm-sec-2">
            <div onclick="frmToggle(2)" style="display:flex;align-items:center;justify-content:space-between;padding:13px 16px;background:var(--background-default);border:1px solid var(--border-subtle);border-radius:10px;cursor:pointer;user-select:none;transition:background 0.12s" onmouseenter="this.style.background='var(--background-subtle)'" onmouseleave="this.style.background='var(--background-default)'">
              <span style="font-family:var(--font-display);font-size:13px;font-weight:700;color:var(--content-primary)">Palettisation</span>
              <span id="frm-chv-2" style="color:var(--content-tertiary);transition:transform 0.2s;display:flex">${CHV_DOWN}</span>
            </div>
            <div id="frm-body-2" style="display:none"></div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
    var _frmOpen = [true, false, false];

    function frmToggle(i) {
      _frmOpen[i] = !_frmOpen[i];
      var body = document.getElementById('frm-body-' + i);
      var chv  = document.getElementById('frm-chv-'  + i);
      var sec  = document.getElementById('frm-sec-'  + i);
      if (!body) return;
      if (_frmOpen[i]) {
        body.style.display = 'flex';
        body.style.flexDirection = 'column';
        body.style.gap = '14px';
        body.style.padding = '16px';
        body.style.border = '1px solid var(--border-subtle)';
        body.style.borderTop = 'none';
        body.style.borderRadius = '0 0 10px 10px';
        body.classList.remove('frm-acc-body'); void body.offsetWidth; body.classList.add('frm-acc-body');
        sec.querySelector('div').style.borderRadius = '10px 10px 0 0';
        if (chv) chv.style.transform = 'rotate(0deg)';
      } else {
        body.style.display = 'none';
        sec.querySelector('div').style.borderRadius = '10px';
        if (chv) chv.style.transform = 'rotate(-90deg)';
      }
    }

    function frmToggleCheck(i) {
      var el = document.getElementById('frm-chk-' + i);
      if (!el) return;
      var on = el.dataset.checked !== 'true';
      el.dataset.checked = on ? 'true' : 'false';
      el.style.background  = on ? 'var(--brand-primary)' : 'var(--background-default)';
      el.style.borderColor = on ? 'var(--brand-primary)' : 'var(--border-default)';
      el.innerHTML = on ? '<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="var(--content-on-brand)" stroke-width="3" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>' : '';
    }

    function frmFocusSel(el) {
      el.style.borderColor = 'var(--brand-primary)';
      el.style.boxShadow   = '0 0 0 3px rgba(67,0,152,0.12)';
      setTimeout(function() { if (document.activeElement !== el) { el.style.borderColor = 'var(--border-default)'; el.style.boxShadow = ''; } }, 0);
    }

    function frmValidate(field) {
      var errors = {
        nom: function() {
          var v = document.getElementById('frm-nom').value.trim();
          if (!v) return 'Ce champ est obligatoire';
          if (v.length < 3) return 'Minimum 3 caractères';
          return null;
        },
        cat: function() {
          var v = document.getElementById('frm-cat').value;
          if (!v) return 'Veuillez choisir une catégorie';
          return null;
        },
      };
      var fn = errors[field];
      if (!fn) return true;
      var err = fn();
      var input = document.getElementById('frm-' + field);
      var errEl = document.getElementById('frm-err-' + field);
      var wrap  = document.getElementById('frm-field-' + field);
      if (err) {
        if (input) { input.style.borderColor = 'var(--input-border-error)'; input.style.boxShadow = 'none'; input.style.background = 'var(--status-danger-bg)'; }
        if (errEl) { errEl.style.display = 'flex'; errEl.querySelector('span').textContent = err; }
        return false;
      } else {
        if (input) { input.style.borderColor = 'var(--status-success-border)'; input.style.boxShadow = '0 0 0 3px rgba(22,163,74,0.1)'; input.style.background = ''; }
        if (errEl) errEl.style.display = 'none';
        return true;
      }
    }

    function frmSubmit() {
      var fields = ['nom','cat'];
      var allValid = true;
      var firstErr = null;
      fields.forEach(function(f) {
        if (!frmValidate(f)) { allValid = false; if (!firstErr) firstErr = f; }
      });
      if (!allValid) {
        var el = document.getElementById('frm-' + firstErr);
        if (el) { el.scrollIntoView({ behavior:'smooth', block:'center' }); el.classList.remove('frm-shake'); void el.offsetWidth; el.classList.add('frm-shake'); }
        return;
      }
      var banner = document.getElementById('frm-success-banner');
      if (banner) { banner.style.display = 'flex'; banner.classList.remove('frm-success-pop'); void banner.offsetWidth; banner.classList.add('frm-success-pop'); banner.scrollIntoView({ behavior:'smooth', block:'start' }); }
      var btn = document.getElementById('frm-save-btn');
      if (btn) { btn.textContent = '✓ Sauvegardé'; btn.style.background = 'var(--status-success-content)'; }
    }

    function frmReset() {
      ['nom'].forEach(function(f) {
        var inp = document.getElementById('frm-' + f);
        if (inp) { inp.value = ''; inp.style.borderColor = ''; inp.style.boxShadow = ''; inp.style.background = ''; }
        var errEl = document.getElementById('frm-err-' + f);
        if (errEl) errEl.style.display = 'none';
      });
      var cat = document.getElementById('frm-cat');
      if (cat) { cat.value = ''; cat.style.borderColor = ''; cat.style.boxShadow = ''; }
      var errCat = document.getElementById('frm-err-cat');
      if (errCat) errCat.style.display = 'none';
      var banner = document.getElementById('frm-success-banner');
      if (banner) banner.style.display = 'none';
      var btn = document.getElementById('frm-save-btn');
      if (btn) { btn.textContent = 'Sauvegarder'; btn.style.background = 'var(--brand-primary)'; }
    }
  </script>

  <!-- ANATOMY -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Anatomy</h2></div>
    <p class="doc-section-desc">Every Iksir form follows the same three-layer anatomy: a page header with the save action, collapsible sections grouping related fields, and a sticky footer fallback for long pages. There is no floating or inline save — the primary action lives top-right at all times.</p>
    <div class="grid-2" style="margin-top:16px">
      <div class="rule-card accent"><div class="rule-card-title">Page header owns the save action</div><div class="rule-card-body">The "Sauvegarder" button lives in the page header, top-right. It stays visible as the user scrolls through long forms. Never put the primary save action only at the bottom.</div></div>
      <div class="rule-card"><div class="rule-card-title">Sections group intent</div><div class="rule-card-body">Related fields are grouped in collapsible sections with accordion headers. The first section is always expanded by default. Subsequent sections are collapsed to reduce cognitive load.</div></div>
      <div class="rule-card"><div class="rule-card-title">No multi-column on the page level</div><div class="rule-card-body">The page is single-column. Multi-column grids exist only inside sections — e.g., 3 select inputs in a row for Catégorie / Comportement / Unité. Never put two sections side-by-side.</div></div>
      <div class="rule-card accent"><div class="rule-card-title">Labels always above inputs</div><div class="rule-card-body">Iksir uses top-aligned labels. Never inline or floating labels. 12px Semibold, <code>content/primary</code>, with a 5px gap to the input below.</div></div>
    </div>
  </div>

  <!-- FIELD STATES -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Field states</h2></div>
    <p class="doc-section-desc">All inputs share the same four states. State is communicated through border colour, shadow, and trailing icon — never background colour alone.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Input — all four states</span></div>
      <div class="inp-demo-stage" style="padding:24px">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;max-width:600px;margin:0 auto">
          <div>
            ${label('Default')}
            ${input({ placeholder: 'Nom de produit', state: 'default' })}
            ${helper('12px Semibold label, neutral border')}
          </div>
          <div>
            ${label('Focused')}
            ${input({ placeholder: 'Nom de produit', state: 'focused' })}
            ${helper('Purple border + 3px ring at 12% opacity')}
          </div>
          <div>
            ${label('Filled')}
            ${input({ value: 'Produit de référence A7', state: 'filled' })}
            ${helper('Value in content/primary')}
          </div>
          <div>
            ${label('Error', true)}
            ${input({ value: 'abc123!', state: 'error' })}
            ${helper('Ce champ est obligatoire', 'error')}
          </div>
        </div>
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#E1E1E1','border/default','Default border')}
        ${swatch('#430098','border/brand','Focused border')}
        ${swatch('#E04756','status/danger-border','Error border')}
        ${swatch('#FFF8F8','status/danger-bg','Error background')}
      </div>
    </div>
  </div>

  <!-- DISABLED STATE -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Disabled state</h2></div>
    <p class="doc-section-desc">Disabled fields are not editable but still communicate their current value. Use 60% opacity on the entire field — label, input, and helper text all dim together.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Disabled field</span></div>
      <div class="inp-demo-stage" style="padding:24px;display:flex;justify-content:center">
        <div style="width:300px">
          <div style="opacity:.6">
            ${label('Code produit')}
            ${input({ value: 'PRD-00441', state: 'disabled' })}
            ${helper('Généré automatiquement — non modifiable')}
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- FIELD GRID -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Field grids</h2></div>
    <p class="doc-section-desc">Within a section, fields can be arranged in 1-, 2-, or 3-column grids. Use column count to signal field relationship — fields in the same row are always related (e.g., Catégorie + Comportement + Unité belong together logically).</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Mixed grid layout</span></div>
      <div class="inp-demo-stage" style="padding:24px">
        <div style="max-width:640px;margin:0 auto;display:flex;flex-direction:column;gap:14px">
          ${field('Nom de produit', input({ value: 'Palette de stockage type A', state: 'filled' }), true)}
          ${row(
            field('Catégorie', select({ label: 'Sélectionner...', value: 'Matériel', state: 'filled' }), true),
            field('Comportement', select({ label: 'Sélectionner...', value: 'Stocké', state: 'filled' }), true),
            field('Unité de mesure', select({ label: 'Sélectionner...', value: 'Unité', state: 'filled' }), true)
          )}
          <div>
            ${label('Description')}
            <textarea readonly style="width:100%;box-sizing:border-box;height:72px;padding:10px 12px;border-radius:8px;border:1px solid var(--border-default);font-family:Inter,sans-serif;font-size:13px;color:var(--content-tertiary);resize:none;outline:none" placeholder="Description facultative..."></textarea>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- COLLAPSIBLE SECTIONS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Collapsible sections</h2></div>
    <p class="doc-section-desc">Long forms are split into collapsible accordion sections. The first section ("Informations de base") is expanded by default. All others start collapsed. Users can expand any section independently.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Three sections — first expanded</span></div>
      <div class="inp-demo-stage" style="padding:24px">
        <div style="max-width:580px;margin:0 auto;display:flex;flex-direction:column;gap:8px">
          ${fieldGroup('Informations de base', `
            ${field('Nom de produit', input({ value: 'Palette de stockage type A', state: 'filled' }), true)}
            ${row(
              field('Catégorie', select({ value: 'Matériel' })),
              field('Unité', select({ value: 'Unité' }))
            )}
            <div style="display:flex;gap:20px;flex-wrap:wrap">
              ${checkbox(true, 'Vendable')}
              ${checkbox(false, 'Commandable')}
              ${checkbox(true, 'Retournable')}
            </div>
          `)}
          ${fieldGroup('Composants', '', true)}
          ${fieldGroup('Palettisation', '', true)}
        </div>
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#FFFFFF','surface/default','Section background')}
        ${swatch('#E1E1E1','border/subtle','Section border')}
        ${swatch('#430098','brand/primary','Active chevron')}
      </div>
    </div>
  </div>

  <!-- REQUIRED FIELDS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Required fields</h2></div>
    <p class="doc-section-desc">Required fields have a red asterisk (<code>*</code>) immediately after the label text, in <code>status/danger-content</code>. There is no "* required fields" footnote — the asterisk is self-explanatory in context.</p>
    <div class="grid-2" style="margin-top:16px">
      <div class="rule-card accent">
        <div class="rule-card-title">Asterisk placement</div>
        <div class="rule-card-body">The asterisk follows the label text directly with 2px margin-left. It inherits the label's 12px Semibold weight. Color: <code>status/danger-content</code> (#D8192C).</div>
      </div>
      <div class="rule-card">
        <div class="rule-card-title">Save button disabled until valid</div>
        <div class="rule-card-body">The primary save action stays in <code>disabled</code> state until all required fields pass validation. On hover over a disabled save button, show a tooltip listing which fields are missing.</div>
      </div>
    </div>
  </div>

  <!-- IMAGE UPLOAD -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Image upload zone</h2></div>
    <p class="doc-section-desc">File uploads use a dashed-border dropzone. The dashed border signals "drag here" without the weight of a solid border. Supports click-to-browse and drag-and-drop.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Image upload — empty state</span></div>
      <div class="inp-demo-stage" style="padding:24px;display:flex;justify-content:center">
        <div style="width:340px;height:120px;border:2px dashed var(--border-default);border-radius:10px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;cursor:pointer;color:var(--content-tertiary);transition:border-color .15s" onmouseenter="this.style.borderColor='#430098';this.style.color='#430098'" onmouseleave="this.style.borderColor='var(--border-default)';this.style.color='var(--content-tertiary)'">
          ${IMG_UP}
          <span style="font-family:Inter,sans-serif;font-size:12px;font-weight:600">Glisser une image ici</span>
          <span style="font-family:Inter,sans-serif;font-size:11px">ou <span style="color:var(--brand-primary);text-decoration:underline">parcourir</span> · PNG, JPG, max 5 MB</span>
        </div>
      </div>
    </div>
  </div>

  <!-- VALIDATION -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Validation timing</h2></div>
    <div class="grid-2" style="margin-top:16px">
      <div class="rule-card accent"><div class="rule-card-title">Validate on blur, not on change</div><div class="rule-card-body">Show error states when the user leaves a field (onBlur), not while they type. Exception: password strength indicators update live on change.</div></div>
      <div class="rule-card"><div class="rule-card-title">Scroll to first error on submit</div><div class="rule-card-body">When the save action is attempted with invalid fields, scroll to and focus the first invalid field. Do not just show a toast — the user needs to know which field to fix.</div></div>
      <div class="rule-card"><div class="rule-card-title">Inline error messages</div><div class="rule-card-body">Error text sits directly below the field in <code>status/danger-content</code> at 11px. It replaces the helper text — both cannot show at once.</div></div>
      <div class="rule-card accent"><div class="rule-card-title">Never clear user input on error</div><div class="rule-card-body">When showing an error, keep the user's value in the field. They need to read what they typed to understand what to fix.</div></div>
    </div>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Group fields by logical intent inside named sections. Users scan form sections before reading individual labels.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use more than 3 columns in a field grid. The 1440px canvas makes 4+ columns too narrow for comfortable interaction.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Keep the primary save action in the page header and always visible, regardless of scroll position.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't show more than one error message per field at a time. Surface only the highest-priority validation rule.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Default to expanding only the first section. Users who understand the form will expand others themselves.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't put the Cancel action in the same visual weight as Save. Use Secondary gray for Cancel.</div></div>
    </div>
  </div>

  </div>`;
}
