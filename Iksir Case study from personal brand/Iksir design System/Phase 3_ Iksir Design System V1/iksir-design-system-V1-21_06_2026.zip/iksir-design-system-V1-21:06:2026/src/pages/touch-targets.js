import { pageHeader } from '../utils/render.js';

export default function touchTargets() {
  return pageHeader(
    'Platform',
    'Touch Targets',
    'Minimum sizes, spacing rules, and component-specific touch target specifications for Iksir mobile interfaces.'
  ) + `<div class="page-body">

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Why touch targets matter</h2>
      </div>
      <p class="doc-section-desc">Task Master is used by warehouse workers who may wear gloves, operate in low-light conditions, and interact with the app while moving. The 44×44px minimum is not a guideline — it is a requirement. Components that fall below this size will fail QA review.</p>
      <div class="grid-2" style="margin-top:16px">
        <div class="rule-card accent">
          <div class="rule-card-title">The 44px rule</div>
          <div class="rule-card-body">Every interactive element must have a minimum tap area of 44×44px. The visual size can be smaller — use invisible padding to extend the tap area. This aligns with Apple HIG and Android Material guidelines.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Gloved hand modifier</div>
          <div class="rule-card-body">For actions in the primary task flow (marking tasks complete, scanning barcodes, confirming orders) increase targets to 56×56px minimum. The extra 12px makes a measurable difference with heavy gloves.</div>
        </div>
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Component minimum sizes</h2>
      </div>
      <div style="margin-top:16px;border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden">
        <div style="display:grid;grid-template-columns:2fr 1fr 1fr 2fr;background:var(--background-subtle);padding:10px 16px;gap:12px">
          ${['Component','Visual size','Touch target','Notes'].map(h => `<div style="font-size:11px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em">${h}</div>`).join('')}
        </div>
        ${[
          ['FAB','56×56px','56×56px','Already at minimum. No invisible padding needed.'],
          ['Tab bar item','24px icon','Full tab width × 56px','Tab bar item is always full-width touch area.'],
          ['Primary button','44px h','Full width × 44px','Full-width buttons are trivially touchable.'],
          ['Icon button (toolbar)','24px icon','44×44px','Add 10px invisible padding on all sides.'],
          ['Checkbox','20×20px','44×44px','Extend tap area with padding: 12px.'],
          ['Toggle / switch','20px h × 36px w','44×44px','Extend height with invisible padding.'],
          ['List row item','56–72px h','Full row','Full-row tap area is the default for list items.'],
          ['Numeric keypad key','56px h','Full key width × 56px','Keys are 56px tall by design.'],
          ['Close × button (modal)','24px','44×44px','Use padding: 10px on the × icon container.'],
          ['Chip (tag / composant)','28–32px h','Entire chip','Minimum chip height is 32px with 6px vert padding.'],
        ].map(([comp, visual, touch, notes], i) => `
        <div style="display:grid;grid-template-columns:2fr 1fr 1fr 2fr;padding:10px 16px;gap:12px;${i < 9 ? 'border-top:1px solid var(--border-subtle)' : ''}">
          <div style="font-size:12px;font-weight:600;color:var(--content-primary)">${comp}</div>
          <div style="font-family:var(--font-mono);font-size:11px;color:var(--content-secondary)">${visual}</div>
          <div style="font-family:var(--font-mono);font-size:11px;color:var(--brand-primary);font-weight:600">${touch}</div>
          <div style="font-size:12px;color:var(--content-tertiary)">${notes}</div>
        </div>`).join('')}
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Spacing between targets</h2>
      </div>
      <p class="doc-section-desc">Adjacent touch targets need enough space to prevent mis-taps. This is especially important in dense list views and action groups.</p>
      <div class="grid-2" style="margin-top:16px">
        <div class="rule-card accent">
          <div class="rule-card-title">Minimum gap between interactive elements</div>
          <div class="rule-card-body">8px minimum between the edges of adjacent tap areas. For high-risk adjacent actions (e.g., Delete next to a Confirm button), increase to 16px.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Inline action groups</div>
          <div class="rule-card-body">Icon button rows (edit + delete + share) should have a minimum 8px gap. Prefer a "…" overflow menu over showing three icon buttons inline when width is constrained.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">List rows</div>
          <div class="rule-card-body">List rows are full-width touch targets. They naturally prevent vertical mis-taps because adjacent rows are separated by the row height (56–72px). No extra gap needed.</div>
        </div>
        <div class="rule-card accent">
          <div class="rule-card-title">Bottom sheet action stacks</div>
          <div class="rule-card-body">Stacked action buttons in a bottom sheet should use 8px gaps and each button should be 48px tall minimum. Do not reduce height to fit more actions — add a scroll instead.</div>
        </div>
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Testing touch targets</h2>
      </div>
      <p class="doc-section-desc">Two methods for verifying touch targets during design review.</p>
      <div class="grid-2" style="margin-top:16px">
        <div class="rule-card">
          <div class="rule-card-title">In Figma</div>
          <div class="rule-card-body">Create a 44×44 frame around any interactive element and check it fits with room to spare. Iksir's "Touch Target Audit" component (in the mobile library) overlays a red indicator on elements that are below 44px.</div>
        </div>
        <div class="rule-card accent">
          <div class="rule-card-title">On device</div>
          <div class="rule-card-body">Enable Settings → Accessibility → Touch → AssistiveTouch on iOS to visualise tap hit areas. The "Tap" tool shows the actual tapped coordinate — use it to verify edge elements reach the full 44px target.</div>
        </div>
      </div>
    </div>

  </div>`;
}
