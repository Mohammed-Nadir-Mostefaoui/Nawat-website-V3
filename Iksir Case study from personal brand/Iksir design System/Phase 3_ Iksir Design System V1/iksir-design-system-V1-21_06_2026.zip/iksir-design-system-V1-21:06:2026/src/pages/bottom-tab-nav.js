import { pageHeader } from '../utils/render.js';

const ICONS = {
  tasks:  `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>`,
  orders: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`,
  scan:   `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 7 4 4 7 4"/><polyline points="17 4 20 4 20 7"/><polyline points="4 17 4 20 7 20"/><polyline points="17 20 20 20 20 17"/><line x1="4" y1="12" x2="20" y2="12"/></svg>`,
  profile:`<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`,
};

const SCREENS = {
  tasks:  { title:'Tasks',    bg:'#F7F4FB', accent:'#430098', lines:['Prepare order CMD-2847','Check stock level A-12','Validate delivery 08:30'] },
  orders: { title:'Orders',   bg:'#EFF6FF', accent:'#0550AE', lines:['CMD-2847 — En transit','CMD-2839 — Livré','CMD-2831 — En attente'] },
  scan:   { title:'Scan',     bg:'#0A0A0A', accent:'#fff',    lines:[] },
  profile:{ title:'Profile',  bg:'#F0FDF4', accent:'#16A34A', lines:['Mohammed Nadir','Admin · Dépôt central','Connecté depuis 2h'] },
};

function swatch(color, name, label) {
  const light = ['#F6F6F6','#BDBDBD','#FFFFFF'].includes(color);
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${color};${light?'border:1px solid #E1E1E1':''}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${label}</div></div></div>`;
}

export default function bottomTabNav() {
  return pageHeader('Components', 'Bottom Tab Nav', 'Primary navigation for mobile. Persistent, always visible, 4–5 tabs max. Active indicator pill + icon + label.', [
    { val: '4–5', label: 'Tabs' },
    { val: '64px', label: 'Height' },
  ]) + `<div class="page-body">

  <style>
    @keyframes tab-content-in { from { opacity:0; transform:translateY(6px); } to { opacity:1; transform:translateY(0); } }
    .tab-screen-content { animation: tab-content-in 0.22s ease; }
    @keyframes tab-ripple { from { transform:scale(0); opacity:0.4; } to { transform:scale(3); opacity:0; } }
  </style>

  <!-- LIVE DEMO -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Live — click any tab</h2></div>
    <p class="doc-section-desc">Tap any tab below. The screen content transitions, the active indicator slides, and the icon + label shift to brand colour. Mirrors exact mobile behaviour.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Bottom Tab Nav — interactive</span></div>
      <div class="inp-demo-stage" style="display:flex;justify-content:center;padding:24px;background:#E8E8E8">
        <!-- phone frame -->
        <div style="width:320px;border-radius:28px;overflow:hidden;box-shadow:0 20px 40px rgba(0,0,0,0.22),0 0 0 1px rgba(0,0,0,0.08);background:#fff;font-family:Inter,sans-serif">
          <!-- status bar -->
          <div style="height:32px;background:#fff;display:flex;align-items:center;justify-content:space-between;padding:0 20px">
            <span style="font-size:11px;font-weight:700;color:#191919">9:41</span>
            <div style="display:flex;gap:4px;align-items:center">
              <div style="width:16px;height:8px;border-radius:2px;border:1px solid #191919;position:relative"><div style="position:absolute;left:1px;top:1px;bottom:1px;width:60%;background:#191919;border-radius:1px"></div></div>
            </div>
          </div>
          <!-- screen area -->
          <div id="btab-screen" style="height:220px;background:#F7F4FB;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:16px;position:relative;overflow:hidden">
            <div class="tab-screen-content" id="btab-content" style="text-align:center">
              <div style="font-size:14px;font-weight:700;color:var(--tab-nav-icon-active);margin-bottom:12px">Tasks</div>
              ${SCREENS.tasks.lines.map(l=>`<div style="font-size:11px;color:var(--content-secondary);padding:4px 8px;background:rgba(255,255,255,0.8);border-radius:6px;margin-bottom:4px">${l}</div>`).join('')}
            </div>
          </div>
          <!-- tab bar -->
          <div id="btab-bar" data-active="tasks" style="display:flex;height:64px;background:var(--tab-nav-bg);border-top:1px solid var(--tab-nav-border)">
            ${Object.entries(ICONS).map(([id, icon]) => {
              const active = id === 'tasks';
              return `<button data-tab="${id}" style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;background:none;border:none;cursor:pointer;position:relative;padding-top:4px;overflow:hidden"
                onclick="(function(el){
                  var bar = document.getElementById('btab-bar');
                  if(bar.dataset.active === el.dataset.tab) return;
                  bar.dataset.active = el.dataset.tab;
                  var tabs = bar.querySelectorAll('[data-tab]');
                  var screens = {tasks:{title:'Tasks',bg:'#F7F4FB',accent:'#430098',lines:['Prepare order CMD-2847','Check stock level A-12','Validate delivery 08:30']},orders:{title:'Orders',bg:'#EFF6FF',accent:'#0550AE',lines:['CMD-2847 — En transit','CMD-2839 — Livré','CMD-2831 — En attente']},scan:{title:'Scan',bg:'#0A0A0A',accent:'#fff',lines:[]},profile:{title:'Profile',bg:'#F0FDF4',accent:'#16A34A',lines:['Mohammed Nadir','Admin · Dépôt central','Connecté depuis 2h']}};
                  var sc = screens[el.dataset.tab] || screens.tasks;
                  var screen = document.getElementById('btab-screen');
                  if(screen) screen.style.background = sc.bg;
                  var content = document.getElementById('btab-content');
                  if(content){
                    content.classList.remove('tab-screen-content');
                    void content.offsetWidth;
                    content.classList.add('tab-screen-content');
                    content.innerHTML = '<div style=\\'font-size:14px;font-weight:700;color:'+sc.accent+';margin-bottom:12px\\'>' + sc.title + '</div>' + sc.lines.map(function(l){return '<div style=\\'font-size:11px;color:'+(sc.bg==='#0A0A0A'?'rgba(255,255,255,0.6)':'#757575')+';padding:4px 8px;background:'+(sc.bg==='#0A0A0A'?'rgba(255,255,255,0.1)':'rgba(255,255,255,0.8)')+';border-radius:6px;margin-bottom:4px\\'>' + l + '</div>';}).join('');
                    if(sc.lines.length===0) content.innerHTML += '<div style=\\'font-size:11px;color:rgba(255,255,255,0.5)\\'>Point camera at barcode</div>';
                  }
                  tabs.forEach(function(t){
                    var a = t.dataset.tab === el.dataset.tab;
                    var icon = t.querySelector('.btab-icon');
                    var label = t.querySelector('.btab-label');
                    var ind = t.querySelector('.btab-ind');
                    var active_clr = getComputedStyle(document.documentElement).getPropertyValue('--tab-nav-icon-active').trim();
                    var inactive_clr = getComputedStyle(document.documentElement).getPropertyValue('--tab-nav-icon-inactive').trim();
                    if(icon) icon.style.color = a ? active_clr : inactive_clr;
                    if(label){ label.style.color = a ? active_clr : inactive_clr; label.style.fontWeight = a ? '700' : '500'; }
                    if(ind) ind.style.opacity = a ? '1' : '0';
                  });
                  var rip = document.createElement('div');
                  var ripClr = getComputedStyle(document.documentElement).getPropertyValue('--tab-nav-ripple').trim();
                  rip.style.cssText='position:absolute;width:40px;height:40px;border-radius:50%;background:'+ripClr+';opacity:0;top:50%;left:50%;margin:-20px 0 0 -20px;pointer-events:none;animation:tab-ripple 0.5s ease-out forwards';
                  el.appendChild(rip);
                  setTimeout(function(){rip.remove();},500);
                })(this)">
                <span class="btab-ind" style="position:absolute;top:0;left:50%;transform:translateX(-50%);width:32px;height:3px;border-radius:0 0 3px 3px;background:var(--tab-nav-indicator);transition:opacity 0.2s;opacity:${active?1:0}"></span>
                <span class="btab-icon" style="color:${active?'var(--tab-nav-icon-active)':'var(--tab-nav-icon-inactive)'};transition:color 0.2s;position:relative">${icon}</span>
                <span class="btab-label" style="font-size:10px;font-weight:${active?'700':'500'};color:${active?'var(--tab-nav-icon-active)':'var(--tab-nav-icon-inactive)'};transition:color 0.2s;font-family:Inter,sans-serif;text-transform:capitalize">${id}</span>
              </button>`;
            }).join('')}
          </div>
        </div>
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#430098','nav/tab/icon-active','Active icon + label')}
        ${swatch('#BDBDBD','nav/tab/icon-inactive','Inactive icon + label')}
        ${swatch('#430098','nav/tab/indicator','Active pill')}
        ${swatch('#FFFFFF','nav/tab/background','Bar background')}
      </div>
    </div>
  </div>

  <!-- BADGE -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Notification badge</h2></div>
    <p class="doc-section-desc">Red dot badge sits top-right of the icon — never on the label. Shows number 1–99; "99+" for overflow. Never badge more than 2 tabs simultaneously.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">Orders badge — select count</span>
        <div class="inp-demo-controls">
          <span class="inp-demo-meta">Count</span>
          <select class="inp-state-select" onchange="(function(v){var b=document.getElementById('btab-badge');if(b){b.textContent=v;b.style.display=v==='none'?'none':'flex';}})(this.value)">
            <option value="none">None</option>
            <option value="3" selected>3</option>
            <option value="12">12</option>
            <option value="99+">99+</option>
          </select>
        </div>
      </div>
      <div class="inp-demo-stage" style="display:flex;justify-content:center;padding:24px;background:#E8E8E8">
        <div style="width:320px;border-radius:16px;overflow:hidden;border:1px solid rgba(0,0,0,0.08);background:var(--tab-nav-bg)">
          <div style="display:flex;height:64px">
            ${Object.entries(ICONS).map(([id, icon]) => {
              const active = id === 'tasks';
              const hasBadge = id === 'orders';
              return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;position:relative;padding-top:4px">
                ${active ? `<span style="position:absolute;top:0;left:50%;transform:translateX(-50%);width:32px;height:3px;border-radius:0 0 3px 3px;background:var(--tab-nav-indicator)"></span>` : ''}
                <span style="color:${active?'var(--tab-nav-icon-active)':'var(--tab-nav-icon-inactive)'};position:relative">
                  ${icon}
                  ${hasBadge ? `<span id="btab-badge" style="position:absolute;top:-4px;right:-6px;min-width:16px;height:16px;border-radius:9999px;background:var(--tab-nav-badge-bg);color:var(--tab-nav-badge-text);font-size:9px;font-weight:700;display:flex;align-items:center;justify-content:center;padding:0 3px;border:1.5px solid #fff;font-family:Inter,sans-serif">3</span>` : ''}
                </span>
                <span style="font-size:10px;font-weight:${active?'700':'500'};color:${active?'var(--tab-nav-icon-active)':'var(--tab-nav-icon-inactive)'};font-family:Inter,sans-serif;text-transform:capitalize">${id}</span>
              </div>`;
            }).join('')}
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <div class="card" style="overflow:hidden">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Value</th><th>Usage</th></tr></thead>
        <tbody>
          ${[
            ['nav/tab/background','surface/default','Bar background'],
            ['nav/tab/icon-active','brand/primary','Active icon + label colour'],
            ['nav/tab/icon-inactive','content/tertiary','Inactive icon + label colour'],
            ['nav/tab/indicator','brand/primary','Active pill colour'],
            ['nav/tab/item-height','64px','Height above safe area'],
            ['nav/tab/icon-size','22×22px','Tab icon dimensions'],
            ['nav/tab/label-size','10px, Bold 700','Tab label typography'],
            ['nav/tab/indicator-width','32px','Pill width'],
            ['nav/tab/indicator-height','3px','Pill height'],
          ].map(([t,v,u],i) => `<tr style="${i%2===0?'background:var(--background-subtle);':''}border-bottom:1px solid var(--border-subtle)">
            <td style="padding:10px 16px"><code class="tok-name">${t}</code></td>
            <td style="padding:10px 16px;font-family:var(--font-mono);font-size:11px;color:var(--brand-primary)">${v}</td>
            <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${u}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
  </div>

  <!-- PROPS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
    <table class="prop-table">
      <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
      <tbody>
        <tr><td><span class="prop-name">tabs</span></td><td><span class="prop-type">Tab[]</span></td><td><span class="prop-default">—</span></td><td>Array of tab objects: { id, label, icon, badge? }. 4–5 items.</td></tr>
        <tr><td><span class="prop-name">activeTab</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>ID of the currently active tab. Controlled by the router.</td></tr>
        <tr><td><span class="prop-name">onTabChange</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Callback with the new tab ID when a tab is tapped.</td></tr>
      </tbody>
    </table>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Keep all top-level destinations in the tab bar. Users should reach any primary screen in a single tap.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use more than 5 tabs. If you have 6+ destinations, consolidate or use a nested navigation pattern.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Tapping the active tab should scroll the current screen back to the top (iOS/Android native convention).</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't hide the tab bar on scroll. It disorients users — only hide for true full-screen surfaces (scanner, video).</div></div>
    </div>
  </div>

  </div>`;
}
