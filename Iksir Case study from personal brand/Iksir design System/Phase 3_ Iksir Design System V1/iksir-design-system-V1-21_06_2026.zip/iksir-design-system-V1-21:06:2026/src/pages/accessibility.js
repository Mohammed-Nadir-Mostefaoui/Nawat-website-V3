import { pageHeader } from '../utils/render.js';

export default function() {
  return `
${pageHeader('Resources', 'Accessibility', 'WCAG 2.1 AA baked into the foundation. Contrast ratios, focus rings, touch targets, and disabled states — all defined as tokens.', [{val:'4.5:1',label:'Normal text'},{val:'3:1',label:'Large text & UI'},{val:'44px',label:'Min touch target'},{val:'2px',label:'Focus ring'}])}
  <div class="page-body">

    <!-- ── CONTRAST RATIOS ─────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Contrast ratios</h2><span class="doc-section-badge">WCAG 2.1 AA</span></div>
      <p class="doc-section-desc">WCAG AA requires 4.5:1 for normal text and 3:1 for large text, UI components, and graphical elements. All Iksir semantic color pairs meet these requirements.</p>

      <div class="a11y-contrast-table">
        <div class="a11y-table-head">
          <span>Pair</span>
          <span>Foreground</span>
          <span>Background</span>
          <span>Ratio</span>
          <span>Normal text</span>
          <span>Large text / UI</span>
        </div>
        ${[
          { pair: 'content/primary on bg/page',       fg: '#191919', bg: '#FFFFFF', ratio: '16.1:1', normal: true,  large: true  },
          { pair: 'content/secondary on bg/page',     fg: '#757575', bg: '#FFFFFF', ratio: '4.6:1',  normal: true,  large: true  },
          { pair: 'content/on-brand on bg/brand',     fg: '#FFFFFF', bg: '#430098', ratio: '8.5:1',  normal: true,  large: true  },
          { pair: 'content/tertiary on bg/page',      fg: '#A3A3A3', bg: '#FFFFFF', ratio: '2.5:1',  normal: false, large: false, note: 'Decorative use only' },
          { pair: 'content/disabled on bg/page',      fg: '#BABABA', bg: '#FFFFFF', ratio: '1.9:1',  normal: false, large: false, note: 'Exempt — disabled state' },
          { pair: 'status/success-content on success-bg', fg: '#148F47', bg: '#F2FDF6', ratio: '4.6:1',  normal: true,  large: true  },
          { pair: 'status/warning-content on warning-bg', fg: '#AE7004', bg: '#FEFBF6', ratio: '4.5:1',  normal: true,  large: true  },
          { pair: 'status/danger-content on danger-bg',   fg: '#D8192C', bg: '#FFF2F4', ratio: '4.7:1',  normal: true,  large: true  },
          { pair: 'content/secondary on bg/brand',         fg: '#757575', bg: '#430098', ratio: '1.8:1',  normal: false, large: false, note: '✗ Never use', fail: true },
        ].map(r => `
          <div class="a11y-table-row">
            <span class="a11y-pair">
              <span class="a11y-swatch" style="background:${r.fg};${r.fg==='#FFFFFF'?'border:1px solid #E1E1E1':''}"></span>
              <span class="a11y-swatch" style="background:${r.bg};${r.bg==='#FFFFFF'?'border:1px solid #E1E1E1':''}"></span>
              <span class="a11y-pair-name">${r.pair}</span>
            </span>
            <span class="a11y-hex">${r.fg}</span>
            <span class="a11y-hex">${r.bg}</span>
            <span class="a11y-ratio" style="font-weight:600;color:${r.normal ? '#148F47' : r.large ? '#AE7004' : '#A3A3A3'}">${r.ratio}</span>
            <span class="a11y-badge ${r.normal ? 'pass' : 'fail'}">${r.normal ? '✓ Pass' : r.note || '✗ Fail'}</span>
            <span class="a11y-badge ${r.large ? 'pass' : r.note && !r.fail ? 'exempt' : 'fail'}">${r.large ? '✓ Pass' : r.note && !r.fail ? r.note : '✗ Fail'}</span>
          </div>`).join('')}
      </div>
    </div>

    <!-- ── BRAND BACKGROUND RULE ────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Brand background text rule</h2><span class="doc-section-badge">Critical</span></div>
      <p class="doc-section-desc"><code>content/secondary</code> (#757575) passes on white and light surfaces but fails catastrophically on <code>background/brand</code> (#430098) with only 1.8:1 contrast. This affects any branded header, hero section, or purple surface in the product.</p>

      <div class="grid-2" style="margin-bottom:24px">
        <div class="card" style="overflow:hidden">
          <div style="padding:10px 16px;background:#FFF2F4;border-bottom:1px solid #FFD0D5;font-size:11px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:#D8192C">✗ Fails — never do this</div>
          <div style="background:#430098;padding:24px">
            <div style="font-size:10px;color:rgba(255,255,255,.5);letter-spacing:.08em;text-transform:uppercase;margin-bottom:8px">Référentiel</div>
            <div style="font-size:18px;font-weight:700;color:#FFFFFF;margin-bottom:6px">Gestion des produits</div>
            <div style="font-size:13px;color:#757575">231 produits · Mis à jour il y a 2h</div>
          </div>
          <div style="padding:12px 16px;display:flex;flex-direction:column;gap:4px">
            <div style="font-size:11px;color:var(--content-secondary)">Subtitle uses <code style="font-size:10px">content/secondary</code> (#757575)</div>
            <div style="font-size:11px;color:#D8192C;font-weight:600">Contrast: 1.8:1 — needs 4.5:1 ✗</div>
          </div>
        </div>
        <div class="card" style="overflow:hidden">
          <div style="padding:10px 16px;background:#F2FDF6;border-bottom:1px solid #C3EDD3;font-size:11px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:#148F47">✓ Passes — do this instead</div>
          <div style="background:#430098;padding:24px">
            <div style="font-size:10px;color:rgba(255,255,255,.5);letter-spacing:.08em;text-transform:uppercase;margin-bottom:8px">Référentiel</div>
            <div style="font-size:18px;font-weight:700;color:#FFFFFF;margin-bottom:6px">Gestion des produits</div>
            <div style="font-size:13px;color:rgba(255,255,255,.75)">231 produits · Mis à jour il y a 2h</div>
          </div>
          <div style="padding:12px 16px;display:flex;flex-direction:column;gap:4px">
            <div style="font-size:11px;color:var(--content-secondary)">Subtitle uses <code style="font-size:10px">rgba(255,255,255,.75)</code></div>
            <div style="font-size:11px;color:#148F47;font-weight:600">Contrast: 5.2:1 — passes AA ✓</div>
          </div>
        </div>
      </div>

      <div class="card" style="overflow:hidden">
        <div style="padding:10px 16px;background:var(--background-subtle);border-bottom:1px solid var(--border-subtle);font-size:11px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:var(--content-tertiary)">Safe text options on background/brand (#430098)</div>
        ${[
          { label: 'content/on-brand',      hex: '#FFFFFF',              ratio: '8.5:1', use: 'All primary text, headings, labels',    passes: true  },
          { label: 'rgba(255,255,255,.9)',   hex: 'rgba(255,255,255,.9)', ratio: '7.4:1', use: 'Strong secondary text',                 passes: true  },
          { label: 'rgba(255,255,255,.75)',  hex: 'rgba(255,255,255,.75)',ratio: '5.2:1', use: 'Muted subtitles, metadata, timestamps', passes: true  },
          { label: 'rgba(255,255,255,.6)',   hex: 'rgba(255,255,255,.6)', ratio: '3.6:1', use: 'Large text only (18px+ or 14px bold)',  passes: false, large: true },
          { label: 'content/secondary',      hex: '#757575',              ratio: '1.8:1', use: 'Never use on brand backgrounds',        passes: false, large: false },
        ].map((r, i) => `
          <div style="display:flex;align-items:center;gap:12px;padding:11px 16px;${i%2===0?'background:var(--background-subtle)':''};border-bottom:1px solid var(--border-subtle)">
            <div style="width:32px;height:32px;border-radius:6px;background:#430098;display:flex;align-items:center;justify-content:center;flex-shrink:0">
              <div style="width:16px;height:3px;border-radius:2px;background:${r.hex}"></div>
            </div>
            <div style="flex:1">
              <div style="font-family:monospace;font-size:11px;color:var(--brand-primary)">${r.label}</div>
              <div style="font-size:11px;color:var(--content-tertiary);margin-top:2px">${r.use}</div>
            </div>
            <div style="font-family:monospace;font-size:12px;font-weight:600;color:${r.passes ? '#148F47' : r.large ? '#AE7004' : '#D8192C'}">${r.ratio}</div>
            <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:4px;background:${r.passes ? '#F2FDF6' : r.large ? '#FEFBF6' : '#FFF2F4'};color:${r.passes ? '#148F47' : r.large ? '#AE7004' : '#D8192C'}">${r.passes ? '✓ AA' : r.large ? '✓ Large only' : '✗ Fail'}</span>
          </div>`).join('')}
      </div>
    </div>

    <!-- ── FOCUS RING ──────────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Focus ring</h2><span class="doc-section-badge">WCAG 2.4.11</span></div>
      <p class="doc-section-desc">The focus ring appears when a user navigates with a keyboard (Tab key). It must be visible on any background. Iksir uses a two-layer ring — a white offset gap followed by the brand color — ensuring visibility on both light and dark surfaces.</p>

      <div class="grid-2" style="margin-bottom:24px">
        <div class="card" style="padding:24px;display:flex;flex-direction:column;gap:16px">
          <div style="font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary)">Live preview</div>
          <div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap">
            <button style="height:40px;padding:0 20px;background:#430098;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;box-shadow:0 0 0 2px #fff, 0 0 0 4px #6933AD;cursor:default">Primary button</button>
            <button style="height:40px;padding:0 20px;background:transparent;color:#430098;border:1px solid #E1E1E1;border-radius:8px;font-size:14px;font-weight:500;box-shadow:0 0 0 2px #fff, 0 0 0 4px #6933AD;cursor:default">Secondary</button>
          </div>
          <div style="font-size:12px;color:var(--content-tertiary)">Both buttons shown in focused state</div>
        </div>
        <div class="card" style="padding:24px">
          <div style="font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary);margin-bottom:16px">Tokens</div>
          ${[
            { name: 'border/focus',  val: '#6933AD · Purple-80', desc: 'Ring color',     swatch: '#6933AD' },
            { name: 'focus/width',   val: '2px',                 desc: 'Ring thickness', swatch: null },
            { name: 'focus/offset',  val: '2px',                 desc: 'Gap from edge',  swatch: null },
          ].map(t => `
            <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border-subtle)">
              ${t.swatch ? `<div style="width:20px;height:20px;border-radius:4px;background:${t.swatch};flex-shrink:0"></div>` : `<div style="width:20px;height:20px;border-radius:4px;background:var(--background-subtle);border:1px solid var(--border-default);flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:var(--content-tertiary)">${t.val.replace('px','')}</div>`}
              <div style="flex:1">
                <div style="font-family:monospace;font-size:11px;color:var(--brand-primary)">${t.name}</div>
                <div style="font-size:11px;color:var(--content-tertiary)">${t.desc}</div>
              </div>
              <div style="font-family:monospace;font-size:11px;color:var(--content-secondary)">${t.val}</div>
            </div>`).join('')}
          <div style="margin-top:12px;background:var(--background-subtle);border-radius:var(--radius-lg);padding:12px;font-family:monospace;font-size:11px;color:var(--content-secondary);line-height:1.8">
            <span style="color:var(--content-tertiary)">/* CSS implementation */</span><br>
            outline: 2px solid #6933AD;<br>
            outline-offset: 2px;
          </div>
        </div>
      </div>

      <div class="callout" style="border-left:3px solid var(--brand-primary);background:var(--brand-primary-subtle);padding:14px 16px;border-radius:0 var(--radius-lg) var(--radius-lg) 0">
        <div style="font-size:13px;color:var(--content-primary);font-weight:500;margin-bottom:4px">WCAG 2.4.11 — Focus Appearance</div>
        <div style="font-size:13px;color:var(--content-secondary)">The focus indicator must have a minimum area equal to a 2px perimeter of the focused component, and a contrast ratio of at least 3:1 between focused and unfocused states. Iksir's 2px ring at <code>#6933AD</code> meets both requirements.</div>
      </div>
    </div>

    <!-- ── DUAL-SCRIPT TYPOGRAPHY ───────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Dual-script sizing rules</h2><span class="doc-section-badge">Arabic · RTL</span></div>
      <p class="doc-section-desc">Arabic fonts require a 2px larger base size than Latin to achieve equivalent optical weight and legibility. Complex ligatures and taller ascenders in Arabic script make the same point size feel visually smaller.</p>

      <div class="grid-2" style="margin-bottom:24px">
        <div class="card" style="padding:24px">
          <div style="font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--content-tertiary);margin-bottom:16px">Latin — 14px base</div>
          <div style="font-size:14px;font-weight:400;color:var(--content-primary);line-height:1.6;margin-bottom:16px">
            The quick brown fox jumps over the lazy dog.<br>
            Le renard brun rapide saute par-dessus le chien.<br>
            Accessibility matters for every user, everywhere.
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <span style="font-size:10px;padding:2px 8px;border-radius:4px;background:var(--brand-primary-muted);color:var(--brand-primary);font-family:monospace">Base: 14px</span>
            <span style="font-size:10px;padding:2px 8px;border-radius:4px;background:var(--brand-primary-muted);color:var(--brand-primary);font-family:monospace">Line height: auto</span>
            <span style="font-size:10px;padding:2px 8px;border-radius:4px;background:var(--brand-primary-muted);color:var(--brand-primary);font-family:monospace">Inter</span>
          </div>
        </div>
        <div class="card" style="padding:24px">
          <div style="font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--content-tertiary);margin-bottom:16px">Arabic — 16px base (+2px rule)</div>
          <div style="font-size:16px;font-weight:400;color:var(--content-primary);line-height:1.7;direction:rtl;text-align:right;margin-bottom:16px">
            الوصول يهم كل مستخدم في كل مكان.<br>
            الثعلب البني السريع يقفز فوق الكلب الكسول.<br>
            تصميم شامل للجميع بدون استثناء.
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <span style="font-size:10px;padding:2px 8px;border-radius:4px;background:#F7F0FF;color:#430098;font-family:monospace">Base: 16px</span>
            <span style="font-size:10px;padding:2px 8px;border-radius:4px;background:#F7F0FF;color:#430098;font-family:monospace">Line height: auto</span>
            <span style="font-size:10px;padding:2px 8px;border-radius:4px;background:#F7F0FF;color:#430098;font-family:monospace">Alexandria (headings) · Inter (body)</span>
          </div>
        </div>
      </div>

      <div style="background:var(--brand-primary-muted);border-left:3px solid var(--brand-primary);border-radius:0 var(--radius-lg) var(--radius-lg) 0;padding:14px 16px">
        <div style="font-size:13px;font-weight:600;color:var(--content-primary);margin-bottom:4px">The rule — Arabic fonts require a larger baseline</div>
        <div style="font-size:13px;color:var(--content-secondary);line-height:1.7">Arabic script has complex ligatures and taller ascenders that make the same point size appear optically smaller than Latin. Adding 2px brings the visual weight and legibility into balance. This is why <code style="font-size:11px">text/body-sm</code> is 14px in Latin mode and 16px in Arabic mode — same token, different mode value.</div>
      </div>
    </div>

    <!-- ── TOUCH TARGETS ──────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Touch targets</h2><span class="doc-section-badge">Mobile</span></div>
      <p class="doc-section-desc">Minimum touch target sizes ensure interactive elements are reachable by users with motor impairments. The visual size of a component can be smaller — the tap area must meet the minimum.</p>

      <div class="grid-2">
        <div class="card" style="padding:24px">
          <div style="font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary);margin-bottom:16px">Platform minimums</div>
          ${[
            { platform: 'iOS',         size: '44×44pt',  token: 'spacing/40 + padding', note: 'Apple HIG requirement' },
            { platform: 'Android',     size: '48×48dp',  token: 'spacing/48',            note: 'Material Design requirement' },
            { platform: 'WCAG 2.5.5',  size: '44×44px',  token: 'spacing/40 + padding', note: 'AAA criterion' },
            { platform: 'WCAG 2.5.8',  size: '24×24px',  token: 'spacing/24',            note: 'AA criterion (minimum)' },
          ].map(r => `
            <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border-subtle)">
              <div style="width:8px;height:8px;border-radius:50%;background:var(--brand-primary);flex-shrink:0"></div>
              <div style="flex:1">
                <div style="font-size:13px;font-weight:500;color:var(--content-primary)">${r.platform} — ${r.size}</div>
                <div style="font-size:11px;color:var(--content-tertiary)">${r.note}</div>
              </div>
              <div style="font-family:monospace;font-size:10px;color:var(--brand-primary)">${r.token}</div>
            </div>`).join('')}
        </div>
        <div class="card" style="padding:24px">
          <div style="font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary);margin-bottom:16px">Iksir component heights</div>
          ${[
            { component: 'Button SM',  height: '32px', touch: '44px', passes: false, note: 'Needs invisible tap area' },
            { component: 'Button MD',  height: '40px', touch: '44px', passes: false, note: 'Needs invisible tap area' },
            { component: 'Button LG',  height: '48px', touch: '48px', passes: true,  note: 'Meets Android minimum' },
            { component: 'Input',      height: '40px', touch: '44px', passes: false, note: 'Needs invisible tap area' },
            { component: 'Checkbox',   height: '20px', touch: '44px', passes: false, note: 'Always needs tap area wrapper' },
          ].map(r => `
            <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border-subtle)">
              <span style="display:inline-block;font-size:10px;font-weight:700;padding:2px 7px;border-radius:4px;background:${r.passes ? '#F2FDF6' : '#FFF2F4'};color:${r.passes ? '#148F47' : '#D8192C'}">${r.passes ? '✓' : '!'}</span>
              <div style="flex:1">
                <div style="font-size:13px;font-weight:500;color:var(--content-primary)">${r.component}</div>
                <div style="font-size:11px;color:var(--content-tertiary)">${r.note}</div>
              </div>
              <div style="text-align:right">
                <div style="font-size:12px;color:var(--content-primary)">${r.height} visual</div>
                <div style="font-size:11px;color:var(--content-tertiary)">${r.touch} tap area</div>
              </div>
            </div>`).join('')}
        </div>
      </div>
    </div>

    <!-- ── COLOR INDEPENDENCE ───────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Color independence</h2><span class="doc-section-badge">WCAG 1.4.1</span></div>
      <p class="doc-section-desc">Color must never be the only visual means of conveying information. In an ERP with dense forms and data tables, always pair status colors with an icon and text — so color-blind users receive exactly the same information as everyone else.</p>

      <div class="grid-2" style="margin-bottom:24px">

        <div class="card" style="overflow:hidden">
          <div style="padding:10px 16px;background:#FFF2F4;border-bottom:1px solid #FFD0D5;font-size:11px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:#D8192C">✗ Bad practice — color only</div>
          <div style="padding:20px">
            <div style="font-size:11px;font-weight:500;color:#191919;margin-bottom:6px">Nom de l'entreprise</div>
            <div style="height:40px;border:2px solid #E04756;border-radius:8px;padding:0 12px;display:flex;align-items:center;font-size:14px;color:#A3A3A3;margin-bottom:8px">Acme Corp</div>
            <div style="font-size:11px;color:#A3A3A3">Ce champ est requis.</div>
          </div>
          <div style="padding:10px 16px;background:#FFF2F4;border-top:1px solid #FFD0D5;font-size:12px;color:#D8192C">
            Red border alone — a color-blind user sees no difference from a normal input.
          </div>
        </div>

        <div class="card" style="overflow:hidden">
          <div style="padding:10px 16px;background:#F2FDF6;border-bottom:1px solid #C3EDD3;font-size:11px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:#148F47">✓ Good practice — color + icon + text</div>
          <div style="padding:20px">
            <div style="font-size:11px;font-weight:500;color:#191919;margin-bottom:6px">Nom de l'entreprise <span style="color:#E04756">*</span></div>
            <div style="height:40px;border:2px solid #E04756;border-radius:8px;padding:0 12px;display:flex;align-items:center;justify-content:space-between;font-size:14px;color:#191919;margin-bottom:8px;background:#FFF9F9">
              <span>Acme Corp</span>
              <span style="color:#E04756;font-size:16px;font-weight:700">⚠</span>
            </div>
            <div style="font-size:12px;color:#D8192C;font-weight:500">! Ce champ est requis.</div>
          </div>
          <div style="padding:10px 16px;background:#F2FDF6;border-top:1px solid #C3EDD3;font-size:12px;color:#148F47">
            Border + icon + helper text — three independent signals, visible to everyone.
          </div>
        </div>

      </div>

      <div style="background:#FFF2F4;border-left:3px solid #E04756;border-radius:0 var(--radius-lg) var(--radius-lg) 0;padding:14px 16px;margin-bottom:16px">
        <div style="font-size:13px;font-weight:600;color:#D8192C;margin-bottom:4px">WCAG 1.4.1 — Use of Color</div>
        <div style="font-size:13px;color:#191919;line-height:1.7">Color must not be the only visual means of conveying information, indicating an action, prompting a response, or distinguishing a visual element. Every status token in Iksir must be paired with at minimum one non-color signal — an icon OR helper text.</div>
      </div>

      <div style="background:var(--brand-primary-muted);border-left:3px solid var(--brand-primary);border-radius:0 var(--radius-lg) var(--radius-lg) 0;padding:14px 16px">
        <div style="font-size:13px;font-weight:600;color:var(--content-primary);margin-bottom:4px">ERP-specific note</div>
        <div style="font-size:13px;color:var(--content-secondary);line-height:1.7">Dense data tables and bulk action confirmations are especially risky — a red row background alone does not communicate "this record has an error" to color-blind users. Always add an icon column or a status label cell.</div>
      </div>
    </div>

    <!-- ── DISABLED STATES ────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Disabled states</h2></div>
      <p class="doc-section-desc">Disabled elements are exempt from contrast requirements — but they must still be clearly distinguishable from enabled elements. Always pair a disabled background token with a disabled text token.</p>
      <div class="grid-2">
        <div class="card" style="padding:24px">
          <div style="font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#148F47;margin-bottom:16px">✓ Do</div>
          <div style="display:flex;gap:12px;align-items:center;margin-bottom:16px">
            <button style="height:40px;padding:0 20px;background:#C0A8D9;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;opacity:.6;cursor:not-allowed">Save</button>
            <button style="height:40px;padding:0 20px;background:transparent;color:#BABABA;border:1px solid #E1E1E1;border-radius:8px;font-size:14px;cursor:not-allowed">Cancel</button>
          </div>
          <div style="font-size:12px;color:var(--content-secondary);line-height:1.6">Use <code style="font-size:11px">brand/primary-disabled</code> + <code style="font-size:11px">content/disabled</code> + <code style="font-size:11px">cursor:not-allowed</code>. Reduce opacity to 60% to reinforce the unavailable state.</div>
        </div>
        <div class="card" style="padding:24px">
          <div style="font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#D8192C;margin-bottom:16px">✗ Don't</div>
          <div style="display:flex;gap:12px;align-items:center;margin-bottom:16px">
            <button style="height:40px;padding:0 20px;background:#430098;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:not-allowed">Save</button>
            <button style="height:40px;padding:0 20px;background:transparent;color:#191919;border:1px solid #191919;border-radius:8px;font-size:14px;cursor:not-allowed">Cancel</button>
          </div>
          <div style="font-size:12px;color:var(--content-secondary);line-height:1.6">Never keep full color on a disabled button — users will try to click it. Never rely on cursor alone to communicate disabled state.</div>
        </div>
      </div>
    </div>

    <!-- ── SCREEN READER ──────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Screen reader guidelines</h2></div>
      <p class="doc-section-desc">Quick reference for developers building components. These apply to every interactive component in the system.</p>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px">
        ${[
          {
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><polyline points="4 7 4 4 20 4 20 7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/></svg>`,
            color: '#430098', bg: '#F7F4FB', border: '#D9CCEA',
            rule: 'Use semantic HTML first',
            desc: 'A &lt;button&gt; is always better than a &lt;div onclick&gt;. Native elements get keyboard support and ARIA roles for free.',
            code: '&lt;button&gt; not &lt;div onclick&gt;',
          },
          {
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18"/><line x1="8" y1="15" x2="14" y2="15"/></svg>`,
            color: '#0550AE', bg: '#EFF6FF', border: '#BFDBFE',
            rule: 'Every input needs a label',
            desc: 'Use &lt;label for="id"&gt; or aria-label. Placeholder text is not a label — it disappears when the user types.',
            code: 'aria-label or &lt;label for&gt;',
          },
          {
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`,
            color: '#B45309', bg: '#FFF7ED', border: '#FED7AA',
            rule: 'Icon-only buttons need aria-label',
            desc: 'A close button with only an × icon must have aria-label="Close". Screen readers announce "button" with no context otherwise.',
            code: 'aria-label="Close"',
          },
          {
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>`,
            color: '#D8192C', bg: '#FFF1F2', border: '#FECDD3',
            rule: 'Error messages need aria-live',
            desc: 'Validation errors that appear after submit must be in an aria-live="polite" region so screen readers announce them.',
            code: 'aria-live="polite"',
          },
          {
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>`,
            color: '#148F47', bg: '#F0FDF4', border: '#BBF7D0',
            rule: 'Focus order follows visual order',
            desc: 'Tab order must match the visual reading order (LTR: left→right, top→bottom). Never use tabindex &gt; 0.',
            code: 'tabindex="0" or -1 only',
          },
          {
            icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"/><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"/><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"/></svg>`,
            color: '#7B4DB7', bg: '#F5F0FF', border: '#D9CCEA',
            rule: 'Loading states need announcements',
            desc: 'When content loads async, add aria-busy="true" to the container and remove it when done.',
            code: 'aria-busy="true / false"',
          },
        ].map(r => `
          <div style="background:${r.bg};border:1px solid ${r.border};border-radius:14px;padding:18px;display:flex;flex-direction:column;gap:10px">
            <div style="display:flex;align-items:center;gap:10px">
              <div style="width:34px;height:34px;border-radius:9px;background:rgba(255,255,255,0.7);border:1px solid ${r.border};display:flex;align-items:center;justify-content:center;color:${r.color};flex-shrink:0">${r.icon}</div>
              <div style="font-family:var(--font-display);font-size:13px;font-weight:700;color:var(--content-primary);line-height:1.3">${r.rule}</div>
            </div>
            <p style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-secondary);line-height:1.65;margin:0">${r.desc}</p>
            <div style="margin-top:auto;padding-top:4px">
              <code style="font-family:var(--font-mono);font-size:11px;color:${r.color};background:rgba(255,255,255,0.7);border:1px solid ${r.border};padding:3px 9px;border-radius:6px">${r.code}</code>
            </div>
          </div>`).join('')}
      </div>
    </div>

  </div>
`;
}
