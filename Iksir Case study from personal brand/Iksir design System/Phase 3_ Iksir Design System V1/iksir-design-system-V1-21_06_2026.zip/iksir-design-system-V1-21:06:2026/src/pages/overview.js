import { pageHeader } from '../utils/render.js';
import { card as ci,
  P_OVERVIEW, P_PRINCIPLES, P_ARCH, P_ACCESS,
  P_PRIMITIVES, P_COLORS, P_TYPO, P_SPACING, P_SIZING, P_RADIUS, P_ELEVATION, P_ICONOGRAPHY,
  P_MOB_OVR, P_RESPONSIVE, P_TOUCH, P_MOB_NAV, P_FAB_PLAT,
  P_AVATAR, P_BADGE, P_BTM_SHEET, P_BTM_TAB, P_BREADCRUMB, P_BUTTON, P_CARD, P_CHECKBOX,
  P_DROPDOWN, P_FAB, P_INPUT, P_MOB_HEADER, P_MODAL, P_NUMPAD, P_PAGINATION, P_PRIORITY,
  P_SCANNER, P_SELECT, P_TAB, P_TABLE, P_TASK_CARD, P_TOAST, P_TOGGLE, P_TOOLTIP,
  P_CHARTS, P_DATA_TABLES, P_FORMS, P_NAVIGATION, P_TEMPLATES,
  P_FIGMA, P_EXPORT, P_CHANGELOG
} from '../data/icons.js';

/* ── card icons (18px rendered, 14×14 viewBox) ─────────────── */
const IC_OVERVIEW    = ci(P_OVERVIEW);
const IC_PRINCIPLES  = ci(P_PRINCIPLES);
const IC_ARCH        = ci(P_ARCH);
const IC_ACCESS      = ci(P_ACCESS);
const IC_PRIMITIVES  = ci(P_PRIMITIVES);
const IC_COLOR       = ci(P_COLORS);
const IC_TYPE        = ci(P_TYPO);
const IC_SPACE       = ci(P_SPACING);
const IC_SIZING      = ci(P_SIZING);
const IC_RADIUS      = ci(P_RADIUS);
const IC_ELEV        = ci(P_ELEVATION);
const IC_ICON        = ci(P_ICONOGRAPHY);
const IC_MOB_OVR     = ci(P_MOB_OVR);
const IC_RESPONSIVE  = ci(P_RESPONSIVE);
const IC_TOUCH       = ci(P_TOUCH);
const IC_MOB_NAV     = ci(P_MOB_NAV);
const IC_FAB_PLAT    = ci(P_FAB_PLAT);
const IC_AVATAR      = ci(P_AVATAR);
const IC_BADGE       = ci(P_BADGE);
const IC_BTM_SHEET   = ci(P_BTM_SHEET);
const IC_BTM_TAB     = ci(P_BTM_TAB);
const IC_BREADCRUMB  = ci(P_BREADCRUMB);
const IC_BUTTON      = ci(P_BUTTON);
const IC_CARD        = ci(P_CARD);
const IC_CHECKBOX    = ci(P_CHECKBOX);
const IC_DROPDOWN    = ci(P_DROPDOWN);
const IC_FAB         = ci(P_FAB);
const IC_INPUT       = ci(P_INPUT);
const IC_MOB_HEADER  = ci(P_MOB_HEADER);
const IC_MODAL       = ci(P_MODAL);
const IC_NUMPAD      = ci(P_NUMPAD);
const IC_PAGINATION  = ci(P_PAGINATION);
const IC_PRIORITY    = ci(P_PRIORITY);
const IC_SCANNER     = ci(P_SCANNER);
const IC_SELECT      = ci(P_SELECT);
const IC_TAB         = ci(P_TAB);
const IC_TABLE       = ci(P_TABLE);
const IC_TASK_CARD   = ci(P_TASK_CARD);
const IC_TOAST       = ci(P_TOAST);
const IC_TOGGLE      = ci(P_TOGGLE);
const IC_TOOLTIP     = ci(P_TOOLTIP);
const IC_CHARTS      = ci(P_CHARTS);
const IC_DATA_TABLES = ci(P_DATA_TABLES);
const IC_FORM        = ci(P_FORMS);
const IC_NAV         = ci(P_NAVIGATION);
const IC_TEMPLATES   = ci(P_TEMPLATES);
const IC_FIGMA       = ci(P_FIGMA);
const IC_EXPORT      = ci(P_EXPORT);
const IC_CHANGELOG   = ci(P_CHANGELOG);

/* ── utility icons (keep these as-is, not from shared set) ─── */
const IC_CHV = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>`;
const IC_ARR = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>`;

/* ── colour accent per section ─────────────────────────────── */
const ACCENTS = {
  tokens:     { bg: '#F7F4FB', border: '#D9CCEA', icon: '#430098', label: 'Tokens' },
  components: { bg: '#EFF6FF', border: '#BFDBFE', icon: '#0550AE', label: 'Components' },
  patterns:   { bg: '#F0FDF4', border: '#BBF7D0', icon: '#16A34A', label: 'Patterns' },
  mobile:     { bg: '#FFF7ED', border: '#FED7AA', icon: '#B45309', label: 'Platform' },
  resources:  { bg: '#FFF1F2', border: '#FECDD3', icon: '#D8192C', label: 'Resources' },
};

/* ── card builder ─────────────────────────────────────────── */
function card(id, icon, title, desc, meta, accent) {
  const { bg, border, icon: ic } = ACCENTS[accent];
  return `<a onclick="navigate('${id}')" style="display:flex;flex-direction:column;gap:0;background:${bg};border:1px solid ${border};border-radius:14px;padding:16px;cursor:pointer;transition:transform .15s,box-shadow .15s;box-shadow:0 1px 3px rgba(0,0,0,.04);text-decoration:none"
    onmouseenter="this.style.transform='translateY(-2px)';this.style.boxShadow='0 8px 24px rgba(0,0,0,.1)'"
    onmouseleave="this.style.transform='';this.style.boxShadow='0 1px 3px rgba(0,0,0,.04)'">
    <div style="width:34px;height:34px;border-radius:9px;background:rgba(255,255,255,0.6);border:1px solid ${border};display:flex;align-items:center;justify-content:center;color:${ic};margin-bottom:12px;flex-shrink:0">${icon}</div>
    <div style="font-family:var(--font-display);font-size:13px;font-weight:700;color:var(--content-primary);margin-bottom:4px">${title}</div>
    <div style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-secondary);line-height:1.55;flex:1">${desc}</div>
    <div style="margin-top:10px;display:flex;align-items:center;justify-content:space-between">
      <span style="font-family:var(--font-mono);font-size:10px;color:var(--content-tertiary)">${meta}</span>
      <span style="color:var(--content-tertiary)">${IC_CHV}</span>
    </div>
  </a>`;
}

/* ── stat pill ────────────────────────────────────────────── */
function stat(value, label, color = '#430098') {
  return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:16px 20px;border-right:1px solid var(--border-subtle)">
    <div style="font-family:var(--font-display);font-size:26px;font-weight:900;color:${color};letter-spacing:-1px;line-height:1">${value}</div>
    <div style="font-family:Inter,sans-serif;font-size:11px;color:var(--content-tertiary);margin-top:3px;white-space:nowrap">${label}</div>
  </div>`;
}

/* ── section header ───────────────────────────────────────── */
function sectionHead(accent, title, desc) {
  const { bg, border, icon: ic, label } = ACCENTS[accent];
  return `<div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:16px">
    <div style="width:28px;height:28px;border-radius:7px;background:${bg};border:1px solid ${border};display:flex;align-items:center;justify-content:center;color:${ic};flex-shrink:0;margin-top:2px">
      <svg width="13" height="13" viewBox="0 0 8 8"><rect width="8" height="8" rx="2" fill="${ic}"/></svg>
    </div>
    <div>
      <div style="font-family:Inter,sans-serif;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:${ic};margin-bottom:2px">${label}</div>
      <h2 class="doc-section-title" style="font-family:var(--font-display);font-size:18px;font-weight:800;color:var(--content-primary);letter-spacing:-.4px;line-height:1.1;margin:0">${title}</h2>
      ${desc ? `<div style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-secondary);margin-top:4px;line-height:1.5">${desc}</div>` : ''}
    </div>
  </div>`;
}

/* ═══════════════════════════════════════════════════════════ */
export default function overview() {
  return `<div style="padding:40px 48px 0;max-width:760px">
    <!-- hero -->
    <div style="margin-bottom:8px">
      <div style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:20px;background:var(--brand-primary-muted);border:1px solid #D9CCEA;font-family:Inter,sans-serif;font-size:11px;font-weight:600;color:#430098;margin-bottom:16px">
        <span style="width:6px;height:6px;border-radius:50%;background:#430098;display:inline-block"></span>
        v1.0 · Design System
      </div>
    </div>
    <h1 style="font-family:var(--font-display);font-size:40px;font-weight:900;color:var(--content-primary);letter-spacing:-1.5px;line-height:1.05;margin:0 0 14px">
      Design foundation<br>for <span style="color:#430098">everything</span>.
    </h1>
    <p style="font-family:Inter,sans-serif;font-size:15px;color:var(--content-secondary);line-height:1.65;max-width:540px;margin:0 0 32px">
      A scalable, token-first design system built for <strong style="color:var(--content-primary)">Iksir Digital Products</strong> — from primitive colour values through semantic tokens, interactive components, mobile-native patterns, and full product-level templates.
    </p>
  </div>

  <!-- stats bar -->
  <div style="margin:0 48px 40px;border:1px solid var(--border-subtle);border-radius:14px;overflow:hidden;display:flex;background:var(--background-default)">
    ${stat('231', 'Variables')}
    ${stat('24', 'Components', '#0550AE')}
    ${stat('5', 'Patterns', '#16A34A')}
    ${stat('6', 'Platforms', '#B45309')}
    <div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:16px 20px">
      <div style="font-family:var(--font-display);font-size:26px;font-weight:900;color:#D8192C;letter-spacing:-1px;line-height:1">2</div>
      <div style="font-family:Inter,sans-serif;font-size:11px;color:var(--content-tertiary);margin-top:3px;white-space:nowrap">Modes (L+D)</div>
    </div>
  </div>

  <div class="page-body" style="padding-top:0">

  <!-- GET STARTED ──────────────────────────────────────────── -->
  <div class="doc-section">
    ${sectionHead('tokens', 'Get started', 'System foundations, design philosophy, and accessibility guidelines.')}
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(188px,1fr));gap:10px">
      ${card('principles',   IC_PRINCIPLES, 'Principles',     'The design values and decision-making rules behind every choice in the system.', '5 principles', 'tokens')}
      ${card('architecture', IC_ARCH,       'Architecture',   'How tokens flow from Figma through code to production.', 'Token pipeline', 'tokens')}
      ${card('accessibility',IC_ACCESS,     'Accessibility',  'Contrast ratios, focus rings, and ARIA roles for every component.', 'WCAG AA', 'tokens')}
    </div>
  </div>

  <!-- LAYER DIAGRAM ─────────────────────────────────────────── -->
  <div class="doc-section">
    <h2 class="doc-section-title" style="margin-bottom:6px">How the system is built</h2>
    <p class="doc-section-desc" style="margin-bottom:20px">Three strict layers. Each layer consumes only the one below it — skip a layer and you break the single-source-of-truth guarantee.</p>
    <div style="display:flex;gap:0;border:1px solid var(--border-subtle);border-radius:14px;overflow:hidden">
      ${[
        { n:'01', label:'Primitives', sub:'Raw values: hex codes, px sizes, ms durations. Named by value, not intent.', ex:['#430098','4px','Inter','250ms'], color:'#430098', bg:'#F7F4FB' },
        { n:'02', label:'Semantic tokens', sub:'Named by intent. Map primitives to meaning. The only layer components touch.', ex:['brand/primary','radius/md','content/primary','duration/fast'], color:'#0550AE', bg:'#EFF6FF' },
        { n:'03', label:'Components & Patterns', sub:'Consume semantic tokens only. Never hard-coded values. Adaptive to any mode.', ex:['Button','Card','Data table','Forms'], color:'#16A34A', bg:'#F0FDF4' },
      ].map((l, i) => `
      <div style="flex:1;${i > 0 ? 'border-left:1px solid var(--border-subtle)' : ''};padding:20px;background:var(--background-default)">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
          <span style="font-family:var(--font-mono);font-size:10px;font-weight:700;color:${l.color};background:${l.bg};padding:2px 7px;border-radius:20px">${l.n}</span>
          <span style="font-family:var(--font-display);font-size:13px;font-weight:700;color:var(--content-primary)">${l.label}</span>
        </div>
        <p style="font-family:Inter,sans-serif;font-size:11px;color:var(--content-secondary);line-height:1.6;margin:0 0 12px">${l.sub}</p>
        <div style="display:flex;flex-wrap:wrap;gap:4px">
          ${l.ex.map(e => `<code style="font-family:var(--font-mono);font-size:10px;padding:2px 6px;border-radius:5px;background:var(--background-subtle);color:var(--content-secondary);border:1px solid var(--border-subtle)">${e}</code>`).join('')}
        </div>
      </div>`).join('')}
    </div>
  </div>

  <!-- TOKENS ───────────────────────────────────────────────── -->
  <div class="doc-section">
    ${sectionHead('tokens', 'Tokens', 'The values that power every component — colours, type, spacing, radius, elevation, and icon library.')}
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(188px,1fr));gap:10px">
      ${card('primitives',  IC_PRIMITIVES, 'Primitives',    'Raw palette and base values. The only place hex codes live.', '7 categories', 'tokens')}
      ${card('colors',      IC_COLOR,      'Colors',        '191 semantic tokens across brand, content, background, border, status groups. Light + Dark modes.', '191 tokens · 2 modes', 'tokens')}
      ${card('typography',  IC_TYPE,       'Typography',    '9 semantic text roles derived from real screen usage. Playground included.', '9 roles · Inter + Montserrat', 'tokens')}
      ${card('spacing',     IC_SPACE,      'Spacing',       '22-step 4pt grid. Every padding, gap, and margin value in the product.', '22 steps · 0–160px', 'tokens')}
      ${card('sizing',      IC_SIZING,     'Sizing',        '225 sizing tokens for widths, heights, and min/max constraints.', '225 tokens', 'tokens')}
      ${card('radius',      IC_RADIUS,     'Border Radius', '8 semantic aliases — scale names, not component names — for maximum reuse.', '8 aliases · none → full', 'tokens')}
      ${card('elevation',   IC_ELEV,       'Elevation',     '4 levels matching surface hierarchy: Card, Dropdown, Modal, Toast.', '4 levels · Effect styles', 'tokens')}
      ${card('iconography', IC_ICON,       'Iconography',   '86 Lucide-based icons in 3 weights. Usage rules and size grid.', '86 icons · 3 weights', 'tokens')}
    </div>
  </div>

  <!-- COMPONENTS ───────────────────────────────────────────── -->
  <div class="doc-section">
    ${sectionHead('components', 'Components', 'Token-bound UI building blocks — every state, variant, and interaction documented.')}
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(188px,1fr));gap:10px">
      ${card('avatar',          IC_AVATAR,     'Avatar',          'User avatar with status dot, group stack, and +N overflow.', 'Stack · status · group', 'components')}
      ${card('badge',           IC_BADGE,      'Badge',           'Status, count, and label badges across all semantic colours.', '6 colours · dot + label', 'components')}
      ${card('bottom-sheet',    IC_BTM_SHEET,  'Bottom Sheet',    'Spring-animated sheet. Drag to dismiss, 3 snap points. Interactive demo.', '3 snap points', 'components')}
      ${card('bottom-tab-nav',  IC_BTM_TAB,    'Bottom Tab Nav',  'iOS/Android-style 5-tab bar with active indicator and badge.', '5 items · badge', 'components')}
      ${card('breadcrumb',      IC_BREADCRUMB, 'Breadcrumb',      'Hierarchy trail. Max 4 crumbs, truncation rule.', '≤ 4 levels', 'components')}
      ${card('button',          IC_BUTTON,     'Button',          '8 hierarchies × 3 sizes × 4 icon types × 5 states. Fully token-bound.', '450 variants', 'components')}
      ${card('card-comp',       IC_CARD,       'Card',            'Surface container. Header, body, footer slots. Hover lift.', '3 slots', 'components')}
      ${card('checkbox',        IC_CHECKBOX,   'Checkbox',        'Boolean and indeterminate states. Label placement rules.', '3 states', 'components')}
      ${card('dropdown',        IC_DROPDOWN,   'Dropdown',        'Context menu and action list. Dividers, icons, danger item.', 'Up to 8 items', 'components')}
      ${card('fab',             IC_FAB,        'FAB',             'Extended, standard (56px), and mini (40px). Spring hover, ripple.', '3 sizes · ripple', 'components')}
      ${card('input',           IC_INPUT,      'Input',           'Text, number, password, search. All validation states.', '5 states', 'components')}
      ${card('mobile-header',   IC_MOB_HEADER, 'Mobile Header',   '4 variants: back+title, subtitle, actions, root screen.', '4 variants', 'components')}
      ${card('modal',           IC_MODAL,      'Modal',           'Overlay dialog. Sizes, backdrop, keyboard dismiss.', '3 sizes', 'components')}
      ${card('numeric-keypad',  IC_NUMPAD,     'Numeric Keypad',  '12-key input pad with haptic-feel press animation.', '12 keys · backspace', 'components')}
      ${card('pagination',      IC_PAGINATION, 'Pagination',      'Page navigation with count label, prev/next, and jump-to.', 'Full + compact', 'components')}
      ${card('priority-tag',    IC_PRIORITY,   'Priority Tag',    'Clickable tag that cycles High → Medium → Low → None.', '4 levels', 'components')}
      ${card('scanner-overlay', IC_SCANNER,    'Scanner Overlay', 'Barcode/QR viewfinder overlay with torch and flash states.', '3 states', 'components')}
      ${card('select',          IC_SELECT,     'Select',          'Single-select dropdown with search and multi-select variant.', 'Searchable', 'components')}
      ${card('tab',             IC_TAB,        'Tab',             'In-page section switcher. Underline indicator, overflow scroll.', 'Underline variant', 'components')}
      ${card('table',           IC_TABLE,      'Table',           'Sortable, selectable data table. Row actions, bulk toolbar.', 'Sort · select · filter', 'components')}
      ${card('task-card',       IC_TASK_CARD,  'Task Card',       'Expandable task row with status, assignee, and priority.', 'Expand · collapse', 'components')}
      ${card('toast',           IC_TOAST,      'Toast',           'Transient notification. 4 severities, auto-dismiss timer.', '4 types · 4s default', 'components')}
      ${card('toggle',          IC_TOGGLE,     'Toggle',          'On/off switch with size variants and disabled state.', 'SM · MD', 'components')}
      ${card('tooltip',         IC_TOOLTIP,    'Tooltip',         'Contextual hint. 4 directions, delay rules, max-width.', '4 positions', 'components')}
    </div>
  </div>

  <!-- PATTERNS ─────────────────────────────────────────────── -->
  <div class="doc-section">
    ${sectionHead('patterns', 'Patterns', 'Compositional guidelines for recurring product screens — not components, but how components work together.')}
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(188px,1fr));gap:10px">
      ${card('charts',      IC_CHARTS,      'Charts',       'Line, bar, donut, sparklines. Token-bound colours, mobile-ready phone demos.', 'Line · Bar · Donut', 'patterns')}
      ${card('data-tables', IC_DATA_TABLES, 'Data Tables',  'Sort, filter, row-select, bulk actions. Live sortable table included.', 'Sort · select · bulk', 'patterns')}
      ${card('forms',       IC_FORM,        'Forms',        'Field layout, validation, collapsible sections. Live interactive demo.', 'Validate on blur', 'patterns')}
      ${card('navigation',  IC_NAV,         'Navigation',   'Sidebar, breadcrumb, in-page tabs, page header. Fully interactive shell.', 'Collapsible sidebar', 'patterns')}
      ${card('templates',   IC_TEMPLATES,   'Templates',    'Full-page layout blueprints: list, detail, wizard. Grid + spacing rules.', 'L1 + L2 + L3', 'patterns')}
    </div>
  </div>

  <!-- RESOURCES ────────────────────────────────────────────── -->
  <div class="doc-section">
    ${sectionHead('resources', 'Resources', 'Export, integrate, and validate your work against the system.')}
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(188px,1fr));gap:10px">
      ${card('figma',     IC_FIGMA,    'Figma Library', 'Variable setup, component swap, multi-mode guide.', 'Variable API', 'resources')}
      ${card('export',    IC_EXPORT,   'CSS Export',    'Copy all semantic tokens as CSS custom properties, ready to paste.', ':root variables', 'resources')}
      ${card('changelog', IC_CHANGELOG,'Changelog',     'Release history, breaking changes, and migration notes.', 'v1.0 · SemVer', 'resources')}
    </div>
  </div>

  <!-- QUICK-START ───────────────────────────────────────────── -->
  <div class="doc-section">
    <h2 class="doc-section-title" style="margin-bottom:6px">Quick-start rules</h2>
    <p class="doc-section-desc" style="margin-bottom:16px">Four non-negotiable constraints that keep the system coherent as it grows.</p>
    <div class="grid-2">
      <div class="rule-card accent">
        <div class="rule-card-title">Always use semantic tokens</div>
        <div class="rule-card-body">Never reference raw hex values or primitive tokens in components. Use <code>brand/primary</code> not <code>#430098</code>. This is what makes the system maintainable and mode-switchable.</div>
      </div>
      <div class="rule-card">
        <div class="rule-card-title">Respect the three-layer chain</div>
        <div class="rule-card-body">Primitives define raw values. Semantics define intent. Components consume semantics. Never skip a layer — it breaks the single-source-of-truth principle.</div>
      </div>
      <div class="rule-card">
        <div class="rule-card-title">Light + Dark is built in</div>
        <div class="rule-card-body">Every semantic token has both Light and Dark values. Use the mode switcher — never maintain two separate colour sets or override tokens in components.</div>
      </div>
      <div class="rule-card accent">
        <div class="rule-card-title">These docs are the spec</div>
        <div class="rule-card-body">Every component page includes exact token references, prop tables, states, and do/don't guidance. These are requirements, not suggestions — follow them or update them.</div>
      </div>
    </div>
  </div>

  </div>`;
}
