import { pageHeader } from '../utils/render.js';

const PLUS = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`;
const SCAN = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 7 4 4 7 4"/><polyline points="17 4 20 4 20 7"/><polyline points="4 17 4 20 7 20"/><polyline points="17 20 20 20 20 17"/><line x1="4" y1="12" x2="20" y2="12"/></svg>`;
const EDIT = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`;

const ICON_SVG = { plus: PLUS, scan: SCAN, edit: EDIT };

function swatch(color, name, label) {
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${color}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${label}</div></div></div>`;
}

export default function fabPage() {
  return pageHeader('Components', 'FAB', 'Floating Action Button — the single highest-priority action on a mobile screen. 56px circle, brand purple, fixed bottom-right above the tab bar.', [
    { val: '3', label: 'Variants' },
    { val: '5', label: 'States' },
  ]) + `<div class="page-body">

  <style>
    @keyframes fab-extend { from { width: 56px; } to { width: var(--fab-extended-w, 160px); } }
    @keyframes fab-label-in { from { opacity:0; max-width:0; } to { opacity:1; max-width:120px; } }
    @keyframes fab-press-spring { 0%,100% { transform:scale(1); } 40% { transform:scale(0.91); } 80% { transform:scale(1.04); } }
    @keyframes fab-ripple { from { transform:scale(0); opacity:0.35; } to { transform:scale(4); opacity:0; } }
    @keyframes fab-tooltip-in { from { opacity:0; transform:translateY(4px); } to { opacity:1; transform:translateY(0); } }
  </style>

  <!-- DEFAULT FAB -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Default — click me</h2></div>
    <p class="doc-section-desc">56px circle. Brand purple, Elevation/3 shadow. Press to feel the spring animation and ripple. Switch the icon with the selector.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">FAB — default (click to interact)</span>
        <div class="inp-demo-controls">
          <span class="inp-demo-meta">Icon</span>
          <select class="inp-state-select" onchange="(function(v){
            var icons = {plus:'${PLUS.replace(/`/g,'\\`').replace(/'/g,"\\'")}', scan:'${SCAN.replace(/`/g,'\\`').replace(/'/g,"\\'")}', edit:'${EDIT.replace(/`/g,'\\`').replace(/'/g,"\\'")}' };
            var el = document.getElementById('fab-icon-inner');
            if(el) el.innerHTML = icons[v] || icons.plus;
          })(this.value)">
            <option value="plus">+ Create</option>
            <option value="scan">Scan</option>
            <option value="edit">Edit</option>
          </select>
        </div>
      </div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;padding:32px 20px;background:#E8EAED">
        <div style="width:280px;border-radius:36px;overflow:hidden;box-shadow:0 20px 48px rgba(0,0,0,0.24),0 0 0 1px rgba(0,0,0,0.08)">
          <div style="height:28px;background:var(--background-default);display:flex;align-items:center;justify-content:space-between;padding:0 18px;color:var(--content-primary)">
            <span style="font-size:11px;font-weight:700;font-family:Inter,sans-serif">9:41</span>
            <div style="display:flex;gap:4px;align-items:center">
              <svg width="13" height="9" viewBox="0 0 24 18" fill="none"><rect x="0" y="6" width="4" height="12" rx="1" fill="currentColor" opacity="0.4"/><rect x="6" y="4" width="4" height="14" rx="1" fill="currentColor" opacity="0.6"/><rect x="12" y="1" width="4" height="17" rx="1" fill="currentColor" opacity="0.8"/><rect x="18" y="0" width="4" height="18" rx="1" fill="currentColor"/></svg>
              <svg width="15" height="9" viewBox="0 0 24 16" fill="none"><rect x="2" y="4" width="17" height="10" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M20 7v4a2 2 0 0 0 0-4z" fill="currentColor" opacity="0.5"/><rect x="4" y="6" width="11" height="6" rx="1" fill="currentColor"/></svg>
            </div>
          </div>
          <div style="height:42px;background:var(--background-default);border-bottom:1px solid var(--border-subtle);display:flex;align-items:center;padding:0 14px">
            <span style="font-family:var(--font-display);font-size:15px;font-weight:700;color:var(--content-primary)">Mes tâches</span>
          </div>
          <div style="height:220px;background:var(--background-subtle);position:relative">
            ${[0,1,2,3].map(i=>`<div style="display:flex;align-items:center;gap:10px;padding:10px 14px;${i<3?'border-bottom:1px solid var(--border-subtle);':''}background:var(--background-default)">
              <div style="width:28px;height:28px;border-radius:6px;background:var(--background-subtle);flex-shrink:0"></div>
              <div style="flex:1">
                <div style="height:8px;border-radius:4px;background:var(--background-subtle);margin-bottom:5px;width:${['70%','55%','80%','60%'][i]}"></div>
                <div style="height:6px;border-radius:3px;background:var(--background-subtle);width:${['40%','50%','35%','45%'][i]}"></div>
              </div>
            </div>`).join('')}
            <button id="fab-default-btn"
              style="position:absolute;bottom:14px;right:14px;width:56px;height:56px;border-radius:50%;background:var(--fab-bg);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--fab-icon);box-shadow:var(--fab-shadow);overflow:hidden;transition:transform 0.15s,box-shadow 0.15s"
              onmouseenter="this.style.transform='scale(1.06)';this.style.boxShadow='0 12px 32px rgba(67,0,152,0.42),0 2px 8px rgba(0,0,0,0.14)'"
              onmouseleave="this.style.transform='scale(1)';this.style.boxShadow=getComputedStyle(document.documentElement).getPropertyValue('--fab-shadow').trim()"
              onmousedown="(function(btn){
                btn.style.transform='scale(0.92)';
                var rip=document.createElement('div');
                rip.style.cssText='position:absolute;width:56px;height:56px;border-radius:50%;background:rgba(255,255,255,0.35);top:0;left:0;pointer-events:none;animation:fab-ripple 0.5s ease-out forwards';
                btn.appendChild(rip);
                setTimeout(function(){rip.remove();},500);
              })(this)"
              onmouseup="this.style.transform='scale(1.06)'">
              <span id="fab-icon-inner">${PLUS}</span>
            </button>
          </div>
          <div style="height:52px;background:var(--background-default);border-top:1px solid var(--border-subtle);display:flex;align-items:center;justify-content:space-around;padding:0 8px">
            ${['Tasks','Orders','Scan','Profile'].map((t,i)=>`<div style="display:flex;flex-direction:column;align-items:center;gap:2px">
              <div style="width:16px;height:16px;border-radius:3px;background:${i===0?'#430098':'var(--background-subtle)'}"></div>
              <span style="font-family:Inter,sans-serif;font-size:9px;color:${i===0?'#430098':'var(--content-tertiary)'}">${t}</span>
            </div>`).join('')}
          </div>
          <div style="height:16px;background:var(--background-default);display:flex;align-items:center;justify-content:center">
            <div style="width:56px;height:4px;border-radius:2px;background:var(--content-primary);opacity:0.12"></div>
          </div>
        </div>
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#430098','component/fab/bg','Background')}
        ${swatch('#FFFFFF','content/on-brand','Icon colour')}
      </div>
    </div>
  </div>

  <!-- EXTENDED FAB -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Extended — click to collapse / expand</h2></div>
    <p class="doc-section-desc">The extended FAB shows a label alongside the icon. Click it to collapse to a circle (as if scrolling down), click again to expand. Label fades in with a max-width reveal.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Extended FAB — click to collapse, click again to expand</span></div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;padding:32px 20px;background:#E8EAED">
        <div style="width:280px;border-radius:36px;overflow:hidden;box-shadow:0 20px 48px rgba(0,0,0,0.24),0 0 0 1px rgba(0,0,0,0.08)">
          <div style="height:28px;background:var(--background-default);display:flex;align-items:center;justify-content:space-between;padding:0 18px;color:var(--content-primary)">
            <span style="font-size:11px;font-weight:700;font-family:Inter,sans-serif">9:41</span>
            <div style="display:flex;gap:4px;align-items:center">
              <svg width="13" height="9" viewBox="0 0 24 18" fill="none"><rect x="0" y="6" width="4" height="12" rx="1" fill="currentColor" opacity="0.4"/><rect x="6" y="4" width="4" height="14" rx="1" fill="currentColor" opacity="0.6"/><rect x="12" y="1" width="4" height="17" rx="1" fill="currentColor" opacity="0.8"/><rect x="18" y="0" width="4" height="18" rx="1" fill="currentColor"/></svg>
              <svg width="15" height="9" viewBox="0 0 24 16" fill="none"><rect x="2" y="4" width="17" height="10" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M20 7v4a2 2 0 0 0 0-4z" fill="currentColor" opacity="0.5"/><rect x="4" y="6" width="11" height="6" rx="1" fill="currentColor"/></svg>
            </div>
          </div>
          <div style="height:42px;background:var(--background-default);border-bottom:1px solid var(--border-subtle);display:flex;align-items:center;padding:0 14px">
            <span style="font-family:var(--font-display);font-size:15px;font-weight:700;color:var(--content-primary)">Commandes</span>
          </div>
          <div style="height:220px;background:var(--background-subtle);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;position:relative">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" style="color:var(--content-tertiary)"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="12" y2="17"/></svg>
            <span style="font-family:Inter,sans-serif;font-size:10px;color:var(--content-tertiary)">No orders yet</span>
            <button id="fab-ext-btn" data-expanded="true"
              style="position:absolute;bottom:14px;right:14px;height:56px;padding:0 20px;border-radius:28px;background:var(--fab-bg);border:none;cursor:pointer;display:flex;align-items:center;gap:10px;color:var(--fab-icon);box-shadow:var(--fab-shadow-extended);white-space:nowrap;overflow:hidden;transition:border-radius 0.3s,padding 0.3s,width 0.35s cubic-bezier(0.32,0.72,0,1);min-width:56px"
              onclick="(function(btn){
                var expanded = btn.dataset.expanded !== 'false';
                btn.dataset.expanded = expanded ? 'false' : 'true';
                var label = btn.querySelector('.fab-ext-label');
                if(expanded) {
                  btn.style.borderRadius='50%';
                  btn.style.padding='0';
                  btn.style.width='56px';
                  btn.style.justifyContent='center';
                  if(label) { label.style.maxWidth='0'; label.style.opacity='0'; }
                } else {
                  btn.style.borderRadius='28px';
                  btn.style.padding='0 20px';
                  btn.style.width='auto';
                  btn.style.justifyContent='';
                  if(label) { setTimeout(function(){ label.style.maxWidth='120px'; label.style.opacity='1'; },150); }
                }
              })(this)">
              <span style="flex-shrink:0">${PLUS}</span>
              <span class="fab-ext-label" style="font-family:Inter,sans-serif;font-size:14px;font-weight:600;overflow:hidden;max-width:120px;opacity:1;transition:max-width 0.3s ease,opacity 0.25s ease">Créer</span>
            </button>
          </div>
          <div style="height:52px;background:var(--background-default);border-top:1px solid var(--border-subtle);display:flex;align-items:center;justify-content:space-around;padding:0 8px">
            ${['Tasks','Orders','Scan','Profile'].map((t,i)=>`<div style="display:flex;flex-direction:column;align-items:center;gap:2px">
              <div style="width:16px;height:16px;border-radius:3px;background:${i===1?'#430098':'var(--background-subtle)'}"></div>
              <span style="font-family:Inter,sans-serif;font-size:9px;color:${i===1?'#430098':'var(--content-tertiary)'}">${t}</span>
            </div>`).join('')}
          </div>
          <div style="height:16px;background:var(--background-default);display:flex;align-items:center;justify-content:center">
            <div style="width:56px;height:4px;border-radius:2px;background:var(--content-primary);opacity:0.12"></div>
          </div>
        </div>
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#430098','component/fab/bg','Extended background')}
        ${swatch('#FFFFFF','content/on-brand','Label + icon colour')}
      </div>
    </div>
  </div>

  <!-- MINI FAB -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Mini variant</h2></div>
    <p class="doc-section-desc">40px circle. Used for secondary floating actions on the same screen as a default FAB, or as a compact action in a tight layout. Always secondary to the 56px FAB.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Mini (40px) stacked above Default (56px)</span></div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;padding:32px 20px;background:#E8EAED">
        <div style="width:280px;border-radius:36px;overflow:hidden;box-shadow:0 20px 48px rgba(0,0,0,0.24),0 0 0 1px rgba(0,0,0,0.08)">
          <div style="height:28px;background:var(--background-default);display:flex;align-items:center;justify-content:space-between;padding:0 18px;color:var(--content-primary)">
            <span style="font-size:11px;font-weight:700;font-family:Inter,sans-serif">9:41</span>
            <div style="display:flex;gap:4px;align-items:center">
              <svg width="13" height="9" viewBox="0 0 24 18" fill="none"><rect x="0" y="6" width="4" height="12" rx="1" fill="currentColor" opacity="0.4"/><rect x="6" y="4" width="4" height="14" rx="1" fill="currentColor" opacity="0.6"/><rect x="12" y="1" width="4" height="17" rx="1" fill="currentColor" opacity="0.8"/><rect x="18" y="0" width="4" height="18" rx="1" fill="currentColor"/></svg>
              <svg width="15" height="9" viewBox="0 0 24 16" fill="none"><rect x="2" y="4" width="17" height="10" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M20 7v4a2 2 0 0 0 0-4z" fill="currentColor" opacity="0.5"/><rect x="4" y="6" width="11" height="6" rx="1" fill="currentColor"/></svg>
            </div>
          </div>
          <div style="height:42px;background:var(--background-default);border-bottom:1px solid var(--border-subtle);display:flex;align-items:center;padding:0 14px">
            <span style="font-family:var(--font-display);font-size:15px;font-weight:700;color:var(--content-primary)">Scan & Create</span>
          </div>
          <div style="height:220px;background:var(--background-subtle);position:relative">
            ${[0,1,2].map(i=>`<div style="display:flex;align-items:center;gap:10px;padding:10px 14px;${i<2?'border-bottom:1px solid var(--border-subtle);':''}background:var(--background-default)">
              <div style="width:28px;height:28px;border-radius:6px;background:var(--background-subtle);flex-shrink:0"></div>
              <div style="flex:1">
                <div style="height:8px;border-radius:4px;background:var(--background-subtle);margin-bottom:5px;width:${['65%','75%','50%'][i]}"></div>
                <div style="height:6px;border-radius:3px;background:var(--background-subtle);width:${['45%','35%','55%'][i]}"></div>
              </div>
            </div>`).join('')}
            <div style="position:absolute;bottom:14px;right:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
              <button style="width:40px;height:40px;border-radius:50%;background:var(--fab-bg);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--fab-icon);box-shadow:var(--fab-shadow-mini);overflow:hidden;position:relative;transition:transform 0.15s"
                onmouseenter="this.style.transform='scale(1.07)'" onmouseleave="this.style.transform='scale(1)'"
                onmousedown="(function(btn){btn.style.transform='scale(0.9)';var rip=document.createElement('div');rip.style.cssText='position:absolute;width:40px;height:40px;border-radius:50%;background:rgba(255,255,255,0.35);top:0;left:0;pointer-events:none;animation:fab-ripple 0.45s ease-out forwards';btn.appendChild(rip);setTimeout(function(){rip.remove();},450);})(this)"
                onmouseup="this.style.transform='scale(1.07)'">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 7 4 4 7 4"/><polyline points="17 4 20 4 20 7"/><polyline points="4 17 4 20 7 20"/><polyline points="17 20 20 20 20 17"/><line x1="4" y1="12" x2="20" y2="12"/></svg>
              </button>
              <button style="width:56px;height:56px;border-radius:50%;background:var(--fab-bg);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--fab-icon);box-shadow:var(--fab-shadow);overflow:hidden;position:relative;transition:transform 0.15s,box-shadow 0.15s"
                onmouseenter="this.style.transform='scale(1.06)';this.style.boxShadow='0 12px 32px rgba(67,0,152,0.42)'"
                onmouseleave="this.style.transform='scale(1)';this.style.boxShadow=getComputedStyle(document.documentElement).getPropertyValue('--fab-shadow').trim()"
                onmousedown="(function(btn){btn.style.transform='scale(0.92)';var rip=document.createElement('div');rip.style.cssText='position:absolute;width:56px;height:56px;border-radius:50%;background:rgba(255,255,255,0.35);top:0;left:0;pointer-events:none;animation:fab-ripple 0.5s ease-out forwards';btn.appendChild(rip);setTimeout(function(){rip.remove();},500);})(this)"
                onmouseup="this.style.transform='scale(1.06)'">${PLUS}</button>
            </div>
          </div>
          <div style="height:52px;background:var(--background-default);border-top:1px solid var(--border-subtle);display:flex;align-items:center;justify-content:space-around;padding:0 8px">
            ${['Tasks','Orders','Scan','Profile'].map((t,i)=>`<div style="display:flex;flex-direction:column;align-items:center;gap:2px">
              <div style="width:16px;height:16px;border-radius:3px;background:${i===2?'#430098':'var(--background-subtle)'}"></div>
              <span style="font-family:Inter,sans-serif;font-size:9px;color:${i===2?'#430098':'var(--content-tertiary)'}">${t}</span>
            </div>`).join('')}
          </div>
          <div style="height:16px;background:var(--background-default);display:flex;align-items:center;justify-content:center">
            <div style="width:56px;height:4px;border-radius:2px;background:var(--content-primary);opacity:0.12"></div>
          </div>
        </div>
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#430098','component/fab/bg','FAB background')}
        ${swatch('#FFFFFF','content/on-brand','Icon colour')}
      </div>
    </div>
  </div>

  <!-- MOBILE PLACEMENT -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Placement on screen</h2></div>
    <p class="doc-section-desc">The FAB is always fixed bottom-right. Its bottom offset accounts for: safe area inset + 56px tab bar + 16px margin. The tab bar determines where the FAB lives.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">FAB position on a real mobile screen</span></div>
      <div class="inp-demo-stage" style="display:flex;justify-content:center;padding:20px">
        <div style="width:220px;border-radius:20px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,0.15),0 0 0 1px rgba(0,0,0,0.06);background:var(--background-subtle);position:relative">
          <div style="height:22px;background:var(--background-default);display:flex;align-items:center;padding:0 16px"><span style="font-size:9px;font-weight:700">9:41</span></div>
          <div style="height:180px;background:var(--background-subtle);position:relative">
            <div style="position:absolute;bottom:16px;right:16px;display:flex;flex-direction:column;align-items:flex-end;gap:4px">
              <div style="font-family:Inter,sans-serif;font-size:9px;color:var(--content-tertiary);text-align:right;line-height:1.4">
                <div>16px margin</div>
                <div style="height:1px;background:var(--content-tertiary);opacity:0.4;margin:2px 0"></div>
                <div>FAB 56px</div>
                <div style="height:1px;background:var(--content-tertiary);opacity:0.4;margin:2px 0"></div>
                <div>16px margin</div>
              </div>
            </div>
            <div style="position:absolute;bottom:16px;right:16px">
              <div style="width:40px;height:40px;border-radius:50%;background:var(--fab-bg);display:flex;align-items:center;justify-content:center;color:var(--fab-icon);box-shadow:var(--fab-shadow-mini)">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              </div>
            </div>
          </div>
          <div style="height:52px;background:var(--background-default);border-top:1px solid var(--border-subtle);display:flex;align-items:center;justify-content:space-around;padding:0 8px">
            ${['Tasks','Orders','Scan','Profile'].map(t=>`<span style="font-family:Inter,sans-serif;font-size:8px;color:var(--content-tertiary)">${t}</span>`).join('')}
          </div>
          <div style="height:12px;background:var(--background-default)"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- STATES -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">States</h2></div>
    <div class="grid-2" style="margin-top:16px">
      <div class="rule-card accent"><div class="rule-card-title">Rest</div><div class="rule-card-body">Default state. Elevation/3 shadow. No hover-only shadow — mobile has no cursor, so don't design for a state that doesn't exist on device.</div></div>
      <div class="rule-card"><div class="rule-card-title">Pressed</div><div class="rule-card-body">Scale to 0.92 with a white ripple emanating from centre. Spring-back to 1.0 with cubic-bezier(0.175, 0.885, 0.32, 1.275). Duration: 350ms total.</div></div>
      <div class="rule-card"><div class="rule-card-title">Scroll collapse</div><div class="rule-card-body">Extended FAB collapses to a circle when the user scrolls down 48px+. It re-expands when scrolled back to top. Transition: 300ms cubic-bezier(0.32, 0.72, 0, 1).</div></div>
      <div class="rule-card accent"><div class="rule-card-title">Disabled (rare)</div><div class="rule-card-body">Opacity 0.4, pointer-events none. A FAB should almost never be disabled — if no action is possible, hide it entirely rather than showing a grey FAB.</div></div>
    </div>
  </div>

  <!-- TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <div class="card" style="overflow:hidden">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Value</th><th>Usage</th></tr></thead>
        <tbody>
          ${[
            ['component/fab/size','56px','Default diameter'],
            ['component/fab/size-mini','40px','Mini variant diameter'],
            ['component/fab/bg','brand/primary','Fill colour'],
            ['component/fab/icon','content/on-brand','Icon stroke colour'],
            ['component/fab/shadow','0 8px 24px rgba(67,0,152,0.35)','Elevation/3 shadow'],
            ['component/fab/press-scale','0.92','Scale on press'],
            ['component/fab/bottom-margin','16px','Gap above the tab bar'],
            ['component/fab/extended-radius','28px','Pill border radius (height/2)'],
            ['component/fab/extended-label-size','14px, SemiBold 600','Extended label'],
          ].map(([t,v,u],i)=>`<tr style="${i%2===0?'background:var(--background-subtle);':''}border-bottom:1px solid var(--border-subtle)">
            <td style="padding:10px 16px"><code class="tok-name">${t}</code></td>
            <td style="padding:10px 16px;font-family:var(--font-mono);font-size:11px;color:var(--brand-primary)">${v}</td>
            <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${u}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use the Extended FAB on empty list screens — the label helps users understand the action before they've created any content.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't place a FAB on every screen. Reserve it for the single most important primary action per screen. Scanner and keypad screens have no FAB.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Keep the icon simple and universally recognisable. ＋ Create and Scan are the two most common FAB actions in Iksir flows.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't show two FABs side by side. Use the Mini variant below the main FAB for a secondary action — never two equal 56px buttons.</div></div>
    </div>
  </div>

  </div>`;
}
