import { pageHeader } from '../utils/render.js';

/* ── icons ─────────────────────────────────────────────────────────────── */
const CLOSE  = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;
const EDIT   = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`;
const SHARE  = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>`;
const TRASH  = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#D8192C" stroke-width="2" stroke-linecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>`;
const SCAN   = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="4 7 4 4 7 4"/><polyline points="17 4 20 4 20 7"/><polyline points="4 17 4 20 7 20"/><polyline points="17 20 20 20 20 17"/><line x1="4" y1="12" x2="20" y2="12"/></svg>`;
const FILTER = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>`;
const ICON_PKG = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>`;
const CHECK  = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>`;

/* ── light palette (always light inside phone) ─────────────────────────── */
const L = {
  bg:       '#FFFFFF',
  bg2:      '#F5F5F7',
  bg3:      '#EFEFEF',
  border:   '#E5E5EA',
  text:     '#1A1A1A',
  text2:    '#6E6E73',
  text3:    '#AEAEB2',
  brand:    '#430098',
  brandBg:  '#F3EEFF',
  brandBdr: '#C4A8F0',
  danger:   '#D8192C',
};

function swatch(color, name, label) {
  const light = ['#FFFFFF','#F5F5F7'].includes(color);
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${color};${light?'border:1px solid #E1E1E1':''}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${label}</div></div></div>`;
}

/* ── phone chrome ───────────────────────────────────────────────────────── */
function phone(id, screenContent, sheetContent, triggerLabel = 'Open') {
  return `
  <div style="display:flex;flex-direction:column;align-items:center;gap:16px">
    <button onclick="bsOpen('${id}')"
      style="padding:0 22px;height:40px;border-radius:10px;background:var(--sheet-footer-primary-bg);border:none;cursor:pointer;font-family:Inter,sans-serif;font-size:13px;font-weight:600;color:var(--sheet-footer-primary-text);box-shadow:0 4px 16px rgba(67,0,152,0.28);transition:transform 0.12s,box-shadow 0.12s"
      onmousedown="this.style.transform='scale(0.95)';this.style.boxShadow='0 2px 8px rgba(67,0,152,0.2)'"
      onmouseup="this.style.transform='';this.style.boxShadow='0 4px 16px rgba(67,0,152,0.28)'"
      onmouseleave="this.style.transform='';this.style.boxShadow='0 4px 16px rgba(67,0,152,0.28)'">${triggerLabel}</button>

    <!-- phone outer -->
    <div style="position:relative;width:270px;height:500px;border-radius:44px;background:linear-gradient(145deg,#2C2C2E,#1A1A1C);box-shadow:0 0 0 1px rgba(255,255,255,0.1) inset,0 32px 64px rgba(0,0,0,0.4),0 8px 24px rgba(0,0,0,0.2);flex-shrink:0">
      <!-- side buttons -->
      <div style="position:absolute;left:-3px;top:100px;width:3px;height:32px;background:#3A3A3C;border-radius:2px 0 0 2px"></div>
      <div style="position:absolute;left:-3px;top:144px;width:3px;height:48px;background:#3A3A3C;border-radius:2px 0 0 2px"></div>
      <div style="position:absolute;left:-3px;top:204px;width:3px;height:48px;background:#3A3A3C;border-radius:2px 0 0 2px"></div>
      <div style="position:absolute;right:-3px;top:130px;width:3px;height:62px;background:#3A3A3C;border-radius:0 2px 2px 0"></div>
      <!-- screen cutout -->
      <div style="position:absolute;inset:8px;border-radius:36px;background:#000;overflow:hidden">
        <!-- dynamic island -->
        <div style="position:absolute;top:10px;left:50%;transform:translateX(-50%);width:88px;height:28px;background:#000;border-radius:20px;z-index:10"></div>
        <!-- screen surface -->
        <div style="position:absolute;inset:0;background:${L.bg};border-radius:36px;overflow:hidden">
          <!-- status bar -->
          <div style="height:48px;padding:14px 20px 0;display:flex;align-items:center;justify-content:space-between;background:${L.bg}">
            <span style="font-size:12px;font-weight:700;color:${L.text};letter-spacing:-.3px">9:41</span>
            <div style="display:flex;align-items:center;gap:5px;color:${L.text}">
              <svg width="14" height="10" viewBox="0 0 28 16" fill="${L.text}"><rect x="0" y="6" width="5" height="10" rx="1.5" opacity=".35"/><rect x="7" y="3" width="5" height="13" rx="1.5" opacity=".65"/><rect x="14" y="0" width="5" height="16" rx="1.5"/><rect x="21" y="0" width="5" height="16" rx="1.5"/></svg>
              <svg width="16" height="11" viewBox="0 0 32 18" fill="none"><rect x="1" y="3" width="23" height="12" rx="3" stroke="${L.text}" stroke-width="2"/><path d="M25 7v4a3 3 0 0 0 0-4z" fill="${L.text}" opacity=".4"/><rect x="4" y="6" width="15" height="6" rx="1.5" fill="${L.text}"/></svg>
            </div>
          </div>
          <!-- page content (always light) -->
          <div id="bs-screen-${id}" style="position:absolute;top:48px;left:0;right:0;bottom:0;transition:transform 0.3s cubic-bezier(0.4,0,0.2,1),filter 0.3s,border-radius 0.3s;background:${L.bg}">
            ${screenContent}
          </div>
          <!-- scrim overlay -->
          <div id="bs-overlay-${id}" onclick="bsClose('${id}')"
            style="position:absolute;inset:0;top:48px;background:rgba(0,0,0,0.45);opacity:0;pointer-events:none;transition:opacity 0.28s;border-radius:0 0 36px 36px"></div>
          <!-- bottom sheet -->
          <div id="bs-sheet-${id}" data-open="false"
            style="position:absolute;bottom:0;left:0;right:0;background:${L.bg};border-radius:24px 24px 0 0;box-shadow:0 -2px 20px rgba(0,0,0,0.12),0 -1px 0 ${L.border};transform:translateY(100%);transition:transform 0.36s cubic-bezier(0.32,0.72,0,1);will-change:transform">
            <!-- drag zone -->
            <div id="bs-handle-${id}" onmousedown="bsDragStart('${id}',event)"
              style="padding:10px 0 6px;display:flex;justify-content:center;cursor:ns-resize;touch-action:none;border-radius:24px 24px 0 0">
              <div style="width:36px;height:4px;border-radius:9999px;background:${L.border}"></div>
            </div>
            ${sheetContent}
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

/* ── page ───────────────────────────────────────────────────────────────── */
export default function bottomSheet() {

  /* ── action sheet screen content ── */
  const actionScreen = `
    <div style="padding:16px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">
        <div style="width:32px;height:32px;border-radius:9px;background:${L.brandBg};display:flex;align-items:center;justify-content:center;color:${L.brand}">${ICON_PKG}</div>
        <div>
          <div style="font-family:Inter,sans-serif;font-size:13px;font-weight:700;color:${L.text}">CMD-2847</div>
          <div style="font-family:Inter,sans-serif;font-size:11px;color:${L.text2}">Modifié il y a 2h</div>
        </div>
        <div style="margin-left:auto;padding:3px 8px;border-radius:20px;background:#EFF6FF;border:1px solid #93C5FD;font-family:Inter,sans-serif;font-size:10px;font-weight:600;color:#0550AE">En transit</div>
      </div>
      ${[['PRD-001','Palette bois standard','342 u.'],['PRD-002','Film étirable PE','×4 rouleaux'],['PRD-003','Carton cannelure','×18 feuilles']].map(([c,n,q])=>`
      <div style="display:flex;align-items:center;gap:8px;padding:9px 0;border-bottom:1px solid ${L.border}">
        <code style="font-family:monospace;font-size:9px;color:${L.text3};background:${L.bg2};padding:2px 5px;border-radius:4px">${c}</code>
        <span style="flex:1;font-family:Inter,sans-serif;font-size:11px;color:${L.text}">${n}</span>
        <span style="font-family:monospace;font-size:11px;font-weight:600;color:${L.text2}">${q}</span>
      </div>`).join('')}
      <div style="margin-top:12px;padding:10px 12px;background:${L.bg2};border-radius:10px;display:flex;align-items:center;justify-content:space-between">
        <span style="font-family:Inter,sans-serif;font-size:11px;color:${L.text2}">Tapez ··· pour agir</span>
        <span style="font-family:Inter,sans-serif;font-size:18px;color:${L.brand};letter-spacing:2px;line-height:1">···</span>
      </div>
    </div>`;

  /* ── action sheet content ── */
  const actionSheet = `
    <div style="padding-bottom:16px">
      <div style="padding:4px 16px 12px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid ${L.border}">
        <span style="font-family:Inter,sans-serif;font-size:13px;font-weight:700;color:${L.text}">Actions — CMD-2847</span>
        <button onclick="bsClose('action')" style="width:26px;height:26px;border-radius:50%;background:${L.bg2};border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;color:${L.text2}">${CLOSE}</button>
      </div>
      ${[
        { icon: SCAN,  label: 'Scanner un article',    sub: 'Ajouter via code-barres',  danger: false },
        { icon: EDIT,  label: 'Modifier la commande',  sub: 'Changer quantités / dates', danger: false },
        { icon: SHARE, label: 'Exporter le bon',       sub: 'PDF • email • impression',  danger: false },
        { icon: TRASH, label: 'Supprimer',             sub: 'Action irréversible',        danger: true  },
      ].map((a, i) => `
      <button onclick="bsClose('action')"
        style="display:flex;align-items:center;gap:12px;padding:11px 16px;width:100%;background:none;border:none;border-top:${i===0?'none':'1px solid '+L.border};cursor:pointer;text-align:left;transition:background 0.1s;animation:bs-action-in 0.22s ease both;animation-delay:${i*0.05}s"
        onmouseenter="this.style.background='${L.bg2}'" onmouseleave="this.style.background='none'">
        <div style="width:34px;height:34px;border-radius:9px;background:${a.danger?'#FFF2F4':L.bg2};display:flex;align-items:center;justify-content:center;color:${a.danger?L.danger:L.text2};flex-shrink:0">${a.icon}</div>
        <div>
          <div style="font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:${a.danger?L.danger:L.text};line-height:1.4">${a.label}</div>
          <div style="font-family:Inter,sans-serif;font-size:10px;color:${a.danger?'#E87580':L.text3};margin-top:1px">${a.sub}</div>
        </div>
        ${!a.danger ? `<svg style="margin-left:auto;color:${L.text3}" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>` : ''}
      </button>`).join('')}
    </div>`;

  /* ── filter sheet screen ── */
  const filterScreen = `
    <div style="padding:14px 16px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
        <span style="font-family:Inter,sans-serif;font-size:14px;font-weight:700;color:${L.text}">Commandes</span>
        <div id="bs-filter-badge" style="display:flex;align-items:center;gap:4px;padding:3px 9px;border-radius:20px;background:${L.brandBg};border:1px solid ${L.brandBdr};font-family:Inter,sans-serif;font-size:10px;font-weight:600;color:${L.brand}">${FILTER}&nbsp;2 filtres</div>
      </div>
      ${[
        ['CMD-2847','En transit','#EFF6FF','#0550AE','#93C5FD'],
        ['CMD-2846','Livré','#F0FDF4','#16A34A','#86EFAC'],
        ['CMD-2845','Express','#F7F4FB','#430098','#C4A8F0'],
        ['CMD-2844','En attente','#FFFBEB','#B45309','#FCD34D'],
      ].map(([ref, lbl, bg, col, bdr]) => `
      <div style="display:flex;align-items:center;justify-content:space-between;padding:9px 0;border-bottom:1px solid ${L.border}">
        <span style="font-family:monospace;font-size:10px;color:${L.text2}">${ref}</span>
        <span style="padding:2px 8px;border-radius:20px;background:${bg};border:1px solid ${bdr};font-family:Inter,sans-serif;font-size:10px;font-weight:600;color:${col}">${lbl}</span>
      </div>`).join('')}
    </div>`;

  /* ── filter sheet content ── */
  const filterSheet = `
    <div>
      <div style="padding:4px 16px 10px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid ${L.border}">
        <span style="font-family:Inter,sans-serif;font-size:13px;font-weight:700;color:${L.text}">Filtrer</span>
        <button onclick="bsClose('filter')" style="width:26px;height:26px;border-radius:50%;background:${L.bg2};border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;color:${L.text2}">${CLOSE}</button>
      </div>

      <div style="padding:12px 16px 0" data-chipgroup="status">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:7px">
          <span style="font-family:Inter,sans-serif;font-size:10px;font-weight:700;color:${L.text3};text-transform:uppercase;letter-spacing:.07em">Statut</span>
          <span class="chip-count" style="font-family:Inter,sans-serif;font-size:10px;color:${L.brand};font-weight:600;opacity:0;transition:opacity 0.15s"></span>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:6px">
          ${['En transit','Livré','En attente','Annulé'].map((s, i) => `
          <button data-selected="${i < 2 ? 'true' : 'false'}" onclick="bsChip(this)"
            style="display:inline-flex;align-items:center;gap:5px;padding:0 10px;height:26px;border-radius:20px;border:1px solid ${i < 2 ? L.brandBdr : L.border};background:${i < 2 ? L.brandBg : L.bg};color:${i < 2 ? L.brand : L.text2};font-family:Inter,sans-serif;font-size:11px;font-weight:500;cursor:pointer;transition:all 0.15s">
            <span class="chip-dot" style="width:5px;height:5px;border-radius:50%;background:${i < 2 ? L.brand : L.text3};flex-shrink:0;transition:background 0.15s"></span>
            ${s}
          </button>`).join('')}
        </div>
      </div>

      <div style="padding:10px 16px 0" data-chipgroup="type">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:7px">
          <span style="font-family:Inter,sans-serif;font-size:10px;font-weight:700;color:${L.text3};text-transform:uppercase;letter-spacing:.07em">Type</span>
          <span class="chip-count" style="font-family:Inter,sans-serif;font-size:10px;color:${L.brand};font-weight:600;opacity:0;transition:opacity 0.15s"></span>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:6px">
          ${['Express','Standard','Palette'].map(s => `
          <button data-selected="false" onclick="bsChip(this)"
            style="display:inline-flex;align-items:center;gap:5px;padding:0 10px;height:26px;border-radius:20px;border:1px solid ${L.border};background:${L.bg};color:${L.text2};font-family:Inter,sans-serif;font-size:11px;font-weight:500;cursor:pointer;transition:all 0.15s">
            <span class="chip-dot" style="width:5px;height:5px;border-radius:50%;background:${L.text3};flex-shrink:0;transition:background 0.15s"></span>
            ${s}
          </button>`).join('')}
        </div>
      </div>

      <div style="padding:12px 16px 16px;display:flex;gap:8px">
        <button onclick="bsClose('filter')" style="flex:1;height:40px;border-radius:10px;background:${L.bg2};border:1px solid ${L.border};cursor:pointer;font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:${L.text2};transition:background 0.12s" onmouseenter="this.style.background='${L.bg3}'" onmouseleave="this.style.background='${L.bg2}'">Réinitialiser</button>
        <button onclick="bsClose('filter')" style="flex:2;height:40px;border-radius:10px;background:${L.brand};border:none;cursor:pointer;font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:#fff;transition:background 0.12s,transform 0.1s" onmouseenter="this.style.background='#561AA2'" onmouseleave="this.style.background='${L.brand}'" onmousedown="this.style.transform='scale(0.97)'" onmouseup="this.style.transform=''">Appliquer</button>
      </div>
    </div>`;

  return pageHeader('Components', 'Bottom Sheet', 'Slides up from the bottom of the screen. Used for action menus, filters, and lightweight forms without full-page navigation.', [
    { val: '3', label: 'Snap points' },
    { val: '36px', label: 'Handle' },
  ]) + `<div class="page-body">

  <style>
    @keyframes bs-action-in { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
    @keyframes bs-chip-pop  { from{transform:scale(0.85);opacity:0.6}   to{transform:scale(1);opacity:1} }
    .bs-chip-active { animation: bs-chip-pop 0.22s cubic-bezier(0.175,0.885,0.32,1.275) both; }
  </style>

  <script>
    /* ── open / close ─────────────────────────────────────── */
    function bsOpen(id) {
      var sheet   = document.getElementById('bs-sheet-'   + id);
      var overlay = document.getElementById('bs-overlay-' + id);
      var screen  = document.getElementById('bs-screen-'  + id);
      if (!sheet || sheet.dataset.open === 'true') return;
      sheet.dataset.open        = 'true';
      sheet.style.transition    = 'transform 0.38s cubic-bezier(0.32,0.72,0,1)';
      sheet.style.transform     = 'translateY(0)';
      overlay.style.opacity     = '1';
      overlay.style.pointerEvents = 'auto';
      screen.style.transform    = 'scale(0.94) translateY(-10px)';
      screen.style.borderRadius = '20px';
      screen.style.filter       = 'brightness(0.7) blur(1px)';
    }
    function bsClose(id) {
      var sheet   = document.getElementById('bs-sheet-'   + id);
      var overlay = document.getElementById('bs-overlay-' + id);
      var screen  = document.getElementById('bs-screen-'  + id);
      if (!sheet || sheet.dataset.open !== 'true') return;
      sheet.dataset.open        = 'false';
      sheet.style.transition    = 'transform 0.24s cubic-bezier(0.4,0,1,1)';
      sheet.style.transform     = 'translateY(100%)';
      overlay.style.opacity     = '0';
      overlay.style.pointerEvents = 'none';
      screen.style.transform    = '';
      screen.style.borderRadius = '';
      screen.style.filter       = '';
    }

    /* ── drag-to-dismiss ──────────────────────────────────── */
    var _bsDrag = null;
    function bsDragStart(id, e) {
      var sheet = document.getElementById('bs-sheet-' + id);
      if (!sheet || sheet.dataset.open !== 'true') return;
      _bsDrag = { id: id, startY: e.clientY, lastY: e.clientY, vy: 0 };
      sheet.style.transition = 'none';
      document.addEventListener('mousemove', bsDragMove);
      document.addEventListener('mouseup',   bsDragEnd);
      e.preventDefault();
    }
    function bsDragMove(e) {
      if (!_bsDrag) return;
      var dy = e.clientY - _bsDrag.startY;
      _bsDrag.vy   = e.clientY - _bsDrag.lastY;
      _bsDrag.lastY = e.clientY;
      var sheet = document.getElementById('bs-sheet-' + _bsDrag.id);
      if (sheet) sheet.style.transform = 'translateY(' + Math.max(0, dy < 0 ? dy * 0.15 : dy) + 'px)';
    }
    function bsDragEnd(e) {
      document.removeEventListener('mousemove', bsDragMove);
      document.removeEventListener('mouseup',   bsDragEnd);
      if (!_bsDrag) return;
      var id = _bsDrag.id, dy = e.clientY - _bsDrag.startY, vy = _bsDrag.vy;
      _bsDrag = null;
      var sheet = document.getElementById('bs-sheet-' + id);
      if (!sheet) return;
      sheet.style.transition = 'transform 0.32s cubic-bezier(0.32,0.72,0,1)';
      if (dy > 70 || vy > 5) { bsClose(id); }
      else { sheet.style.transform = 'translateY(0)'; }
    }

    /* ── chip toggle ─────────────────────────────────────── */
    function bsChip(btn) {
      var on = btn.dataset.selected !== 'true';
      btn.dataset.selected  = on ? 'true' : 'false';
      btn.style.background  = on ? '#F3EEFF' : '#FFFFFF';
      btn.style.color       = on ? '#430098' : '#6E6E73';
      btn.style.borderColor = on ? '#C4A8F0' : '#E5E5EA';
      var dot = btn.querySelector('.chip-dot');
      if (dot) dot.style.background = on ? '#430098' : '#AEAEB2';
      btn.classList.remove('bs-chip-active'); void btn.offsetWidth; btn.classList.add('bs-chip-active');
      var grp = btn.closest('[data-chipgroup]');
      if (!grp) return;
      var n     = grp.querySelectorAll('[data-selected=true]').length;
      var count = grp.querySelector('.chip-count');
      if (count) { count.textContent = n > 0 ? n + ' sélectionné' + (n > 1 ? 's' : '') : ''; count.style.opacity = n > 0 ? '1' : '0'; }
    }
  </script>

  <!-- ACTION SHEET ────────────────────────────────────────────────── -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Action sheet — tap trigger, drag to dismiss</h2></div>
    <p class="doc-section-desc">Click the button to open. The background scales down and blurs. Drag the handle downward to dismiss — spring-back if you don't drag far enough. Click the dim area or the × to close.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Action sheet — 4 options</span></div>
      <div class="inp-demo-stage" style="display:flex;justify-content:center;padding:32px 24px;background:linear-gradient(135deg,#EEE8FF 0%,#E8ECFF 100%)">
        ${phone('action', actionScreen, actionSheet, 'Ouvrir les actions ···')}
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#FFFFFF','surface/default','Sheet background')}
        ${swatch('#430098','brand/primary','Primary action')}
        ${swatch('#D8192C','status/danger','Destructive action')}
      </div>
    </div>
  </div>

  <!-- FILTER SHEET ────────────────────────────────────────────────── -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Filter sheet — live chip selection</h2></div>
    <p class="doc-section-desc">Chips spring-animate on toggle. The active count badge updates live. "Appliquer" closes with state persisted. Drag the handle to dismiss at any time.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Filter sheet — chip groups</span></div>
      <div class="inp-demo-stage" style="display:flex;justify-content:center;padding:32px 24px;background:linear-gradient(135deg,#E8F5FF 0%,#EEF2FF 100%)">
        ${phone('filter', filterScreen, filterSheet, '⊟  Filtrer les commandes')}
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#F3EEFF','brand/primary-muted','Selected chip bg')}
        ${swatch('#C4A8F0','brand/border','Selected chip border')}
        ${swatch('#430098','brand/primary','Selected chip text + dot')}
      </div>
    </div>
  </div>

  <!-- SNAP POINTS ─────────────────────────────────────────────────── -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Snap points</h2></div>
    <div class="grid-2" style="margin-top:16px">
      <div class="rule-card accent"><div class="rule-card-title">25% — Peek</div><div class="rule-card-body">Shows 1–2 items only. Triggered by a long-press on a list item. Used as a quick contextual preview before committing to the full sheet.</div></div>
      <div class="rule-card"><div class="rule-card-title">50% — Standard</div><div class="rule-card-body">The default snap point for action sheets (3–5 items) and short forms. Covers the lower half and keeps context visible above.</div></div>
      <div class="rule-card"><div class="rule-card-title">90% — Full</div><div class="rule-card-body">For complex forms or long filter lists. The sheet scrolls internally. Always a sticky footer for the primary action.</div></div>
      <div class="rule-card accent"><div class="rule-card-title">Drag-to-dismiss</div><div class="rule-card-body">Drag below 25% of sheet height or release with downward velocity > 6px/frame to dismiss. Screen springs back on dismissal.</div></div>
    </div>
  </div>

  <!-- TOKENS ─────────────────────────────────────────────────────── -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <div class="card" style="overflow:hidden">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Value</th><th>Usage</th></tr></thead>
        <tbody>
          ${[
            ['component/sheet/background','surface/default','Sheet fill'],
            ['component/sheet/radius','24px 24px 0 0','Top corners'],
            ['component/sheet/handle-width','36px','Drag handle width'],
            ['component/sheet/handle-height','4px','Drag handle height'],
            ['component/sheet/handle-color','#E5E5EA','Drag handle colour'],
            ['component/sheet/overlay-alpha','0.45','Dim overlay opacity'],
            ['component/sheet/screen-scale','0.94','Background scale when open'],
            ['component/sheet/screen-blur','1px','Background blur when open'],
            ['component/sheet/animation-in','0.38s cubic-bezier(0.32,0.72,0,1)','Spring-in easing'],
            ['component/sheet/animation-out','0.24s cubic-bezier(0.4,0,1,1)','Fast dismiss easing'],
          ].map(([t,v,u],i)=>`<tr style="${i%2===0?'background:var(--background-subtle);':''}border-bottom:1px solid var(--border-subtle)">
            <td style="padding:10px 16px"><code class="tok-name">${t}</code></td>
            <td style="padding:10px 16px;font-family:var(--font-mono);font-size:10px;color:var(--brand-primary)">${v}</td>
            <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${u}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
  </div>

  <!-- DO / DON'T ─────────────────────────────────────────────────── -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Scale and dim the background when the sheet is open — it reinforces modal context and prevents accidental taps on content behind.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't stack two bottom sheets. Use in-sheet navigation (push a new view within the sheet) instead.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use the 90% sheet for forms — keeps users oriented in context without navigating away from the list.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't put a Cancel button inside the sheet — the dim overlay and drag handle are the primary dismiss mechanisms.</div></div>
    </div>
  </div>

  </div>`;
}
