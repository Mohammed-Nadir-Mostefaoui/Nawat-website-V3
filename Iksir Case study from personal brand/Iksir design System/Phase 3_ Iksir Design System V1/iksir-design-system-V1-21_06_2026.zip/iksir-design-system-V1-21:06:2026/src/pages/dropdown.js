import { pageHeader } from '../utils/render.js';
import { SIZING } from '../data/sizing.js';

const EDIT = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`;
const COPY = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`;
const ARCHIVE = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 8 21 21 3 21 3 8"/><rect x="1" y="3" width="22" height="5"/><line x1="10" y1="12" x2="14" y2="12"/></svg>`;
const SHARE = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>`;
const DOWNLOAD = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`;
const SETTINGS = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`;
const TRASH = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>`;
const CHK = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`;
const CHEV = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>`;
const MORE = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>`;

const HVR = `onmouseenter="if(!this.dataset.disabled)this.style.background='var(--dropdown-option-bg-hover)'" onmouseleave="if(!this.dataset.selected)this.style.background='';"`;
const HVR_KEEP = `onmouseenter="if(!this.dataset.disabled)this.style.background='var(--dropdown-option-bg-hover)'" onmouseleave="this.style.background=this.dataset.selected==='true'?'':'';"`;

const PANEL_STYLE = `position:absolute;top:calc(100% + 4px);left:0;min-width:200px;background:var(--dropdown-panel-bg);border:1px solid var(--dropdown-panel-border);border-radius:8px;box-shadow:0 4px 8px rgba(0,0,0,0.08),0 2px 4px rgba(0,0,0,0.06);padding:4px 0;z-index:100`;
const TRIGGER_STYLE = `display:inline-flex;align-items:center;gap:6px;padding:0 14px;height:36px;border:1px solid var(--border-default);border-radius:8px;background:var(--background-surface);font-size:14px;font-weight:500;color:var(--content-primary);cursor:pointer;font-family:Inter,sans-serif;white-space:nowrap`;

function trigger(id, label, section) {
  return `<button id="${id}" onclick="ddToggle('${section}');event.stopPropagation()" style="${TRIGGER_STYLE}">${label}${CHEV}</button>`;
}

function iconTrigger(id, section) {
  return `<button id="${id}" onclick="ddToggle('${section}');event.stopPropagation()" style="display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border:1px solid var(--border-default);border-radius:8px;background:var(--background-surface);cursor:pointer;color:var(--icon-default)">${MORE}</button>`;
}

function item(label, { icon, sub, destructive, disabled, section, checked } = {}) {
  const textColor = disabled ? 'var(--dropdown-option-text-disabled)' : destructive ? 'var(--status-danger-content)' : 'var(--dropdown-option-text-default)';
  const iconColor = disabled ? 'var(--dropdown-option-icon-disabled)' : destructive ? 'var(--status-danger-content)' : 'var(--dropdown-option-icon-default)';
  const disAttr = disabled ? ' data-disabled="true"' : '';
  const cursor = disabled ? 'not-allowed' : 'pointer';
  const clk = disabled ? '' : section
    ? ` onclick="ddClose('${section}');event.stopPropagation()"`
    : '';
  const baseStyle = `display:flex;align-items:center;gap:8px;min-height:36px;padding:${sub ? '8px' : '0'} 12px;cursor:${cursor};user-select:none;`;
  return `<div style="${baseStyle}" ${HVR}${clk}${disAttr}>
    ${icon ? `<span style="color:${iconColor};flex-shrink:0;display:flex;align-items:center">${icon}</span>` : ''}
    <span style="flex:1;font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:${textColor};white-space:nowrap">${label}</span>
    ${sub ? `<span style="font-family:Inter,sans-serif;font-size:12px;font-weight:400;color:${disabled ? 'var(--dropdown-option-text-disabled)' : 'var(--dropdown-option-supporting-default)'};white-space:nowrap;margin-left:auto">${sub}</span>` : ''}
    ${checked !== undefined ? `<span class="dd-chk-${section || 'x'}" style="color:var(--dropdown-option-check-icon-default);display:${checked ? 'flex' : 'none'};align-items:center;flex-shrink:0">${CHK}</span>` : ''}
  </div>`;
}

function checkItem(label, { section, checked } = {}) {
  const esc = label.replace(/'/g, "\\'");
  return `<div data-selected="${checked ? 'true' : 'false'}" style="display:flex;align-items:center;gap:8px;height:36px;padding:0 12px;cursor:pointer;user-select:none;background:${checked ? 'var(--dropdown-option-bg-hover)' : ''}"
    onmouseenter="this.style.background='var(--dropdown-option-bg-hover)'"
    onmouseleave="this.style.background=this.dataset.selected==='true'?'var(--dropdown-option-bg-hover)':''"
    onclick="ddCheckItem(this,'${section}','${esc}');event.stopPropagation()">
    <span style="flex:1;font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:${checked ? 'var(--content-primary)' : 'var(--dropdown-option-text-default)'}" class="dd-chk-label">${label}</span>
    <span class="dd-chk-icon" style="color:var(--dropdown-option-check-icon-default);display:${checked ? 'flex' : 'none'};align-items:center;flex-shrink:0">${CHK}</span>
  </div>`;
}

function divider() {
  return `<div style="height:1px;background:var(--divider-divider);margin:4px 0"></div>`;
}

function panel(id, section, children) {
  return `<div id="${id}" onclick="event.stopPropagation()" style="display:none;${PANEL_STYLE}">${children}</div>`;
}

function tRow(t, i) {
  const bg = i % 2 === 0 ? 'background:var(--background-subtle);' : '';
  const vc = t.val >= 9999 ? '9999px' : t.val + 'px';
  return `<tr style="${bg}border-bottom:1px solid var(--border-subtle)">
    <td style="padding:10px 16px"><code class="tok-name">${t.token}</code></td>
    <td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'${vc}')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">${t.ref}<span class="tok-alias-copied">${vc}</span></span></td>
    <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${t.use}</td>
  </tr>`;
}

function sizePanel(size, h, px) {
  const items = ['Edit project', 'Duplicate', 'Archive'];
  return `<div style="background:var(--dropdown-panel-bg);border:1px solid var(--dropdown-panel-border);border-radius:8px;box-shadow:0 4px 8px rgba(0,0,0,0.08),0 2px 4px rgba(0,0,0,0.06);padding:4px 0;min-width:160px">
    ${items.map(l => `<div style="display:flex;align-items:center;height:${h}px;padding:0 ${px}px;font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:var(--dropdown-option-text-default);cursor:default" ${HVR}>${l}</div>`).join('')}
    ${divider()}
    <div style="display:flex;align-items:center;height:${h}px;padding:0 ${px}px;font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:var(--status-danger-content);cursor:default" ${HVR}>Delete</div>
  </div>
  <span class="inp-multi-label">${size} — ${h}px · px ${px}</span>`;
}

export default function dropdown() {
  return pageHeader('Components', 'Dropdown menu', 'Contextual action panel triggered by a button. 3 option sizes with icon, supporting text, check, and divider variants.', [
    { val: '3',  label: 'Sizes' },
    { val: String(SIZING.dropdown.length), label: 'Size tokens' },
    { val: '26', label: 'Color tokens' },
  ]) + `<div class="page-body">

  <!-- VARIANTS -->
  <div class="doc-section">
    <h2 class="doc-section-title">Variants</h2>
    <p class="doc-section-desc">Six dropdown configurations covering the most common content patterns — plain text, icon-leading, supporting text, check-toggle, divider-grouped, and mixed disabled states. All demos are fully interactive.</p>

    <!-- DEFAULT -->
    <div class="doc-variant-block">
      <h3 class="doc-variant-title">Default</h3>
      <p class="doc-section-desc">Text-only action items with a destructive delete at the bottom separated by a divider. Click the trigger to open, click any item or outside to close.</p>
      <div class="inp-section-demo" style="overflow:visible">
        <div class="inp-demo-toolbar" style="border-radius:8px 8px 0 0"><span class="inp-demo-title">Default — click to open</span></div>
        <div class="inp-demo-stage" style="display:flex;align-items:flex-start;justify-content:center;min-height:240px;padding-top:40px">
          <div style="position:relative">
            ${trigger('dd-trigger-default', 'Options', 'default')}
            ${panel('dd-panel-default', 'default', [
              item('Edit',       { section: 'default' }),
              item('Duplicate',  { section: 'default' }),
              item('Rename',     { section: 'default' }),
              item('Archive',    { section: 'default' }),
              divider(),
              item('Delete',     { section: 'default', destructive: true }),
            ].join(''))}
          </div>
        </div>
        <div class="btn-tokens-strip">
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#FFFFFF;border:1px solid #E1E1E1;"></div><div><div class="btn-token-name">dropdown/panel/bg</div><div class="btn-token-label">Panel background</div></div></div>
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#E8E8E8;"></div><div><div class="btn-token-name">dropdown/panel/border</div><div class="btn-token-label">Panel border</div></div></div>
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#474747;"></div><div><div class="btn-token-name">dropdown/option/text/default</div><div class="btn-token-label">Option text</div></div></div>
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#FAFAFA;border:1px solid #E1E1E1;"></div><div><div class="btn-token-name">dropdown/option/bg/hover</div><div class="btn-token-label">Hover background</div></div></div>
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#D8192C;"></div><div><div class="btn-token-name">status/danger-content</div><div class="btn-token-label">Destructive text</div></div></div>
        </div>
      </div>
    </div>

    <!-- WITH ICON -->
    <div class="doc-variant-block">
      <h3 class="doc-variant-title">With icon</h3>
      <p class="doc-section-desc">16px leading icon beside each label. Icon color matches the option text token — gray for default, red for destructive, muted for disabled.</p>
      <div class="inp-section-demo" style="overflow:visible">
        <div class="inp-demo-toolbar" style="border-radius:8px 8px 0 0"><span class="inp-demo-title">Icon leading — click to open</span></div>
        <div class="inp-demo-stage" style="display:flex;align-items:flex-start;justify-content:center;min-height:260px;padding-top:40px">
          <div style="position:relative">
            ${trigger('dd-trigger-icon', 'Options', 'icon')}
            ${panel('dd-panel-icon', 'icon', [
              item('Edit',       { icon: EDIT,     section: 'icon' }),
              item('Duplicate',  { icon: COPY,     section: 'icon' }),
              item('Share',      { icon: SHARE,    section: 'icon' }),
              item('Download',   { icon: DOWNLOAD, section: 'icon', disabled: true }),
              divider(),
              item('Delete',     { icon: TRASH,    section: 'icon', destructive: true }),
            ].join(''))}
          </div>
        </div>
        <div class="btn-tokens-strip">
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#757575;"></div><div><div class="btn-token-name">dropdown/option/icon/default</div><div class="btn-token-label">Icon default</div></div></div>
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#5E5E5E;"></div><div><div class="btn-token-name">dropdown/option/icon/hover</div><div class="btn-token-label">Icon hover</div></div></div>
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#D1D1D1;"></div><div><div class="btn-token-name">dropdown/option/icon/disabled</div><div class="btn-token-label">Icon disabled</div></div></div>
        </div>
      </div>
    </div>

    <!-- WITH SUPPORTING TEXT -->
    <div class="doc-variant-block">
      <h3 class="doc-variant-title">With supporting text</h3>
      <p class="doc-section-desc">Secondary metadata on the right of the label — keyboard shortcut, count, or a short description. Uses the <code>dropdown/option/supporting/default</code> token.</p>
      <div class="inp-section-demo" style="overflow:visible">
        <div class="inp-demo-toolbar" style="border-radius:8px 8px 0 0"><span class="inp-demo-title">Supporting text — click to open</span></div>
        <div class="inp-demo-stage" style="display:flex;align-items:flex-start;justify-content:center;min-height:240px;padding-top:40px">
          <div style="position:relative">
            ${trigger('dd-trigger-sub', 'Actions', 'sub')}
            ${panel('dd-panel-sub', 'sub', [
              item('Edit',       { sub: '⌘E',   section: 'sub' }),
              item('Duplicate',  { sub: '⌘D',   section: 'sub' }),
              item('Archive',    { sub: '⌘A',   section: 'sub' }),
              divider(),
              item('Delete',     { sub: '⌫',    section: 'sub', destructive: true }),
            ].join(''))}
          </div>
        </div>
        <div class="btn-tokens-strip">
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#A3A3A3;"></div><div><div class="btn-token-name">dropdown/option/supporting/default</div><div class="btn-token-label">Supporting default</div></div></div>
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#757575;"></div><div><div class="btn-token-name">dropdown/option/supporting/hover</div><div class="btn-token-label">Supporting hover</div></div></div>
        </div>
      </div>
    </div>

    <!-- WITH CHECK -->
    <div class="doc-variant-block">
      <h3 class="doc-variant-title">With check</h3>
      <p class="doc-section-desc">Toggle-style menu where items persist their selected state. Click any item to check or uncheck. The check icon uses the <code>dropdown/option/check-icon/default</code> token.</p>
      <div class="inp-section-demo" style="overflow:visible">
        <div class="inp-demo-toolbar" style="border-radius:8px 8px 0 0"><span class="inp-demo-title">Check items — click items to toggle</span></div>
        <div class="inp-demo-stage" style="display:flex;align-items:flex-start;justify-content:center;min-height:260px;padding-top:40px">
          <div style="position:relative">
            ${trigger('dd-trigger-chk', 'View', 'chk')}
            <div id="dd-panel-chk" onclick="event.stopPropagation()" style="display:none;${PANEL_STYLE}">
              ${checkItem('Show toolbar',    { section: 'chk', checked: true })}
              ${checkItem('Show sidebar',    { section: 'chk', checked: true })}
              ${checkItem('Show grid',       { section: 'chk', checked: false })}
              ${checkItem('Show minimap',    { section: 'chk', checked: false })}
              ${divider()}
              ${checkItem('Compact mode',    { section: 'chk', checked: false })}
            </div>
          </div>
        </div>
        <div class="btn-tokens-strip">
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#430098;"></div><div><div class="btn-token-name">dropdown/option/check-icon/default</div><div class="btn-token-label">Check icon</div></div></div>
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#191919;"></div><div><div class="btn-token-name">dropdown/option/text/hover</div><div class="btn-token-label">Selected text</div></div></div>
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#FAFAFA;border:1px solid #E1E1E1;"></div><div><div class="btn-token-name">dropdown/option/bg/focus</div><div class="btn-token-label">Selected bg</div></div></div>
        </div>
      </div>
    </div>

    <!-- WITH DIVIDER -->
    <div class="doc-variant-block">
      <h3 class="doc-variant-title">With divider</h3>
      <p class="doc-section-desc">A 1px rule rendered with the <code>divider/divider</code> token, with 4px vertical margin. Group related actions and visually separate destructive ones at the bottom.</p>
      <div class="inp-section-demo" style="overflow:visible">
        <div class="inp-demo-toolbar" style="border-radius:8px 8px 0 0"><span class="inp-demo-title">Grouped with dividers — click to open</span></div>
        <div class="inp-demo-stage" style="display:flex;align-items:flex-start;justify-content:center;min-height:320px;padding-top:40px">
          <div style="position:relative">
            ${iconTrigger('dd-trigger-div', 'div')}
            ${panel('dd-panel-div', 'div', [
              item('Edit',         { icon: EDIT,     section: 'div' }),
              item('Duplicate',    { icon: COPY,     section: 'div' }),
              divider(),
              item('Settings',     { icon: SETTINGS, section: 'div' }),
              item('Archive',      { icon: ARCHIVE,  section: 'div' }),
              divider(),
              item('Delete',       { icon: TRASH,    section: 'div', destructive: true }),
            ].join(''))}
          </div>
        </div>
      </div>
    </div>

    <!-- DISABLED ITEMS -->
    <div class="doc-variant-block">
      <h3 class="doc-variant-title">Disabled items</h3>
      <p class="doc-section-desc">Disabled items use the <code>dropdown/option/text/disabled</code> and <code>dropdown/option/icon/disabled</code> tokens. They do not respond to hover or click. Always pair with a tooltip to explain why the action is unavailable.</p>
      <div class="inp-section-demo" style="overflow:visible">
        <div class="inp-demo-toolbar" style="border-radius:8px 8px 0 0"><span class="inp-demo-title">Mixed enabled/disabled — click to open</span></div>
        <div class="inp-demo-stage" style="display:flex;align-items:flex-start;justify-content:center;min-height:240px;padding-top:40px">
          <div style="position:relative">
            ${trigger('dd-trigger-dis', 'File', 'dis')}
            ${panel('dd-panel-dis', 'dis', [
              item('Save',         { icon: DOWNLOAD, section: 'dis' }),
              item('Save as…',     { icon: COPY,     section: 'dis' }),
              item('Export PDF',   { icon: SHARE,    section: 'dis', disabled: true }),
              item('Print',        { icon: SETTINGS, section: 'dis', disabled: true }),
              divider(),
              item('Close',        { section: 'dis' }),
            ].join(''))}
          </div>
        </div>
        <div class="btn-tokens-strip">
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#D1D1D1;"></div><div><div class="btn-token-name">dropdown/option/text/disabled</div><div class="btn-token-label">Disabled text</div></div></div>
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#F6F6F6;border:1px solid #E1E1E1;"></div><div><div class="btn-token-name">dropdown/option/bg/disabled</div><div class="btn-token-label">Disabled bg</div></div></div>
          <div class="btn-token-item"><div class="btn-token-swatch" style="background:#D1D1D1;"></div><div><div class="btn-token-name">dropdown/option/icon/disabled</div><div class="btn-token-label">Disabled icon</div></div></div>
        </div>
      </div>
    </div>
  </div>

  <!-- SIZES -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Sizes</h2></div>
    <p class="doc-section-desc">Three option sizes — SM (32px), MD (36px), LG (40px) — matching the density of the surrounding UI. Panel radius (8px) and shadow stay constant across sizes.</p>
    <div class="inp-section-demo" style="overflow:visible">
      <div class="inp-demo-toolbar" style="border-radius:8px 8px 0 0"><span class="inp-demo-title">All sizes — live panels</span></div>
      <div class="inp-multi-stage" style="align-items:flex-start;gap:24px;padding-top:16px">
        <div class="inp-multi-cell">${sizePanel('SM', 32, 10)}</div>
        <div class="inp-multi-cell">${sizePanel('MD', 36, 12)}</div>
        <div class="inp-multi-cell">${sizePanel('LG', 40, 16)}</div>
      </div>
    </div>
  </div>

  <!-- COMPONENT TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <p class="doc-section-desc">All sizing values bound to the <code>Components</code> collection. Hover to preview the value, click to copy.</p>
    <div class="card" style="overflow:hidden;margin-bottom:16px">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Aliases → (hover for value, click to copy)</th><th>Usage</th></tr></thead>
        <tbody>${SIZING.dropdown.map(tRow).join('')}</tbody>
      </table>
    </div>
  </div>

  <!-- PROPS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
    <table class="prop-table">
      <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
      <tbody>
        <tr><td><span class="prop-name">trigger</span></td><td><span class="prop-type">ReactNode</span></td><td><span class="prop-default">—</span></td><td>Element that opens the menu on click.</td></tr>
        <tr><td><span class="prop-name">size</span></td><td><span class="prop-type">"sm"|"md"|"lg"</span></td><td><span class="prop-default">"md"</span></td><td>Option height (32/36/40px) and horizontal padding.</td></tr>
        <tr><td><span class="prop-name">align</span></td><td><span class="prop-type">"left"|"right"</span></td><td><span class="prop-default">"left"</span></td><td>Panel alignment relative to the trigger.</td></tr>
        <tr><td><span class="prop-name">width</span></td><td><span class="prop-type">number|"auto"</span></td><td><span class="prop-default">"auto"</span></td><td>Panel width in px. Auto fits the widest item.</td></tr>
        <tr><td><span class="prop-name">open</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Controlled open state.</td></tr>
        <tr><td><span class="prop-name">onOpenChange</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Called when the open state changes.</td></tr>
        <tr><td><span class="prop-name">children</span></td><td><span class="prop-type">ReactNode</span></td><td><span class="prop-default">—</span></td><td><code>DropdownItem</code>, <code>DropdownDivider</code>, or <code>DropdownLabel</code> elements.</td></tr>
      </tbody>
    </table>
    <h3 style="font-size:14px;font-weight:600;color:var(--content-primary);margin:24px 0 12px">DropdownItem props</h3>
    <table class="prop-table">
      <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
      <tbody>
        <tr><td><span class="prop-name">icon</span></td><td><span class="prop-type">ReactNode</span></td><td><span class="prop-default">—</span></td><td>16px leading icon.</td></tr>
        <tr><td><span class="prop-name">supportingText</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Secondary label shown to the right.</td></tr>
        <tr><td><span class="prop-name">checked</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">—</span></td><td>Shows a check icon when true. Enables toggle behaviour.</td></tr>
        <tr><td><span class="prop-name">destructive</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Renders the item in danger red.</td></tr>
        <tr><td><span class="prop-name">disabled</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Prevents hover and click.</td></tr>
        <tr><td><span class="prop-name">onClick</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Click handler. Menu closes automatically unless prevented.</td></tr>
      </tbody>
    </table>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Keep menus short — 5 to 7 items max. Long menus are hard to scan; break them into submenus or a dedicated page.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't mix icon and non-icon items in the same menu. If any item has an icon, all items should have one to maintain alignment.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Place destructive actions at the bottom, separated by a divider, so they are never accidentally triggered.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use a Dropdown to replace a Select field for form values — use the Select component for user input that gets submitted.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use supporting text for keyboard shortcuts so power users can discover and memorize them without cluttering the label.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't disable actions without providing a way to understand why. Pair disabled items with a tooltip or a contextual hint.</div></div>
    </div>
  </div>

  </div>`;
}
