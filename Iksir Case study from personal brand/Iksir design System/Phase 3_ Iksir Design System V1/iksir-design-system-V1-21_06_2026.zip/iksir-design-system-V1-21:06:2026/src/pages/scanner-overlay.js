import { pageHeader } from '../utils/render.js';

const CLOSE   = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;
const TORCH   = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>`;
const KEYBOARD= `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M6 8h.01M10 8h.01M14 8h.01M18 8h.01M8 12h.01M12 12h.01M16 12h.01M7 16h10"/></svg>`;

function swatch(color, name, lbl) {
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${color}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${lbl}</div></div></div>`;
}

export default function scannerOverlay() {
  return pageHeader('Components', 'Scanner Overlay', 'Full-screen barcode scanner. Dark camera surface, L-bracket corners, animated scan line. Success state with green flash.', [
    { val: '2', label: 'States' },
    { val: '280ms', label: 'Success anim' },
  ]) + `<div class="page-body">

  <style>
    @keyframes scan-sweep {
      0%   { top: 10%; opacity: 0.9; }
      10%  { opacity: 1; }
      90%  { opacity: 1; }
      100% { top: 88%; opacity: 0.9; }
    }
    @keyframes scan-sweep-back {
      0%   { top: 88%; opacity: 0.9; }
      100% { top: 10%; opacity: 0.9; }
    }
    .scan-line-active { animation: scan-sweep 1.8s ease-in-out infinite alternate; }
    @keyframes corner-success {
      0%   { border-color: #fff; }
      100% { border-color: #16A34A; }
    }
    @keyframes success-badge-in {
      from { opacity: 0; transform: scale(0.5); }
      to   { opacity: 1; transform: scale(1); }
    }
    @keyframes torch-glow {
      from { background: rgba(255,220,0,0); }
      to   { background: rgba(255,220,0,0.08); }
    }
    .scanner-torch-on { animation: torch-glow 0.2s ease forwards; }
  </style>

  <!-- LIVE SCANNER -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Live — animated scanner</h2></div>
    <p class="doc-section-desc">Click <strong>Simulate scan</strong> to trigger the success state. The scan line stops, corners flash green, and a success badge animates in. Click <strong>Reset</strong> to return to scanning mode. Torch and manual entry are also interactive.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Scanner Overlay — interactive</span></div>
      <div class="inp-demo-stage" style="display:flex;justify-content:center;padding:24px;background:#1A1A2E">

        <div id="sc-root" data-state="scanning" data-torch="off" style="width:280px;background:var(--scanner-bg);border-radius:24px;overflow:hidden;box-shadow:0 20px 48px rgba(0,0,0,0.6),0 0 0 1px rgba(255,255,255,0.08);font-family:Inter,sans-serif;position:relative">

          <!-- status bar -->
          <div style="height:28px;display:flex;align-items:center;justify-content:space-between;padding:0 16px;background:rgba(0,0,0,0.3)">
            <span style="font-size:11px;font-weight:700;color:#fff">9:41</span>
            <span style="font-size:9px;color:rgba(255,255,255,0.5)">● ● ▐▐</span>
          </div>

          <!-- header -->
          <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 16px;position:relative;z-index:3">
            <button onclick="(function(){
              var r=document.getElementById('sc-root');
              if(r.dataset.state==='success') { scReset(); return; }
            })()" style="width:34px;height:34px;border-radius:50%;background:var(--scanner-ui-btn-bg);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--scanner-ui-text);backdrop-filter:blur(4px)">${CLOSE}</button>
            <span style="font-size:13px;font-weight:700;color:var(--scanner-ui-text)">Scan barcode</span>
            <button id="sc-torch-btn" onclick="(function(btn){
              var r=document.getElementById('sc-root');
              var on = r.dataset.torch !== 'on';
              r.dataset.torch = on ? 'on' : 'off';
              btn.style.background = on ? 'rgba(255,220,0,0.25)' : 'var(--scanner-ui-btn-bg)';
              btn.style.color = on ? 'var(--scanner-torch-active)' : 'var(--scanner-ui-text)';
              var glow = document.getElementById('sc-torch-glow');
              if(glow) glow.style.opacity = on ? '1' : '0';
            })(this)" style="width:34px;height:34px;border-radius:50%;background:var(--scanner-ui-btn-bg);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--scanner-ui-text);transition:all 0.2s">${TORCH}</button>
          </div>

          <!-- camera area -->
          <div id="sc-camera" style="position:relative;margin:0 12px;background:#000;border-radius:8px;overflow:hidden">
            <!-- torch glow overlay -->
            <div id="sc-torch-glow" style="position:absolute;inset:0;background:rgba(255,220,0,0.06);opacity:0;transition:opacity 0.3s;pointer-events:none;z-index:2"></div>

            <!-- dim top -->
            <div style="height:20px;background:rgba(0,0,0,0.7)"></div>

            <!-- middle row -->
            <div style="display:flex">
              <div style="width:28px;background:rgba(0,0,0,0.7)"></div>

              <!-- viewfinder -->
              <div id="sc-viewfinder" style="flex:1;height:150px;position:relative;overflow:hidden">
                <!-- fake camera feed -->
                <div style="position:absolute;inset:0;background:linear-gradient(135deg,#0A0A14 0%,#0D0D1A 40%,#070710 100%)">
                  ${Array.from({length:20},()=>`<div style="position:absolute;width:${Math.random()*60+20}px;height:2px;background:rgba(255,255,255,${Math.random()*0.06+0.02});top:${Math.random()*100}%;left:${Math.random()*80}%;transform:rotate(${Math.random()*10-5}deg)"></div>`).join('')}
                </div>

                <!-- barcode hint -->
                <div id="sc-barcode" style="position:absolute;inset:20px;display:flex;align-items:center;justify-content:center;gap:1px;opacity:0.15">
                  ${Array.from({length:28},(_,i)=>`<div style="width:${i%3===0?3:i%5===0?4:2}px;height:55%;background:#fff"></div>`).join('')}
                </div>

                <!-- L-bracket corners -->
                <div id="sc-tl" style="position:absolute;top:0;left:0;width:22px;height:22px;border-top:3px solid var(--scanner-corner-default);border-left:3px solid var(--scanner-corner-default);border-radius:2px 0 0 0;transition:border-color 0.3s"></div>
                <div id="sc-tr" style="position:absolute;top:0;right:0;width:22px;height:22px;border-top:3px solid var(--scanner-corner-default);border-right:3px solid var(--scanner-corner-default);border-radius:0 2px 0 0;transition:border-color 0.3s"></div>
                <div id="sc-bl" style="position:absolute;bottom:0;left:0;width:22px;height:22px;border-bottom:3px solid var(--scanner-corner-default);border-left:3px solid var(--scanner-corner-default);border-radius:0 0 0 2px;transition:border-color 0.3s"></div>
                <div id="sc-br" style="position:absolute;bottom:0;right:0;width:22px;height:22px;border-bottom:3px solid var(--scanner-corner-default);border-right:3px solid var(--scanner-corner-default);border-radius:0 0 2px 0;transition:border-color 0.3s"></div>

                <!-- scan line -->
                <div id="sc-scan-line" class="scan-line-active" style="position:absolute;top:10%;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent 0%,rgba(67,0,152,0.3) 20%,var(--scanner-scan-line-mid) 50%,rgba(67,0,152,0.3) 80%,transparent 100%);filter:drop-shadow(0 0 4px var(--scanner-scan-line))"></div>

                <!-- success badge -->
                <div id="sc-success-badge" style="position:absolute;inset:0;display:none;flex-direction:column;align-items:center;justify-content:center;gap:6px;background:rgba(22,163,74,0.15)">
                  <div style="width:36px;height:36px;border-radius:50%;background:var(--scanner-success-icon);display:flex;align-items:center;justify-content:center">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
                  </div>
                  <span style="font-size:10px;font-weight:700;color:var(--scanner-corner-success);font-family:Inter,sans-serif">Barcode found</span>
                </div>
              </div>

              <div style="width:28px;background:rgba(0,0,0,0.7)"></div>
            </div>

            <!-- dim bottom -->
            <div style="height:20px;background:rgba(0,0,0,0.7)"></div>
          </div>

          <!-- result panel -->
          <div id="sc-result" style="margin:10px 12px 0;padding:10px 14px;background:rgba(255,255,255,0.07);border-radius:8px;display:none">
            <div style="font-size:9px;color:rgba(255,255,255,0.5);font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin-bottom:2px">Scanned</div>
            <div id="sc-barcode-val" style="font-family:var(--font-mono);font-size:14px;color:#fff;font-weight:700"></div>
          </div>

          <!-- hint -->
          <div id="sc-hint" style="padding:10px 16px;font-size:11px;color:rgba(255,255,255,0.5);text-align:center">Align barcode within the frame</div>

          <!-- manual entry -->
          <div style="padding:0 16px 16px;display:flex;gap:8px">
            <button onclick="(function(){
              var h=document.getElementById('sc-manual-row');
              if(!h) return;
              h.style.display = h.style.display==='none'?'flex':'none';
            })()" style="flex:1;height:36px;border-radius:8px;background:rgba(255,255,255,0.1);border:none;cursor:pointer;color:rgba(255,255,255,0.8);font-family:Inter,sans-serif;font-size:12px;font-weight:500;display:flex;align-items:center;justify-content:center;gap:6px;transition:background 0.15s" onmouseenter="this.style.background='rgba(255,255,255,0.16)'" onmouseleave="this.style.background='rgba(255,255,255,0.1)'">${KEYBOARD} Saisie manuelle</button>
          </div>

          <!-- manual entry row -->
          <div id="sc-manual-row" style="display:none;padding:0 16px 16px;gap:6px;align-items:center">
            <input id="sc-manual-input" placeholder="Ex: 3760224000014" style="flex:1;height:36px;border-radius:8px;background:var(--scanner-ui-btn-bg);border:1px solid rgba(255,255,255,0.15);color:var(--scanner-ui-text);font-family:var(--font-mono);font-size:12px;padding:0 10px;outline:none" oninput="this.style.borderColor='rgba(67,0,152,0.8)'">
            <button onclick="(function(){
              var inp = document.getElementById('sc-manual-input');
              if(!inp||!inp.value.trim()) return;
              scTriggerSuccess(inp.value.trim());
            })()" style="padding:0 12px;height:36px;border-radius:8px;background:var(--scanner-confirm-bg);border:none;cursor:pointer;color:var(--scanner-confirm-text);font-family:Inter,sans-serif;font-size:12px;font-weight:600">OK</button>
          </div>
        </div>

      </div>

      <!-- controls below demo -->
      <div style="display:flex;gap:8px;justify-content:center;padding:12px 0">
        <button onclick="scTriggerSuccess('3760224000014')" style="padding:0 16px;height:34px;border-radius:8px;background:var(--scanner-confirm-bg);border:none;cursor:pointer;font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--scanner-confirm-text)">Simulate scan</button>
        <button onclick="scReset()" style="padding:0 16px;height:34px;border-radius:8px;background:var(--background-subtle);border:1px solid var(--border-default);cursor:pointer;font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--content-primary)">Reset</button>
      </div>

      <div class="btn-tokens-strip">
        ${swatch('#0A0A0A','color/black','Camera background')}
        ${swatch('#7B3FEF','brand/primary-light','Scan line colour')}
        ${swatch('#16A34A','status/success-content','Success corners')}
        ${swatch('rgba(0,0,0,0.7)','overlay/camera-dim','Dim zone')}
      </div>
    </div>
  </div>

  <!-- STATES -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">States</h2></div>
    <div class="grid-2" style="margin-top:16px">
      <div class="rule-card accent"><div class="rule-card-title">Scanning — animated line</div><div class="rule-card-body">Purple scan line sweeps vertically through the viewfinder at 1.8s interval. Corners are white. Background dim is 70% black. Barcode hint fades in at 15% opacity to guide placement.</div></div>
      <div class="rule-card"><div class="rule-card-title">Success — green flash</div><div class="rule-card-body">On detection: corners transition to <code>status/success-content</code> (#16A34A), scan line disappears, a checkmark badge scales in from zero. The result string appears in a glass panel below.</div></div>
      <div class="rule-card"><div class="rule-card-title">Torch on</div><div class="rule-card-body">Torch button turns amber. A warm golden overlay (rgba(255,220,0,0.06)) covers the camera area to simulate torchlight. Real implementation activates the device flashlight API.</div></div>
      <div class="rule-card accent"><div class="rule-card-title">Manual entry fallback</div><div class="rule-card-body">"Saisie manuelle" button slides in an input row below the camera. Typing a value and pressing OK triggers the same success flow as a real scan.</div></div>
    </div>
  </div>

  <!-- TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <div class="card" style="overflow:hidden">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Value</th><th>Usage</th></tr></thead>
        <tbody>
          ${[
            ['component/scanner/bg','#0A0A0A','Camera background'],
            ['component/scanner/dim-alpha','0.70','Dim zone opacity'],
            ['component/scanner/corner-default','#FFFFFF','Viewfinder corner colour'],
            ['component/scanner/corner-success','status/success-content','Success corner colour'],
            ['component/scanner/scan-line','brand/primary-light','Scan line gradient centre'],
            ['component/scanner/scan-duration','1.8s','Sweep animation duration'],
            ['component/scanner/success-duration','280ms','Badge scale-in duration'],
            ['component/scanner/glass-bg','rgba(255,255,255,0.07)','Result panel background'],
          ].map(([t,v,u],i) => `<tr style="${i%2===0?'background:var(--background-subtle);':''}border-bottom:1px solid var(--border-subtle)">
            <td style="padding:10px 16px"><code class="tok-name">${t}</code></td>
            <td style="padding:10px 16px;font-family:var(--font-mono);font-size:11px;color:var(--brand-primary)">${v}</td>
            <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${u}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Always provide a manual entry fallback. Barcodes can be damaged or poorly lit — the keyboard option is a safety net, not a secondary feature.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't keep the success state showing indefinitely. Auto-dismiss after 1.8s to resume scanning or navigate to the scanned item.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Show the scanned value in the result panel immediately so users can verify the correct item was read before confirming.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use the scanner overlay for QR codes intended for navigation — QR scan should be a separate surface, not the same viewfinder.</div></div>
    </div>
  </div>

  </div>

  <script>
    function scTriggerSuccess(code) {
      var r = document.getElementById('sc-root');
      if(!r || r.dataset.state === 'success') return;
      r.dataset.state = 'success';
      var line = document.getElementById('sc-scan-line');
      if(line) { line.classList.remove('scan-line-active'); line.style.opacity='0'; }
      var successClr = getComputedStyle(document.documentElement).getPropertyValue('--scanner-corner-success').trim();
      ['sc-tl','sc-tr','sc-bl','sc-br'].forEach(function(id){
        var el = document.getElementById(id);
        if(el) el.style.borderColor = successClr;
      });
      var badge = document.getElementById('sc-success-badge');
      if(badge) { badge.style.display='flex'; badge.style.animation='success-badge-in 0.28s cubic-bezier(0.175,0.885,0.32,1.275)'; }
      var result = document.getElementById('sc-result');
      var val = document.getElementById('sc-barcode-val');
      if(result && val) { val.textContent = code; result.style.display='block'; }
      var hint = document.getElementById('sc-hint');
      if(hint) { hint.textContent='Scan successful — item found'; hint.style.color='rgba(22,163,74,0.9)'; }
      var barcode = document.getElementById('sc-barcode');
      if(barcode) barcode.style.opacity = '0.5';
    }
    function scReset() {
      var r = document.getElementById('sc-root');
      if(!r) return;
      r.dataset.state = 'scanning';
      var line = document.getElementById('sc-scan-line');
      if(line) { line.style.opacity='1'; line.classList.add('scan-line-active'); }
      var defaultClr = getComputedStyle(document.documentElement).getPropertyValue('--scanner-corner-default').trim();
      ['sc-tl','sc-tr','sc-bl','sc-br'].forEach(function(id){
        var el = document.getElementById(id);
        if(el) el.style.borderColor = defaultClr;
      });
      var badge = document.getElementById('sc-success-badge');
      if(badge) { badge.style.display='none'; }
      var result = document.getElementById('sc-result');
      if(result) result.style.display='none';
      var hint = document.getElementById('sc-hint');
      if(hint) { hint.textContent='Align barcode within the frame'; hint.style.color='rgba(255,255,255,0.5)'; }
      var barcode = document.getElementById('sc-barcode');
      if(barcode) barcode.style.opacity='0.15';
      var manual = document.getElementById('sc-manual-row');
      if(manual) manual.style.display='none';
      var inp = document.getElementById('sc-manual-input');
      if(inp) inp.value='';
    }
  </script>
  `;
}
