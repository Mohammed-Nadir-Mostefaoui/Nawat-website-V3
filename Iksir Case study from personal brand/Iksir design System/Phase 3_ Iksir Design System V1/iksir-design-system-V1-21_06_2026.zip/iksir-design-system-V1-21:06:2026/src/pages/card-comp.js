import { pageHeader } from '../utils/render.js';

function swatch(color, name, lbl) {
  const light = ['#FFFFFF','#F6F6F6','#F7F4FB'].includes(color);
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${color};${light?'border:1px solid #E1E1E1':''}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${lbl}</div></div></div>`;
}

const TREND_UP = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--status-success-content)" stroke-width="2.5" stroke-linecap="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>`;
const TREND_DN = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--status-danger-content)" stroke-width="2.5" stroke-linecap="round"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/></svg>`;
const PKG = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>`;
const CHV = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>`;
const WARN = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--status-danger-content)" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;

/* Status card accent colours — mapped to semantic tokens */
const STATUS_ACCENTS = {
  danger:  { accent: 'var(--status-danger-content)',  text: 'var(--status-danger-content)',  bg: 'var(--status-danger-bg)' },
  warning: { accent: 'var(--status-warning-content)', text: 'var(--status-warning-content)', bg: 'var(--status-warning-bg)' },
  info:    { accent: 'var(--status-info-content)',     text: 'var(--status-info-content)',    bg: 'var(--status-info-bg)' },
  success: { accent: 'var(--status-success-content)', text: 'var(--status-success-content)', bg: 'var(--status-success-bg)' },
};

export default function cardComp() {
  return pageHeader('Components', 'Card', 'Surface container for related content. The building block of every ERP list, dashboard, and detail view.', [
    { val: '5', label: 'Variants' },
    { val: '10px', label: 'Radius' },
  ]) + `<div class="page-body">

  <!-- INTERACTIVE PLAYGROUND -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Live playground</h2></div>
    <p class="doc-section-desc">Click cards to feel the press state. Hover the interactive variant for the lift effect. Use the controls to switch variant and elevation.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">Card — interactive</span>
        <div class="inp-demo-controls">
          <span class="inp-demo-meta">Variant</span>
          <select class="inp-state-select" id="card-variant-sel" onchange="(function(v){
            var cards = document.querySelectorAll('.card-pg-item');
            cards.forEach(function(c){ c.style.display = 'none'; });
            var el = document.getElementById('card-pg-'+v);
            if(el) el.style.display = '';
          })(this.value)">
            <option value="default">Default</option>
            <option value="elevated">Elevated</option>
            <option value="interactive">Interactive</option>
            <option value="status">Status</option>
            <option value="stat">Stat</option>
          </select>
          <span class="inp-demo-meta" style="margin-left:8px">Elevation</span>
          <select class="inp-state-select" onchange="(function(v){
            var map={none:'none','1':'var(--elevation-1)','2':'var(--elevation-2)','3':'var(--elevation-3)'};
            var active=document.querySelector('.card-pg-item:not([style*=none])');
            if(active){var card=active.querySelector('.card-surface');if(card)card.style.boxShadow=map[v]||'none';}
          })(this.value)">
            <option value="none">None</option>
            <option value="1">Elevation/1</option>
            <option value="2" selected>Elevation/2</option>
            <option value="3">Elevation/3</option>
          </select>
        </div>
      </div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;padding:32px;min-height:200px;background:var(--background-subtle)">

        <!-- DEFAULT -->
        <div id="card-pg-default" class="card-pg-item" style="display:none">
          <div class="card-surface" style="width:280px;background:var(--background-default);border:1px solid var(--border-default);border-radius:10px;padding:16px;box-shadow:var(--elevation-2)">
            <div style="font-family:Inter,sans-serif;font-size:11px;font-weight:600;color:var(--content-secondary);text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px">Commande</div>
            <div style="font-family:var(--font-display);font-size:15px;font-weight:700;color:var(--content-primary);margin-bottom:8px">CMD-2847</div>
            <div style="display:flex;gap:6px">
              <span style="padding:0 7px;height:20px;display:inline-flex;align-items:center;border-radius:9999px;font-size:11px;font-weight:600;background:var(--status-success-bg);color:var(--status-success-content);border:1px solid var(--status-success-border)">Livré</span>
              <span style="padding:0 7px;height:20px;display:inline-flex;align-items:center;border-radius:9999px;font-size:11px;font-weight:600;background:var(--brand-primary-subtle);color:var(--brand-primary);border:1px solid var(--purple-20)">Express</span>
            </div>
          </div>
        </div>

        <!-- ELEVATED -->
        <div id="card-pg-elevated" class="card-pg-item" style="display:none">
          <div class="card-surface" style="width:280px;background:var(--background-default);border:1px solid var(--border-default);border-radius:10px;padding:16px;box-shadow:var(--elevation-2)">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
              <div style="width:36px;height:36px;border-radius:8px;background:var(--brand-primary-subtle);display:flex;align-items:center;justify-content:center;color:var(--brand-primary)">${PKG}</div>
              <div>
                <div style="font-family:Inter,sans-serif;font-size:13px;font-weight:600;color:var(--content-primary)">Palette bois standard</div>
                <div style="font-family:var(--font-mono);font-size:11px;color:var(--content-secondary)">PRD-00441</div>
              </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
              <div style="background:var(--background-subtle);border-radius:6px;padding:8px 10px">
                <div style="font-size:10px;color:var(--content-secondary);font-family:Inter,sans-serif">Stock</div>
                <div style="font-size:14px;font-weight:700;color:var(--content-primary);font-family:var(--font-mono)">342</div>
              </div>
              <div style="background:var(--background-subtle);border-radius:6px;padding:8px 10px">
                <div style="font-size:10px;color:var(--content-secondary);font-family:Inter,sans-serif">Prix</div>
                <div style="font-size:14px;font-weight:700;color:var(--content-primary);font-family:var(--font-mono)">12.50 €</div>
              </div>
            </div>
          </div>
        </div>

        <!-- INTERACTIVE -->
        <div id="card-pg-interactive" class="card-pg-item">
          <div class="card-surface" style="width:280px;background:var(--background-default);border:1px solid var(--border-default);border-radius:10px;padding:16px;box-shadow:var(--elevation-2);cursor:pointer;transition:transform 0.15s,box-shadow 0.15s,border-color 0.15s;user-select:none"
            onmouseenter="this.style.transform='translateY(-3px)';this.style.boxShadow='0 12px 28px rgba(67,0,152,0.14)';this.style.borderColor='var(--purple-30)'"
            onmouseleave="this.style.transform='';this.style.boxShadow='var(--elevation-2)';this.style.borderColor='var(--border-default)'"
            onmousedown="this.style.transform='translateY(-1px)';this.style.boxShadow='0 4px 12px rgba(67,0,152,0.12)'"
            onmouseup="this.style.transform='translateY(-3px)';this.style.boxShadow='0 12px 28px rgba(67,0,152,0.14)'">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
              <div style="font-family:Inter,sans-serif;font-size:13px;font-weight:600;color:var(--content-primary)">Palette bois standard</div>
              <span style="color:var(--purple-30)">${CHV}</span>
            </div>
            <div style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-secondary);margin-bottom:12px">Hover to lift · click to press</div>
            <div style="height:1px;background:var(--border-subtle);margin-bottom:10px"></div>
            <div style="display:flex;justify-content:space-between;align-items:center">
              <div style="font-family:var(--font-mono);font-size:11px;color:var(--content-secondary)">PRD-00441</div>
              <span style="padding:0 7px;height:20px;display:inline-flex;align-items:center;border-radius:9999px;font-size:11px;font-weight:600;background:var(--status-success-bg);color:var(--status-success-content);border:1px solid var(--status-success-border)">Actif</span>
            </div>
          </div>
        </div>

        <!-- STATUS -->
        <div id="card-pg-status" class="card-pg-item" style="display:none">
          <div style="display:flex;flex-direction:column;gap:10px;width:280px">
            ${[
              { accent:'var(--status-danger-content)',  label:'Stock critique',        desc:'Palette bois — 4 unités restantes' },
              { accent:'var(--status-warning-content)', label:'Commande en attente',   desc:'CMD-2847 nécessite une validation' },
              { accent:'var(--status-success-content)', label:'Livraison confirmée',   desc:'CMD-2839 — livrée ce matin' },
            ].map(s => `
            <div class="card-surface" style="background:var(--background-default);border:1px solid var(--border-default);border-left:3px solid ${s.accent};border-radius:10px;padding:12px 14px;box-shadow:var(--elevation-2);display:flex;align-items:center;gap:10px">
              <div style="width:6px;height:6px;border-radius:50%;background:${s.accent};flex-shrink:0"></div>
              <div>
                <div style="font-family:Inter,sans-serif;font-size:12px;font-weight:700;color:var(--content-primary)">${s.label}</div>
                <div style="font-family:Inter,sans-serif;font-size:11px;color:var(--content-secondary)">${s.desc}</div>
              </div>
            </div>`).join('')}
          </div>
        </div>

        <!-- STAT -->
        <div id="card-pg-stat" class="card-pg-item" style="display:none">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;width:300px">
            ${[
              { label:'Commandes',  val:'1 284', delta:'+12%', up:true },
              { label:'Produits',   val:'3 847', delta:'+4%',  up:true },
              { label:'Retours',    val:'23',    delta:'+8%',  up:false },
              { label:'CA du jour', val:'42 k€', delta:'-2%',  up:false },
            ].map(s => `
            <div class="card-surface" style="background:var(--background-default);border:1px solid var(--border-default);border-radius:10px;padding:14px;box-shadow:var(--elevation-2)">
              <div style="font-family:Inter,sans-serif;font-size:11px;color:var(--content-secondary);margin-bottom:4px">${s.label}</div>
              <div style="font-family:var(--font-display);font-size:22px;font-weight:700;color:var(--content-primary);line-height:1;margin-bottom:6px">${s.val}</div>
              <div style="display:flex;align-items:center;gap:4px">${s.up?TREND_UP:TREND_DN}<span style="font-family:Inter,sans-serif;font-size:11px;font-weight:600;color:${s.up?'var(--status-success-content)':'var(--status-danger-content)'}">${s.delta}</span></div>
            </div>`).join('')}
          </div>
        </div>

      </div>
      <div class="btn-tokens-strip">
        ${swatch('#FFFFFF','background/default','Card background')}
        ${swatch('#E1E1E1','border/default','Default border')}
        ${swatch('#C7B3E0','purple-30','Hover border (interactive)')}
        ${swatch('#F6F6F6','background/subtle','Inner section bg')}
      </div>
    </div>
  </div>

  <!-- ANATOMY -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Anatomy</h2></div>
    <p class="doc-section-desc">A card has four optional zones stacked vertically: a media zone (image or icon), a header zone (eyebrow + title), a body zone (metadata, badges, content), and a footer zone (actions). Not every card uses all zones.</p>
    <div class="grid-2" style="margin-top:16px">
      <div class="rule-card accent"><div class="rule-card-title">10px radius, always</div><div class="rule-card-body">All card variants use <code>border-radius: 10px</code> (<code>radius/lg</code>). This is a non-negotiable visual signature of the Iksir surface system.</div></div>
      <div class="rule-card"><div class="rule-card-title">16px default padding</div><div class="rule-card-body">Internal padding is <code>16px</code> on all sides. Dense card variants (table rows, mobile compact lists) use <code>12px</code>.</div></div>
      <div class="rule-card"><div class="rule-card-title">1px border, never shadow only</div><div class="rule-card-body">Cards always have a <code>border: 1px solid border/default</code>. On elevated cards, the border stays — it prevents the card from "floating" with no edge on white backgrounds.</div></div>
      <div class="rule-card accent"><div class="rule-card-title">Transparent background on dark surfaces</div><div class="rule-card-body">When a card sits on a dark or coloured background (e.g., the scanner overlay, a status banner), use <code>rgba(255,255,255,0.12)</code> instead of white — never a full white card on a dark bg.</div></div>
    </div>
  </div>

  <!-- VARIANTS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Variants</h2></div>
    <div style="margin-top:16px;border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden">
      <div style="display:grid;grid-template-columns:140px 1fr 2fr;background:var(--background-subtle);padding:10px 16px;gap:12px">
        ${['Variant','Shadow','Usage'].map(h=>`<div style="font-size:11px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em">${h}</div>`).join('')}
      </div>
      ${[
        ['Default','None','Form sections, list items, table cells where the surface is already distinct.'],
        ['Elevated/1','elevation-1','Cards on page backgrounds. Subtle lift.'],
        ['Elevated/2','elevation-2','Primary content cards, product tiles, order summaries.'],
        ['Elevated/3','elevation-3','Modals, dropdowns, floating surfaces.'],
        ['Interactive','elevation-2 → elevation-3 on hover','Clickable cards. Always with cursor:pointer and border transition.'],
        ['Status','elevation-1 + accent left-border','Alert cards, notification items, priority indicators.'],
        ['Stat','elevation-2','KPI tiles on dashboards. Large number + trend.'],
      ].map(([v,sh,u],i)=>`<div style="display:grid;grid-template-columns:140px 1fr 2fr;padding:10px 16px;gap:12px;${i<6?'border-top:1px solid var(--border-subtle)':''}">
        <div style="font-size:12px;font-weight:600;color:var(--content-primary)">${v}</div>
        <div style="font-family:var(--font-mono);font-size:10px;color:var(--content-secondary)">${sh}</div>
        <div style="font-size:12px;color:var(--content-tertiary)">${u}</div>
      </div>`).join('')}
    </div>
  </div>

  <!-- STATUS CARD ACCENTS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Status accent borders</h2></div>
    <p class="doc-section-desc">Status cards use a 3px left-border accent in place of a status badge to communicate severity at a glance. The card background is always <code>background/default</code> — only the border carries the colour.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Four severity levels</span></div>
      <div class="inp-demo-stage" style="display:flex;flex-direction:column;gap:8px;padding:20px">
        ${[
          { kind:'danger',  label:'Critical', desc:'Requires immediate action.',          warn: true },
          { kind:'warning', label:'Warning',  desc:'Needs attention before next cycle.',  warn: false },
          { kind:'info',    label:'Info',     desc:'For your awareness — no action yet.', warn: false },
          { kind:'success', label:'Success',  desc:'Completed successfully.',             warn: false },
        ].map(s => {
          const tok = STATUS_ACCENTS[s.kind];
          return `
        <div style="background:var(--background-default);border:1px solid var(--border-subtle);border-left:3px solid ${tok.accent};border-radius:10px;padding:12px 16px;display:flex;align-items:center;gap:12px;max-width:480px">
          ${s.warn ? WARN : ''}
          <div style="flex:1">
            <div style="font-family:Inter,sans-serif;font-size:13px;font-weight:700;color:var(--content-primary)">${s.label}</div>
            <div style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-secondary)">${s.desc}</div>
          </div>
        </div>`;
        }).join('')}
      </div>
    </div>
  </div>

  <!-- EMPTY STATE -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Empty state card</h2></div>
    <p class="doc-section-desc">When a card has no data to show yet, use the empty state variant: centered icon, short message, and an optional CTA button. No content in the card means no border-left accent.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Empty product card</span></div>
      <div class="inp-demo-stage" style="display:flex;justify-content:center;padding:20px">
        <div style="width:280px;background:var(--background-default);border:1px dashed var(--border-default);border-radius:10px;padding:28px 20px;display:flex;flex-direction:column;align-items:center;gap:8px;text-align:center">
          <div style="width:36px;height:36px;border-radius:9999px;background:var(--background-subtle);display:flex;align-items:center;justify-content:center;color:var(--content-tertiary)">${PKG}</div>
          <div style="font-family:Inter,sans-serif;font-size:13px;font-weight:600;color:var(--content-primary)">Aucun produit</div>
          <div style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-secondary);max-width:200px">Ajoutez votre premier produit pour commencer.</div>
          <button style="margin-top:4px;padding:0 14px;height:32px;border-radius:8px;background:var(--brand-primary);border:none;cursor:pointer;font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--content-on-brand);transition:background .15s" onmouseenter="this.style.background='var(--brand-primary-hover)'" onmouseleave="this.style.background='var(--brand-primary)'">+ Créer</button>
        </div>
      </div>
    </div>
  </div>

  <!-- TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <div class="card" style="overflow:hidden">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Value</th><th>Usage</th></tr></thead>
        <tbody>
          ${[
            ['component/card/background','background/default','Card fill'],
            ['component/card/border','border/default','1px border'],
            ['component/card/radius','10px','Corner radius'],
            ['component/card/padding','16px','Internal padding'],
            ['component/card/padding-dense','12px','Dense card padding'],
            ['component/card/shadow-1','elevation-1','Subtle lift'],
            ['component/card/shadow-2','elevation-2','Default elevated'],
            ['component/card/shadow-3','elevation-3','Modals & floating'],
            ['component/card/border-hover','purple-30','Interactive card hover border'],
            ['component/card/status-border-width','3px','Left accent border width'],
          ].map(([t,v,u],i)=>`<tr style="${i%2===0?'background:var(--background-subtle);':''}border-bottom:1px solid var(--border-subtle)">
            <td style="padding:10px 16px"><code class="tok-name">${t}</code></td>
            <td style="padding:10px 16px;font-family:var(--font-mono);font-size:11px;color:var(--brand-primary)">${v}</td>
            <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${u}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
  </div>

  <!-- PROPS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
    <table class="prop-table">
      <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
      <tbody>
        <tr><td><span class="prop-name">variant</span></td><td><span class="prop-type">"default"|"elevated"|"interactive"|"status"|"stat"</span></td><td><span class="prop-default">"elevated"</span></td><td>Visual variant. Drives shadow, cursor, and hover behavior.</td></tr>
        <tr><td><span class="prop-name">elevation</span></td><td><span class="prop-type">1|2|3</span></td><td><span class="prop-default">2</span></td><td>Shadow level. Only applies to elevated and interactive variants.</td></tr>
        <tr><td><span class="prop-name">statusColor</span></td><td><span class="prop-type">string (token)</span></td><td><span class="prop-default">—</span></td><td>Left-border accent — must be a <code>status/*-content</code> token. Only applies to the status variant.</td></tr>
        <tr><td><span class="prop-name">onClick</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Required for interactive variant. Adds role="button" and keyboard handler.</td></tr>
        <tr><td><span class="prop-name">padding</span></td><td><span class="prop-type">"default"|"dense"|"none"</span></td><td><span class="prop-default">"default"</span></td><td>Internal padding. "none" for cards where the content provides its own padding (e.g., images).</td></tr>
      </tbody>
    </table>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use the Interactive variant only when the entire card is clickable. If only part of it is clickable, use buttons/links inside a Default card.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't nest cards. A card inside a card creates visual ambiguity — use a table row or a list item instead.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Keep card width consistent within a layout. Use CSS grid to enforce equal-width columns, not manually set widths per card.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't put a primary action button inside a Status card — status cards are informational, not action-driven. Use a toast or inline message for follow-up actions.</div></div>
    </div>
  </div>

  </div>`;
}
