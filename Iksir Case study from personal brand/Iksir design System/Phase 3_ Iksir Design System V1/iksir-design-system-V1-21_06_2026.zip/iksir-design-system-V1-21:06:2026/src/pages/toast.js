import { pageHeader } from '../utils/render.js';
import { SIZING } from '../data/sizing.js';

const ICON_INFO  = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`;
const ICON_CHECK = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`;
const ICON_WARN  = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;
const ICON_ERROR = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`;
const ICON_SPIN  = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>`;
const CLOSE      = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;

const TYPES = {
  default: { icon: ICON_INFO,  color: 'var(--toast-icon-default)', title: 'Just a heads up'        },
  success: { icon: ICON_CHECK, color: 'var(--toast-icon-success)', title: 'Changes saved'           },
  warning: { icon: ICON_WARN,  color: 'var(--toast-icon-warning)', title: 'Approaching limit'       },
  error:   { icon: ICON_ERROR, color: 'var(--toast-icon-error)',   title: 'Something went wrong'    },
  loading: { icon: ICON_SPIN,  color: 'var(--toast-icon-loading)', title: 'Processing your request' },
};

const CLOSE_BTN = (onclick) =>
  `<button onclick="${onclick}"
    style="display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:24px;height:24px;border-radius:4px;border:none;background:transparent;color:var(--toast-close-default);cursor:pointer;transition:color .12s;margin-left:4px"
    onmouseenter="this.style.color='var(--toast-close-hover)'"
    onmouseleave="this.style.color='var(--toast-close-default)'"
  >${CLOSE}</button>`;

function toastEl(type, { desc, action, closeable = true, closeOnClick } = {}) {
  const t = TYPES[type] || TYPES.default;
  const closeHandler = closeOnClick || "this.closest('[data-toast]').style.display='none'";
  const descHtml = desc
    ? `<div style="font-family:Inter,sans-serif;font-size:13px;color:var(--toast-text-description);line-height:1.4;margin-top:4px">${desc}</div>`
    : '';
  const actionHtml = action
    ? `<div style="margin-top:12px">
        <button
          style="display:inline-flex;align-items:center;height:28px;padding:0 10px;border-radius:6px;border:1px solid var(--toast-action-border-default);background:var(--toast-action-bg-default);font-family:Inter,sans-serif;font-size:12px;font-weight:500;color:var(--toast-action-text-default);cursor:pointer;transition:background .12s,border-color .12s,color .12s"
          onmouseenter="this.style.background='var(--toast-action-bg-hover)';this.style.borderColor='var(--toast-action-border-hover)';this.style.color='var(--toast-action-text-hover)'"
          onmouseleave="this.style.background='var(--toast-action-bg-default)';this.style.borderColor='var(--toast-action-border-default)';this.style.color='var(--toast-action-text-default)'"
        >${action}</button>
      </div>`
    : '';

  return `<div data-toast style="display:flex;align-items:flex-start;gap:12px;padding:12px 16px;border-radius:8px;background:var(--toast-bg);width:340px;box-shadow:0 4px 16px rgba(0,0,0,.25)">
    <span style="display:inline-flex;align-items:center;color:${t.color};flex-shrink:0;margin-top:1px">${t.icon}</span>
    <div style="flex:1;min-width:0">
      <div style="font-family:Inter,sans-serif;font-size:14px;font-weight:600;color:var(--toast-text-title);line-height:1.4">${t.title}</div>
      ${descHtml}
      ${actionHtml}
    </div>
    ${closeable ? CLOSE_BTN(closeHandler) : ''}
  </div>`;
}

function triggerBtn(type, label) {
  return `<button onclick="toastTrigger('${type}')"
    style="display:inline-flex;align-items:center;gap:6px;height:32px;padding:0 14px;border-radius:6px;border:1px solid var(--border-default);background:var(--background-surface);font-family:Inter,sans-serif;font-size:13px;font-weight:500;color:var(--content-primary);cursor:pointer;transition:background .12s,border-color .12s"
    onmouseenter="this.style.background='var(--background-subtle)'"
    onmouseleave="this.style.background='var(--background-surface)'"
  >${label}</button>`;
}

const RESET_ICON = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M1 4v6h6"/><path d="M3.51 15a9 9 0 1 0 .49-3.69"/></svg>`;

function demoToolbar(title, stageId) {
  return `<div class="inp-demo-toolbar">
    <span class="inp-demo-title">${title}</span>
    <div style="display:flex;align-items:center;gap:6px">
      <div style="display:inline-flex;border:1px solid var(--border-default);border-radius:6px;overflow:hidden">
        <button data-mode-btn="dark" onclick="toastSectionMode('${stageId}','dark')"
          style="padding:4px 12px;border:none;background:#191919;font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:#fff;cursor:pointer;transition:background .12s,color .12s">Dark</button>
        <button data-mode-btn="light" onclick="toastSectionMode('${stageId}','light')"
          style="padding:4px 12px;border:none;background:var(--background-surface);font-family:Inter,sans-serif;font-size:12px;font-weight:400;color:var(--content-secondary);cursor:pointer;transition:background .12s,color .12s">Light</button>
      </div>
      <button onclick="toastSectionRefresh('${stageId}')"
        style="display:inline-flex;align-items:center;gap:5px;padding:4px 10px;border-radius:6px;border:1px solid var(--border-default);background:var(--background-surface);font-family:Inter,sans-serif;font-size:12px;color:var(--content-secondary);cursor:pointer;transition:background .12s"
        onmouseenter="this.style.background='var(--background-subtle)'"
        onmouseleave="this.style.background='var(--background-surface)'"
      >${RESET_ICON} Reset</button>
    </div>
  </div>`;
}

function swatch(hex, name, label, bordered) {
  const b = bordered ? 'border:1px solid #E1E1E1;' : '';
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${hex};${b}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${label}</div></div></div>`;
}

function tRow(t, i) {
  const bg = i % 2 === 0 ? 'background:var(--background-subtle);' : '';
  const vc = t.val >= 9999 ? '9999px' : t.val + 'px';
  return `<tr style="${bg}border-bottom:1px solid var(--border-subtle)">
    <td style="padding:10px 16px"><code class="tok-name">${t.token}</code></td>
    <td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'${vc}')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">${t.ref}<span class="tok-alias-copied">${vc}</span></span></td>
    <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${t.use}</td>
  </tr>`;
}

export default function toast() {
  return pageHeader('Components', 'Toast', 'Temporary notification that overlays the UI without interrupting the flow. Appears in a corner, auto-dismisses, and stacks when multiple fire at once.', [
    { val: '5',  label: 'Types' },
    { val: String(SIZING.toast.length), label: 'Size tokens' },
    { val: '17', label: 'Color tokens' },
  ]) + `<div class="page-body">

  <!-- VARIANTS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Variants</h2></div>
    <p class="doc-section-desc">Four content variants — from the minimal default to toasts with description text, inline actions, and all five types at a glance.</p>

    <!-- DEFAULT -->
    <div class="doc-variant-block">
      <div class="btn-section-toolbar"><h3 class="doc-variant-title">Default</h3></div>
      <p class="doc-section-desc">Click any type to fire a toast into the demo area. It slides in from the bottom-right, stays for 3 seconds, then fades out. Click × to dismiss early. Toggle background or Reset to restart.</p>
      <div class="inp-section-demo">
        ${demoToolbar('Live trigger — click a type below', 'toast-demo-stage')}
        <div id="toast-demo-stage" data-toast-stage style="position:relative;height:160px;background:var(--background-subtle);display:flex;align-items:center;justify-content:center;gap:8px;flex-wrap:wrap;padding:16px">
          ${triggerBtn('default', 'Default')}
          ${triggerBtn('success', 'Success')}
          ${triggerBtn('warning', 'Warning')}
          ${triggerBtn('error',   'Error')}
          ${triggerBtn('loading', 'Loading')}
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#191919','toast/bg','Toast background')}
          ${swatch('#FFFFFF','toast/text/title','Title text',true)}
          ${swatch('#BABABA','toast/text/description','Description text')}
          ${swatch('#A3A3A3','toast/close/default','Close icon — default')}
          ${swatch('#474747','toast/close/hover','Close icon — hover')}
        </div>
      </div>
    </div>

    <!-- WITH DESCRIPTION -->
    <div class="doc-variant-block">
      <div class="btn-section-toolbar"><h3 class="doc-variant-title">With description</h3></div>
      <p class="doc-section-desc">A short body line below the title using the description token. Keep it under two lines. Use it when the title alone doesn't provide enough context.</p>
      <div class="inp-section-demo">
        ${demoToolbar('Success with description — dismiss or toggle background', 'toast-desc-stage')}
        <div id="toast-desc-stage" data-toast-stage class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:120px">
          ${toastEl('success', { desc: 'Your profile has been updated and changes are live.' })}
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#FFFFFF','toast/text/title','Title text',true)}
          ${swatch('#BABABA','toast/text/description','Description text')}
        </div>
      </div>
    </div>

    <!-- WITH ACTION -->
    <div class="doc-variant-block">
      <div class="btn-section-toolbar"><h3 class="doc-variant-title">With action</h3></div>
      <p class="doc-section-desc">An inline action button lets users respond directly from the toast — undo a change, retry a failed operation, or open the affected resource. Limit to one action per toast.</p>
      <div class="inp-section-demo">
        ${demoToolbar('Error with action — hover the action button', 'toast-action-stage')}
        <div id="toast-action-stage" data-toast-stage class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:130px">
          ${toastEl('error', { desc: 'We couldn\'t save your changes. Check your connection and try again.', action: 'Retry' })}
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#FFFFFF','toast/action/bg/default','Action bg — default',true)}
          ${swatch('#FAFAFA','toast/action/bg/hover','Action bg — hover',true)}
          ${swatch('#5E5E5E','toast/action/text/default','Action text — default')}
          ${swatch('#191919','toast/action/text/hover','Action text — hover')}
          ${swatch('#E6E6E6','toast/action/border/default','Action border — default')}
          ${swatch('#A3A3A3','toast/action/border/hover','Action border — hover')}
        </div>
      </div>
    </div>

    <!-- ALL TYPES -->
    <div class="doc-variant-block">
      <div class="btn-section-toolbar"><h3 class="doc-variant-title">All types</h3></div>
      <p class="doc-section-desc">Five types share the same background — the icon color is the only differentiator. Toggle between Dark and Light to compare both modes side by side.</p>
      <div class="inp-section-demo">
        ${demoToolbar('All five types — dismiss or toggle background', 'toast-types-stage')}
        <div id="toast-types-stage" data-toast-stage class="inp-demo-stage" style="display:flex;flex-direction:column;align-items:center;gap:12px;padding:24px 16px;min-height:auto">
          ${toastEl('default', {})}
          ${toastEl('success', {})}
          ${toastEl('warning', {})}
          ${toastEl('error',   {})}
          ${toastEl('loading', { closeable: false })}
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#E8E8E8','toast/icon/default','Icon — default')}
          ${swatch('#148F47','toast/icon/success','Icon — success')}
          ${swatch('#AE7004','toast/icon/warning','Icon — warning')}
          ${swatch('#D8192C','toast/icon/error','Icon — error')}
          ${swatch('#430098','toast/icon/loading','Icon — loading')}
        </div>
      </div>
    </div>
  </div>

  <!-- COMPONENT TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <p class="doc-section-desc">All sizing values bound to the <code>Components</code> collection. Hover to preview the value, click to copy.</p>
    <div class="card" style="overflow:hidden;margin-bottom:16px">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Aliases → (hover for value, click to copy)</th><th>Usage</th></tr></thead>
        <tbody>${SIZING.toast.map(tRow).join('')}</tbody>
      </table>
    </div>
  </div>

  <!-- PROPS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
    <table class="prop-table">
      <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
      <tbody>
        <tr><td><span class="prop-name">type</span></td><td><span class="prop-type">"default"|"success"|"warning"|"error"|"loading"</span></td><td><span class="prop-default">"default"</span></td><td>Determines the icon and icon color. All types share the same dark background.</td></tr>
        <tr><td><span class="prop-name">title</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Primary message. Required. Keep it under 60 characters.</td></tr>
        <tr><td><span class="prop-name">description</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Secondary body text shown below the title.</td></tr>
        <tr><td><span class="prop-name">action</span></td><td><span class="prop-type">{ label: string, onClick: fn }</span></td><td><span class="prop-default">—</span></td><td>Inline action button. Limit to one per toast.</td></tr>
        <tr><td><span class="prop-name">duration</span></td><td><span class="prop-type">number | "infinite"</span></td><td><span class="prop-default">4000</span></td><td>Auto-dismiss delay in ms. Pass <code>"infinite"</code> for loading toasts that dismiss on completion.</td></tr>
        <tr><td><span class="prop-name">dismissable</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">true</span></td><td>Shows the × close button. Set to <code>false</code> for loading toasts.</td></tr>
        <tr><td><span class="prop-name">position</span></td><td><span class="prop-type">"bottom-right"|"bottom-left"|"top-right"|"top-left"|"bottom-center"</span></td><td><span class="prop-default">"bottom-right"</span></td><td>Corner where the toast stack renders.</td></tr>
        <tr><td><span class="prop-name">onDismiss</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Called when the toast is dismissed (user click or auto-timeout).</td></tr>
      </tbody>
    </table>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use toasts for non-critical, transient feedback: "Saved", "Copied", "Deleted". The user can continue working — the toast confirms something happened in the background.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use toasts for errors that require action to continue. If a form submission fails, show inline validation. A toast that auto-dismisses will be missed.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Keep the title under 60 characters and the description under two lines. Toasts are peripheral — users scan them, they don't read them.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't stack more than 3 toasts at once. If multiple events can fire simultaneously, queue them or batch them into a single toast with a count.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use the Loading type with <code>dismissable: false</code> for background operations. Replace it with a Success or Error toast when the operation completes.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't put more than one action in a toast. If a user needs to make a choice, use a Modal or an inline inline dialog — toasts are not decision points.</div></div>
    </div>
  </div>

  </div>`;
}
