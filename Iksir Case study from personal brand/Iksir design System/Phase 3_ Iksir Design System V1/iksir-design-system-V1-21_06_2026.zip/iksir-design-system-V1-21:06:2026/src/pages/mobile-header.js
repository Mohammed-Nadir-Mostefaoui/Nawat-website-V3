import { pageHeader } from '../utils/render.js';

const BACK   = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>`;
const DOTS   = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>`;
const EDIT   = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`;
const FILTER = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>`;

function iconBtn(icon) {
  return `<button style="width:36px;height:36px;border-radius:50%;background:var(--background-subtle);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--content-secondary)">${icon}</button>`;
}

export default function mobileHeader() {
  return pageHeader('Components', 'Mobile Header', 'Top navigation bar for mobile screens. Four variants: back+title, with subtitle, with actions, and root screen.', [
    { val: '4', label: 'Variants' },
    { val: '54px', label: 'Height' },
  ]) + `<div class="page-body">

  <style>
    @keyframes mh-variant-in { from { opacity:0; transform:translateY(-6px); } to { opacity:1; transform:translateY(0); } }
    .mh-anim { animation: mh-variant-in 0.2s ease; }
  </style>

  <!-- Hidden HTML cache — the onclick reads innerHTML from here, avoiding JSON embedding -->
  <div id="mh-cache" style="display:none">
    <div id="mh-v-default">
      <div style="display:flex;align-items:center;height:54px;padding:0 12px;gap:12px;background:var(--background-default);border-bottom:1px solid var(--border-subtle);width:100%;box-sizing:border-box">
        ${iconBtn(BACK)}
        <span style="flex:1;font-family:var(--font-display);font-size:16px;font-weight:700;color:var(--content-primary);text-align:center">Mes tâches</span>
        <div style="width:36px"></div>
      </div>
    </div>
    <div id="mh-v-subtitle">
      <div style="display:flex;align-items:center;height:60px;padding:0 12px;gap:12px;background:var(--background-default);border-bottom:1px solid var(--border-subtle);width:100%;box-sizing:border-box">
        ${iconBtn(BACK)}
        <div style="flex:1;text-align:center">
          <div style="font-family:var(--font-display);font-size:15px;font-weight:700;color:var(--content-primary);line-height:1.2">CMD-2847</div>
          <div style="font-family:Inter,sans-serif;font-size:11px;color:var(--content-tertiary);margin-top:1px">Livraison express · En transit</div>
        </div>
        ${iconBtn(DOTS)}
      </div>
    </div>
    <div id="mh-v-actions">
      <div style="display:flex;align-items:center;height:54px;padding:0 12px;gap:12px;background:var(--background-default);border-bottom:1px solid var(--border-subtle);width:100%;box-sizing:border-box">
        ${iconBtn(BACK)}
        <span style="flex:1;font-family:var(--font-display);font-size:16px;font-weight:700;color:var(--content-primary)">Commandes</span>
        <div style="display:flex;gap:4px">${iconBtn(FILTER)}${iconBtn(EDIT)}</div>
      </div>
    </div>
    <div id="mh-v-root">
      <div style="display:flex;align-items:center;height:54px;padding:0 16px;gap:12px;background:var(--background-default);border-bottom:1px solid var(--border-subtle);width:100%;box-sizing:border-box">
        <span style="font-family:var(--font-display);font-size:18px;font-weight:800;color:var(--content-primary);flex:1">Bonjour, Nadir 👋</span>
        <div style="width:36px;height:36px;border-radius:50%;background:var(--mobile-header-avatar-bg);display:flex;align-items:center;justify-content:center;font-family:Inter,sans-serif;font-size:12px;font-weight:700;color:var(--mobile-header-avatar-text);cursor:pointer">MN</div>
      </div>
    </div>
  </div>

  <!-- VARIANT SWITCHER -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Live variants</h2></div>
    <p class="doc-section-desc">Click any tab to switch the displayed header variant. Each variant is shown inside a phone chrome to give real proportional context.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar" style="gap:8px;flex-wrap:wrap">
        <div style="display:inline-flex;gap:6px;flex-wrap:wrap">
        ${[
          { id:'default',  label:'Back + title',        desc:'L1 screen with back navigation. Title centred between back arrow and optional action.' },
          { id:'subtitle', label:'With subtitle',        desc:'When extra context is needed under the title — e.g., a record ID and status.' },
          { id:'actions',  label:'With actions',         desc:'Back arrow + title + two utility icon buttons on the right.' },
          { id:'root',     label:'Root screen',          desc:'L0 tab screens. Title left-aligned, avatar right. No back button.' },
        ].map((v,i) => `
        <button data-mhv="${v.id}" data-label="${v.label}" data-desc="${v.desc.replace(/"/g,'&quot;')}"
          onclick="(function(btn){
            document.querySelectorAll('[data-mhv]').forEach(function(b){
              b.style.background='var(--background-surface)';
              b.style.color='var(--content-primary)';
              b.style.borderColor='var(--border-default)';
              b.style.fontWeight='500';
            });
            btn.style.background='#430098';
            btn.style.color='#fff';
            btn.style.borderColor='#430098';
            btn.style.fontWeight='600';
            var cache=document.getElementById('mh-v-'+btn.dataset.mhv);
            var panel=document.getElementById('mh-panel');
            var lbl=document.getElementById('mh-vlabel');
            var dsc=document.getElementById('mh-vdesc');
            if(cache&&panel){panel.innerHTML=cache.innerHTML;panel.classList.remove('mh-anim');void panel.offsetWidth;panel.classList.add('mh-anim');}
            if(lbl)lbl.textContent=btn.dataset.label;
            if(dsc)dsc.textContent=btn.dataset.desc;
          })(this)"
          style="padding:5px 14px;height:30px;border-radius:8px;border:1px solid ${i===0?'#430098':'var(--border-default)'};background:${i===0?'#430098':'var(--background-surface)'};color:${i===0?'#fff':'var(--content-primary)'};font-family:Inter,sans-serif;font-size:12px;font-weight:${i===0?'600':'500'};cursor:pointer;transition:all 0.15s;white-space:nowrap">${v.label}</button>`).join('')}
        </div>
      </div>
      <div style="padding:8px 16px 12px;display:flex;align-items:center;gap:6px;border-bottom:1px solid var(--border-subtle)">
        <span style="display:inline-flex;width:6px;height:6px;border-radius:50%;background:#430098;flex-shrink:0"></span>
        <span id="mh-vlabel" style="font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--content-primary)">Back + title</span>
        <span style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-tertiary)">—</span>
        <span id="mh-vdesc" style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-secondary)">L1 screen with back navigation. Title centred between back arrow and optional action.</span>
      </div>
      <div class="inp-demo-stage" style="padding:32px 20px;display:flex;justify-content:center;background:#E8EAED">
        <div style="width:320px;border-radius:40px;overflow:hidden;box-shadow:0 24px 56px rgba(0,0,0,0.28),0 0 0 1px rgba(0,0,0,0.1),inset 0 0 0 1px rgba(255,255,255,0.08)">
          <div style="height:32px;background:var(--background-default);display:flex;align-items:center;justify-content:space-between;padding:0 20px">
            <span style="font-size:12px;font-weight:700;color:var(--content-primary);font-family:Inter,sans-serif">9:41</span>
            <div style="display:flex;align-items:center;gap:5px;color:var(--content-primary)">
              <svg width="14" height="10" viewBox="0 0 24 18" fill="none"><rect x="0" y="6" width="4" height="12" rx="1" fill="currentColor" opacity="0.4"/><rect x="6" y="4" width="4" height="14" rx="1" fill="currentColor" opacity="0.6"/><rect x="12" y="1" width="4" height="17" rx="1" fill="currentColor" opacity="0.8"/><rect x="18" y="0" width="4" height="18" rx="1" fill="currentColor"/></svg>
              <svg width="16" height="10" viewBox="0 0 24 16" fill="none"><rect x="2" y="4" width="17" height="10" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M20 7v4a2 2 0 0 0 0-4z" fill="currentColor" opacity="0.5"/><rect x="4" y="6" width="11" height="6" rx="1" fill="currentColor"/></svg>
            </div>
          </div>
          <div id="mh-panel" class="mh-anim">
            <div style="display:flex;align-items:center;height:54px;padding:0 12px;gap:12px;background:var(--background-default);border-bottom:1px solid var(--border-subtle);width:100%;box-sizing:border-box">
              ${iconBtn(BACK)}
              <span style="flex:1;font-family:var(--font-display);font-size:16px;font-weight:700;color:var(--content-primary);text-align:center">Mes tâches</span>
              <div style="width:36px"></div>
            </div>
          </div>
          <div style="height:240px;background:var(--background-subtle);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" style="color:var(--content-tertiary)"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
            <span style="font-family:Inter,sans-serif;font-size:10px;color:var(--content-tertiary);letter-spacing:.05em;text-transform:uppercase">Screen content</span>
          </div>
          <div style="height:20px;background:var(--background-default);display:flex;align-items:center;justify-content:center">
            <div style="width:60px;height:4px;border-radius:2px;background:var(--content-primary);opacity:0.15"></div>
          </div>
        </div>
      </div>
      <div class="btn-tokens-strip">
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:var(--background-default);border:1px solid #E1E1E1"></div><div><div class="btn-token-name">surface/default</div><div class="btn-token-label">Header background</div></div></div>
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#E1E1E1"></div><div><div class="btn-token-name">border/subtle</div><div class="btn-token-label">Bottom separator</div></div></div>
      </div>
    </div>
  </div>

  <!-- ALL FOUR STATIC -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Anatomy</h2></div>
    <p class="doc-section-desc">All header variants shown inside a phone frame. Scroll the list to see them stacked as they would appear on consecutive screens.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">All variants in context</span></div>
      <div class="inp-demo-stage" style="padding:32px 20px;display:flex;justify-content:center;background:#E8EAED">
        <div style="width:320px;border-radius:40px;overflow:hidden;box-shadow:0 24px 56px rgba(0,0,0,0.28),0 0 0 1px rgba(0,0,0,0.1)">
          <div style="height:32px;background:var(--background-default);display:flex;align-items:center;justify-content:space-between;padding:0 20px;color:var(--content-primary)">
            <span style="font-size:12px;font-weight:700;font-family:Inter,sans-serif">9:41</span>
            <div style="display:flex;gap:5px;align-items:center">
              <svg width="14" height="10" viewBox="0 0 24 18" fill="none"><rect x="0" y="6" width="4" height="12" rx="1" fill="currentColor" opacity="0.4"/><rect x="6" y="4" width="4" height="14" rx="1" fill="currentColor" opacity="0.6"/><rect x="12" y="1" width="4" height="17" rx="1" fill="currentColor" opacity="0.8"/><rect x="18" y="0" width="4" height="18" rx="1" fill="currentColor"/></svg>
              <svg width="16" height="10" viewBox="0 0 24 16" fill="none"><rect x="2" y="4" width="17" height="10" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M20 7v4a2 2 0 0 0 0-4z" fill="currentColor" opacity="0.5"/><rect x="4" y="6" width="11" height="6" rx="1" fill="currentColor"/></svg>
            </div>
          </div>
          <div>
            <div style="padding:4px 14px 3px;background:var(--background-subtle);display:flex;align-items:center;gap:6px">
              <span style="font-family:Inter,sans-serif;font-size:9px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.08em">Back + title</span>
            </div>
            <div style="display:flex;align-items:center;height:54px;padding:0 12px;gap:12px;background:var(--background-default);border-bottom:1px solid var(--border-subtle);box-sizing:border-box">
              ${iconBtn(BACK)}
              <span style="flex:1;font-family:var(--font-display);font-size:16px;font-weight:700;color:var(--content-primary);text-align:center">Mes tâches</span>
              <div style="width:36px"></div>
            </div>
            <div style="padding:4px 14px 3px;background:var(--background-subtle);display:flex;align-items:center;gap:6px">
              <span style="font-family:Inter,sans-serif;font-size:9px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.08em">With subtitle</span>
            </div>
            <div style="display:flex;align-items:center;height:60px;padding:0 12px;gap:12px;background:var(--background-default);border-bottom:1px solid var(--border-subtle);box-sizing:border-box">
              ${iconBtn(BACK)}
              <div style="flex:1;text-align:center">
                <div style="font-family:var(--font-display);font-size:15px;font-weight:700;color:var(--content-primary)">CMD-2847</div>
                <div style="font-family:Inter,sans-serif;font-size:11px;color:var(--content-tertiary);margin-top:1px">Livraison express · En transit</div>
              </div>
              ${iconBtn(DOTS)}
            </div>
            <div style="padding:4px 14px 3px;background:var(--background-subtle);display:flex;align-items:center;gap:6px">
              <span style="font-family:Inter,sans-serif;font-size:9px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.08em">With actions</span>
            </div>
            <div style="display:flex;align-items:center;height:54px;padding:0 12px;gap:12px;background:var(--background-default);border-bottom:1px solid var(--border-subtle);box-sizing:border-box">
              ${iconBtn(BACK)}
              <span style="flex:1;font-family:var(--font-display);font-size:16px;font-weight:700;color:var(--content-primary)">Commandes</span>
              <div style="display:flex;gap:4px">${iconBtn(FILTER)}${iconBtn(EDIT)}</div>
            </div>
            <div style="padding:4px 14px 3px;background:var(--background-subtle);display:flex;align-items:center;gap:6px">
              <span style="font-family:Inter,sans-serif;font-size:9px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.08em">Root screen — no back</span>
            </div>
            <div style="display:flex;align-items:center;height:54px;padding:0 16px;gap:12px;background:var(--background-default);box-sizing:border-box">
              <span style="font-family:var(--font-display);font-size:18px;font-weight:800;color:var(--content-primary);flex:1">Bonjour, Nadir 👋</span>
              <div style="width:36px;height:36px;border-radius:50%;background:var(--mobile-header-avatar-bg);display:flex;align-items:center;justify-content:center;font-family:Inter,sans-serif;font-size:12px;font-weight:700;color:var(--mobile-header-avatar-text)">MN</div>
            </div>
          </div>
          <div style="height:20px;background:var(--background-default);display:flex;align-items:center;justify-content:center">
            <div style="width:60px;height:4px;border-radius:2px;background:var(--content-primary);opacity:0.15"></div>
          </div>
        </div>
      </div>
      <div class="btn-tokens-strip">
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:var(--background-default);border:1px solid #E1E1E1"></div><div><div class="btn-token-name">surface/default</div><div class="btn-token-label">Header background</div></div></div>
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#E1E1E1"></div><div><div class="btn-token-name">border/subtle</div><div class="btn-token-label">Bottom separator</div></div></div>
      </div>
    </div>
  </div>

  <!-- TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <div class="card" style="overflow:hidden">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Value</th><th>Usage</th></tr></thead>
        <tbody>
          ${[
            ['component/header/height','54px','Default height'],
            ['component/header/height-subtitle','60px','With subtitle'],
            ['component/header/background','surface/default','Fill'],
            ['component/header/border','border/subtle','Bottom separator'],
            ['component/header/title-size','16px Bold 700','Title'],
            ['component/header/subtitle-size','11px Regular 400','Subtitle'],
            ['component/header/icon-btn','36×36px, radius 50%','Back / action buttons'],
            ['component/header/h-padding','12px','Side padding (root: 16px)'],
          ].map(([t,v,u],i)=>`<tr style="${i%2===0?'background:var(--background-subtle);':''}border-bottom:1px solid var(--border-subtle)">
            <td style="padding:10px 16px"><code class="tok-name">${t}</code></td>
            <td style="padding:10px 16px;font-family:var(--font-mono);font-size:11px;color:var(--brand-primary)">${v}</td>
            <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${u}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Centre the title between the back button and any right-side action. Add an invisible 36px placeholder when there's no right action so the title stays centred.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't put more than 2 action icons on the right side. Use a "···" overflow menu for 3+ actions.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Left-align the title on root screens. Centre-align only on L1+ screens where the back button is present.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't let long titles overflow — truncate with ellipsis at 1 line maximum.</div></div>
    </div>
  </div>

  </div>`;
}
