import { pageHeader } from '../utils/render.js';

const ARROW_UP   = `<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>`;
const ARROW_MID  = `<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>`;
const ARROW_DOWN = `<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>`;
const CLOCK = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`;
const CHV_D = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="6 9 12 15 18 9"/></svg>`;
const CHV_U = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="18 15 12 9 6 15"/></svg>`;

const PRIORITY_CFG = {
  high:   { label:'High',   icon:ARROW_UP,   bg:'var(--priority-high-bg)',   text:'var(--priority-high-text)',   border:'var(--priority-high-border)' },
  medium: { label:'Medium', icon:ARROW_MID,  bg:'var(--priority-medium-bg)', text:'var(--priority-medium-text)', border:'var(--priority-medium-border)' },
  low:    { label:'Low',    icon:ARROW_DOWN, bg:'var(--priority-low-bg)',    text:'var(--priority-low-text)',    border:'var(--priority-low-border)' },
  none:   { label:'None',   icon:'',         bg:'var(--priority-none-bg)',   text:'var(--priority-none-text)',   border:'var(--priority-none-border)' },
};

const STATUS_CFG = {
  todo:       { label:'To do',       bg:'var(--task-status-todo-bg)',        text:'var(--task-status-todo-text)',        border:'var(--task-status-todo-border)' },
  inprogress: { label:'In progress', bg:'var(--task-status-inprogress-bg)',  text:'var(--task-status-inprogress-text)',  border:'var(--task-status-inprogress-border)' },
  done:       { label:'Done',        bg:'var(--task-status-done-bg)',        text:'var(--task-status-done-text)',        border:'var(--task-status-done-border)' },
  blocked:    { label:'Blocked',     bg:'var(--task-status-blocked-bg)',     text:'var(--task-status-blocked-text)',     border:'var(--task-status-blocked-border)' },
};

function av(init, color, size=24) {
  return `<span style="display:inline-flex;align-items:center;justify-content:center;width:${size}px;height:${size}px;border-radius:50%;background:${color};color:#fff;font-family:Inter,sans-serif;font-size:${size<=24?9:11}px;font-weight:700;border:2px solid var(--background-default)">${init}</span>`;
}

function pBadge(p) {
  const t = PRIORITY_CFG[p] || PRIORITY_CFG.medium;
  return `<span style="display:inline-flex;align-items:center;gap:4px;padding:0 6px;height:20px;border-radius:5px;font-size:11px;font-weight:600;font-family:Inter,sans-serif;background:${t.bg};color:${t.text};border:1px solid ${t.border}">${t.icon}${t.label}</span>`;
}

function sBadge(s) {
  const t = STATUS_CFG[s] || STATUS_CFG.todo;
  return `<span style="display:inline-flex;align-items:center;padding:0 7px;height:20px;border-radius:9999px;font-size:10px;font-weight:600;font-family:Inter,sans-serif;background:${t.bg};color:${t.text};border:1px solid ${t.border}">${t.label}</span>`;
}

function swatch(c, n, l) {
  const light = ['#FFFFFF','#F6F6F6','#FFF2F4','#FFF8EC','#EFF6FF','#F0FDF4'].includes(c);
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${c};${light?'border:1px solid #E1E1E1':''}"></div><div><div class="btn-token-name">${n}</div><div class="btn-token-label">${l}</div></div></div>`;
}

export default function taskCard() {
  return pageHeader('Components', 'Task Card', 'Core mobile card for task tracking. Expandable subtasks, priority badge, status, assignee stack, and due date.', [
    { val: '4', label: 'Priority levels' },
    { val: '4', label: 'Status states' },
  ]) + `<div class="page-body">

  <style>
    @keyframes subtask-row-in { from { opacity:0; transform:translateY(-4px); } to { opacity:1; transform:translateY(0); } }
    @keyframes card-pop { 0%,100% { transform:scale(1); } 50% { transform:scale(1.015); } }
    @keyframes priority-swap { from { opacity:0; transform:scale(0.7); } to { opacity:1; transform:scale(1); } }
    .subtask-row-animated { animation: subtask-row-in 0.18s ease both; }
    .priority-badge-swap { animation: priority-swap 0.2s cubic-bezier(0.175,0.885,0.32,1.275); }
  </style>

  <!-- LIVE INTERACTIVE CARD -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Live — fully interactive</h2></div>
    <p class="doc-section-desc">Click the arrow to expand subtasks. Check off tasks to mark them done. Change priority and status with the controls above. Each interaction updates the card in real time.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">Task Card — interactive</span>
        <div class="inp-demo-controls">
          <span class="inp-demo-meta">Priority</span>
          <select class="inp-state-select" onchange="(function(v){
            var badge = document.getElementById('tc-priority-badge');
            if(!badge) return;
            var cfg = {high:{label:'High',icon:'▲',bg:'var(--priority-high-bg)',text:'var(--priority-high-text)',border:'var(--priority-high-border)'},medium:{label:'Medium',icon:'—',bg:'var(--priority-medium-bg)',text:'var(--priority-medium-text)',border:'var(--priority-medium-border)'},low:{label:'Low',icon:'▼',bg:'var(--priority-low-bg)',text:'var(--priority-low-text)',border:'var(--priority-low-border)'},none:{label:'None',icon:'',bg:'var(--priority-none-bg)',text:'var(--priority-none-text)',border:'var(--priority-none-border)'}};
            var t = cfg[v] || cfg.medium;
            badge.style.background = t.bg; badge.style.color = t.text; badge.style.borderColor = t.border;
            badge.classList.remove('priority-badge-swap'); void badge.offsetWidth; badge.classList.add('priority-badge-swap');
            badge.querySelector('.tc-p-label').textContent = t.label;
          })(this.value)">
            <option value="high">High</option>
            <option value="medium" selected>Medium</option>
            <option value="low">Low</option>
            <option value="none">None</option>
          </select>
          <span class="inp-demo-meta" style="margin-left:8px">Status</span>
          <select class="inp-state-select" onchange="(function(v){
            var badge = document.getElementById('tc-status-badge');
            if(!badge) return;
            var cfg = {todo:{label:'To do',bg:'var(--task-status-todo-bg)',text:'var(--task-status-todo-text)',border:'var(--task-status-todo-border)'},inprogress:{label:'In progress',bg:'var(--task-status-inprogress-bg)',text:'var(--task-status-inprogress-text)',border:'var(--task-status-inprogress-border)'},done:{label:'Done',bg:'var(--task-status-done-bg)',text:'var(--task-status-done-text)',border:'var(--task-status-done-border)'},blocked:{label:'Blocked',bg:'var(--task-status-blocked-bg)',text:'var(--task-status-blocked-text)',border:'var(--task-status-blocked-border)'}};
            var t = cfg[v] || cfg.todo;
            badge.style.background=t.bg; badge.style.color=t.text; badge.style.borderColor=t.border; badge.textContent=t.label;
          })(this.value)">
            <option value="todo">To do</option>
            <option value="inprogress">In progress</option>
            <option value="done">Done</option>
            <option value="blocked">Blocked</option>
          </select>
        </div>
      </div>
      <div class="inp-demo-stage" style="display:flex;justify-content:center;padding:24px;background:var(--background-subtle)">
        <div id="tc-card" style="background:var(--background-default);border:1px solid var(--border-subtle);border-radius:12px;padding:12px 14px;width:300px;box-shadow:0 2px 8px rgba(0,0,0,0.06)">
          <div style="display:flex;align-items:flex-start;gap:8px;margin-bottom:8px">
            <div style="flex:1;min-width:0">
              <div style="font-family:Inter,sans-serif;font-size:13px;font-weight:600;color:var(--content-primary);line-height:1.4;margin-bottom:6px">Préparer commande CMD-2847</div>
              <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
                <span id="tc-priority-badge" style="display:inline-flex;align-items:center;gap:4px;padding:0 6px;height:20px;border-radius:5px;font-size:11px;font-weight:600;font-family:Inter,sans-serif;background:var(--priority-medium-bg);color:var(--priority-medium-text);border:1px solid var(--priority-medium-border);transition:background 0.2s,color 0.2s,border-color 0.2s">
                  <span class="tc-p-label">Medium</span>
                </span>
                <span id="tc-status-badge" style="display:inline-flex;align-items:center;padding:0 7px;height:20px;border-radius:9999px;font-size:10px;font-weight:600;font-family:Inter,sans-serif;background:var(--task-status-inprogress-bg);color:var(--task-status-inprogress-text);border:1px solid var(--task-status-inprogress-border);transition:background 0.2s,color 0.2s,border-color 0.2s">In progress</span>
              </div>
            </div>
            <button id="tc-expand-btn" onclick="(function(btn){
              var body = document.getElementById('tc-subtask-body');
              if(!body) return;
              var open = btn.dataset.open === 'true';
              btn.dataset.open = open ? 'false' : 'true';
              btn.style.transform = open ? 'rotate(0deg)' : 'rotate(180deg)';
              body.style.maxHeight = open ? '0' : '500px';
              body.style.opacity = open ? '0' : '1';
            })(this)" data-open="false" style="flex-shrink:0;width:28px;height:28px;display:flex;align-items:center;justify-content:center;background:var(--background-subtle);border:1px solid var(--border-subtle);border-radius:7px;cursor:pointer;color:var(--content-secondary);transition:background 0.15s,transform 0.22s cubic-bezier(0.4,0,0.2,1)">${CHV_D}</button>
          </div>

          <!-- meta row -->
          <div style="display:flex;align-items:center;justify-content:space-between">
            <div style="display:flex;align-items:center;gap:4px;font-family:Inter,sans-serif;font-size:10px;color:var(--content-tertiary)">
              ${CLOCK} Aujourd'hui 14:30
            </div>
            <div style="display:flex;align-items:center">
              ${[['MN','var(--avatar-color-brand)'],['AK','var(--avatar-color-blue)'],['RB','var(--avatar-color-green)']].map(([i,c],idx)=>`<span style="margin-left:${idx>0?-6:0}px">${av(i,c)}</span>`).join('')}
            </div>
          </div>

          <!-- subtasks (expandable) -->
          <div id="tc-subtask-body" style="max-height:0;overflow:hidden;opacity:0;transition:max-height 0.28s cubic-bezier(0.4,0,0.2,1),opacity 0.2s ease">
            <div style="border-top:1px solid var(--border-subtle);margin-top:10px;padding-top:10px;display:flex;flex-direction:column;gap:6px">
              <div id="tc-progress-label" style="font-family:Inter,sans-serif;font-size:10px;font-weight:600;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.05em;margin-bottom:2px">Subtasks (0/3)</div>
              ${[
                { id:'st0', label:'Vérifier stock palette A-12' },
                { id:'st1', label:'Imprimer bon de livraison' },
                { id:'st2', label:'Valider auprès du chef de dépôt' },
              ].map((s,i)=>`
              <div class="subtask-row-animated" style="display:flex;align-items:center;gap:8px;animation-delay:${i*0.04}s">
                <button id="${s.id}" data-done="false" onclick="(function(btn){
                  var done = btn.dataset.done !== 'true';
                  btn.dataset.done = done ? 'true' : 'false';
                  btn.style.background = done ? 'var(--fab-bg)' : 'transparent';
                  btn.style.borderColor = done ? 'var(--fab-bg)' : 'var(--border-default)';
                  btn.innerHTML = done ? '<svg width=\\'9\\' height=\\'9\\' viewBox=\\'0 0 24 24\\' fill=\\'none\\' stroke=\\'#fff\\' stroke-width=\\'3\\' stroke-linecap=\\'round\\'><polyline points=\\'20 6 9 17 4 12\\'/></svg>' : '';
                  var row = btn.parentElement;
                  var lbl = row.querySelector('.st-lbl');
                  if(lbl){ lbl.style.textDecoration = done ? 'line-through' : 'none'; lbl.style.color = done ? 'var(--content-tertiary)' : 'var(--content-primary)'; }
                  var doneCount = document.querySelectorAll('[id^=\\'st\\'][data-done=\\'true\\']').length;
                  var pl = document.getElementById('tc-progress-label');
                  if(pl) pl.textContent = 'Subtasks ('+doneCount+'/3)';
                })(this)" style="width:14px;height:14px;border-radius:3px;border:1.5px solid var(--border-default);background:transparent;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;cursor:pointer;transition:background 0.15s,border-color 0.15s;padding:0"></button>
                <span class="st-lbl" style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-primary);transition:color 0.2s,text-decoration 0.2s">${s.label}</span>
              </div>`).join('')}
            </div>
          </div>
        </div>
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#FFF8EC','priority/medium-bg','Medium priority bg')}
        ${swatch('#FFF2F4','priority/high-bg','High priority bg')}
        ${swatch('#F0FDF4','priority/low-bg','Low priority bg')}
        ${swatch('#430098','brand/primary','Done checkbox')}
      </div>
    </div>
  </div>

  <!-- PRIORITY LEVELS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Priority levels</h2></div>
    <p class="doc-section-desc">Four levels: High, Medium, Low, None. Each has a distinct icon + background + text + border combination. Priority is always shown as the first badge on the card.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">All four levels — side by side</span></div>
      <div class="inp-demo-stage" style="display:flex;justify-content:center;align-items:center;flex-wrap:wrap;gap:16px;padding:24px">
        ${Object.entries(PRIORITY_CFG).map(([k,t]) => `
        <div style="background:var(--background-default);border:1px solid var(--border-subtle);border-radius:12px;padding:10px 14px;width:200px">
          <div style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-tertiary);margin-bottom:6px">Task title here</div>
          ${pBadge(k)}
        </div>`).join('')}
      </div>
    </div>
  </div>

  <!-- STATUS FLOW -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Status states</h2></div>
    <p class="doc-section-desc">Status badge cycles through four states in a workflow order. The badge is a pill (9999px radius) while the priority badge is a rectangle (5px radius) — they are always visually distinct.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Status flow: To do → In progress → Done · or → Blocked</span></div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:8px;padding:20px">
        ${Object.entries(STATUS_CFG).map(([k,t]) => sBadge(k)).join(
          `<span style="font-family:Inter,sans-serif;font-size:16px;color:var(--content-tertiary)">→</span>`
        )}
      </div>
    </div>
  </div>

  <!-- TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <div class="card" style="overflow:hidden">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Value</th><th>Usage</th></tr></thead>
        <tbody>
          ${[
            ['component/task-card/radius','12px','Card corner radius'],
            ['component/task-card/padding','12px 14px','Internal padding'],
            ['component/task-card/title-size','13px, SemiBold 600','Task title'],
            ['component/task-card/priority-radius','5px','Priority badge radius'],
            ['component/task-card/status-radius','9999px','Status pill radius'],
            ['component/task-card/subtask-checkbox','14px','Subtask checkbox size'],
            ['component/task-card/expand-btn','28×28px','Expand chevron button'],
            ['component/task-card/expand-duration','280ms','Subtask reveal animation'],
          ].map(([t,v,u],i)=>`<tr style="${i%2===0?'background:var(--background-subtle);':''}border-bottom:1px solid var(--border-subtle)">
            <td style="padding:10px 16px"><code class="tok-name">${t}</code></td>
            <td style="padding:10px 16px;font-family:var(--font-mono);font-size:11px;color:var(--brand-primary)">${v}</td>
            <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${u}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Always show priority + status together on the card. Users judge urgency from both signals simultaneously — removing one creates ambiguity.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't show more than 4 subtasks without a "see all" link. Expanding 10 subtasks collapses the task list view.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use the assignee avatar stack to show ownership at a glance. Max 3 avatars + "+N" overflow.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't change the priority badge shape to a pill — it must be visually distinct from the status badge (rectangle vs pill).</div></div>
    </div>
  </div>

  </div>`;
}
