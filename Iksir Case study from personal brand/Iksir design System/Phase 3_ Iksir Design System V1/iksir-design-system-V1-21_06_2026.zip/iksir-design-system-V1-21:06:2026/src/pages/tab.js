import { pageHeader } from '../utils/render.js';
import { SIZING } from '../data/sizing.js';

const GRID = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>`;
const LIST = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>`;
const STAR = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`;

function badge(count, isActive) {
  const bg  = isActive ? 'var(--tab-badge-bg-active)'   : 'var(--tab-badge-bg-default)';
  const tc  = isActive ? 'var(--tab-badge-text-active)'  : 'var(--tab-badge-text-default)';
  return `<span data-tab-badge style="display:inline-flex;align-items:center;padding:0 5px;height:18px;border-radius:9999px;font-size:11px;font-weight:600;font-family:Inter,sans-serif;background:${bg};color:${tc};line-height:1;transition:background .12s,color .12s">${count}</span>`;
}

// Underline / Line tab item
function ulItem(cid, label, idx, active, { icon, bdg, disabled } = {}) {
  const tc = disabled ? 'var(--tab-underline-item-text-disabled)'
           : active   ? 'var(--tab-underline-item-text-active)'
           :             'var(--tab-underline-item-text-default)';
  const bc = active && !disabled ? 'var(--tab-underline-indicator-active)' : 'transparent';
  const cur = disabled ? 'not-allowed' : 'pointer';
  const state = disabled ? 'disabled' : active ? 'active' : 'default';
  const ico = icon ? `<span style="display:inline-flex;align-items:center;color:inherit">${icon}</span>` : '';
  const badgeHtml = bdg !== undefined ? badge(bdg, active) : '';
  const dis = disabled ? ' data-disabled="true"' : '';
  const hov = !disabled ? ` onmouseenter="tabHover(this,true)" onmouseleave="tabHover(this,false)"` : '';
  const clk = !disabled ? ` onclick="tabSet('${cid}',${idx})"` : '';
  return `<button data-tab data-state="${state}"${dis}
    style="display:inline-flex;align-items:center;gap:6px;height:32px;padding:0 12px;border-radius:6px 6px 0 0;font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:${tc};background:var(--tab-underline-item-bg-default);border:none;border-bottom:2px solid ${bc};margin-bottom:-1px;cursor:${cur};user-select:none;transition:color .12s,background .12s,border-color .12s"${hov}${clk}>${ico}${label}${badgeHtml}</button>`;
}

// Line tab item (same structure, different hover tokens)
function lineItem(cid, label, idx, active, { icon, disabled } = {}) {
  const tc = disabled ? 'var(--tab-line-item-text-disabled)'
           : active   ? 'var(--tab-line-item-text-active)'
           :             'var(--tab-line-item-text-default)';
  const bc = active && !disabled ? 'var(--tab-line-indicator-active)' : 'transparent';
  const cur = disabled ? 'not-allowed' : 'pointer';
  const state = disabled ? 'disabled' : active ? 'active' : 'default';
  const ico = icon ? `<span style="display:inline-flex;align-items:center;color:inherit">${icon}</span>` : '';
  const dis = disabled ? ' data-disabled="true"' : '';
  const hov = !disabled ? ` onmouseenter="tabHover(this,true)" onmouseleave="tabHover(this,false)"` : '';
  const clk = !disabled ? ` onclick="tabSet('${cid}',${idx})"` : '';
  return `<button data-tab data-state="${state}"${dis}
    style="display:inline-flex;align-items:center;gap:6px;height:32px;padding:0 12px;border-radius:6px 6px 0 0;font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:${tc};background:var(--tab-line-item-bg-default);border:none;border-bottom:2px solid ${bc};margin-bottom:-1px;cursor:${cur};user-select:none;transition:color .12s,background .12s,border-color .12s"${hov}${clk}>${ico}${label}</button>`;
}

// Button-style tab item (border / gray / brand)
function btnItem(cid, label, idx, active, variant, { disabled } = {}) {
  const v = `tab-button-${variant}`;
  const tc = disabled ? `var(--${v}-item-text-disabled)`
           : active   ? `var(--${v}-item-text-active)`
           :             `var(--${v}-item-text-default)`;
  const bg = disabled ? `var(--${v}-item-bg-disabled)`
           : active   ? `var(--${v}-item-bg-active)`
           :             `var(--${v}-item-bg-default)`;
  const cur = disabled ? 'not-allowed' : 'pointer';
  const state = disabled ? 'disabled' : active ? 'active' : 'default';
  const dis = disabled ? ' data-disabled="true"' : '';
  const hov = !disabled ? ` onmouseenter="tabHover(this,true)" onmouseleave="tabHover(this,false)"` : '';
  const clk = !disabled ? ` onclick="tabSet('${cid}',${idx})"` : '';
  return `<button data-tab data-state="${state}"${dis}
    style="display:inline-flex;align-items:center;gap:6px;height:32px;padding:0 12px;border-radius:6px;font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:${tc};background:${bg};border:none;cursor:${cur};user-select:none;transition:color .12s,background .12s"${hov}${clk}>${label}</button>`;
}

function swatch(hex, name, label, bordered) {
  const border = bordered ? 'border:1px solid #E1E1E1;' : '';
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${hex};${border}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${label}</div></div></div>`;
}

function tRow(t, i) {
  const bg = i % 2 === 0 ? 'background:var(--background-subtle);' : '';
  const vc = t.val >= 9999 ? '9999px' : t.val + 'px';
  return `<tr style="${bg}border-bottom:1px solid var(--border-subtle)">
    <td style="padding:10px 16px"><code class="tok-name">${t.token}</code></td>
    <td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'${vc}')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">${t.ref}<span class="tok-alias-copied">${vc}</span></span></td>
    <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${t.use}</td>
  </tr>`;
}

export default function tab() {
  return pageHeader('Components', 'Tab', 'Switch between views or filter content within a page. Five style variants — underline, line, and three button modes. Tabs never navigate to a new URL.', [
    { val: '5',  label: 'Variants' },
    { val: String(SIZING.tab.length), label: 'Size tokens' },
    { val: '82', label: 'Color tokens' },
  ]) + `<div class="page-body">

  <!-- VARIANTS -->
  <div class="doc-section">
    <h2 class="doc-section-title">Variants</h2>
    <p class="doc-section-desc">Eight tab configurations spanning all five visual styles plus icon, badge, and disabled states. Every demo is interactive — click any tab to switch the active state.</p>

    <!-- UNDERLINE -->
    <div class="doc-variant-block">
      <h3 class="doc-variant-title">Underline</h3>
      <p class="doc-section-desc">The default tab style. A 2px brand-colored underline marks the active tab; the full-width grey line provides a visual baseline for the whole strip. Use for primary in-page navigation.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar"><span class="inp-demo-title">Underline — click to switch</span></div>
        <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:80px">
          <div id="tabs-ul" data-variant="underline" style="display:flex;gap:4px;border-bottom:1px solid var(--tab-underline-container-border)">
            ${ulItem('tabs-ul','Overview',0,true)}
            ${ulItem('tabs-ul','Analytics',1,false)}
            ${ulItem('tabs-ul','Settings',2,false)}
          </div>
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#8C8C8C','tab/underline/item/text/default','Default text')}
          ${swatch('#8E66C1','tab/underline/item/text/hover','Hover text')}
          ${swatch('#430098','tab/underline/item/text/active','Active text')}
          ${swatch('#430098','tab/underline/indicator/active','Active indicator')}
          ${swatch('#F6F6F6','tab/underline/container/border','Container border',true)}
        </div>
      </div>
    </div>

    <!-- LINE -->
    <div class="doc-variant-block">
      <h3 class="doc-variant-title">Line</h3>
      <p class="doc-section-desc">Same underline structure but with a neutral hover color (grey-80) instead of purple. Use when the purple hover is too prominent for the surrounding context.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar"><span class="inp-demo-title">Line — click to switch</span></div>
        <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:80px">
          <div id="tabs-line" data-variant="line" style="display:flex;gap:4px;border-bottom:1px solid var(--tab-line-container-border)">
            ${lineItem('tabs-line','Overview',0,true)}
            ${lineItem('tabs-line','Analytics',1,false)}
            ${lineItem('tabs-line','Settings',2,false)}
          </div>
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#8C8C8C','tab/line/item/text/default','Default text')}
          ${swatch('#474747','tab/line/item/text/hover','Hover text')}
          ${swatch('#430098','tab/line/item/text/active','Active text')}
          ${swatch('#8E66C1','tab/line/indicator/hover','Hover indicator')}
          ${swatch('#430098','tab/line/indicator/active','Active indicator')}
        </div>
      </div>
    </div>

    <!-- BUTTON: BORDER -->
    <div class="doc-variant-block">
      <h3 class="doc-variant-title">Button: Border</h3>
      <p class="doc-section-desc">Segmented control with a visible border. The active item lifts to a white surface background. Use inside cards, panels, or wherever the underline line feels too light.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar"><span class="inp-demo-title">Button border — click to switch</span></div>
        <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:80px">
          <div id="tabs-bb" data-variant="border" style="display:inline-flex;align-items:center;gap:4px;padding:4px;background:var(--tab-button-border-container-bg);border:1px solid var(--tab-button-border-container-border);border-radius:8px">
            ${btnItem('tabs-bb','Overview',0,true,'border')}
            ${btnItem('tabs-bb','Analytics',1,false,'border')}
            ${btnItem('tabs-bb','Settings',2,false,'border')}
          </div>
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#F6F6F6','tab/button-border/container/bg','Container bg',true)}
          ${swatch('#E6E6E6','tab/button-border/container/border','Container border')}
          ${swatch('#FFFFFF','tab/button-border/item/bg/active','Active item bg',true)}
          ${swatch('#8C8C8C','tab/button-border/item/text/default','Default text')}
          ${swatch('#191919','tab/button-border/item/text/active','Active text')}
        </div>
      </div>
    </div>

    <!-- BUTTON: GRAY -->
    <div class="doc-variant-block">
      <h3 class="doc-variant-title">Button: Gray</h3>
      <p class="doc-section-desc">Ghost segmented control — no container border, no item border. The active item gets a grey fill. Use on white backgrounds where subtle state differentiation is preferred.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar"><span class="inp-demo-title">Button gray — click to switch</span></div>
        <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:80px">
          <div id="tabs-bg" data-variant="gray" style="display:inline-flex;align-items:center;gap:4px;padding:4px;background:var(--tab-button-gray-container-bg);border-radius:8px">
            ${btnItem('tabs-bg','Overview',0,true,'gray')}
            ${btnItem('tabs-bg','Analytics',1,false,'gray')}
            ${btnItem('tabs-bg','Settings',2,false,'gray')}
          </div>
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#FFFFFF','tab/button-gray/container/bg','Container bg',true)}
          ${swatch('#F6F6F6','tab/button-gray/item/bg/active','Active item bg',true)}
          ${swatch('#8C8C8C','tab/button-gray/item/text/default','Default text')}
          ${swatch('#191919','tab/button-gray/item/text/active','Active text')}
        </div>
      </div>
    </div>

    <!-- BUTTON: BRAND -->
    <div class="doc-variant-block">
      <h3 class="doc-variant-title">Button: Brand</h3>
      <p class="doc-section-desc">Brand-tinted container. The active item gets a brand-subtle background with brand text. Use when you want the tab strip to feel part of the brand's visual identity.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar"><span class="inp-demo-title">Button brand — click to switch</span></div>
        <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:80px">
          <div id="tabs-br" data-variant="brand" style="display:inline-flex;align-items:center;gap:4px;padding:4px;background:var(--tab-button-brand-container-bg);border-radius:8px">
            ${btnItem('tabs-br','Overview',0,true,'brand')}
            ${btnItem('tabs-br','Analytics',1,false,'brand')}
            ${btnItem('tabs-br','Settings',2,false,'brand')}
          </div>
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#FDFDFD','tab/button-brand/container/bg','Container bg',true)}
          ${swatch('#F7F4FB','tab/button-brand/item/bg/active','Active item bg',true)}
          ${swatch('#8C8C8C','tab/button-brand/item/text/default','Default text')}
          ${swatch('#430098','tab/button-brand/item/text/active','Active text')}
        </div>
      </div>
    </div>

    <!-- WITH ICON -->
    <div class="doc-variant-block">
      <h3 class="doc-variant-title">With icon</h3>
      <p class="doc-section-desc">A 16px leading icon (icon-size/sm) with a 6px gap to the label. The icon inherits <code>currentColor</code>, so it transitions through all states automatically. Icons work on all five variants.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar"><span class="inp-demo-title">Underline with icon — click to switch</span></div>
        <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:80px">
          <div id="tabs-icon" data-variant="underline" style="display:flex;gap:4px;border-bottom:1px solid var(--tab-underline-container-border)">
            ${ulItem('tabs-icon','Grid view',0,true,{icon:GRID})}
            ${ulItem('tabs-icon','List view',1,false,{icon:LIST})}
            ${ulItem('tabs-icon','Favourites',2,false,{icon:STAR})}
          </div>
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#A3A3A3','tab/underline/item/icon/default','Icon — default')}
          ${swatch('#8E66C1','tab/underline/item/icon/hover','Icon — hover')}
          ${swatch('#430098','tab/underline/item/icon/active','Icon — active')}
        </div>
      </div>
    </div>

    <!-- WITH BADGE -->
    <div class="doc-variant-block">
      <h3 class="doc-variant-title">With badge</h3>
      <p class="doc-section-desc">Count badges sit 6px (badge-gap token) to the right of the label. The badge background and text shift to brand colors when the tab is active. Use to surface unread counts or item totals.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar"><span class="inp-demo-title">Underline with badge — click to switch</span></div>
        <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:80px">
          <div id="tabs-bdg" data-variant="underline" style="display:flex;gap:4px;border-bottom:1px solid var(--tab-underline-container-border)">
            ${ulItem('tabs-bdg','Inbox',0,true,{bdg:4})}
            ${ulItem('tabs-bdg','Sent',1,false,{bdg:12})}
            ${ulItem('tabs-bdg','Archived',2,false,{bdg:0})}
          </div>
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#FAFAFA','tab/badge/bg/default','Badge bg — default',true)}
          ${swatch('#F6F6F6','tab/badge/bg/hover','Badge bg — hover',true)}
          ${swatch('#ECE6F5','tab/badge/bg/active','Badge bg — active')}
          ${swatch('#8C8C8C','tab/badge/text/default','Badge text — default')}
          ${swatch('#430098','tab/badge/text/active','Badge text — active')}
        </div>
      </div>
    </div>

    <!-- DISABLED -->
    <div class="doc-variant-block">
      <h3 class="doc-variant-title">Disabled items</h3>
      <p class="doc-section-desc">Individual tabs can be disabled — not the whole strip. Disabled items use the global disabled text token and show a <code>not-allowed</code> cursor. They cannot receive focus or click events.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar"><span class="inp-demo-title">Tab 3 disabled — hover or click it</span></div>
        <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:80px">
          <div id="tabs-dis" data-variant="underline" style="display:flex;gap:4px;border-bottom:1px solid var(--tab-underline-container-border)">
            ${ulItem('tabs-dis','Overview',0,true)}
            ${ulItem('tabs-dis','Analytics',1,false)}
            ${ulItem('tabs-dis','Billing',2,false,{disabled:true})}
          </div>
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#E6E6E6','tab/underline/item/text/disabled','Disabled text')}
          ${swatch('#E6E6E6','tab/underline/item/icon/disabled','Disabled icon')}
        </div>
      </div>
    </div>
  </div>

  <!-- COMPONENT TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <p class="doc-section-desc">All sizing values bound to the <code>Components</code> collection. Hover to preview the value, click to copy.</p>
    <div class="card" style="overflow:hidden;margin-bottom:16px">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Aliases → (hover for value, click to copy)</th><th>Usage</th></tr></thead>
        <tbody>${SIZING.tab.map(tRow).join('')}</tbody>
      </table>
    </div>
  </div>

  <!-- PROPS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
    <table class="prop-table">
      <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
      <tbody>
        <tr><td><span class="prop-name">variant</span></td><td><span class="prop-type">"underline"|"line"|"button-border"|"button-gray"|"button-brand"</span></td><td><span class="prop-default">"underline"</span></td><td>Visual style of the tab strip.</td></tr>
        <tr><td><span class="prop-name">tabs</span></td><td><span class="prop-type">TabItem[]</span></td><td><span class="prop-default">—</span></td><td>Array of <code>{ label, value, icon?, badge?, disabled? }</code> objects.</td></tr>
        <tr><td><span class="prop-name">value</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Controlled active tab value.</td></tr>
        <tr><td><span class="prop-name">defaultValue</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Uncontrolled initial active tab value.</td></tr>
        <tr><td><span class="prop-name">onChange</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Called with the <code>value</code> of the newly active tab.</td></tr>
        <tr><td><span class="prop-name">fullWidth</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Stretches all tabs equally to fill the container width.</td></tr>
        <tr><td><span class="prop-name">aria-label</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Accessible label for the tab list element. Required when there is no visible heading above the tabs.</td></tr>
      </tbody>
    </table>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use tabs to switch between views of the same data or related content within a single page context. The content area updates; the URL may or may not change.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use tabs for primary site navigation between unrelated pages. Use a sidebar, nav bar, or breadcrumb instead — tabs imply shared context.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Keep tab labels short — 1 to 3 words. If a label needs more than 3 words, the content it describes is probably too varied to belong in a single tab group.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use more than 6 tabs in a single strip. Beyond that, switch to a Select or navigation pattern — a tab bar that wraps is a layout problem.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Pick one variant per context and apply it consistently. Mix only when two separate tab groups on the same page serve genuinely different purposes.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use tabs to step through a wizard or form. Steps have a defined order and a submit action — use a Stepper component instead.</div></div>
    </div>
  </div>

  </div>`;
}
