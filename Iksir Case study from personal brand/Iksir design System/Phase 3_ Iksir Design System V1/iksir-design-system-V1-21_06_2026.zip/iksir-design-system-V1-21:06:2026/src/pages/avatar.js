import { pageHeader } from '../utils/render.js';

const COLORS = ['var(--avatar-color-brand)','var(--avatar-color-blue)','var(--avatar-color-green)','var(--avatar-color-amber)','var(--avatar-color-danger)','var(--avatar-color-neutral)'];
const NAMES  = [
  { init:'MN', color:'var(--avatar-color-brand)',   name:'Mohammed Nadir' },
  { init:'AK', color:'var(--avatar-color-blue)',    name:'Amira Kader' },
  { init:'RB', color:'var(--avatar-color-green)',   name:'Rafik Bouali' },
  { init:'SL', color:'var(--avatar-color-amber)',   name:'Sara Laïb' },
  { init:'TC', color:'var(--avatar-color-danger)',  name:'Tarek Cherif' },
  { init:'DF', color:'var(--avatar-color-neutral)', name:'Dalia Ferhat' },
];

function av(init, color, size = 32, status = null, id = '') {
  const fs = size <= 24 ? 9 : size <= 32 ? 11 : size <= 40 ? 13 : 16;
  const dotSz = Math.round(size * 0.3);
  const dotColor = status === 'online' ? 'var(--avatar-status-online)' : status === 'away' ? 'var(--avatar-status-away)' : 'var(--avatar-status-offline)';
  const idAttr = id ? ` id="${id}"` : '';
  return `<span${idAttr} style="position:relative;display:inline-flex;align-items:center;justify-content:center;width:${size}px;height:${size}px;border-radius:50%;background:${color};color:var(--avatar-on-color);font-family:Inter,sans-serif;font-size:${fs}px;font-weight:700;flex-shrink:0;user-select:none">
    ${init}
    ${status ? `<span style="position:absolute;bottom:0;right:0;width:${dotSz}px;height:${dotSz}px;border-radius:50%;background:${dotColor};border:2px solid var(--background-default)"></span>` : ''}
  </span>`;
}

function swatch(color, name, lbl) {
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${color}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${lbl}</div></div></div>`;
}

export default function avatarComp() {
  return pageHeader('Components', 'Avatar', 'User representation component. Five sizes, status dot, group stack with +N overflow, and deterministic colour assignment from user ID.', [
    { val: '5', label: 'Sizes' },
    { val: '6', label: 'Color slots' },
  ]) + `<div class="page-body">

  <style>
    @keyframes av-pop-in { from { opacity:0; transform:scale(0.4); } to { opacity:1; transform:scale(1); } }
    @keyframes av-pop-out { from { opacity:1; transform:scale(1); } to { opacity:0; transform:scale(0.4); } }
    .av-popin  { animation: av-pop-in  0.22s cubic-bezier(0.175,0.885,0.32,1.275); }
    .av-popout { animation: av-pop-out 0.15s ease forwards; }
    @keyframes status-ping { 0%,100% { transform:scale(1); } 50% { transform:scale(1.5); opacity:0.5; } }
    @keyframes av-slot-glow { from { box-shadow:0 0 0 0 rgba(67,0,152,0.4); } to { box-shadow:0 0 0 8px rgba(67,0,152,0); } }
  </style>

  <!-- SIZES -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Sizes</h2></div>
    <p class="doc-section-desc">Five sizes from XS (20px) to XL (56px). Use XS and SM in dense table rows. MD is the default for cards and comments. LG and XL for profile headers only.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">All five sizes</span></div>
      <div class="inp-demo-stage" style="display:flex;align-items:flex-end;justify-content:center;gap:20px;padding:24px;flex-wrap:wrap">
        ${[[20,'XS'],[24,'SM'],[32,'MD'],[40,'LG'],[56,'XL']].map(([sz,label])=>`
        <div style="display:flex;flex-direction:column;align-items:center;gap:8px">
          ${av('MN','var(--avatar-color-brand)',sz)}
          <span style="font-family:Inter,sans-serif;font-size:10px;color:var(--content-tertiary)">${label} ${sz}px</span>
        </div>`).join('')}
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#430098','component/avatar/bg','Default background')}
        ${swatch('#FFFFFF','content/on-brand','Initials text')}
      </div>
    </div>
  </div>

  <!-- GROUP BUILDER -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Group builder — click to add / remove</h2></div>
    <p class="doc-section-desc">Click the user tiles below to add or remove them from the assignee group. Watch the stack animate in and out. Overflow at 4 collapses to a "+N" counter.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Assignee group — interactive</span></div>
      <div class="inp-demo-stage" style="padding:20px">
        <!-- live group display -->
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;padding:12px 16px;background:var(--background-default);border:1px solid var(--border-subtle);border-radius:10px">
          <div id="av-group-stack" style="display:flex;align-items:center;min-width:40px;min-height:32px"></div>
          <span id="av-group-label" style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-tertiary)">No assignees</span>
        </div>
        <!-- user tiles -->
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
          ${NAMES.map((u,i)=>`
          <button id="av-tile-${i}" data-selected="false" data-init="${u.init}" data-color="${u.color}" onclick="(function(btn){
            var sel = btn.dataset.selected !== 'true';
            btn.dataset.selected = sel ? 'true' : 'false';
            btn.style.borderColor = sel ? 'var(--purple-30)' : 'var(--border-subtle)';
            btn.style.background  = sel ? 'var(--brand-primary-muted)' : 'var(--background-default)';
            var dot = btn.querySelector('.av-sel-dot');
            if(dot) dot.style.opacity = sel ? '1' : '0';
            var stack = document.getElementById('av-group-stack');
            var label = document.getElementById('av-group-label');
            if(!stack) return;
            var selected = document.querySelectorAll('[id^=\\'av-tile-\\'][data-selected=\\'true\\']');
            var show = Array.from(selected).slice(0,4);
            var extra = selected.length - 4;
            stack.innerHTML = show.map(function(b,idx){
              return '<span class=\\'av-popin\\' style=\\'margin-left:'+(idx>0?-8:0)+'px;border-radius:50%;border:2px solid var(--background-default);display:inline-flex;flex-shrink:0;z-index:'+(10-idx)+';position:relative\\'><span style=\\'display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:50%;background:'+b.dataset.color+';color:var(--avatar-on-color);font-family:Inter,sans-serif;font-size:11px;font-weight:700\\'>'+b.dataset.init+'</span></span>';
            }).join('')+(extra>0?'<span style=\\'margin-left:-8px;border-radius:50%;border:2px solid var(--background-default);display:inline-flex;width:32px;height:32px;align-items:center;justify-content:center;background:var(--avatar-overflow-bg);font-family:Inter,sans-serif;font-size:10px;font-weight:700;color:var(--avatar-overflow-text);flex-shrink:0;z-index:1\\'> +'+extra+'</span>':'');
            if(label) label.textContent = selected.length === 0 ? 'No assignees' : selected.length === 1 ? '1 assignee' : selected.length+' assignees';
          })(this)" style="display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;border:1px solid var(--border-subtle);background:var(--background-default);cursor:pointer;transition:all 0.15s;text-align:left">
            ${av(u.init,u.color,28)}
            <span style="font-family:Inter,sans-serif;font-size:11px;font-weight:600;color:var(--content-primary)">${u.name.split(' ')[0]}</span>
            <span class="av-sel-dot" style="margin-left:auto;width:7px;height:7px;border-radius:50%;background:var(--brand-primary);opacity:0;transition:opacity 0.15s;flex-shrink:0"></span>
          </button>`).join('')}
        </div>
      </div>
    </div>
  </div>

  <!-- COLOR SLOTS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Color assignment</h2></div>
    <p class="doc-section-desc">Avatar colour is derived from <code>userId % 6</code> — never set manually. The same user always gets the same colour across every screen in the app.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">6 colour slots — user ID % 6</span></div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;padding:20px">
        ${COLORS.map((c,i)=>`
        <div style="display:flex;flex-direction:column;align-items:center;gap:6px">
          ${av('AB',c,32)}
          <span style="font-family:var(--font-mono);font-size:9px;color:var(--content-tertiary)">slot ${i}</span>
        </div>`).join('')}
      </div>
      <div class="btn-tokens-strip">
        ${COLORS.map((c,i)=>swatch(c,`avatar/color/${i}`,`Slot ${i}`)).join('')}
      </div>
    </div>
  </div>

  <!-- STATUS DOT -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Status dot — click to cycle</h2></div>
    <p class="doc-section-desc">Three states: online (green), away (amber), offline (grey). Click the avatars below to cycle through states.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Status dot — click to change</span></div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;gap:28px;padding:24px">
        ${NAMES.slice(0,3).map((u,i)=>{
          const statuses = ['online','away','offline'];
          const init = statuses[i];
          const dotColor = init==='online'?'var(--avatar-status-online)':init==='away'?'var(--avatar-status-away)':'var(--avatar-status-offline)';
          return `<div style="display:flex;flex-direction:column;align-items:center;gap:8px">
            <div id="av-status-wrap-${i}" data-status="${init}" style="position:relative;display:inline-flex;cursor:pointer"
              onclick="(function(wrap){
                var statuses=['online','away','offline'];
                var cur=statuses.indexOf(wrap.dataset.status);
                var next=statuses[(cur+1)%3];
                wrap.dataset.status=next;
                var dot=wrap.querySelector('.av-status-dot-inner');
                var label=document.getElementById('av-status-label-${i}');
                var colors={online:'var(--avatar-status-online)',away:'var(--avatar-status-away)',offline:'var(--avatar-status-offline)'};
                if(dot){dot.style.background=colors[next];}
                if(label){label.textContent=next.charAt(0).toUpperCase()+next.slice(1);label.style.color=colors[next];}
              })(this)">
              ${av(u.init,u.color,40)}
              <span style="position:absolute;bottom:0;right:0;width:12px;height:12px;border-radius:50%;border:2px solid var(--background-default);display:flex;align-items:center;justify-content:center">
                <span class="av-status-dot-inner" style="width:8px;height:8px;border-radius:50%;background:${dotColor};display:block;transition:background 0.2s"></span>
              </span>
            </div>
            <span id="av-status-label-${i}" style="font-family:Inter,sans-serif;font-size:11px;font-weight:600;color:${dotColor};transition:color 0.2s;text-transform:capitalize">${init}</span>
          </div>`;
        }).join('')}
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#16A34A','status/success-content','Online')}
        ${swatch('#B45309','status/warning-content','Away')}
        ${swatch('#A3A3A3','content/tertiary','Offline')}
      </div>
    </div>
  </div>

  <!-- TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <div class="card" style="overflow:hidden">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Value</th><th>Usage</th></tr></thead>
        <tbody>
          ${[
            ['component/avatar/size/xs','20px','Inline use, compact rows'],
            ['component/avatar/size/sm','24px','Dense lists, toolbar'],
            ['component/avatar/size/md','32px','Card default'],
            ['component/avatar/size/lg','40px','Profile sections'],
            ['component/avatar/size/xl','56px','Page headers only'],
            ['component/avatar/overlap','25%','Stack negative margin = size × 0.25'],
            ['component/avatar/border-width','2px','Border around each stacked avatar'],
            ['component/avatar/dot-size','30%','Status dot diameter = size × 0.30'],
          ].map(([t,v,u],i)=>`<tr style="${i%2===0?'background:var(--background-subtle);':''}border-bottom:1px solid var(--border-subtle)">
            <td style="padding:10px 16px"><code class="tok-name">${t}</code></td>
            <td style="padding:10px 16px;font-family:var(--font-mono);font-size:12px;color:var(--brand-primary)">${v}</td>
            <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${u}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
  </div>

  <!-- PROPS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
    <table class="prop-table">
      <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
      <tbody>
        <tr><td><span class="prop-name">userId</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Drives colour assignment (userId % 6). Required.</td></tr>
        <tr><td><span class="prop-name">initials</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>1–2 characters shown when no image is provided.</td></tr>
        <tr><td><span class="prop-name">src</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Image URL. Falls back to initials if not provided or on error.</td></tr>
        <tr><td><span class="prop-name">size</span></td><td><span class="prop-type">"xs"|"sm"|"md"|"lg"|"xl"</span></td><td><span class="prop-default">"md"</span></td><td>Diameter size.</td></tr>
        <tr><td><span class="prop-name">status</span></td><td><span class="prop-type">"online"|"away"|"offline"|null</span></td><td><span class="prop-default">null</span></td><td>Show status dot. Null hides the dot entirely.</td></tr>
      </tbody>
    </table>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Derive avatar colour from userId deterministically — the same user always gets the same colour across every screen in the app.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't show more than 4 avatars in a stack — use "+N" for the overflow. A stack of 8 avatars is unreadable.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Always provide initials as a fallback in case the image URL fails or is slow to load.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use status dots on stacked group avatars — only single-avatar views should show status.</div></div>
    </div>
  </div>

  </div>`;
}
