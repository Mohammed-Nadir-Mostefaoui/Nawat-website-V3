import { pageHeader } from '../utils/render.js';

/* ── icons ──────────────────────────────────────────────── */
const SORT_BOTH  = `<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="8 9 12 5 16 9"/><polyline points="16 15 12 19 8 15"/></svg>`;
const SORT_ASC   = `<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="8 9 12 5 16 9"/><polyline points="16 15 12 19 8 15" opacity=".3"/></svg>`;
const SORT_DESC  = `<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="8 9 12 5 16 9" opacity=".3"/><polyline points="16 15 12 19 8 15"/></svg>`;
const LINK_ICON  = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>`;
const TRASH_ICON = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>`;
const SEARCH     = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`;
const EMPTY_BOX  = `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>`;

/* ── helpers ─────────────────────────────────────────────── */
function checkbox(checked = false, id = '') {
  const idAttr = id ? ` id="chk-${id}"` : '';
  return `<span${idAttr} style="width:16px;height:16px;border-radius:4px;border:1.5px solid ${checked?'var(--brand-primary)':'var(--border-default)'};background:${checked?'var(--brand-primary)':'var(--background-default)'};display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;cursor:pointer;color:#fff">
    ${checked?`<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="var(--content-on-brand)" stroke-width="3" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>`:''}
  </span>`;
}

function th(label, sort = null, width = 'auto') {
  const icon = sort === 'asc' ? SORT_ASC : sort === 'desc' ? SORT_DESC : SORT_BOTH;
  return `<th style="padding:10px 12px;text-align:left;font-family:Inter,sans-serif;font-size:11px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em;background:var(--background-subtle);white-space:nowrap;width:${width};cursor:${sort!==undefined?'pointer':'default'};user-select:none">
    <span style="display:inline-flex;align-items:center;gap:4px">${label}${sort !== undefined ? icon : ''}</span>
  </th>`;
}

function td(content, align = 'left', muted = false) {
  return `<td style="padding:10px 12px;font-family:Inter,sans-serif;font-size:13px;color:var(--content-${muted?'secondary':'primary'});text-align:${align};white-space:nowrap;border-bottom:1px solid var(--border-subtle)">${content}</td>`;
}

function badge(text, color, bg, border) {
  return `<span style="display:inline-flex;padding:0 7px;height:20px;border-radius:9999px;font-family:Inter,sans-serif;font-size:11px;font-weight:600;color:${color};background:${bg};border:1px solid ${border};align-items:center">${text}</span>`;
}

function actionBtn(icon, label = '') {
  return `<button title="${label}" style="width:28px;height:28px;display:inline-flex;align-items:center;justify-content:center;background:none;border:none;cursor:pointer;border-radius:6px;color:var(--content-secondary)" onmouseenter="this.style.background='var(--background-subtle)'" onmouseleave="this.style.background='none'">${icon}</button>`;
}

const CAT_COLORS = {
  Contenants:   { text:'var(--brand-primary)', bg:'var(--brand-primary-subtle)', border:'var(--purple-30,#C7B3E0)' },
  Consommables: { text:'#0550AE', bg:'#EFF6FF', border:'#93C5FD' },
  Emballage:    { text:'#16A34A', bg:'#F0FDF4', border:'#86EFAC' },
};

const PRODUCTS = [
  { code:'PRD-001', name:'Palette bois standard',  cat:'Contenants',   unit:'Unité',   price:'12.50', qty:'342' },
  { code:'PRD-002', name:'Film étirable 20µm',      cat:'Consommables', unit:'Rouleau', price:'4.20',  qty:'1 840' },
  { code:'PRD-003', name:'Carton simple cannelure', cat:'Emballage',    unit:'Unité',   price:'0.85',  qty:'6 230' },
  { code:'PRD-004', name:'Étiquette thermique A6',  cat:'Consommables', unit:'Lot 1000',price:'18.00', qty:'94' },
];

function table(selectedRows = [], sortCol = null, sortDir = 'asc') {
  const allSelected = selectedRows.length === PRODUCTS.length;
  return `
  <div style="border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden;background:var(--background-default)">
    <table style="width:100%;border-collapse:collapse">
      <thead>
        <tr>
          <th style="padding:10px 12px;background:var(--background-subtle);width:40px">${checkbox(allSelected)}</th>
          ${th('Code', sortCol === 'code' ? sortDir : 'none', '100px')}
          ${th('Nom du produit', sortCol === 'name' ? sortDir : 'none')}
          ${th('Catégorie', 'none', '120px')}
          ${th('Unité', null, '90px')}
          ${th('Prix', sortCol === 'price' ? sortDir : 'none', '80px')}
          ${th('Quantité', sortCol === 'qty' ? sortDir : 'none', '90px')}
          <th style="padding:10px 12px;background:var(--background-subtle);width:72px"></th>
        </tr>
      </thead>
      <tbody>
        ${PRODUCTS.map((p, i) => {
          const sel = selectedRows.includes(i);
          const c = CAT_COLORS[p.cat] || CAT_COLORS.Contenants;
          return `<tr style="background:${sel?'var(--brand-primary-subtle)':'var(--background-default)'}" onmouseenter="this.style.background='${sel?'var(--brand-primary-muted)':'var(--background-subtle)'}'" onmouseleave="this.style.background='${sel?'var(--brand-primary-subtle)':'var(--background-default)'}'">
            <td style="padding:10px 12px;border-bottom:1px solid var(--border-subtle)">${checkbox(sel)}</td>
            ${td(`<code style="font-size:11px;font-family:var(--font-mono);color:var(--content-secondary)">${p.code}</code>`)}
            ${td(`<span style="font-weight:500">${p.name}</span>`)}
            ${td(badge(p.cat, c.text, c.bg, c.border))}
            ${td(p.unit, 'left', true)}
            ${td(`<span style="font-family:var(--font-mono)">${p.price} €</span>`)}
            ${td(`<span style="font-family:var(--font-mono);font-weight:600">${p.qty}</span>`, 'right')}
            <td style="padding:6px 8px;border-bottom:1px solid var(--border-subtle);text-align:right">
              ${actionBtn(LINK_ICON, 'Lier')}${actionBtn(TRASH_ICON, 'Supprimer')}
            </td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>
  </div>`;
}

function swatch(color, name, lbl) {
  const light = ['#FFFFFF','#F6F6F6','#F7F4FB','#ECE6F5'].includes(color);
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${color};${light?'border:1px solid #E1E1E1':''}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${lbl}</div></div></div>`;
}

/* ════════════════════════════════════════════════════════════ */
export default function dataTables() {
  return pageHeader('Patterns', 'Data Tables', 'Column anatomy, sortable headers, row selection, inline actions, empty states, and pagination — for all ERP listing screens.') + `<div class="page-body">

  <style>
    @keyframes dt-row-select { from { background: var(--brand-primary-muted); } to { background: var(--brand-primary-subtle); } }
    @keyframes dt-bulk-in { from { opacity:0; transform:translateY(-6px); } to { opacity:1; transform:translateY(0); } }
    .dt-row-sel-anim { animation: dt-row-select 0.28s ease; }
    .dt-bulk-anim { animation: dt-bulk-in 0.2s ease; }
  </style>

  <!-- LIVE INTERACTIVE TABLE -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Live — click checkboxes, sort columns</h2></div>
    <p class="doc-section-desc">Click any checkbox to select a row (row turns purple). Click again to deselect. The header checkbox selects all. Click column headers to cycle sort direction. The bulk-action bar appears when rows are selected.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">Products table — fully interactive</span>
        <div style="display:flex;align-items:center;gap:8px">
          <div style="display:flex;align-items:center;gap:6px;padding:0 10px;height:30px;border:1px solid var(--border-default);border-radius:7px;background:var(--background-default);width:220px">
            <span style="color:var(--content-tertiary);flex-shrink:0;display:flex">${SEARCH}</span>
            <input id="dt-search" placeholder="Rechercher un produit…" oninput="dtFilter(this.value)" style="border:none;outline:none;font-family:Inter,sans-serif;font-size:12px;color:var(--content-primary);background:transparent;width:100%">
          </div>
          <button style="display:flex;align-items:center;gap:5px;padding:0 12px;height:30px;border-radius:7px;background:var(--brand-primary);border:none;cursor:pointer;font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--content-on-brand);white-space:nowrap;transition:background .15s" onmouseenter="this.style.background='var(--brand-primary-hover)'" onmouseleave="this.style.background='var(--brand-primary)'">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Créer
          </button>
        </div>
      </div>
      <div class="inp-demo-stage" style="padding:16px;overflow-x:auto">

        <!-- Bulk toolbar (hidden when 0 rows selected) -->
        <div id="dt-bulk" style="display:none;align-items:center;justify-content:space-between;padding:0 14px;height:40px;background:var(--brand-primary);border-radius:8px;margin-bottom:10px">
          <span id="dt-bulk-label" style="font-family:Inter,sans-serif;font-size:13px;font-weight:600;color:var(--content-on-brand)">0 sélectionné</span>
          <div style="display:flex;align-items:center;gap:8px">
            <button style="padding:0 12px;height:28px;border-radius:6px;background:rgba(255,255,255,0.18);border:none;cursor:pointer;font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--content-on-brand);transition:background 0.12s" onmouseenter="this.style.background='rgba(255,255,255,0.28)'" onmouseleave="this.style.background='rgba(255,255,255,0.18)'">Exporter</button>
            <button style="padding:0 12px;height:28px;border-radius:6px;background:rgba(255,255,255,0.18);border:none;cursor:pointer;font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:#FFB3B3;transition:background 0.12s" onmouseenter="this.style.background='rgba(255,255,255,0.28)'" onmouseleave="this.style.background='rgba(255,255,255,0.18)'">Supprimer</button>
          </div>
        </div>

        <!-- Table -->
        <div style="border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden;background:var(--background-default)">
          <table id="dt-table" style="width:100%;border-collapse:collapse">
            <thead>
              <tr>
                <th style="padding:10px 12px;background:var(--background-subtle);width:40px">
                  <span id="dt-header-chk" onclick="dtToggleAll()"
                    style="width:16px;height:16px;border-radius:4px;border:1.5px solid var(--border-default);background:var(--background-default);display:inline-flex;align-items:center;justify-content:center;cursor:pointer;color:#fff;flex-shrink:0"></span>
                </th>
                ${[
                  { key:'code',  label:'Code',          w:'100px' },
                  { key:'name',  label:'Nom du produit' },
                  { key:'cat',   label:'Catégorie',     w:'130px' },
                  { key:'unit',  label:'Unité',         w:'90px',  sort:false },
                  { key:'price', label:'Prix',          w:'80px' },
                  { key:'qty',   label:'Quantité',      w:'90px' },
                ].map(col=>`
                <th data-col="${col.key}" onclick="${col.sort!==false?'dtSort(\''+col.key+'\')':''}"
                  style="padding:10px 12px;text-align:left;font-family:Inter,sans-serif;font-size:11px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em;background:var(--background-subtle);white-space:nowrap;width:${col.w||'auto'};cursor:${col.sort!==false?'pointer':'default'};user-select:none;transition:color 0.12s"
                  ${col.sort!==false?`onmouseenter="this.style.color='var(--content-primary)'" onmouseleave="this.style.color='var(--content-tertiary)'"`:''}>
                  <span style="display:inline-flex;align-items:center;gap:4px">${col.label}
                    ${col.sort!==false?`<span class="dt-sort-icon" data-col="${col.key}" style="opacity:0.4">${SORT_BOTH}</span>`:''}
                  </span>
                </th>`).join('')}
                <th style="padding:10px 12px;background:var(--background-subtle);width:72px"></th>
              </tr>
            </thead>
            <tbody id="dt-tbody">
              ${PRODUCTS.map((p,i)=> {
                const c = CAT_COLORS[p.cat] || CAT_COLORS.Contenants;
                return `
              <tr id="dt-row-${i}" data-i="${i}" data-selected="false" data-name="${p.name.toLowerCase()}" data-cat="${p.cat.toLowerCase()}"
                style="background:var(--background-default);transition:background 0.18s"
                onmouseenter="if(this.dataset.selected!=='true')this.style.background='var(--background-subtle)'"
                onmouseleave="if(this.dataset.selected!=='true')this.style.background='var(--background-default)'">
                <td style="padding:10px 12px;border-bottom:1px solid var(--border-subtle)">
                  <span id="dt-chk-${i}" onclick="dtToggleRow(${i})"
                    style="width:16px;height:16px;border-radius:4px;border:1.5px solid var(--border-default);background:var(--background-default);display:inline-flex;align-items:center;justify-content:center;cursor:pointer;color:#fff;flex-shrink:0;transition:background 0.15s,border-color 0.15s"></span>
                </td>
                <td style="padding:10px 12px;border-bottom:1px solid var(--border-subtle)"><code style="font-size:11px;font-family:var(--font-mono);color:var(--content-secondary)">${p.code}</code></td>
                <td style="padding:10px 12px;border-bottom:1px solid var(--border-subtle);font-family:Inter,sans-serif;font-size:13px;font-weight:500;color:var(--content-primary)">${p.name}</td>
                <td style="padding:10px 12px;border-bottom:1px solid var(--border-subtle)">
                  <span style="display:inline-flex;padding:0 7px;height:20px;border-radius:9999px;font-family:Inter,sans-serif;font-size:11px;font-weight:600;color:${c.text};background:${c.bg};border:1px solid ${c.border};align-items:center">${p.cat}</span>
                </td>
                <td style="padding:10px 12px;border-bottom:1px solid var(--border-subtle);font-family:Inter,sans-serif;font-size:13px;color:var(--content-secondary)">${p.unit}</td>
                <td style="padding:10px 12px;border-bottom:1px solid var(--border-subtle);font-family:var(--font-mono);font-size:13px;color:var(--content-primary)">${p.price} €</td>
                <td style="padding:10px 12px;border-bottom:1px solid var(--border-subtle);font-family:var(--font-mono);font-size:13px;font-weight:600;color:var(--content-primary);text-align:right">${p.qty}</td>
                <td style="padding:6px 8px;border-bottom:1px solid var(--border-subtle);text-align:right">
                  ${actionBtn(LINK_ICON,'Lier')}${actionBtn(TRASH_ICON,'Supprimer')}
                </td>
              </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>

      </div>
      <div class="btn-tokens-strip">
        ${swatch('#F6F6F6','background/subtle','Header bg')}
        ${swatch('#F7F4FB','brand/primary-subtle','Selected row bg')}
        ${swatch('#430098','brand/primary','Bulk toolbar + checkbox')}
        ${swatch('#E1E1E1','border/subtle','Row divider')}
      </div>
    </div>
  </div>

  <script>
    var _dtSelected = [];
    var _dtSort = { col: null, dir: 'asc' };

    function dtToggleRow(i) {
      var row = document.getElementById('dt-row-' + i);
      var chk = document.getElementById('dt-chk-' + i);
      if (!row || !chk) return;
      var sel = row.dataset.selected !== 'true';
      row.dataset.selected = sel ? 'true' : 'false';
      row.style.background = sel ? 'var(--brand-primary-subtle)' : 'var(--background-default)';
      if (sel) row.classList.add('dt-row-sel-anim');
      chk.style.background  = sel ? 'var(--brand-primary)' : 'var(--background-default)';
      chk.style.borderColor = sel ? 'var(--brand-primary)' : 'var(--border-default)';
      chk.innerHTML = sel ? '<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="var(--content-on-brand)" stroke-width="3" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>' : '';
      _dtSelected = Array.from(document.querySelectorAll('#dt-tbody tr[data-selected=true]')).map(r => parseInt(r.dataset.i));
      dtUpdateBulk();
      dtUpdateHeaderChk();
    }

    function dtToggleAll() {
      var allSel = _dtSelected.length === ${PRODUCTS.length};
      var rows = document.querySelectorAll('#dt-tbody tr');
      rows.forEach(function(row) {
        if (row.style.display === 'none') return;
        var i = parseInt(row.dataset.i);
        if (isNaN(i)) return;
        var chk = document.getElementById('dt-chk-' + i);
        var target = !allSel;
        row.dataset.selected = target ? 'true' : 'false';
        row.style.background = target ? 'var(--brand-primary-subtle)' : 'var(--background-default)';
        if (chk) {
          chk.style.background  = target ? 'var(--brand-primary)' : 'var(--background-default)';
          chk.style.borderColor = target ? 'var(--brand-primary)' : 'var(--border-default)';
          chk.innerHTML = target ? '<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="var(--content-on-brand)" stroke-width="3" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>' : '';
        }
      });
      _dtSelected = allSel ? [] : [${PRODUCTS.map((_,i)=>i).join(',')}];
      dtUpdateBulk();
      dtUpdateHeaderChk();
    }

    function dtUpdateBulk() {
      var bulk  = document.getElementById('dt-bulk');
      var label = document.getElementById('dt-bulk-label');
      if (!bulk) return;
      var n = _dtSelected.length;
      if (n > 0) {
        bulk.style.display = 'flex';
        bulk.classList.remove('dt-bulk-anim'); void bulk.offsetWidth; bulk.classList.add('dt-bulk-anim');
        if (label) label.textContent = n + ' élément' + (n > 1 ? 's' : '') + ' sélectionné' + (n > 1 ? 's' : '');
      } else {
        bulk.style.display = 'none';
      }
    }

    function dtUpdateHeaderChk() {
      var hchk = document.getElementById('dt-header-chk');
      if (!hchk) return;
      var n = _dtSelected.length;
      var total = document.querySelectorAll('#dt-tbody tr:not([style*="display: none"])').length;
      if (n === 0) {
        hchk.style.background  = 'var(--background-default)';
        hchk.style.borderColor = 'var(--border-default)';
        hchk.innerHTML = '';
      } else if (n === total) {
        hchk.style.background  = 'var(--brand-primary)';
        hchk.style.borderColor = 'var(--brand-primary)';
        hchk.innerHTML = '<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="var(--content-on-brand)" stroke-width="3" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>';
      } else {
        hchk.style.background  = 'var(--brand-primary)';
        hchk.style.borderColor = 'var(--brand-primary)';
        hchk.innerHTML = '<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="var(--content-on-brand)" stroke-width="2.5"><line x1="2" y1="5" x2="14" y2="5"/></svg>';
      }
    }

    function dtSort(col) {
      var dir = (_dtSort.col === col && _dtSort.dir === 'asc') ? 'desc' : 'asc';
      _dtSort = { col: col, dir: dir };
      document.querySelectorAll('.dt-sort-icon').forEach(function(el) {
        el.style.opacity = '0.4';
        el.innerHTML = '${SORT_BOTH.replace(/'/g,"\\'")}';
      });
      var icon = document.querySelector('.dt-sort-icon[data-col="' + col + '"]');
      if (icon) {
        icon.style.opacity = '1';
        icon.innerHTML = dir === 'asc' ? '${SORT_ASC.replace(/'/g,"\\'")}' : '${SORT_DESC.replace(/'/g,"\\'")}';
      }
      var rows = Array.from(document.querySelectorAll('#dt-tbody tr'));
      var colMap = { code: 2, name: 3, cat: 4, price: 6, qty: 7 };
      var ci = colMap[col];
      if (!ci) return;
      rows.sort(function(a, b) {
        var av = a.cells[ci] ? a.cells[ci].textContent.trim().replace(/[^0-9.]/g,'') : '';
        var bv = b.cells[ci] ? b.cells[ci].textContent.trim().replace(/[^0-9.]/g,'') : '';
        var an = parseFloat(av); var bn = parseFloat(bv);
        if (!isNaN(an) && !isNaN(bn)) return dir === 'asc' ? an - bn : bn - an;
        return dir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
      });
      var tbody = document.getElementById('dt-tbody');
      if (tbody) rows.forEach(function(r) { tbody.appendChild(r); });
    }

    function dtFilter(q) {
      var query = q.toLowerCase();
      document.querySelectorAll('#dt-tbody tr').forEach(function(row) {
        var name = row.dataset.name || '';
        var cat  = row.dataset.cat  || '';
        row.style.display = (!query || name.includes(query) || cat.includes(query)) ? '' : 'none';
      });
    }
  </script>

  <!-- COLUMN TYPES -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Column types</h2></div>
    <p class="doc-section-desc">Different data types have specific rendering conventions. Never mix types within a column.</p>
    <div style="margin-top:16px;border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden;background:var(--background-default)">
      <div style="display:grid;grid-template-columns:1fr 1fr 2fr;background:var(--background-subtle);padding:10px 16px;gap:12px">
        ${['Type','Example','Rule'].map(h=>`<div style="font-size:11px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em">${h}</div>`).join('')}
      </div>
      ${[
        ['Text','Nom de produit','Left-aligned, font-weight 500. Truncates with ellipsis after 1 line.'],
        ['Code / ID','PRD-00441','Monospace font, content/secondary. Never bold.'],
        ['Number / Price','12.50 €','Right-aligned, monospace. Currency always after the number.'],
        ['Quantity','1 840','Right-aligned, monospace, font-weight 600.'],
        ['Badge','Consommables','Left-aligned, inline badge. Max 1 badge per cell.'],
        ['Actions','✎ 🗑','Right-aligned icon buttons, 28×28px, visible on row hover only.'],
        ['Checkbox','☑','Left-most column, always. 40px column width.'],
      ].map(([type,ex,rule],i) => `
      <div style="display:grid;grid-template-columns:1fr 1fr 2fr;padding:10px 16px;gap:12px;${i<6?'border-top:1px solid var(--border-subtle)':''}">
        <div style="font-size:12px;font-weight:600;color:var(--content-primary)">${type}</div>
        <div style="font-size:12px;font-family:var(--font-mono);color:var(--content-secondary)">${ex}</div>
        <div style="font-size:12px;color:var(--content-tertiary)">${rule}</div>
      </div>`).join('')}
    </div>
  </div>

  <!-- EMPTY STATE -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Empty state</h2></div>
    <p class="doc-section-desc">Two empty state variants: <strong>no data yet</strong> (first visit, no records created) and <strong>no results</strong> (search or filter returned nothing). Each has a different message and CTA.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Empty table — no data</span></div>
      <div class="inp-demo-stage" style="padding:20px">
        <div style="border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden;background:var(--background-default)">
          <table style="width:100%;border-collapse:collapse">
            <thead>
              <tr>
                <th style="padding:10px 12px;background:var(--background-subtle);width:40px">${checkbox(false)}</th>
                ${th('Code')}&nbsp;${th('Nom du produit')}&nbsp;${th('Catégorie')}&nbsp;${th('Prix')}&nbsp;${th('Quantité')}
              </tr>
            </thead>
          </table>
          <div style="padding:48px 24px;display:flex;flex-direction:column;align-items:center;gap:12px;color:var(--content-tertiary)">
            ${EMPTY_BOX}
            <div style="font-family:var(--font-display);font-size:14px;font-weight:700;color:var(--content-primary)">Aucun produit pour le moment</div>
            <div style="font-family:Inter,sans-serif;font-size:13px;color:var(--content-secondary);text-align:center;max-width:300px">Créez votre premier produit pour commencer à gérer votre catalogue.</div>
            <button style="margin-top:4px;padding:0 16px;height:36px;border-radius:8px;background:var(--brand-primary);border:none;cursor:pointer;font-family:Inter,sans-serif;font-size:13px;font-weight:600;color:var(--content-on-brand)">+ Créer un produit</button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- DENSITY -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Row density</h2></div>
    <div class="grid-2" style="margin-top:16px">
      <div class="rule-card accent"><div class="rule-card-title">Default — 40px rows</div><div class="rule-card-body">10px top + 10px bottom padding. 13px text. Used on all ERP listing pages. Comfortably scannable at a glance.</div></div>
      <div class="rule-card"><div class="rule-card-title">Compact — 32px rows</div><div class="rule-card-body">6px top + 6px bottom padding. 12px text. For read-only reference tables where density matters. Never use compact for tables with action buttons.</div></div>
    </div>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Stick to one sort column at a time. Multi-column sort is complex to communicate and rarely needed in logistics ERP.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't put more than 2 action icons per row. Use a "…" overflow menu for 3+ actions.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Always show the bulk-action toolbar when rows are selected — surface destructive bulk actions (delete) here, not inline.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use colored row backgrounds beyond the selection state. Zebra striping is disabled — it fights with the row hover state.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Make the empty state actionable — include a CTA that directly creates the first record, reducing dead ends.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't right-align text columns — only numbers, prices, and quantities are right-aligned. Mixed alignment within a column is never acceptable.</div></div>
    </div>
  </div>

  </div>`;
}
