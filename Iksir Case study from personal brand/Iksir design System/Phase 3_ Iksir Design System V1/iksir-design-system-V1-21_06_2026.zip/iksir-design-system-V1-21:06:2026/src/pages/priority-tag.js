import { pageHeader } from '../utils/render.js';

const ARROW_UP   = `<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>`;
const ARROW_MID  = `<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>`;
const ARROW_DOWN = `<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>`;

const PRIORITY = [
  { key:'high',   label:'High',   icon:ARROW_UP,   bg:'var(--priority-high-bg)',   text:'var(--priority-high-text)',   border:'var(--priority-high-border)',
    desc:'Immédiat — besoin d\'action dans l\'heure',  swatch_bg:'#FFF2F4', swatch_text:'#D8192C' },
  { key:'medium', label:'Medium', icon:ARROW_MID,  bg:'var(--priority-medium-bg)', text:'var(--priority-medium-text)', border:'var(--priority-medium-border)',
    desc:'Important — traiter avant la fin de journée', swatch_bg:'#FFF8EC', swatch_text:'#B45309' },
  { key:'low',    label:'Low',    icon:ARROW_DOWN, bg:'var(--priority-low-bg)',    text:'var(--priority-low-text)',    border:'var(--priority-low-border)',
    desc:'Faible — planifier pour la semaine prochaine', swatch_bg:'#F0FDF4', swatch_text:'#16A34A' },
  { key:'none',   label:'None',   icon:'',         bg:'var(--priority-none-bg)',   text:'var(--priority-none-text)',   border:'var(--priority-none-border)',
    desc:'Non classé — à trier lors du prochain sprint',  swatch_bg:'#F6F6F6', swatch_text:'#757575' },
];

function tag(p, size = 'md') {
  const small = size === 'sm';
  return `<span style="display:inline-flex;align-items:center;gap:${small?3:4}px;padding:0 ${small?5:6}px;height:${small?18:20}px;border-radius:5px;font-size:${small?10:11}px;font-weight:600;font-family:Inter,sans-serif;background:${p.bg};color:${p.text};border:1px solid ${p.border}">${p.icon}${p.label}</span>`;
}

function swatch(color, name, lbl) {
  const light = ['#FFF2F4','#FFF8EC','#F0FDF4','#F6F6F6'].includes(color);
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${color};${light?'border:1px solid #E1E1E1':''}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${lbl}</div></div></div>`;
}

export default function priorityTag() {
  return pageHeader('Components', 'Priority Tag', 'Four-level priority indicator. Communicates urgency at a glance with colour, direction arrow, and label. Always paired with task cards.', [
    { val: '4', label: 'Levels' },
    { val: '2', label: 'Sizes' },
  ]) + `<div class="page-body">

  <style>
    @keyframes ptag-swap { 0% { opacity:0; transform:scale(0.7) translateY(-4px); } 100% { opacity:1; transform:scale(1) translateY(0); } }
    .ptag-animate { animation: ptag-swap 0.22s cubic-bezier(0.175,0.885,0.32,1.275); }
    @keyframes row-highlight { 0%,100% { background:transparent; } 40% { background:var(--background-subtle); } }
    .row-flash { animation: row-highlight 0.5s ease; }
  </style>

  <!-- CLICK-TO-CYCLE DEMO -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Click to cycle — try it</h2></div>
    <p class="doc-section-desc">Click any priority tag to cycle to the next level. The tag springs with a scale animation and the row flashes to confirm the change. This mirrors the tap-to-change interaction in the mobile app.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Task list — click a priority tag</span></div>
      <div class="inp-demo-stage" style="padding:0;overflow:hidden;border-radius:0 0 8px 8px">
        ${[
          { title:'Préparer commande CMD-2847', pi:0, due:'Aujourd\'hui 14:30' },
          { title:'Vérifier stock palette A-12',  pi:1, due:'Demain 09:00' },
          { title:'Valider bon de livraison',      pi:2, due:'Vendredi 16:00' },
          { title:'Mettre à jour catalogue',       pi:3, due:'Semaine prochaine' },
        ].map((r,ri)=>`
        <div id="ptag-row-${ri}" style="display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:1px solid var(--border-subtle);background:var(--background-default);transition:background 0.2s">
          <span id="ptag-${ri}" data-pi="${r.pi}" onclick="(function(el){
            var levels=[{label:'High',icon:'▲',bg:'var(--priority-high-bg)',text:'var(--priority-high-text)',border:'var(--priority-high-border)'},{label:'Medium',icon:'—',bg:'var(--priority-medium-bg)',text:'var(--priority-medium-text)',border:'var(--priority-medium-border)'},{label:'Low',icon:'▼',bg:'var(--priority-low-bg)',text:'var(--priority-low-text)',border:'var(--priority-low-border)'},{label:'None',icon:'',bg:'var(--priority-none-bg)',text:'var(--priority-none-text)',border:'var(--priority-none-border)'}];
            var pi = (parseInt(el.dataset.pi,10)+1)%4;
            el.dataset.pi = pi;
            var p = levels[pi];
            el.style.background=p.bg; el.style.color=p.text; el.style.borderColor=p.border;
            el.innerHTML=(p.icon?'<span style=\\'margin-right:4px\\'>'+p.icon+'</span>':'')+p.label;
            el.classList.remove('ptag-animate'); void el.offsetWidth; el.classList.add('ptag-animate');
            var row = el.closest('[id^=\\'ptag-row-\\']');
            if(row){ row.classList.remove('row-flash'); void row.offsetWidth; row.classList.add('row-flash'); }
          })(this)"
          style="display:inline-flex;align-items:center;gap:4px;padding:0 6px;height:20px;border-radius:5px;font-size:11px;font-weight:600;font-family:Inter,sans-serif;background:${PRIORITY[r.pi].bg};color:${PRIORITY[r.pi].text};border:1px solid ${PRIORITY[r.pi].border};cursor:pointer;transition:background 0.2s,color 0.2s,border-color 0.2s;user-select:none;flex-shrink:0">
            ${PRIORITY[r.pi].icon ? `<span style="margin-right:0">${PRIORITY[r.pi].icon}</span>` : ''}${PRIORITY[r.pi].label}
          </span>
          <div style="flex:1;min-width:0">
            <div style="font-family:Inter,sans-serif;font-size:13px;font-weight:500;color:var(--content-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${r.title}</div>
            <div style="font-family:Inter,sans-serif;font-size:10px;color:var(--content-tertiary);margin-top:1px">${r.due}</div>
          </div>
        </div>`).join('')}
      </div>
    </div>
  </div>

  <!-- ALL FOUR LEVELS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">All four levels</h2></div>
    <p class="doc-section-desc">Each level has a unique combination of icon direction, background, text, and border colour. Never use colour alone — the icon and label always accompany the colour signal.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Priority levels — MD and SM sizes</span></div>
      <div class="inp-demo-stage" style="padding:24px">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;max-width:500px;margin:0 auto">
          ${PRIORITY.map(p => `
          <div style="display:flex;flex-direction:column;gap:8px">
            <div style="display:flex;align-items:center;gap:8px">
              ${tag(p,'md')}
              ${tag(p,'sm')}
            </div>
            <div style="background:${p.bg};border:1px solid ${p.border};border-radius:8px;padding:8px 10px">
              <div style="font-family:Inter,sans-serif;font-size:10px;font-weight:600;color:${p.text};text-transform:uppercase;letter-spacing:.05em;margin-bottom:2px">${p.label}</div>
              <div style="font-family:Inter,sans-serif;font-size:10px;color:var(--content-secondary)">${p.desc}</div>
            </div>
          </div>`).join('')}
        </div>
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#FFF2F4','priority/high-bg','High bg')}
        ${swatch('#FFF8EC','priority/medium-bg','Medium bg')}
        ${swatch('#F0FDF4','priority/low-bg','Low bg')}
        ${swatch('#F6F6F6','background/subtle','None bg')}
      </div>
    </div>
  </div>

  <!-- SIZE COMPARISON -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Sizes</h2></div>
    <p class="doc-section-desc">MD (20px) is the default for task card badges. SM (18px) is used in dense table rows and list items where vertical space is constrained to 40px or less.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">MD vs SM</span></div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;gap:32px;padding:24px">
        <div style="display:flex;flex-direction:column;align-items:center;gap:10px">
          ${tag(PRIORITY[0],'md')}
          <span style="font-family:Inter,sans-serif;font-size:10px;color:var(--content-tertiary)">MD — 20px</span>
        </div>
        <div style="display:flex;flex-direction:column;align-items:center;gap:10px">
          ${tag(PRIORITY[0],'sm')}
          <span style="font-family:Inter,sans-serif;font-size:10px;color:var(--content-tertiary)">SM — 18px</span>
        </div>
      </div>
    </div>
  </div>

  <!-- TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <div class="card" style="overflow:hidden">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Value</th><th>Usage</th></tr></thead>
        <tbody>
          ${[
            ['priority/high/bg','#FFF2F4','High background'],
            ['priority/high/text','#D8192C','High text + icon'],
            ['priority/high/border','#E87580','High border'],
            ['priority/medium/bg','#FFF8EC','Medium background'],
            ['priority/medium/text','#B45309','Medium text + icon'],
            ['priority/medium/border','#F6C060','Medium border'],
            ['priority/low/bg','#F0FDF4','Low background'],
            ['priority/low/text','#16A34A','Low text + icon'],
            ['priority/low/border','#86EFAC','Low border'],
            ['priority/none/bg','#F6F6F6','None background'],
            ['priority/none/text','#757575','None text'],
            ['component/priority-tag/radius','5px','Badge border radius'],
            ['component/priority-tag/height-md','20px','MD height'],
            ['component/priority-tag/height-sm','18px','SM height'],
          ].map(([t,v,u],i)=>`<tr style="${i%2===0?'background:var(--background-subtle);':''}border-bottom:1px solid var(--border-subtle)">
            <td style="padding:10px 16px"><code class="tok-name">${t}</code></td>
            <td style="padding:10px 16px;font-family:var(--font-mono);font-size:11px;color:var(--brand-primary)">${v}</td>
            <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${u}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
  </div>

  <!-- PROPS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
    <table class="prop-table">
      <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
      <tbody>
        <tr><td><span class="prop-name">level</span></td><td><span class="prop-type">"high"|"medium"|"low"|"none"</span></td><td><span class="prop-default">"none"</span></td><td>Priority level. Drives all visual properties.</td></tr>
        <tr><td><span class="prop-name">size</span></td><td><span class="prop-type">"md"|"sm"</span></td><td><span class="prop-default">"md"</span></td><td>Visual size.</td></tr>
        <tr><td><span class="prop-name">onClick</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Called when tapped. The parent component is responsible for cycling the level value.</td></tr>
      </tbody>
    </table>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Always show the icon alongside the label. Colour alone is not sufficient for accessibility — the arrow direction adds a second signal.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use the Priority Tag as a general-purpose coloured badge for statuses — it is strictly for task urgency levels.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use the SM size in table rows with 40px row height. The MD size in a 40px row leaves no breathing room.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't show a priority tag without a corresponding due date nearby — priority only makes sense in the context of time.</div></div>
    </div>
  </div>

  </div>`;
}
