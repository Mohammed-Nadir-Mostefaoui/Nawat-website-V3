import { pageHeader } from '../utils/render.js';

export default function mobileNavigation() {
  return pageHeader(
    'Platform',
    'Mobile Navigation',
    'Bottom tab bar anatomy, token map, states, and badge rules for the primary navigation layer of Iksir mobile apps.'
  ) + `<div class="page-body">

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Structure</h2>
      </div>
      <p class="doc-section-desc">Iksir mobile uses a persistent bottom tab bar for top-level navigation. It never uses a hamburger menu or a top navigation bar as the primary nav — all primary destinations are reachable in one tap from anywhere in the app.</p>
      <div class="grid-2" style="margin-top:16px">
        <div class="rule-card accent">
          <div class="rule-card-title">4–5 tabs maximum</div>
          <div class="rule-card-body">Task Master ships with 4 tabs: Tasks, Orders, Scan, Profile. A fifth tab can be added for a new primary destination. Never add a sixth — use nested navigation or a bottom sheet instead.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Icons + labels always</div>
          <div class="rule-card-body">Every tab item shows both an icon (24×24px) and a text label. Never icon-only on mobile — labels reduce error rate in enterprise/logistics contexts where gloved hands are common.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Active tab highlight</div>
          <div class="rule-card-body">The active tab uses <code>nav/tab/icon-active</code> (brand purple) for the icon and label, and a small pill indicator above the icon. Inactive tabs use <code>nav/tab/icon-inactive</code> (neutral grey).</div>
        </div>
        <div class="rule-card accent">
          <div class="rule-card-title">Safe area</div>
          <div class="rule-card-body">The tab bar background extends to the physical bottom edge. Interactive items (icons + labels) sit above the home indicator safe area. Height above safe area: 56px.</div>
        </div>
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Token map</h2>
      </div>
      <p class="doc-section-desc">All tab bar visual properties are expressed through semantic tokens — never hardcoded colours or sizes.</p>
      <div style="margin-top:16px;border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden">
        <div style="display:grid;grid-template-columns:2fr 2fr 1fr;background:var(--background-subtle);padding:10px 16px;gap:12px">
          ${['Token','Role','Value'].map(h => `<div style="font-size:11px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em">${h}</div>`).join('')}
        </div>
        ${[
          ['nav/tab/background','Tab bar background colour','Surface/default'],
          ['nav/tab/border-top','Top border separating bar from content','Border/subtle'],
          ['nav/tab/icon-active','Icon + label colour when tab is selected','Brand/primary'],
          ['nav/tab/icon-inactive','Icon + label colour when tab is not selected','Content/tertiary'],
          ['nav/tab/indicator','Pill indicator above active icon','Brand/primary'],
          ['nav/tab/item-height','Height of the tap target area (above safe zone)','56px'],
          ['nav/tab/icon-size','Icon size','24×24px'],
          ['nav/tab/label-size','Label font size','10px, Semibold'],
        ].map(([token, role, value], i) => `
        <div style="display:grid;grid-template-columns:2fr 2fr 1fr;padding:10px 16px;gap:12px;${i < 7 ? 'border-top:1px solid var(--border-subtle)' : ''}">
          <div style="font-family:var(--font-mono);font-size:11px;color:var(--brand-primary)">${token}</div>
          <div style="font-size:12px;color:var(--content-secondary)">${role}</div>
          <div style="font-family:var(--font-mono);font-size:11px;color:var(--content-tertiary)">${value}</div>
        </div>`).join('')}
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Badge rules</h2>
      </div>
      <p class="doc-section-desc">Notification badges appear on tab icons to signal unread or pending items. They follow a strict count-display and truncation rule.</p>
      <div class="grid-2" style="margin-top:16px">
        <div class="rule-card accent">
          <div class="rule-card-title">Count display</div>
          <div class="rule-card-body">Show the exact count for 1–99. At 100+, show "99+" (never "100" or higher). The badge is right-aligned on the icon and never obscures the icon's visual meaning.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Dot variant</div>
          <div class="rule-card-body">When presence (not count) is the signal — e.g., "there is activity but count is irrelevant" — use the 8px dot badge with no number. Used in Task Master for the Profile tab (sync status).</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Colour semantics</div>
          <div class="rule-card-body">Red badge = action required (overdue tasks, urgent orders). No colour badge = informational (profile updates). Never use badge colour as the sole signal — the tab label or destination screen must reinforce it.</div>
        </div>
        <div class="rule-card accent">
          <div class="rule-card-title">Never badge more than 2 tabs</div>
          <div class="rule-card-body">If more than 2 tabs have active badges simultaneously, the visual noise defeats the purpose. Consolidate notifications or use a unified "Inbox" destination instead.</div>
        </div>
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Navigation hierarchy</h2>
      </div>
      <p class="doc-section-desc">The tab bar sits at level 0. Every other navigation pattern is additive on top of it.</p>
      <div style="margin-top:16px;border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden">
        <div style="display:grid;grid-template-columns:80px 1fr 2fr;background:var(--background-subtle);padding:10px 16px;gap:12px">
          ${['Level','Pattern','When to use'].map(h => `<div style="font-size:11px;font-weight:700;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.06em">${h}</div>`).join('')}
        </div>
        ${[
          ['L0','Bottom tab bar','Top-level destinations. Always visible. Tap to navigate without losing scroll position.'],
          ['L1','Stack push (header back arrow)','Detail views, record pages, forms. Header back arrow returns to L0 or previous L1.'],
          ['L2','Bottom sheet','Contextual actions, filters, quick edits. Does not replace the current screen — overlays it.'],
          ['L2','Modal','Focused sub-tasks that require completion before returning. E.g., add a composant, scan a barcode.'],
          ['L3','Inline expansion','Accordion sections within a form or detail view. No navigation — pure show/hide.'],
        ].map(([level, pattern, when], i) => `
        <div style="display:grid;grid-template-columns:80px 1fr 2fr;padding:10px 16px;gap:12px;${i < 4 ? 'border-top:1px solid var(--border-subtle)' : ''}">
          <div style="font-family:var(--font-mono);font-size:11px;color:var(--brand-primary);font-weight:700">${level}</div>
          <div style="font-size:12px;font-weight:600;color:var(--content-primary)">${pattern}</div>
          <div style="font-size:12px;color:var(--content-secondary)">${when}</div>
        </div>`).join('')}
      </div>
    </div>

  </div>`;
}
