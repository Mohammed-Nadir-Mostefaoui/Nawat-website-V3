import { pageHeader, spacingRows } from '../utils/render.js';

export default function spacing() {
  return pageHeader('Tokens', 'Spacing', 'Twenty-two steps on a 4pt grid, from 0 to 160px. Every padding, gap, and margin in the product resolves to one of these tokens.', [{val:'22',label:'Steps'},{val:'4pt',label:'Grid base'},{val:'0–160',label:'px range'}]) + `<div class="page-body">
    <div class="callout warning" style="margin-bottom:24px">
      <div class="callout-icon">⚠</div>
      <div>spacing/14 breaks the 4pt grid and is scheduled for removal in a future cleanup. Avoid using it in new components. Use spacing/12 or spacing/16 instead.</div>
    </div>
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Full scale</h2></div>
      <div class="spacing-table">
        <div class="spacing-row header">
          <div class="type-col-label">Token</div>
          <div class="type-col-label">Value</div>
          <div class="type-col-label">Visual</div>
          <div class="type-col-label">Usage</div>
        </div>
        ${spacingRows()}
      </div>
    </div>
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">The 4pt grid</h2></div>
      <div class="grid-2">
        <div class="rule-card accent">
          <div class="rule-card-title">Why 4px?</div>
          <div class="rule-card-body">4px divides cleanly into all screen densities (1x, 1.5x, 2x, 3x) and aligns with common component heights (32, 36, 44, 48px). Result: pixel-perfect rendering across all devices without fractional pixels.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Intentional exceptions</div>
          <div class="rule-card-body"><code>spacing/2</code> and <code>spacing/6</code> are valid micro-gaps for dense components like badges. <code>spacing/10</code> and <code>spacing/14</code> exist for specific button and input geometry. Document any new exceptions.</div>
        </div>
      </div>
    </div>
  </div>`;
}
