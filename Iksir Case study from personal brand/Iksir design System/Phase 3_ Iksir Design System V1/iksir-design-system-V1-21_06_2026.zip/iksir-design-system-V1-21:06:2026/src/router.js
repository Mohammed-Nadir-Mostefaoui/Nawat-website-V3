'use strict';

import { NAV } from './data/nav.js';
import { TYPE_ROLES } from './data/tokens.js';

import overview     from './pages/overview.js';
import colors       from './pages/colors.js';
import typography   from './pages/typography.js';
import spacing      from './pages/spacing.js';
import radius       from './pages/radius.js';
import elevation    from './pages/elevation.js';
import button       from './pages/button.js';
import iconography  from './pages/iconography.js';
import input        from './pages/input.js';
import tooltip      from './pages/tooltip.js';
import checkbox     from './pages/checkbox.js';
import accessibility from './pages/accessibility.js';
import exportPage   from './pages/export.js';
import figma        from './pages/figma.js';
import changelog    from './pages/changelog.js';
import principles   from './pages/principles.js';
import architecture from './pages/architecture.js';
import primitives   from './pages/primitives.js';
import sizing       from './pages/sizing.js';
import select       from './pages/select.js';
import badge        from './pages/badge.js';
import dropdown     from './pages/dropdown.js';
import toggle       from './pages/toggle.js';
import breadcrumb   from './pages/breadcrumb.js';
import tab          from './pages/tab.js';
import toastPage    from './pages/toast.js';
import pagination   from './pages/pagination.js';
import tables       from './pages/tables.js';
import modalComp    from './pages/modal-comp.js';
import templates       from './pages/templates.js';
import mobileOverview  from './pages/mobile-overview.js';
import mobileNavigation from './pages/mobile-navigation.js';
import mobileFab       from './pages/mobile-fab.js';
import touchTargets    from './pages/touch-targets.js';
import responsive      from './pages/responsive.js';
import bottomTabNav    from './pages/bottom-tab-nav.js';
import mobileHeader    from './pages/mobile-header.js';
import fab             from './pages/fab.js';
import taskCard        from './pages/task-card.js';
import priorityTag     from './pages/priority-tag.js';
import avatar          from './pages/avatar.js';
import numericKeypad   from './pages/numeric-keypad.js';
import bottomSheet     from './pages/bottom-sheet.js';
import scannerOverlay  from './pages/scanner-overlay.js';
import forms           from './pages/forms.js';
import dataTables      from './pages/data-tables.js';
import navigationPage  from './pages/navigation.js';
import cardComp        from './pages/card-comp.js';
import charts          from './pages/charts.js';

import { comingSoon } from './utils/render.js';

const PAGES = {
  overview,
  colors,
  typography,
  spacing,
  radius,
  elevation,
  button,
  iconography,
  input,
  tooltip,
  checkbox,
  accessibility,
  export: exportPage,
  figma,
  changelog,
  principles,
  architecture,
  primitives,
  sizing,
  select,
  badge,
  dropdown,
  toggle,
  breadcrumb,
  tab,
  toast: toastPage,
  pagination,
  table: tables,
  'modal-comp': modalComp,
  templates,
  'mobile-overview':   mobileOverview,
  'mobile-navigation': mobileNavigation,
  'mobile-fab':        mobileFab,
  'touch-targets':     touchTargets,
  responsive,
  'bottom-tab-nav':    bottomTabNav,
  'mobile-header':     mobileHeader,
  fab,
  'task-card':         taskCard,
  'priority-tag':      priorityTag,
  avatar,
  'numeric-keypad':    numericKeypad,
  'bottom-sheet':      bottomSheet,
  'scanner-overlay':   scannerOverlay,
  forms,
  'data-tables':       dataTables,
  navigation:          navigationPage,
  'card-comp':         cardComp,
  charts,
};

/* ── TYPOGRAPHY PLAYGROUND GLOBALS ───────────────────────── */
let pgState = { size: 20, weight: 600, ls: -4, color: '#191919', bg: '#FFFFFF', script: 'latin' };

const PG_SCRIPTS = {
  latin: {
    font:        'Inter, sans-serif',
    fontDisplay: 'Montserrat, sans-serif',
    dir:         'ltr',
    sampleText:  'The quick brown fox jumps over the lazy dog',
    lsDefault:   -4,
  },
  arabic: {
    font:        'Inter, sans-serif',
    fontDisplay: 'Alexandria, sans-serif',
    dir:         'rtl',
    sampleText:  'النظام السريع للتخطيط والمتابعة',
    lsDefault:   0,
  },
};

function updatePlayground() {
  const sizeEl = document.getElementById('pg-size');
  const lsEl   = document.getElementById('pg-ls');
  const text   = document.getElementById('pg-text');
  const canvas = document.getElementById('pg-canvas');
  if (!text || !canvas) return;

  if (sizeEl) pgState.size = +sizeEl.value;
  if (lsEl)   pgState.ls   = +lsEl.value;

  const script = PG_SCRIPTS[pgState.script] || PG_SCRIPTS.latin;
  const useDisplay = pgState.size >= 18;
  text.style.fontFamily    = useDisplay ? script.fontDisplay : script.font;
  text.style.fontSize      = pgState.size + 'px';
  text.style.fontWeight    = pgState.weight;
  text.style.lineHeight    = 'normal';
  text.style.letterSpacing = (pgState.ls / 100) + 'em';
  text.style.color         = pgState.color;
  text.style.direction     = script.dir;
  text.style.textAlign     = script.dir === 'rtl' ? 'right' : 'left';
  canvas.style.background  = pgState.bg;

  const sizeValEl = document.getElementById('pg-size-val');
  const lsValEl   = document.getElementById('pg-ls-val');
  if (sizeValEl) sizeValEl.textContent = pgState.size + 'px';
  if (lsValEl)   lsValEl.textContent   = pgState.ls + '%';
}

function setSlider(id, val) {
  const el = document.getElementById(id);
  if (el) el.value = val;
}

function setScript(script, btn) {
  pgState.script = script;
  document.querySelectorAll('.pg-tab').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  const cfg = PG_SCRIPTS[script];
  const text = document.getElementById('pg-text');
  if (text && !text.dataset.edited) text.textContent = cfg.sampleText;
  pgState.ls = cfg.lsDefault;
  setSlider('pg-ls', cfg.lsDefault);
  updatePlayground();
}

function setWeightFromSelect(val) {
  pgState.weight = +val;
  updatePlayground();
}

function setColor(hex, _token, btn) {
  pgState.color = hex;
  document.querySelectorAll('.pg-color-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  updatePlayground();
}

function setBg(hex, textColor, btn) {
  pgState.bg    = hex;
  pgState.color = textColor;
  document.querySelectorAll('.pg-bg-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  updatePlayground();
}

function applyPreset(idx) {
  document.querySelectorAll('.pg-preset').forEach(b => b.classList.remove('active'));
  const activeBtn = document.querySelector('.pg-preset[data-idx="' + idx + '"]');
  if (activeBtn) activeBtn.classList.add('active');
  if (idx === -1) return;
  const r = TYPE_ROLES[idx];
  if (!r) return;
  pgState.size   = r.fs;
  pgState.weight = r.fw;
  pgState.ls     = pgState.script === 'arabic' ? 0 : r.ls;
  pgState.color  = r.brand ? '#430098' : r.muted ? '#757575' : '#191919';
  setSlider('pg-size', r.fs);
  setSlider('pg-ls', pgState.ls);
  document.querySelectorAll('.pg-weight-btn').forEach(b => b.classList.toggle('active', +b.dataset.weight === r.fw));
  const sel = document.getElementById('pg-weight-select');
  if (sel) sel.value = String(r.fw);
  document.querySelectorAll('.pg-color-btn').forEach((b, i) => b.classList.toggle('active', i === 0));
  document.querySelectorAll('.pg-bg-btn').forEach((b, i) => b.classList.toggle('active', i === 0));
  pgState.bg = '#FFFFFF';
  updatePlayground();
}

function initPlayground() {
  if (!document.getElementById('pg-text')) return;
  pgState = { size: 20, weight: 600, ls: -4, color: '#191919', bg: '#FFFFFF', script: 'latin' };
  document.querySelectorAll('.pg-script-btn').forEach((b, i) => b.classList.toggle('active', i === 0));
  document.querySelectorAll('.pg-tab').forEach((b, i) => b.classList.toggle('active', i === 0));
  const sel = document.getElementById('pg-weight-select');
  if (sel) sel.value = '600';
  const text = document.getElementById('pg-text');
  if (text) { text.textContent = PG_SCRIPTS.latin.sampleText; delete text.dataset.edited; }
  setSlider('pg-size', 20);
  setSlider('pg-ls', -4);
  updatePlayground();
}

/* ── NAVIGATION ───────────────────────────────────────────── */
let currentPage = 'overview';

function buildNav() {
  const nav = document.getElementById('sidebar-nav');
  nav.innerHTML = NAV.map(section => `
    <div class="nav-section">
      <div class="nav-section-label">${section.label}</div>
      ${section.items.map(item => `
        <div class="nav-item ${item.id === currentPage ? 'active' : ''}"
             onclick="navigate('${item.id}')"
             data-id="${item.id}">
          <span class="nav-item-icon">${item.icon}</span>
          ${item.label}
          ${item.badge ? `<span class="nav-item-badge">${item.badge}</span>` : ''}
          ${item.tag ? `<span class="nav-item-tag ${item.tag}">${item.tag}</span>` : ''}
        </div>`).join('')}
    </div>`).join('');
}

function navigate(id) {
  currentPage = id;

  // Update nav active state
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.id === id);
  });

  // Find nav item info
  let pageInfo = null;
  for (const section of NAV) {
    const found = section.items.find(i => i.id === id);
    if (found) { pageInfo = { section: section.label, ...found }; break; }
  }

  // Render page
  const container = document.getElementById('page-container');
  const renderFn = PAGES[pageInfo?.page || id] || PAGES[id];
  if (renderFn) {
    container.innerHTML = `<div class="page active" id="page-${id}">${renderFn()}</div>`;
    // Re-execute any <script> tags injected via innerHTML (browsers skip them by default)
    container.querySelectorAll('script').forEach(function(old) {
      var s = document.createElement('script');
      s.textContent = old.textContent;
      old.parentNode.replaceChild(s, old);
    });
    // Store initial HTML for toast section refresh
    container.querySelectorAll('[data-toast-stage]').forEach(function(stage) {
      _toastStageInit[stage.id] = stage.innerHTML;
    });
  }

  // Update breadcrumb
  if (pageInfo) {
    document.getElementById('breadcrumb').innerHTML = `
      <span>${pageInfo.section}</span>
      <span class="topbar-breadcrumb-sep">›</span>
      <span class="topbar-breadcrumb-current">${pageInfo.label}</span>`;
  }

  // Update URL hash — silently fails in sandboxed iframes
  try { history.replaceState(null, '', `#${id}`); } catch (_) {}

  // Init playground if on typography page
  if (id === 'typography') setTimeout(initPlayground, 0);

  // Init input page listeners
  if (id === 'input') setTimeout(initInputPage, 0);

  // Build on-this-page rail
  setTimeout(buildOnThisPage, 0);

  // Scroll to top
  window.scrollTo({ top: 0 });
}

/* ── COPY CODE ────────────────────────────────────────────── */
function copyHex(hex, el) {
  navigator.clipboard.writeText(hex).then(() => {
    const hint = el.querySelector('.prim-copy-hint');
    const hexEl = el.querySelector('.prim-hex');
    if (hint) { hint.textContent = 'Copied!'; hint.style.opacity = '1'; }
    if (hexEl) hexEl.style.opacity = '0';
    el.style.outline = '2px solid #430098';
    el.style.outlineOffset = '-2px';
    setTimeout(() => {
      if (hint) { hint.textContent = 'Copy'; hint.style.opacity = ''; }
      if (hexEl) hexEl.style.opacity = '';
      el.style.outline = '';
    }, 1200);
  });
}

function copyCode(btn) {
  const pre = btn.closest('.code-block').querySelector('pre');
  const text = pre.innerText || pre.textContent;
  navigator.clipboard.writeText(text).then(() => {
    btn.textContent = 'Copied!';
    setTimeout(() => btn.textContent = 'Copy', 2000);
  });
}

/* ── ON THIS PAGE RAIL ───────────────────────────────────── */
function buildOnThisPage() {
  const otpNav = document.getElementById('otp-nav');
  const otpEl  = document.getElementById('on-this-page');
  if (!otpNav || !otpEl) return;

  const inner = document.querySelector('.content-inner');
  const headings = document.querySelectorAll('#page-container .doc-section-title');
  if (headings.length < 2) {
    otpNav.innerHTML = '';
    otpEl.style.visibility = 'hidden';
    if (inner) inner.style.gridTemplateColumns = '1fr';
    return;
  }
  otpEl.style.visibility = 'visible';
  if (inner) inner.style.gridTemplateColumns = '1fr 220px';

  const links = [];
  headings.forEach((h, i) => {
    const id = 'otp-section-' + i;
    const section = h.closest('.doc-section');
    if (section) section.id = id;
    links.push({ id, text: h.textContent.trim() });
  });

  otpNav.innerHTML = links.map(l =>
    '<div class="otp-link" data-id="' + l.id + '" onclick="scrollToSection(\'' + l.id + '\')">' + l.text + '</div>'
  ).join('');

  // Remove old scroll listener
  if (window._otpListener) window.removeEventListener('scroll', window._otpListener, true);

  const listener = () => {
    let active = links[0]?.id;
    links.forEach(l => {
      const el = document.getElementById(l.id);
      if (el && el.getBoundingClientRect().top < 130) active = l.id;
    });
    document.querySelectorAll('.otp-link').forEach(el => {
      el.classList.toggle('active', el.dataset.id === active);
    });
  };
  window._otpListener = listener;
  window.addEventListener('scroll', listener, { passive: true, capture: true });
  setTimeout(listener, 50);
}

function scrollToSection(id) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ── SEARCH (simple filter) ───────────────────────────────── */
function initSearch() {
  const input = document.getElementById('nav-search');
  if (!input) return;
  input.addEventListener('input', () => {
    const q = input.value.toLowerCase().trim();
    document.querySelectorAll('.nav-item').forEach(el => {
      const text = el.textContent.toLowerCase();
      el.style.display = q && !text.includes(q) ? 'none' : '';
    });
    document.querySelectorAll('.nav-section').forEach(sec => {
      const hasVisible = [...sec.querySelectorAll('.nav-item')].some(el => el.style.display !== 'none');
      sec.style.display = q && !hasVisible ? 'none' : '';
    });
  });
}

/* ── COLOR TAB / MODE ─────────────────────────────────────── */
function copyColorHex(row) {
  const isDark = document.querySelector('.ctoken-mode-btn[data-mode="dark"]')?.classList.contains('active');
  const hex = isDark ? row.dataset.hexDark : row.dataset.hexLight;
  if (!hex) return;
  navigator.clipboard.writeText(hex).then(() => {
    const prev = row.querySelector('.ctoken-prim-main');
    if (!prev) return;
    const original = prev.textContent;
    prev.textContent = 'Copied!';
    prev.style.color = '#148F47';
    row.style.background = '#F2FDF6';
    setTimeout(() => {
      prev.textContent = original;
      prev.style.color = '';
      row.style.background = '';
    }, 1400);
  });
}

function setColorTab(group, btn) {
  document.querySelectorAll('.ctoken-tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.ctoken-row').forEach(row => {
    row.style.display = (group === 'all' || row.dataset.group === group) ? '' : 'none';
  });
}

function setSizingTab(group, btn) {
  document.querySelectorAll('.ctoken-tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.ctoken-row').forEach(row => {
    row.style.display = (group === 'all' || row.dataset.group === group) ? '' : 'none';
  });
}

/* ── SELECT INTERACTIVE CONTROLLER ──────────────────────── */
const SEL_PLACEHOLDERS = {
  default: 'Select an option',
  label:   'Select a category',
  icon:    'Select a type',
  search:  'Search options…',
  sm: 'Select…', md: 'Select…', lg: 'Select…',
};

function selOpen(section) {
  const field = document.getElementById('sel-field-' + section);
  const drop  = document.getElementById('sel-drop-'  + section);
  const chev  = document.getElementById('sel-chev-'  + section);
  const icon  = document.getElementById('sel-icon-'  + section);
  const srch  = document.getElementById('sel-srch-'  + section);
  if (!field || !drop) return;
  field.style.borderColor = '#C7B3E0';
  field.style.boxShadow   = '0 0 0 3px rgba(199,179,224,.25)';
  if (chev) { chev.style.color = '#C7B3E0'; chev.style.transform = 'rotate(180deg)'; }
  if (icon) icon.style.color = '#C7B3E0';
  if (srch) srch.style.color = '#C7B3E0';
  drop.style.display = 'block';
}

function selClose(section) {
  const field = document.getElementById('sel-field-' + section);
  const drop  = document.getElementById('sel-drop-'  + section);
  const chev  = document.getElementById('sel-chev-'  + section);
  const icon  = document.getElementById('sel-icon-'  + section);
  const srch  = document.getElementById('sel-srch-'  + section);
  if (!field || !drop) return;
  field.style.borderColor = '#E6E6E6';
  field.style.boxShadow   = '';
  if (chev) { chev.style.color = '#757575'; chev.style.transform = ''; }
  if (icon) icon.style.color = '#757575';
  if (srch) srch.style.color = '#757575';
  drop.style.display = 'none';
}

function selToggle(section) {
  const drop = document.getElementById('sel-drop-' + section);
  if (!drop) return;
  const isOpen = drop.style.display !== 'none';
  // Close all open selects
  document.querySelectorAll('[id^="sel-drop-"]').forEach(d => {
    if (d.style.display !== 'none') selClose(d.id.replace('sel-drop-', ''));
  });
  // Also restore any disabled search fields
  selSearchClose();
  if (!isOpen) selOpen(section);
}

function selSelect(section, value) {
  // Update option rows: highlight selected, clear others
  const drop = document.getElementById('sel-drop-' + section);
  if (drop) {
    drop.querySelectorAll('[data-val]').forEach(row => {
      const isSel = row.dataset.val === value;
      row.dataset.selected      = isSel ? 'true' : 'false';
      row.style.background      = isSel ? '#F7F4FB' : '';
      const chk = row.querySelector('.sel-opt-chk');
      if (chk) chk.style.display = isSel ? 'flex' : 'none';
      const lbl = row.querySelector('.sel-opt-label');
      if (lbl) lbl.style.color = isSel ? '#430098' : '#474747';
    });
  }
  const val = document.getElementById('sel-val-' + section);
  if (val) { val.textContent = value; val.style.color = '#191919'; }
  selClose(section);
  selSearchClose();
}

// Search variant: swap span↔input on open/close
function selOpenSearch() {
  const drop  = document.getElementById('sel-drop-search');
  if (!drop) return;
  const isOpen = drop.style.display !== 'none';
  // Close all other open selects
  document.querySelectorAll('[id^="sel-drop-"]').forEach(d => {
    if (d !== drop && d.style.display !== 'none') selClose(d.id.replace('sel-drop-', ''));
  });
  if (isOpen) { selSearchClose(); return; }
  // Open: swap placeholder span → input
  const span  = document.getElementById('sel-val-search');
  const input = document.getElementById('sel-search-input');
  if (span)  span.style.display  = 'none';
  if (input) { input.style.display = 'block'; setTimeout(() => input.focus(), 0); }
  selOpen('search');
}

function selSearchClose() {
  const span  = document.getElementById('sel-val-search');
  const input = document.getElementById('sel-search-input');
  if (input && input.style.display !== 'none') {
    input.style.display = 'none';
    input.value = '';
    if (span) span.style.display = '';
    // Restore all option rows
    const drop = document.getElementById('sel-drop-search');
    if (drop) drop.querySelectorAll('[data-opt]').forEach(r => r.style.display = '');
  }
}

function selFilterOpts(query) {
  const drop = document.getElementById('sel-drop-search');
  if (!drop) return;
  const q = query.toLowerCase();
  drop.querySelectorAll('[data-opt]').forEach(row => {
    const label = row.dataset.opt.toLowerCase();
    row.style.display = label.includes(q) ? '' : 'none';
  });
}

function selState(section, state) {
  const field = document.getElementById('sel-field-' + section);
  const val   = document.getElementById('sel-val-'   + section);
  const lbl   = document.getElementById('sel-lbl-'   + section);
  const hint  = document.getElementById('sel-hint-'  + section);
  if (!field) return;

  const ph = SEL_PLACEHOLDERS[section] || 'Select an option';

  // Close & reset
  selClose(section);
  selSearchClose();
  field.style.opacity       = '1';
  field.style.pointerEvents = '';
  field.style.cursor        = 'pointer';
  if (val)  { val.textContent = ph; val.style.color = '#A3A3A3'; val.style.display = ''; }
  if (lbl)  lbl.style.color  = '#5E5E5E';
  if (hint) hint.style.color = '#A3A3A3';
  // Clear any selected option highlights
  const drop = document.getElementById('sel-drop-' + section);
  if (drop) {
    drop.querySelectorAll('[data-val]').forEach(row => {
      row.dataset.selected = 'false';
      row.style.background = '';
      const chk = row.querySelector('.sel-opt-chk');
      if (chk) chk.style.display = 'none';
      const optLbl = row.querySelector('.sel-opt-label');
      if (optLbl) optLbl.style.color = '#474747';
    });
  }

  switch (state) {
    case 'Filled':
      if (val) { val.textContent = 'Design System'; val.style.color = '#191919'; }
      break;
    case 'Opened':
      if (section === 'search') selOpenSearch();
      else selOpen(section);
      break;
    case 'Disabled': {
      field.style.opacity       = '.5';
      field.style.pointerEvents = 'none';
      field.style.cursor        = 'not-allowed';
      const chev = document.getElementById('sel-chev-' + section);
      const icon = document.getElementById('sel-icon-' + section);
      const srch = document.getElementById('sel-srch-' + section);
      if (chev) chev.style.color = '#D1D1D1';
      if (icon) icon.style.color = '#D1D1D1';
      if (srch) srch.style.color = '#D1D1D1';
      if (lbl)  lbl.style.color  = '#D1D1D1';
      if (hint) hint.style.color = '#D1D1D1';
      break;
    }
  }
}

/* ── TOGGLE INTERACTIVE CONTROLLER ──────────────────────────── */
function tglSet(id, on) {
  const track = document.getElementById('tgl-track-' + id);
  const thumb = document.getElementById('tgl-thumb-' + id);
  if (!track || !thumb) return;
  const isSm = track.dataset.size === 'sm';
  const w  = isSm ? 36 : 48;
  const ts = isSm ? 16 : 20;
  track.dataset.checked  = on ? 'true' : 'false';
  track.style.background = on ? 'var(--toggle-track-bg-on)' : 'var(--toggle-track-bg-off)';
  const hasFocus = track.style.boxShadow.includes('var(--toggle-focus-ring)');
  track.style.boxShadow = hasFocus ? '0 0 0 4px var(--toggle-focus-ring)' : 'none';
  thumb.style.left = on ? (w - ts - 2) + 'px' : '2px';
}

function tglToggle(id) {
  const track = document.getElementById('tgl-track-' + id);
  if (!track || track.style.pointerEvents === 'none') return;
  tglSet(id, track.dataset.checked !== 'true');
}

function tglState(id, state) {
  const track = document.getElementById('tgl-track-' + id);
  const thumb = document.getElementById('tgl-thumb-' + id);
  const wrap  = document.getElementById('tgl-wrap-'  + id);
  const lbl   = document.getElementById('tgl-lbl-'   + id);
  const sub   = document.getElementById('tgl-sub-'   + id);
  if (!track || !thumb) return;

  // Reset
  track.style.opacity      = '1';
  track.style.pointerEvents = '';
  track.style.boxShadow    = '';
  track.style.cursor       = 'pointer';
  if (wrap) wrap.style.pointerEvents = '';
  if (lbl)  lbl.style.color = 'var(--toggle-text-label)';
  if (sub)  sub.style.color = 'var(--toggle-text-supporting)';

  const on = state === 'On' || state === 'Focused On' || state === 'Disabled On';
  tglSet(id, on);

  if (state === 'Focused Off' || state === 'Focused On') {
    track.style.boxShadow = '0 0 0 4px var(--toggle-focus-ring)';
  }
  if (state === 'Disabled Off' || state === 'Disabled On') {
    track.style.opacity       = '.5';
    track.style.pointerEvents = 'none';
    track.style.cursor        = 'not-allowed';
    if (wrap) wrap.style.pointerEvents = 'none';
    if (lbl)  lbl.style.color = 'var(--toggle-text-label-disabled)';
    if (sub)  sub.style.color = 'var(--toggle-text-supporting-disabled)';
  }
}

/* ── TOAST INTERACTIVE CONTROLLER ───────────────────────────── */
const TOAST_ICONS = {
  default: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`,
  success: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`,
  warning: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
  error:   `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`,
  loading: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>`,
};
const TOAST_CFG = {
  default: { color: 'var(--toast-icon-default)', title: 'Just a heads up'        },
  success: { color: 'var(--toast-icon-success)', title: 'Changes saved'           },
  warning: { color: 'var(--toast-icon-warning)', title: 'Approaching limit'       },
  error:   { color: 'var(--toast-icon-error)',   title: 'Something went wrong'    },
  loading: { color: 'var(--toast-icon-loading)', title: 'Processing your request' },
};
const TOAST_CLOSE = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;

let _toastTimer     = null;
let _toastMode      = 'dark';
const _toastStageInit = {};

const _TOAST_DARK_VARS = ['--toast-bg','--toast-text-title','--toast-text-description',
  '--toast-close-default','--toast-close-hover','--toast-action-text-default',
  '--toast-action-text-hover','--toast-action-bg-default','--toast-action-bg-hover',
  '--toast-action-border-default','--toast-action-border-hover'];

function toastSectionMode(stageId, mode) {
  const stage = document.getElementById(stageId);
  if (!stage) return;
  const isLight = mode === 'light';

  // Sync mode buttons in the containing section
  const section = stage.closest('.inp-section-demo');
  if (section) {
    section.querySelectorAll('[data-mode-btn]').forEach(function(btn) {
      const active = btn.dataset.modeBtn === mode;
      btn.style.background = active ? (mode === 'dark' ? '#191919' : 'var(--background-default)') : 'var(--background-surface)';
      btn.style.color      = active ? (mode === 'dark' ? '#fff'    : 'var(--content-primary)')    : 'var(--content-secondary)';
      btn.style.fontWeight = active ? '600' : '400';
    });
  }

  if (isLight) {
    stage.style.setProperty('--toast-bg',                   'var(--background-default)');
    stage.style.setProperty('--toast-text-title',           'var(--content-primary)');
    stage.style.setProperty('--toast-text-description',     'var(--content-secondary)');
    stage.style.setProperty('--toast-close-default',        'var(--content-tertiary)');
    stage.style.setProperty('--toast-close-hover',          'var(--content-secondary)');
    stage.style.setProperty('--toast-action-text-default',  'var(--content-primary)');
    stage.style.setProperty('--toast-action-text-hover',    'var(--content-primary)');
    stage.style.setProperty('--toast-action-bg-default',    'var(--background-subtle)');
    stage.style.setProperty('--toast-action-bg-hover',      'var(--background-subtle)');
    stage.style.setProperty('--toast-action-border-default','var(--border-default)');
    stage.style.setProperty('--toast-action-border-hover',  'var(--border-default)');
    stage.querySelectorAll('[data-toast]').forEach(function(t) {
      t.style.boxShadow = '0 4px 24px rgba(0,0,0,.1),0 1px 4px rgba(0,0,0,.06)';
      t.style.border    = '1px solid var(--border-subtle)';
    });
  } else {
    _TOAST_DARK_VARS.forEach(function(p) { stage.style.removeProperty(p); });
    stage.querySelectorAll('[data-toast]').forEach(function(t) {
      t.style.boxShadow = '0 4px 16px rgba(0,0,0,.25)';
      t.style.border    = '';
    });
  }

  // For the live-trigger stage, also store mode for future toasts
  if (stageId === 'toast-demo-stage') _toastMode = mode;
}

function toastSectionRefresh(stageId) {
  const stage = document.getElementById(stageId);
  if (!stage) return;

  // Restore initial HTML
  if (_toastStageInit[stageId]) stage.innerHTML = _toastStageInit[stageId];

  // Remove any CSS variable overrides (reset to dark)
  _TOAST_DARK_VARS.forEach(function(p) { stage.style.removeProperty(p); });

  // Reset mode buttons to Dark
  const section = stage.closest('.inp-section-demo');
  if (section) {
    section.querySelectorAll('[data-mode-btn]').forEach(function(btn) {
      const isDark = btn.dataset.modeBtn === 'dark';
      btn.style.background = isDark ? '#191919' : 'var(--background-surface)';
      btn.style.color      = isDark ? '#fff'    : 'var(--content-secondary)';
      btn.style.fontWeight = isDark ? '600'     : '400';
    });
  }

  // Clear live toast timer
  if (_toastTimer) { clearTimeout(_toastTimer); _toastTimer = null; }
  if (stageId === 'toast-demo-stage') _toastMode = 'dark';
}

function toastSetMode(mode) {
  toastSectionMode('toast-demo-stage', mode);
}

function toastTrigger(type) {
  const stage = document.getElementById('toast-demo-stage');
  if (!stage) return;
  const prev = document.getElementById('toast-live');
  if (prev) prev.remove();
  if (_toastTimer) clearTimeout(_toastTimer);

  const cfg = TOAST_CFG[type] || TOAST_CFG.default;
  const icon = TOAST_ICONS[type] || TOAST_ICONS.default;

  const wrap = document.createElement('div');
  wrap.id = 'toast-live';
  wrap.style.cssText = 'position:absolute;bottom:16px;right:16px;opacity:0;transform:translateY(8px);transition:opacity .2s,transform .2s;pointer-events:auto';
  wrap.innerHTML = `<div data-toast style="display:flex;align-items:flex-start;gap:12px;padding:12px 16px;border-radius:8px;background:var(--toast-bg);width:300px;box-shadow:0 4px 16px rgba(0,0,0,.25)">
    <span style="display:inline-flex;align-items:center;color:${cfg.color};flex-shrink:0;margin-top:1px">${icon}</span>
    <div style="flex:1;font-family:Inter,sans-serif;font-size:14px;font-weight:600;color:var(--toast-text-title);line-height:1.4">${cfg.title}</div>
    <button onclick="document.getElementById('toast-live').remove()"
      style="display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:24px;height:24px;border-radius:4px;border:none;background:transparent;color:var(--toast-close-default);cursor:pointer;transition:color .12s;margin-left:4px"
      onmouseenter="this.style.color='var(--toast-close-hover)'" onmouseleave="this.style.color='var(--toast-close-default)'"
    >${TOAST_CLOSE}</button>
  </div>`;
  stage.appendChild(wrap);

  requestAnimationFrame(() => { wrap.style.opacity = '1'; wrap.style.transform = 'translateY(0)'; });

  _toastTimer = setTimeout(() => {
    wrap.style.opacity = '0';
    wrap.style.transform = 'translateY(8px)';
    setTimeout(() => { if (wrap.parentNode) wrap.remove(); }, 200);
  }, 3000);
}

/* ── TAB INTERACTIVE CONTROLLER ─────────────────────────────── */
const TAB_V = {
  underline: {
    default: { color: 'var(--tab-underline-item-text-default)', bg: 'var(--tab-underline-item-bg-default)', borderColor: 'transparent' },
    hover:   { color: 'var(--tab-underline-item-text-hover)',   bg: 'var(--tab-underline-item-bg-hover)',   borderColor: 'var(--tab-underline-indicator-hover)' },
    active:  { color: 'var(--tab-underline-item-text-active)',  bg: 'var(--tab-underline-item-bg-active)',  borderColor: 'var(--tab-underline-indicator-active)' },
  },
  line: {
    default: { color: 'var(--tab-line-item-text-default)', bg: 'var(--tab-line-item-bg-default)', borderColor: 'transparent' },
    hover:   { color: 'var(--tab-line-item-text-hover)',   bg: 'var(--tab-line-item-bg-hover)',   borderColor: 'var(--tab-line-indicator-hover)' },
    active:  { color: 'var(--tab-line-item-text-active)',  bg: 'var(--tab-line-item-bg-active)',  borderColor: 'var(--tab-line-indicator-active)' },
  },
  border: {
    default: { color: 'var(--tab-button-border-item-text-default)', bg: 'var(--tab-button-border-item-bg-default)', borderColor: null },
    hover:   { color: 'var(--tab-button-border-item-text-hover)',   bg: 'var(--tab-button-border-item-bg-hover)',   borderColor: null },
    active:  { color: 'var(--tab-button-border-item-text-active)',  bg: 'var(--tab-button-border-item-bg-active)',  borderColor: null },
  },
  gray: {
    default: { color: 'var(--tab-button-gray-item-text-default)', bg: 'var(--tab-button-gray-item-bg-default)', borderColor: null },
    hover:   { color: 'var(--tab-button-gray-item-text-hover)',   bg: 'var(--tab-button-gray-item-bg-hover)',   borderColor: null },
    active:  { color: 'var(--tab-button-gray-item-text-active)',  bg: 'var(--tab-button-gray-item-bg-active)',  borderColor: null },
  },
  brand: {
    default: { color: 'var(--tab-button-brand-item-text-default)', bg: 'var(--tab-button-brand-item-bg-default)', borderColor: null },
    hover:   { color: 'var(--tab-button-brand-item-text-hover)',   bg: 'var(--tab-button-brand-item-bg-hover)',   borderColor: null },
    active:  { color: 'var(--tab-button-brand-item-text-active)',  bg: 'var(--tab-button-brand-item-bg-active)',  borderColor: null },
  },
};

function tabApply(el, variant, stateName) {
  const s = TAB_V[variant] && TAB_V[variant][stateName];
  if (!s) return;
  el.style.color      = s.color;
  el.style.background = s.bg;
  if (s.borderColor !== null) el.style.borderBottomColor = s.borderColor;
  el.dataset.state = stateName;
  const bdg = el.querySelector('[data-tab-badge]');
  if (bdg) {
    bdg.style.background = stateName === 'active' ? 'var(--tab-badge-bg-active)' : stateName === 'hover' ? 'var(--tab-badge-bg-hover)' : 'var(--tab-badge-bg-default)';
    bdg.style.color      = stateName === 'active' ? 'var(--tab-badge-text-active)' : stateName === 'hover' ? 'var(--tab-badge-text-hover)' : 'var(--tab-badge-text-default)';
  }
}

function tabSet(containerId, idx) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const variant = container.dataset.variant;
  container.querySelectorAll('[data-tab]').forEach((item, i) => {
    if (item.dataset.disabled === 'true') return;
    tabApply(item, variant, i === idx ? 'active' : 'default');
  });
}

function tabHover(el, on) {
  if (el.dataset.state === 'active' || el.dataset.disabled === 'true') return;
  const container = el.closest('[data-variant]');
  if (!container) return;
  tabApply(el, container.dataset.variant, on ? 'hover' : 'default');
}

/* ── PAGINATION INTERACTIVE CONTROLLER ──────────────────────── */
function pgHover(el, on) {
  if (el.dataset.state === 'disabled' || el.dataset.state === 'active') return;
  const isNum = el.dataset.type === 'num';
  el.style.background  = on ? 'var(--pagination-button-bg-hover)' : (isNum ? 'transparent' : 'var(--pagination-button-bg-default)');
  el.style.color       = on ? 'var(--pagination-button-text-hover)'   : 'var(--pagination-button-text-default)';
  el.style.borderColor = on ? 'var(--pagination-button-border-hover)' : (isNum ? 'transparent' : 'var(--pagination-button-border-default)');
}

function _buildNums(cid, page, total) {
  const DOT = `<span style="display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;font-family:Inter,sans-serif;font-size:13px;color:var(--pagination-ellipsis)">...</span>`;
  function nb(p) {
    const isActive = p === page;
    const tc = isActive ? 'var(--pagination-button-text-active)'   : 'var(--pagination-button-text-default)';
    const bc = isActive ? 'var(--pagination-button-border-active)' : 'transparent';
    const bg = isActive ? 'var(--pagination-button-bg-active)'     : 'transparent';
    const hov = !isActive ? ` onmouseenter="pgHover(this,true)" onmouseleave="pgHover(this,false)"` : '';
    const clk = !isActive ? ` onclick="pgGo('${cid}',${p})"` : '';
    return `<button data-pg="${p}" data-type="num" data-state="${isActive ? 'active' : 'default'}"
      style="display:inline-flex;align-items:center;justify-content:center;min-width:28px;height:28px;padding:0 4px;border-radius:6px;border:1px solid ${bc};background:${bg};font-family:Inter,sans-serif;font-size:13px;font-weight:500;color:${tc};cursor:${isActive ? 'default' : 'pointer'};transition:background .12s,border-color .12s,color .12s"${hov}${clk}>${p}</button>`;
  }
  if (total <= 7) return Array.from({length: total}, (_, i) => nb(i + 1)).join('');
  const win = [];
  for (let p = Math.max(2, page - 1); p <= Math.min(total - 1, page + 1); p++) win.push(p);
  let html = nb(1);
  if (!win.length || win[0] > 2) html += DOT;
  win.forEach(p => { html += nb(p); });
  if (!win.length || win[win.length - 1] < total - 1) html += DOT;
  html += nb(total);
  return html;
}

function pgGo(cid, page) {
  const container = document.getElementById(cid);
  if (!container) return;
  const total = parseInt(container.dataset.total);
  page = Math.max(1, Math.min(page, total));
  container.dataset.page = page;

  // Re-render numbered strip if present
  const numStrip = document.getElementById(cid + '-nums');
  if (numStrip) numStrip.innerHTML = _buildNums(cid, page, total);

  // Update prev/next nav buttons
  container.querySelectorAll('[data-pg="prev"],[data-pg="next"]').forEach(btn => {
    const isPrev = btn.dataset.pg === 'prev';
    const dis = isPrev ? page <= 1 : page >= total;
    btn.style.color       = dis ? 'var(--pagination-button-text-disabled)' : 'var(--pagination-button-text-default)';
    btn.style.borderColor = dis ? 'var(--pagination-button-border-disabled)' : 'var(--pagination-button-border-default)';
    btn.style.background  = 'var(--pagination-button-bg-default)';
    btn.style.cursor      = dis ? 'not-allowed' : 'pointer';
    btn.dataset.state     = dis ? 'disabled' : 'default';
    btn.onclick           = dis ? null : isPrev ? () => pgPrev(cid) : () => pgNext(cid);
  });

  const info = document.getElementById(cid + '-info');
  if (info) info.textContent = `Page ${page} of ${total}`;
}

function pgPrev(cid) {
  const c = document.getElementById(cid);
  if (c) pgGo(cid, parseInt(c.dataset.page) - 1);
}

function pgNext(cid) {
  const c = document.getElementById(cid);
  if (c) pgGo(cid, parseInt(c.dataset.page) + 1);
}

function pgPerPageToggle(cid, event) {
  if (event) event.stopPropagation();
  const drop = document.getElementById(cid + '-pp-drop');
  if (!drop) return;
  const isOpen = drop.style.display !== 'none';
  document.querySelectorAll('[id$="-pp-drop"]').forEach(d => { d.style.display = 'none'; });
  if (!isOpen) drop.style.display = 'block';
}

function pgSetPerPage(cid, val) {
  const drop    = document.getElementById(cid + '-pp-drop');
  const ppLabel = document.getElementById(cid + '-pp-label');
  if (drop)    drop.style.display = 'none';
  if (ppLabel) ppLabel.textContent = val + ' per page';
  const container = document.getElementById(cid);
  if (container) {
    const totalItems = parseInt(container.dataset.totalItems || 100);
    container.dataset.total = Math.ceil(totalItems / val);
    pgGo(cid, 1);
  }
}

/* ── BREADCRUMB INTERACTIVE CONTROLLER ──────────────────────── */
function bcHover(el, on) {
  el.style.color = on ? 'var(--breadcrumb-text-hover)' : 'var(--breadcrumb-text-default)';
}

function bcSetView(v) {
  const coll = document.getElementById('bc-collapsed');
  const expd = document.getElementById('bc-expanded');
  if (coll) coll.style.display = v === 'Collapsed' ? 'inline-flex' : 'none';
  if (expd) expd.style.display = v === 'Expanded'  ? 'inline-flex' : 'none';
}

/* ── DROPDOWN INTERACTIVE CONTROLLER ────────────────────────── */
function ddOpen(section) {
  const panel   = document.getElementById('dd-panel-'   + section);
  const trigger = document.getElementById('dd-trigger-' + section);
  if (!panel) return;
  panel.style.display = 'block';
  if (trigger) { trigger.style.background = '#F6F6F6'; trigger.style.borderColor = '#A3A3A3'; }
}

function ddClose(section) {
  const panel   = document.getElementById('dd-panel-'   + section);
  const trigger = document.getElementById('dd-trigger-' + section);
  if (!panel) return;
  panel.style.display = 'none';
  if (trigger) { trigger.style.background = 'var(--background-surface)'; trigger.style.borderColor = 'var(--border-default)'; }
}

function ddToggle(section) {
  const panel = document.getElementById('dd-panel-' + section);
  if (!panel) return;
  const isOpen = panel.style.display !== 'none';
  document.querySelectorAll('[id^="dd-panel-"]').forEach(d => {
    if (d.style.display !== 'none') ddClose(d.id.replace('dd-panel-', ''));
  });
  if (!isOpen) ddOpen(section);
}

function ddCheckItem(el, _section, _label) {
  const isChecked = el.dataset.selected === 'true';
  el.dataset.selected = isChecked ? 'false' : 'true';
  el.style.background = isChecked ? '' : '#FAFAFA';
  const chkIcon = el.querySelector('.dd-chk-icon');
  const chkLbl  = el.querySelector('.dd-chk-label');
  if (chkIcon) chkIcon.style.display = isChecked ? 'none' : 'flex';
  if (chkLbl)  chkLbl.style.color    = isChecked ? '#474747' : '#191919';
}

/* ── BADGE STATE CONTROLLER ─────────────────────────────────── */
const BADGE_STYLES = {
  default:     { Default: {bg:'#430098',text:'#FFFFFF',border:'#430098'}, Hover: {bg:'#561AA2',text:'#FFFFFF',border:'#561AA2'}, Disabled: {bg:'#430098',text:'#FFFFFF',border:'#430098',opacity:'.5'} },
  secondary:   { Default: {bg:'#F7F4FB',text:'#430098',border:'#D9CCEA'}, Hover: {bg:'#ECE6F5',text:'#430098',border:'#C7B3E0'}, Disabled: {bg:'#F7F4FB',text:'#430098',border:'#D9CCEA',opacity:'.5'} },
  destructive: { Default: {bg:'#FFF2F4',text:'#D8192C',border:'#E87580'}, Hover: {bg:'#FBE8EA',text:'#D8192C',border:'#DC3041'}, Disabled: {bg:'#FFF2F4',text:'#D8192C',border:'#E87580',opacity:'.5'} },
  outline:     { Default: {bg:'#FFFFFF',text:'#430098',border:'#C7B3E0'}, Hover: {bg:'#F7F4FB',text:'#430098',border:'#430098'}, Disabled: {bg:'#FFFFFF',text:'#430098',border:'#C7B3E0',opacity:'.5'} },
  ghost:       { Default: {bg:'transparent',text:'#430098',border:'transparent'}, Hover: {bg:'#ECE6F5',text:'#430098',border:'transparent'}, Disabled: {bg:'transparent',text:'#430098',border:'transparent',opacity:'.5'} },
};

function badgeState(variant, state) {
  const el = document.getElementById('badge-' + variant);
  if (!el) return;
  const s = BADGE_STYLES[variant]?.[state];
  if (!s) return;
  el.style.background    = s.bg;
  el.style.color         = s.text;
  el.style.borderColor   = s.border;
  el.style.opacity       = s.opacity || '1';
  el.style.pointerEvents = s.opacity ? 'none' : '';
  el.style.cursor        = s.opacity ? 'not-allowed' : 'default';
}

function setColorMode(mode) {
  document.querySelectorAll('.ctoken-mode-btn').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
  document.querySelectorAll('.light-swatch').forEach(el => el.style.display = mode === 'light' ? '' : 'none');
  document.querySelectorAll('.dark-swatch').forEach(el => el.style.display = mode === 'dark' ? '' : 'none');
  document.querySelectorAll('.light-hex').forEach(el => el.style.display = mode === 'light' ? '' : 'none');
  document.querySelectorAll('.dark-hex').forEach(el => el.style.display = mode === 'dark' ? '' : 'none');
}

function setTypeScript(script, _btn) {
  document.querySelectorAll('.ctoken-mode-btn[data-script]').forEach(b => b.classList.toggle('active', b.dataset.script === script));
  // Re-render rows using typeRows helper
  const container = document.getElementById('type-rows-container');
  if (container) {
    // Import typeRows dynamically to avoid circular issues — use inline reimplementation
    const WEIGHT_NAMES = { 400: 'Regular', 500: 'Medium', 600: 'SemiBold', 700: 'Bold', 800: 'ExtraBold' };
    container.innerHTML = TYPE_ROLES.map(r => {
      const color = r.brand ? '#430098' : r.muted ? '#757575' : '#191919';
      const arFw = r.arFw || r.fw;
      if (script === 'arabic') {
        const arFont = r.arFs >= 18 ? 'Alexandria' : 'Inter';
        const arabicStyle = 'font-family:' + arFont + ',sans-serif;font-size:' + r.arFs + 'px;font-weight:' + arFw + ';letter-spacing:0%;color:' + color + ';direction:rtl;text-align:right;';
        const sizeTag = '<span class="type-spec-val">' + r.arFs + 'px</span>';
        return '<div class="type-row">' +
          '<div><span class="type-token-pill">' + r.token + '</span></div>' +
          '<div class="type-specs-col">' +
            '<div class="type-spec-item">' + sizeTag + '<span class="type-spec-key">size</span></div>' +
            '<div class="type-spec-item"><span class="type-spec-val">' + WEIGHT_NAMES[arFw] + '</span><span class="type-spec-key">weight</span></div>' +
            '<div class="type-spec-item"><span class="type-spec-val">' + arFont + '</span><span class="type-spec-key">font</span></div>' +
          '</div>' +
          '<div class="type-preview"><span style="' + arabicStyle + '">' + r.arPreview + '</span></div>' +
          '<div class="type-usage">' + r.use + '</div>' +
          '</div>';
      } else {
        const latinFont = r.fs >= 18 ? 'Montserrat' : 'Inter';
        const latinStyle = 'font-family:' + latinFont + ',sans-serif;font-size:' + r.fs + 'px;font-weight:' + r.fw + ';letter-spacing:' + r.ls + '%;color:' + color + ';' + (r.italic ? 'font-style:italic' : '');
        return '<div class="type-row">' +
          '<div><span class="type-token-pill">' + r.token + '</span></div>' +
          '<div class="type-specs-col">' +
            '<div class="type-spec-item"><span class="type-spec-val">' + r.fs + 'px</span><span class="type-spec-key">size</span></div>' +
            '<div class="type-spec-item"><span class="type-spec-val">' + WEIGHT_NAMES[r.fw] + '</span><span class="type-spec-key">weight</span></div>' +
            '<div class="type-spec-item"><span class="type-spec-val">' + latinFont + '</span><span class="type-spec-key">font</span></div>' +
            (r.italic ? '<div class="type-spec-item"><span class="type-spec-val">italic</span><span class="type-spec-key">style</span></div>' : '') +
          '</div>' +
          '<div class="type-preview"><span style="' + latinStyle + '">' + r.preview + '</span></div>' +
          '<div class="type-usage">' + r.use + '</div>' +
          '</div>';
      }
    }).join('');
  }
}

function setPrimTab(group, btn) {
  document.querySelectorAll('.ctoken-tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('#prim-table .ctoken-row').forEach(row => {
    row.style.display = (group === 'all' || row.dataset.group === group) ? '' : 'none';
  });
}

function copyPrimHex(row) {
  const hex = row.dataset.hexLight;
  if (!hex) return;
  navigator.clipboard.writeText(hex).then(() => {
    const el = row.querySelector('.ctoken-prim-main');
    if (!el) return;
    const original = el.textContent;
    el.textContent = 'Copied!';
    el.style.color = '#148F47';
    row.style.background = '#F2FDF6';
    setTimeout(() => {
      el.textContent = original;
      el.style.color = '';
      row.style.background = '';
    }, 1400);
  });
}

function tokCopy(el, val) {
  navigator.clipboard.writeText(val).catch(() => {});
  el.classList.add('copied-flash');
  const tip = el.querySelector('.tok-alias-copied');
  const prev = tip.textContent;
  tip.textContent = 'Copied!';
  el.classList.add('show-tip');
  setTimeout(() => { el.classList.remove('copied-flash','show-tip'); tip.textContent = prev; }, 1200);
}

/* ── BUTTON STATE CONTROLLER ────────────────────────────────── */
const BTN_CLASS_MAP = {
  'primary':        'btn btn-primary',
  'secondary':      'btn btn-secondary',
  'secondary-gray': 'btn btn-secondary-gray',
  'ghost':          'btn btn-ghost',
  'tertiary-gray':  'btn btn-tertiary-gray',
  'destructive':    'btn btn-destructive',
  'link-color':     'btn btn-link-color',
  'link-gray':      'btn btn-link-gray',
};

const BTN_HIER_MAP = {
  'Primary':         'primary',
  'Secondary color': 'secondary',
  'Secondary gray':  'secondary-gray',
  'Ghost':           'ghost',
  'Tertiary gray':   'tertiary-gray',
  'Destructive':     'destructive',
};

const BTN_STATE_STYLES = {
  primary: {
    Default:  { style:'', extra:'' },
    Hover:    { style:'background:#561AA2;border-color:#561AA2', extra:'' },
    Active:   { style:'background:#6933AD;border-color:#6933AD', extra:'' },
    Focused:  { style:'outline:2px solid #6933AD;outline-offset:2px', extra:'' },
    Disabled: { style:'background:#B499D6;border-color:#B499D6;opacity:.5;cursor:not-allowed;pointer-events:none', extra:'' },
  },
  secondary: {
    Default:  { style:'', extra:'' },
    Hover:    { style:'background:#ECE6F5', extra:'' },
    Active:   { style:'background:#D9CCEA', extra:'' },
    Focused:  { style:'outline:2px solid #6933AD;outline-offset:2px', extra:'' },
    Disabled: { style:'opacity:.5;cursor:not-allowed;pointer-events:none', extra:'' },
  },
  'secondary-gray': {
    Default:  { style:'', extra:'' },
    Hover:    { style:'background:#F6F6F6;border-color:#A3A3A3', extra:'' },
    Active:   { style:'background:#F0F0F0;border-color:#757575', extra:'' },
    Focused:  { style:'outline:2px solid #6933AD;outline-offset:2px', extra:'' },
    Disabled: { style:'opacity:.5;cursor:not-allowed;pointer-events:none', extra:'' },
  },
  ghost: {
    Default:  { style:'', extra:'' },
    Hover:    { style:'background:#ECE6F5', extra:'' },
    Active:   { style:'background:#D9CCEA', extra:'' },
    Focused:  { style:'outline:2px solid #6933AD;outline-offset:2px', extra:'' },
    Disabled: { style:'opacity:.5;cursor:not-allowed;pointer-events:none', extra:'' },
  },
  'tertiary-gray': {
    Default:  { style:'', extra:'' },
    Hover:    { style:'background:#F6F6F6', extra:'' },
    Active:   { style:'background:#F0F0F0', extra:'' },
    Focused:  { style:'outline:2px solid #6933AD;outline-offset:2px', extra:'' },
    Disabled: { style:'opacity:.5;cursor:not-allowed;pointer-events:none', extra:'' },
  },
  destructive: {
    Default:  { style:'', extra:'' },
    Hover:    { style:'background:#FBE8EA;border-color:#DC3041', extra:'' },
    Active:   { style:'background:#F7D1D5;border-color:#D8192C', extra:'' },
    Focused:  { style:'outline:2px solid #E04756;outline-offset:2px', extra:'' },
    Disabled: { style:'opacity:.5;cursor:not-allowed;pointer-events:none', extra:'' },
  },
  'link-color': {
    Default:  { style:'', extra:'' },
    Hover:    { style:'text-decoration:underline', extra:'' },
    Active:   { style:'color:#6933AD;text-decoration:underline', extra:'' },
    Focused:  { style:'outline:2px solid #6933AD;outline-offset:2px', extra:'' },
    Disabled: { style:'opacity:.5;cursor:not-allowed;pointer-events:none', extra:'' },
  },
  'link-gray': {
    Default:  { style:'', extra:'' },
    Hover:    { style:'text-decoration:underline;color:#191919', extra:'' },
    Active:   { style:'text-decoration:underline;color:#191919', extra:'' },
    Focused:  { style:'outline:2px solid #6933AD;outline-offset:2px', extra:'' },
    Disabled: { style:'opacity:.5;cursor:not-allowed;pointer-events:none', extra:'' },
  },
};

function btnState(section, state) {
  const simpleMap = {
    'primary':        'primary',
    'secondary':      'secondary',
    'secondary-gray': 'secondary-gray',
    'ghost':          'ghost',
    'tertiary-gray':  'tertiary-gray',
    'destructive':    'destructive',
    'link-color':     'link-color',
    'link-gray':      'link-gray',
  };

  if (simpleMap[section]) {
    const btnId = 'btn-' + section;
    const btn = document.getElementById(btnId);
    if (!btn) return;
    const hier = simpleMap[section];
    btn.className = BTN_CLASS_MAP[hier];
    btn.disabled = false;
    btn.style.cssText = '';
    const s = BTN_STATE_STYLES[hier]?.[state];
    if (s) btn.style.cssText = s.style;
    if (state === 'Disabled') btn.disabled = true;
    return;
  }

  if (section === 'icon-lead' || section === 'icon-lead-hier') {
    const hierSel = document.getElementById('sel-btn-icon-lead-hier');
    const stateSel = document.getElementById('sel-btn-icon-lead');
    if (!hierSel || !stateSel) return;
    const hier = BTN_HIER_MAP[hierSel.value] || 'primary';
    const st   = stateSel.value;
    const btn  = document.getElementById('btn-icon-lead');
    if (!btn) return;
    btn.className = BTN_CLASS_MAP[hier];
    btn.disabled = false;
    btn.style.cssText = '';
    const s = BTN_STATE_STYLES[hier]?.[st];
    if (s) btn.style.cssText = s.style;
    if (st === 'Disabled') btn.disabled = true;
  }

  if (section === 'icon-trail' || section === 'icon-trail-hier') {
    const hierSel = document.getElementById('sel-btn-icon-trail-hier');
    const stateSel = document.getElementById('sel-btn-icon-trail');
    if (!hierSel || !stateSel) return;
    const hier = BTN_HIER_MAP[hierSel.value] || 'primary';
    const st   = stateSel.value;
    const btn  = document.getElementById('btn-icon-trail');
    if (!btn) return;
    btn.className = BTN_CLASS_MAP[hier];
    btn.disabled = false;
    btn.style.cssText = '';
    const s = BTN_STATE_STYLES[hier]?.[st];
    if (s) btn.style.cssText = s.style;
    if (st === 'Disabled') btn.disabled = true;
  }

  if (section === 'icon-only' || section === 'icon-only-hier') {
    const hierSel = document.getElementById('sel-btn-icon-only-hier');
    const stateSel = document.getElementById('sel-btn-icon-only');
    if (!hierSel || !stateSel) return;
    const hier = BTN_HIER_MAP[hierSel.value] || 'primary';
    const st   = stateSel.value;
    const btn  = document.getElementById('btn-icon-only');
    if (!btn) return;
    btn.className = BTN_CLASS_MAP[hier] + ' btn-icon-only';
    btn.disabled = false;
    btn.style.cssText = '';
    const s = BTN_STATE_STYLES[hier]?.[st];
    if (s) btn.style.cssText = s.style;
    if (st === 'Disabled') btn.disabled = true;
  }
}

/* ── DARK MODE TOKEN VALUES ───────────────────────────────── */
const BTN_DARK_TOKENS = {
  'brand/primary':          '#BF84FF',
  'brand/primary-hover':    '#C793FF',
  'brand/primary-active':   '#CFA3FF',
  'brand/primary-disabled': '#E7D1FF',
  'brand/primary-subtle':   '#190046',
  'brand/primary-muted':    '#47336B',
  'content/on-brand':       '#FFFFFF',
  'content/primary':        '#FFFFFF',
  'content/disabled':       '#757575',
  'border/default':         '#5E5E5E',
  'border/brand':           '#BF84FF',
  'border/focus':           '#CFA3FF',
  'status/danger-bg':       '#D8192C',
  'status/danger-border':   '#E45E6B',
  'status/danger-content':  '#E87580',
  'background/page':        '#191919',
  'background/surface':     '#303030',
  'background/subtle':      '#474747',
};

function toggleSectionMode(btn) {
  const slug = btn.dataset.section;
  const isDark = btn.classList.toggle('dark');
  const icon = btn.querySelector('.btn-section-toggle-icon');
  const label = btn.querySelector('.btn-section-toggle-label');
  const moonSVG = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
  const sunSVG  = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>';

  icon.innerHTML  = isDark ? sunSVG : moonSVG;
  label.textContent = isDark ? 'Light' : 'Dark';

  const stageBg = isDark ? '#474747' : '';
  const stage = document.querySelector(`.btn-preview-stage-themed[data-section="${slug}"]`);
  if (!stage) return;
  stage.style.background = stageBg;

  const D = BTN_DARK_TOKENS;

  stage.querySelectorAll('.btn-primary').forEach(btn => {
    if (!btn.disabled) {
      const bg = btn.style.background;
      if (isDark) {
        if (bg.includes('561AA2')) btn.style.background = D['brand/primary-hover'];
        else if (bg.includes('6933AD')) btn.style.background = D['brand/primary-active'];
        else btn.style.background = D['brand/primary'];
        btn.style.color = D['content/on-brand'];
        if (btn.style.outline) btn.style.outline = '2px solid ' + D['border/focus'];
      } else {
        if (btn.style.background === D['brand/primary-hover']) btn.style.background = '#561AA2';
        else if (btn.style.background === D['brand/primary-active']) btn.style.background = '#6933AD';
        else btn.style.background = '';
        btn.style.color = '';
        if (btn.style.outline) btn.style.outline = '2px solid #6933AD';
      }
    } else {
      btn.style.background = isDark ? D['brand/primary-disabled'] : '#B499D6';
      btn.style.color = isDark ? D['content/disabled'] : '';
    }
  });

  stage.querySelectorAll('.btn-secondary').forEach(btn => {
    if (isDark) {
      btn.style.color = D['content/primary'];
      btn.style.borderColor = D['border/default'];
      if (btn.style.background?.includes('F7F4FB')) { btn.style.background = D['brand/primary-subtle']; btn.style.borderColor = D['border/brand']; }
      else if (btn.style.background?.includes('ECE6F5')) btn.style.background = D['brand/primary-muted'];
      else btn.style.background = 'transparent';
    } else {
      btn.style.color = ''; btn.style.borderColor = '';
      btn.style.background = btn.style.background === D['brand/primary-subtle'] ? '#F7F4FB' :
                             btn.style.background === D['brand/primary-muted']   ? '#ECE6F5' : '';
    }
  });

  stage.querySelectorAll('.btn-secondary-gray').forEach(btn => {
    if (isDark) {
      btn.style.color = D['content/secondary'] || '#BABABA';
      btn.style.borderColor = D['border/default'];
      if (btn.style.background?.includes('F6F6F6')) { btn.style.background = D['background/subtle']; btn.style.borderColor = D['border/strong']; btn.style.color = D['content/primary']; }
      else btn.style.background = 'transparent';
    } else {
      btn.style.color = ''; btn.style.borderColor = ''; btn.style.background = '';
    }
  });

  stage.querySelectorAll('.btn-tertiary-gray').forEach(btn => {
    if (isDark) {
      btn.style.color = D['content/secondary'] || '#BABABA';
      if (btn.style.background?.includes('F6F6F6')) { btn.style.background = D['background/subtle']; btn.style.color = D['content/primary']; }
      else btn.style.background = 'transparent';
    } else {
      btn.style.color = ''; btn.style.background = '';
    }
  });

  stage.querySelectorAll('.btn-ghost').forEach(btn => {
    if (isDark) {
      btn.style.color = D['content/primary'];
      if (btn.style.background?.includes('F7F4FB')) btn.style.background = D['brand/primary-subtle'];
      else if (btn.style.background?.includes('ECE6F5')) btn.style.background = D['brand/primary-muted'];
    } else {
      btn.style.color = '';
      btn.style.background = btn.style.background === D['brand/primary-subtle'] ? '#F7F4FB' :
                             btn.style.background === D['brand/primary-muted']   ? '#ECE6F5' : '';
    }
  });

  stage.querySelectorAll('.btn-destructive').forEach(btn => {
    if (isDark) {
      btn.style.background = D['status/danger-bg'] + '22';
      btn.style.borderColor = D['status/danger-border'];
      btn.style.color = D['status/danger-content'];
    } else {
      btn.style.background = ''; btn.style.borderColor = ''; btn.style.color = '';
    }
  });

  stage.querySelectorAll('.btn-link-color').forEach(btn => { btn.style.color = isDark ? D['brand/primary'] : ''; });
  stage.querySelectorAll('.btn-link-gray').forEach(btn => { btn.style.color = isDark ? '#BABABA' : ''; });
  stage.querySelectorAll('.btn-state-label').forEach(el => { el.style.color = isDark ? '#5A5A72' : ''; });
  stage.querySelectorAll('.btn-spinner-dark').forEach(el => {
    if (isDark) { el.style.borderColor = 'rgba(191,132,255,.2)'; el.style.borderTopColor = D['brand/primary']; }
    else { el.style.borderColor = ''; el.style.borderTopColor = ''; }
  });
}

/* ── CHECKBOX STATE CONTROLLER ─────────────────────────────── */
function cbState(sid) {
  // sid may be like 'main-type', 'main-state', etc. — extract the prefix
  const parts = sid.split('-');
  // The section prefix is everything except the last part
  const prefix = parts.slice(0, -1).join('-');

  const get = k => { const el = document.getElementById('sel-cb-' + k); return el ? el.value : null; };

  const typeVal  = get(prefix + '-type')    || 'Checkbox';
  const stateVal = get(prefix + '-state')   || 'Default';
  const sizeVal  = get(prefix + '-size')    || 'MD';
  const chkVal   = get(prefix + '-checked') || 'Unchecked';

  const wrap    = document.getElementById('cb-wrap-'    + prefix);
  const inp     = document.getElementById('cb-inp-'     + prefix);
  const box     = document.getElementById('cb-box-'     + prefix);
  const iconEl  = document.getElementById('cb-icon-'    + prefix);
  if (!wrap || !inp || !box) return;

  inp.checked = (chkVal === 'Checked');

  const px     = sizeVal === 'SM' ? 16 : 20;
  const iconPx = sizeVal === 'SM' ? 12 : 14;
  const sw     = sizeVal === 'SM' ? 1.67 : 2;
  const radMap = { Checkbox: sizeVal==='SM'?4:6, Radio: sizeVal==='SM'?8:10, 'Check circle': sizeVal==='SM'?10:10 };
  box.style.width        = px + 'px';
  box.style.height       = px + 'px';
  box.style.borderRadius = (radMap[typeVal] || 4) + 'px';
  inp.style.width  = px + 'px';
  inp.style.height = px + 'px';

  box.classList.remove('cb-circle');
  if (typeVal === 'Check circle') box.classList.add('cb-circle');

  if (iconEl) {
    iconEl.style.width  = iconPx + 'px';
    iconEl.style.height = iconPx + 'px';
    const iconColor = typeVal === 'Check circle' ? '#FFFFFF' : '#430098';
    if (typeVal === 'Radio') {
      const dotPx = sizeVal === 'SM' ? 6 : 8;
      iconEl.innerHTML = `<span class="cb-radio-dot" style="width:${dotPx}px;height:${dotPx}px;border-radius:50%;background:${iconColor};display:block"></span>`;
    } else {
      iconEl.innerHTML = `<svg width="${iconPx}" height="${iconPx}" viewBox="0 0 ${iconPx} ${iconPx}" fill="none" stroke="${iconColor}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round"><path d="M${(iconPx*.14).toFixed(1)} ${(iconPx*.5).toFixed(1)} L${(iconPx*.4).toFixed(1)} ${(iconPx*.76).toFixed(1)} L${(iconPx*.86).toFixed(1)} ${(iconPx*.24).toFixed(1)}"/></svg>`;
    }
  }

  box.classList.remove('cb-s-hover','cb-s-focused','cb-s-disabled');
  wrap.classList.remove('cb-disabled');
  if (stateVal === 'Hover')    box.classList.add('cb-s-hover');
  if (stateVal === 'Focused')  box.classList.add('cb-s-focused');
  if (stateVal === 'Disabled') { box.classList.add('cb-s-disabled'); wrap.classList.add('cb-disabled'); }
}

/* ── INPUT STATE CONTROLLER ──────────────────────────────── */
const INP_EYE_ON  = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;
const INP_EYE_OFF = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`;
const INP_ALRT    = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;

function inpState(section, state) {
  if (section === 'default') {
    const inp = document.getElementById('inp-default');
    const wrap = document.getElementById('wrap-default');
    const hint = document.getElementById('hint-default');
    inp.disabled = false; inp.className = 'inp-field'; inp.style.borderColor=''; inp.style.boxShadow=''; inp.value='';
    hint.className='inp-hint'; hint.textContent='This is a hint text to help the user.'; wrap.style.opacity='1';
    if (state==='Filled') inp.value='Value text';
    if (state==='Focused') { inp.style.borderColor='#C7B3E0'; inp.style.boxShadow='0 0 0 3px rgba(199,179,224,.25)'; inp.value='Value text'; inp.focus(); return; }
    if (state==='Disabled') { wrap.style.opacity='.5'; inp.disabled=true; }
  }
  if (section === 'icon') {
    const field=document.getElementById('inp-icon-field'), inpEl=document.getElementById('inp-icon-input'), svg=document.getElementById('inp-icon-svg');
    field.style.borderColor=''; field.style.boxShadow=''; field.style.opacity='1'; field.style.pointerEvents=''; svg.style.color=''; inpEl.value='';
    if (state==='Filled') inpEl.value='Design system';
    if (state==='Focused') { field.style.borderColor='#C7B3E0'; field.style.boxShadow='0 0 0 3px rgba(199,179,224,.25)'; svg.style.color='#C7B3E0'; inpEl.value='Design system'; inpEl.focus(); return; }
    if (state==='Disabled') { field.style.opacity='.5'; field.style.pointerEvents='none'; }
  }
  if (section === 'destructive') {
    const inp=document.getElementById('inp-destructive');
    inp.className='inp-field inp-error'; inp.style.boxShadow=''; inp.value='not-an-email';
    if (state==='Focused error') { inp.style.boxShadow='0 0 0 3px rgba(224,71,86,.16)'; inp.focus(); }
  }
  if (section === 'help') {
    const inp=document.getElementById('inp-help'), hint=document.getElementById('hint-help');
    inp.className='inp-field'; inp.value='';
    if (state==='Default') { inp.placeholder='XX-XXXXXXX'; hint.className='inp-hint'; hint.textContent='Enter your employer identification number.'; }
    if (state==='Error') { inp.className='inp-field inp-error'; inp.value='123'; hint.className='inp-hint-error'; hint.innerHTML=INP_ALRT+' Invalid format. Use XX-XXXXXXX.'; }
  }
  if (section === 'leadingtext') {
    const inp=document.getElementById('inp-leadingtext'), addon=document.getElementById('addon-leadingtext'), wrap=document.getElementById('wrap-leadingtext');
    inp.className='inp-field inp-joined-left'; inp.style.borderColor=''; inp.style.boxShadow=''; addon.style.borderColor=''; wrap.style.opacity='1'; inp.disabled=false;
    if (state==='Default') { inp.value=''; inp.placeholder='yourcompany.com'; }
    if (state==='Focused') { inp.style.borderColor='#C7B3E0'; inp.style.boxShadow='0 0 0 3px rgba(199,179,224,.25)'; addon.style.borderColor='#C7B3E0'; inp.focus(); return; }
    if (state==='Error') { inp.className='inp-field inp-joined-left inp-error'; inp.value='bad url'; addon.style.borderColor='var(--status-danger-border)'; }
    if (state==='Disabled') { wrap.style.opacity='.5'; inp.disabled=true; }
  }
  if (section === 'leadingdd') {
    const inp=document.getElementById('inp-leadingdd'), dd=document.getElementById('dd-leading'), wrap=document.getElementById('wrap-leadingdd');
    inp.className='inp-field inp-joined-left'; inp.style.borderColor=''; inp.style.boxShadow=''; dd.style.borderColor=''; wrap.style.opacity='1'; inp.disabled=false; dd.disabled=false;
    if (state==='Default') inp.value='';
    if (state==='Focused') { inp.style.borderColor='#C7B3E0'; inp.style.boxShadow='0 0 0 3px rgba(199,179,224,.25)'; dd.style.borderColor='#C7B3E0'; inp.focus(); return; }
    if (state==='Disabled') { wrap.style.opacity='.5'; inp.disabled=true; dd.disabled=true; }
  }
  if (section === 'trailingdd') {
    const inp=document.getElementById('inp-trailingdd'), dd=document.getElementById('dd-trailing'), hint=document.getElementById('hint-trailingdd');
    inp.className='inp-field inp-joined-right'; inp.style.borderColor=''; inp.style.boxShadow=''; dd.style.borderColor=''; hint.style.display='none';
    if (state==='Default') { inp.value=''; inp.placeholder='0.00'; }
    if (state==='Focused') { inp.style.borderColor='#C7B3E0'; inp.style.boxShadow='0 0 0 3px rgba(199,179,224,.25)'; dd.style.borderColor='#C7B3E0'; inp.focus(); return; }
    if (state==='Error') { inp.className='inp-field inp-joined-right inp-error'; inp.value='abc'; dd.style.borderColor='var(--status-danger-border)'; hint.style.display='flex'; hint.className='inp-hint-error'; hint.innerHTML=INP_ALRT+' Numbers only.'; }
  }
  if (section === 'password') {
    const inp=document.getElementById('inp-password'), btn=document.getElementById('pw-eye-btn'), hint=document.getElementById('hint-password');
    inp.type='password'; inp.className='inp-field'; inp.style.boxShadow=''; btn.style.color=''; btn.innerHTML=INP_EYE_ON;
    btn.onclick=function(){ inp.type=inp.type==='password'?'text':'password'; btn.innerHTML=inp.type==='password'?INP_EYE_ON:INP_EYE_OFF; inp.focus(); };
    inp.onfocus=function(){ btn.style.color='#C7B3E0'; }; inp.onblur=function(){ btn.style.color=''; };
    if (state==='Default') { inp.value=''; hint.className='inp-hint'; hint.textContent='Must be at least 8 characters.'; }
    if (state==='Error') { inp.className='inp-field inp-error'; inp.value='123'; hint.className='inp-hint-error'; hint.innerHTML=INP_ALRT+' Password must be at least 8 characters.'; }
  }
  if (section === 'tags') {
    const field=document.getElementById('inp-tags-field'), pills=document.getElementById('inp-tags-pills'), hint=document.getElementById('hint-tags');
    field.className='inp-field inp-tags'; field.style.display='flex'; field.style.borderColor=''; field.style.boxShadow=''; hint.className='inp-hint';
    if (state==='Empty') { pills.innerHTML=''; hint.textContent='Press Enter or comma to add a skill.'; }
    if (state==='With tags') { pills.innerHTML=['Figma','Design system'].map(t=>'<span class="inp-tag-pill" style="margin-right:4px">'+t+' <span class="inp-tag-remove" onclick="this.parentNode.remove()">×</span></span>').join(''); hint.textContent=''; }
    if (state==='Error') { field.className='inp-field inp-tags inp-error'; field.style.display='flex'; pills.innerHTML='<span class="inp-tag-pill" style="margin-right:4px">Figma <span class="inp-tag-remove" onclick="this.parentNode.remove()">×</span></span>'; hint.className='inp-hint-error'; hint.innerHTML=INP_ALRT+' Add at least 2 skills.'; }
  }
}

function handleTagKey(e) {
  const inp=document.getElementById('inp-tags-input'), pills=document.getElementById('inp-tags-pills'), hint=document.getElementById('hint-tags');
  const val=inp.value.trim().replace(/,$/,'');
  if ((e.key==='Enter'||e.key===',')&&val) {
    e.preventDefault();
    const pill=document.createElement('span'); pill.className='inp-tag-pill'; pill.style.marginRight='4px';
    pill.innerHTML=val+' <span class="inp-tag-remove" onclick="this.parentNode.remove()">×</span>';
    pills.appendChild(pill); inp.value=''; hint.textContent='Press Enter or comma to add more.';
  }
  if (e.key==='Backspace'&&!inp.value) { const all=pills.querySelectorAll('.inp-tag-pill'); if(all.length) all[all.length-1].remove(); }
}

function initInputPage() {
  const wrap=document.getElementById('help-icon-wrap'), tip=document.getElementById('help-tooltip');
  if (wrap&&tip) { wrap.addEventListener('mouseenter',()=>tip.style.display='block'); wrap.addEventListener('mouseleave',()=>tip.style.display='none'); }
  const btn=document.getElementById('pw-eye-btn');
  if (btn) inpState('password','Default');
}

/* ── ICON TAB ─────────────────────────────────────────────── */
function switchIconTab(catIndex, btn) {
  document.querySelectorAll('.icon-tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  const cells = document.querySelectorAll('#icon-browser-grid .icon-lib-cell');
  const cats = ['Navigation & Actions', 'Editing & Content', 'Data & Files', 'Status & Feedback', 'User & Account', 'Commerce & ERP', 'UI & Layout'];
  cells.forEach(cell => {
    if (catIndex === 0) {
      cell.style.display = '';
    } else if (catIndex === -1) {
      cell.style.display = cell.dataset.rtl === 'true' ? '' : 'none';
    } else {
      cell.style.display = cell.dataset.category === cats[catIndex - 1] ? '' : 'none';
    }
  });
}

/* ── INIT ─────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  buildNav();
  initSearch();

  // Close any open select/dropdown panels when clicking outside
  document.addEventListener('click', () => {
    document.querySelectorAll('[id^="sel-drop-"]').forEach(d => {
      if (d.style.display !== 'none') {
        selClose(d.id.replace('sel-drop-', ''));
        selSearchClose();
      }
    });
    document.querySelectorAll('[id^="dd-panel-"]').forEach(d => {
      if (d.style.display !== 'none') ddClose(d.id.replace('dd-panel-', ''));
    });
  });

  // Route to hash or default
  const hash = window.location.hash.slice(1);
  navigate(hash || 'overview');
});

/* ── WINDOW GLOBALS ───────────────────────────────────────── */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const _w = /** @type {any} */ (window);
_w.navigate          = navigate;
_w.setColorTab       = setColorTab;
_w.setSizingTab      = setSizingTab;
_w.setColorMode      = setColorMode;
_w.setTypeScript     = setTypeScript;
_w.setPrimTab        = setPrimTab;
_w.copyPrimHex       = copyPrimHex;
_w.copyColorHex      = copyColorHex;
_w.copyCode          = copyCode;
_w.copyHex           = copyHex;
_w.tokCopy           = tokCopy;
_w.scrollToSection   = scrollToSection;
_w.btnState          = btnState;
_w.toggleSectionMode = toggleSectionMode;
_w.cbState           = cbState;
_w.inpState          = inpState;
_w.selOpen           = selOpen;
_w.selClose          = selClose;
_w.selToggle         = selToggle;
_w.selSelect         = selSelect;
_w.selOpenSearch     = selOpenSearch;
_w.selFilterOpts     = selFilterOpts;
_w.selState          = selState;
_w.toastTrigger       = toastTrigger;
_w.toastSetMode       = toastSetMode;
_w.toastSectionMode   = toastSectionMode;
_w.toastSectionRefresh = toastSectionRefresh;
_w.tabSet            = tabSet;
_w.tabHover          = tabHover;
_w.bcHover           = bcHover;
_w.bcSetView         = bcSetView;
_w.tglToggle         = tglToggle;
_w.tglState          = tglState;
_w.ddToggle          = ddToggle;
_w.ddClose           = ddClose;
_w.ddCheckItem       = ddCheckItem;
_w.badgeState        = badgeState;
/* ── TABLE CONTROLLER ────────────────────────────────────── */
function tblRowHover(row, on) {
  if (row.dataset.state === 'disabled') return;
  const isSelected = row.dataset.state === 'selected';
  row.style.background = on
    ? (isSelected ? 'var(--table-row-bg-selected-hover)' : 'var(--table-row-bg-hover)')
    : (isSelected ? 'var(--table-row-bg-selected)'
       : row.dataset.striped === 'true' ? 'var(--table-row-bg-striped)' : 'var(--table-row-bg-default)');
}

function tblSort(tableId, colIdx) {
  const SORT_ICO  = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m7 15 5 5 5-5M7 9l5-5 5 5"/></svg>`;
  const SORT_ASC  = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6"/></svg>`;
  const SORT_DESC = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>`;
  const table = document.getElementById(tableId);
  if (!table) return;
  const headers = table.querySelectorAll('[data-sort-col]');
  let dir = 'asc';
  headers.forEach(th => {
    const ico = th.querySelector('[data-sort-icon]');
    if (parseInt(th.dataset.sortCol) === colIdx) {
      const cur = th.dataset.sortDir || 'none';
      dir = cur === 'asc' ? 'desc' : 'asc';
      th.dataset.sortDir = dir;
      if (ico) { ico.innerHTML = dir === 'asc' ? SORT_ASC : SORT_DESC; ico.style.color = 'var(--table-header-icon-active)'; }
    } else {
      th.dataset.sortDir = 'none';
      if (ico) { ico.innerHTML = SORT_ICO; ico.style.color = 'var(--table-header-icon)'; }
    }
  });
  const tbody = table.querySelector('tbody');
  if (!tbody) return;
  const rows = Array.from(tbody.querySelectorAll('tr'));
  rows.sort((a, b) => {
    const cells = (r) => Array.from(r.querySelectorAll('td'));
    const hasCheckbox = cells(a).length > 4;
    const off = hasCheckbox ? 1 : 0;
    const av = cells(a)[colIdx + off]?.textContent?.trim() || '';
    const bv = cells(b)[colIdx + off]?.textContent?.trim() || '';
    return dir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
  });
  rows.forEach(r => tbody.appendChild(r));
}

function tblSelectRow(tableId, rowIdx, cb) {
  const row = document.getElementById(`${tableId}-row-${rowIdx}`);
  if (!row) return;
  const sel = cb.checked;
  row.dataset.state    = sel ? 'selected' : 'default';
  row.style.background = sel ? 'var(--table-row-bg-selected)' : 'var(--table-row-bg-default)';
  tblUpdateHeaderCb(tableId);
}

function tblSelectAll(tableId, headerCb) {
  const table = document.getElementById(tableId);
  if (!table) return;
  const all = table.querySelectorAll('[data-row-cb] input.cb-input');
  all.forEach((cb, idx) => {
    /** @type {HTMLInputElement} */ (cb).checked = headerCb.checked;
    const row = document.getElementById(`${tableId}-row-${idx}`);
    if (row) {
      row.dataset.state    = headerCb.checked ? 'selected' : 'default';
      row.style.background = headerCb.checked ? 'var(--table-row-bg-selected)' : 'var(--table-row-bg-default)';
    }
  });
}

function tblUpdateHeaderCb(tableId) {
  const table    = document.getElementById(tableId);
  const headerCb = /** @type {HTMLInputElement|null} */ (document.getElementById(`${tableId}-header-cb`));
  if (!table || !headerCb) return;
  const all     = /** @type {NodeListOf<HTMLInputElement>} */ (table.querySelectorAll('[data-row-cb] input.cb-input'));
  const checked = Array.from(all).filter(cb => cb.checked).length;
  headerCb.checked       = checked === all.length && all.length > 0;
  headerCb.indeterminate = checked > 0 && checked < all.length;
}

function tblActToggle(sid, btn) {
  const panel = document.getElementById('dd-panel-' + sid);
  if (!panel) return;
  const isOpen = panel.style.display !== 'none';
  document.querySelectorAll('[id^="dd-panel-"]').forEach(d => {
    if (d.style.display !== 'none') ddClose(d.id.replace('dd-panel-', ''));
  });
  if (isOpen) return;
  // move to body so it escapes any overflow/transform containing block
  if (panel.parentElement !== document.body) document.body.appendChild(panel);
  const r = btn.getBoundingClientRect();
  const cw = document.documentElement.clientWidth;
  panel.style.position = 'fixed';
  panel.style.top      = (r.bottom + 4) + 'px';
  panel.style.left     = 'auto';
  panel.style.right    = (cw - r.right) + 'px';
  ddOpen(sid);
}

/* ── MODAL CONTROLLER ────────────────────────────────────── */
function modalOpen(id) {
  const overlay = document.getElementById('modal-overlay-' + id);
  if (!overlay) return;
  overlay.style.display = 'flex';
  document.body.style.overflow = 'hidden';
  const onKey = (e) => { if (e.key === 'Escape') { modalClose(id); document.removeEventListener('keydown', onKey); } };
  document.addEventListener('keydown', onKey);
}

function modalClose(id) {
  const overlay = document.getElementById('modal-overlay-' + id);
  if (!overlay) return;
  overlay.style.display = 'none';
  document.body.style.overflow = '';
}

_w.modalOpen         = modalOpen;
_w.modalClose        = modalClose;
_w.tblActToggle      = tblActToggle;
_w.tblRowHover       = tblRowHover;
_w.tblSort           = tblSort;
_w.tblSelectRow      = tblSelectRow;
_w.tblSelectAll      = tblSelectAll;
_w.tblUpdateHeaderCb = tblUpdateHeaderCb;
_w.pgHover           = pgHover;
_w.pgGo              = pgGo;
_w.pgPrev            = pgPrev;
_w.pgNext            = pgNext;
_w.pgPerPageToggle   = pgPerPageToggle;
_w.pgSetPerPage      = pgSetPerPage;
_w.handleTagKey      = handleTagKey;
_w.switchIconTab     = switchIconTab;
_w.updatePlayground  = updatePlayground;
_w.setScript         = setScript;
_w.setWeightFromSelect = setWeightFromSelect;
_w.setColor          = setColor;
_w.setBg             = setBg;
_w.applyPreset       = applyPreset;

/* ── CHARTS PAGE CONTROLLERS ──────────────────────────────── */
const _C = { p1:'#430098', p2:'#7B4DB7', p3:'#AF65FF', g1:'#148F47', a1:'#E19614', r1:'#D8192C' };

function _buildLinePath(pts, smooth) {
  if (!smooth) return 'M' + pts.map(function(p){return p[0]+','+p[1];}).join('L');
  var d = 'M'+pts[0][0]+','+pts[0][1];
  for (var i=1; i<pts.length; i++) {
    var x0=pts[i-1][0],y0=pts[i-1][1],x1=pts[i][0],y1=pts[i][1],cx=(x0+x1)/2;
    d += ' C'+cx+','+y0+' '+cx+','+y1+' '+x1+','+y1;
  }
  return d;
}
function _linePts(data) {
  return data.map(function(v,i){ return [40+(i/(data.length-1))*320, 16+(1-v/100)*(116)]; });
}
function _areaPath(pts, baseline) {
  return _buildLinePath(pts,true)+' L'+pts[pts.length-1][0]+','+baseline+' L'+pts[0][0]+','+baseline+' Z';
}


function _makeLineSVG(data1, data2) {
  var MONTHS=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  var pts1=_linePts(data1);
  var path1=_buildLinePath(pts1,true);
  var area1=_areaPath(pts1,132);
  var gridLines = [0,25,50,75,100].map(function(v){
    var y=16+(1-v/100)*116;
    return '<line x1="40" y1="'+y+'" x2="370" y2="'+y+'" stroke="var(--border-subtle)" stroke-width="1"/>'+
      '<text x="34" y="'+(y+4)+'" text-anchor="end" font-size="9" fill="var(--content-tertiary)" font-family="var(--font-mono)">'+v+'%</text>';
  }).join('');
  var xLabels = MONTHS.map(function(m,i){
    var x=40+(i/11)*320;
    return '<text x="'+x+'" y="162" text-anchor="middle" font-size="9" fill="var(--content-tertiary)" font-family="var(--font-mono)">'+m+'</text>';
  }).join('');
  var dots1=pts1.map(function(p,i){
    return '<circle cx="'+p[0]+'" cy="'+p[1]+'" r="3" fill="'+_C.p1+'" stroke="white" stroke-width="1.5" style="cursor:pointer;transition:r 0.15s"'+
      ' onmouseenter="(function(el,e){el.setAttribute(\'r\',\'5\');var t=document.getElementById(\'lc-tt\');if(t){t.style.display=\'block\';t.style.left=(e.offsetX+8)+\'px\';t.style.top=(e.offsetY-32)+\'px\';t.querySelector(\'.lc-tt-val\').textContent=\''+data1[i]+'%\';t.querySelector(\'.lc-tt-label\').textContent=\''+MONTHS[i]+'\';}})(this,event)"'+
      ' onmouseleave="(function(el){el.setAttribute(\'r\',\'3\');var t=document.getElementById(\'lc-tt\');if(t)t.style.display=\'none\';})(this)"/>';
  }).join('');
  var sec2 = '';
  if (data2) {
    var pts2=_linePts(data2);
    sec2 = '<path d="'+_buildLinePath(pts2,true)+'" fill="none" stroke="'+_C.p3+'" stroke-width="1.5" stroke-dasharray="4,3" stroke-linecap="round" opacity="0.8"/>';
  }
  return '<svg viewBox="0 0 370 170" style="width:100%;height:auto;overflow:visible">'+
    '<defs><linearGradient id="lc-grad" x1="0" y1="0" x2="0" y2="1">'+
    '<stop offset="0%" stop-color="'+_C.p1+'" stop-opacity="0.18"/><stop offset="100%" stop-color="'+_C.p1+'" stop-opacity="0"/></linearGradient></defs>'+
    gridLines+xLabels+
    '<path d="'+area1+'" fill="url(#lc-grad)"/>'+
    sec2+
    '<path d="'+path1+'" fill="none" stroke="'+_C.p1+'" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'+
    dots1+
    '<circle cx="'+pts1[pts1.length-1][0]+'" cy="'+pts1[pts1.length-1][1]+'" r="5" fill="'+_C.p1+'" stroke="white" stroke-width="2"/>'+
    '</svg>';
}

function chartLineToggle(mode) {
  var DATA1=[28,42,38,55,48,67,72,60,80,74,88,95];
  var DATA2=[18,30,25,40,35,48,52,44,58,52,64,70];
  var stage=document.getElementById('line-chart-stage');
  var legend=document.getElementById('line-legend');
  if (!stage) return;
  var svg=stage.querySelector('svg');
  if (svg) svg.remove();
  stage.insertAdjacentHTML('afterbegin',_makeLineSVG(DATA1,mode==='compare'?DATA2:null));
  if (legend) legend.innerHTML = mode==='compare'
    ? '<div class="chart-legend-item"><div class="chart-legend-dot" style="background:'+_C.p1+'"></div>Revenue</div><div class="chart-legend-item"><div class="chart-legend-dot" style="background:'+_C.p3+'"></div>Target</div>'
    : '<div class="chart-legend-item"><div class="chart-legend-dot" style="background:'+_C.p1+'"></div>Revenue</div>';
}

function _makeBarSVG(grouped) {
  var CATS=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  var D1=[44,72,58,85,66,91,48], D2=[28,55,40,60,45,74,32];
  var W=360,H=160,PAD_L=40,PAD_B=26,TOP=14;
  var cW=W-PAD_L-8, cH=H-PAD_B-TOP;
  var bgW=cW/CATS.length, barW=grouped?bgW*0.35:bgW*0.6;
  var gridLines=[0,25,50,75,100].map(function(v){
    var y=TOP+cH*(1-v/100);
    return '<line x1="40" y1="'+y+'" x2="'+(W-8)+'" y2="'+y+'" stroke="var(--border-subtle)" stroke-width="1"/>'+
      '<text x="34" y="'+(y+4)+'" text-anchor="end" font-size="9" fill="var(--content-tertiary)" font-family="var(--font-mono)">'+v+'%</text>';
  }).join('');
  var bars=CATS.map(function(c,i){
    var gx=PAD_L+i*bgW+bgW/2;
    var h1=(D1[i]/100)*cH, h2=(D2[i]/100)*cH;
    if(grouped){
      var x1=gx-barW-2, x2=gx+2;
      return '<rect x="'+x1+'" y="'+(TOP+cH-h1)+'" width="'+barW+'" height="'+h1+'" rx="3" fill="'+_C.p1+'" style="transition:opacity 0.15s" onmouseenter="this.style.opacity=\'0.8\'" onmouseleave="this.style.opacity=\'1\'"/>'+
             '<rect x="'+x2+'" y="'+(TOP+cH-h2)+'" width="'+barW+'" height="'+h2+'" rx="3" fill="'+_C.p3+'" style="transition:opacity 0.15s" onmouseenter="this.style.opacity=\'0.8\'" onmouseleave="this.style.opacity=\'1\'"/>';
    } else {
      var x=gx-barW/2;
      return '<rect x="'+x+'" y="'+(TOP+cH-h1)+'" width="'+barW+'" height="'+h1+'" rx="3" fill="'+_C.p1+'" style="transition:opacity 0.15s" onmouseenter="this.style.opacity=\'0.8\'" onmouseleave="this.style.opacity=\'1\'"/>';
    }
  }).join('');
  var xLbls=CATS.map(function(c,i){
    return '<text x="'+(PAD_L+i*bgW+bgW/2)+'" y="'+(H-8)+'" text-anchor="middle" font-size="9" fill="var(--content-tertiary)" font-family="var(--font-mono)">'+c+'</text>';
  }).join('');
  return '<svg viewBox="0 0 '+W+' '+H+'" style="width:100%;height:auto;overflow:visible">'+gridLines+xLbls+bars+'</svg>';
}

function chartBarToggle(mode) {
  var stage=document.getElementById('bar-chart-stage');
  var legend=document.getElementById('bar-legend');
  if (!stage) return;
  var svg=stage.querySelector('svg');
  if (svg) svg.remove();
  var grouped=mode==='grouped';
  stage.insertAdjacentHTML('afterbegin',_makeBarSVG(grouped));
  if (legend) legend.innerHTML = grouped
    ? '<div class="chart-legend-item"><div class="chart-legend-dot" style="background:'+_C.p1+'"></div>This week</div><div class="chart-legend-item"><div class="chart-legend-dot" style="background:'+_C.p3+'"></div>Last week</div>'
    : '<div class="chart-legend-item"><div class="chart-legend-dot" style="background:'+_C.p1+'"></div>This week</div>';
}

function _polar(cx,cy,r,a){ var rad=(a-90)*Math.PI/180; return [cx+r*Math.cos(rad),cy+r*Math.sin(rad)]; }
function _donutSlice(cx,cy,r,inner,s,e,color,id){
  var p1=_polar(cx,cy,r,s),p2=_polar(cx,cy,r,e),ip1=_polar(cx,cy,inner,s),ip2=_polar(cx,cy,inner,e);
  var large=e-s>180?1:0;
  return '<path d="M'+p1[0]+','+p1[1]+' A'+r+','+r+' 0 '+large+' 1 '+p2[0]+','+p2[1]+' L'+ip2[0]+','+ip2[1]+' A'+inner+','+inner+' 0 '+large+' 0 '+ip1[0]+','+ip1[1]+' Z" fill="'+color+'" '+(id?'id="'+id+'"':'')+' style="cursor:pointer;transition:opacity 0.15s" onmouseenter="this.style.opacity=\'0.8\'" onmouseleave="this.style.opacity=\'1\'"/>';
}

function _makeDonutSVG(size) {
  var configs={
    sm:{cx:56,cy:56,r:44,inner:28,vw:112,vh:112,fs1:16,fs2:8},
    md:{cx:80,cy:80,r:62,inner:40,vw:160,vh:160,fs1:22,fs2:9},
    lg:{cx:96,cy:96,r:78,inner:50,vw:192,vh:192,fs1:26,fs2:10}
  };
  var c=configs[size]||configs.md;
  var DATA=[{l:'Delivered',v:42,c:_C.p1},{l:'In Transit',v:28,c:_C.p3},{l:'Pending',v:18,c:_C.a1},{l:'Failed',v:12,c:_C.r1}];
  var cur=-90;
  var slices=DATA.map(function(d,i){
    var sw=(d.v/100)*360,s=cur; cur+=sw+1.5;
    return _donutSlice(c.cx,c.cy,c.r,c.inner,s,s+sw,d.c,'donut-slice-'+i);
  }).join('');
  return '<svg viewBox="0 0 '+c.vw+' '+c.vh+'" style="width:'+c.vw+'px;height:'+c.vh+'px;flex-shrink:0">'+
    slices+
    '<text x="'+c.cx+'" y="'+(c.cy-4)+'" text-anchor="middle" font-size="'+c.fs1+'" font-weight="700" fill="var(--content-primary)" font-family="var(--font-display)">100%</text>'+
    '<text x="'+c.cx+'" y="'+(c.cy+c.fs2+4)+'" text-anchor="middle" font-size="'+c.fs2+'" fill="var(--content-tertiary)" font-family="Inter,sans-serif">Orders</text>'+
    '</svg>';
}

function chartDonutToggle(size) {
  var wrap = document.getElementById('donut-svg-wrap');
  if (!wrap) return;
  var svg = wrap.querySelector('svg');
  if (svg) svg.remove();
  wrap.insertAdjacentHTML('afterbegin', _makeDonutSVG(size));
}

_w.chartLineToggle  = chartLineToggle;
_w.chartBarToggle   = chartBarToggle;
_w.chartDonutToggle = chartDonutToggle;
