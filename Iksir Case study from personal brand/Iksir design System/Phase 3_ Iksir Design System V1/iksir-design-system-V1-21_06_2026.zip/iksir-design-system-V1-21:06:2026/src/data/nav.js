import { nav,
  P_OVERVIEW, P_PRINCIPLES, P_ARCH, P_ACCESS,
  P_PRIMITIVES, P_COLORS, P_TYPO, P_SPACING, P_SIZING, P_RADIUS, P_ELEVATION, P_ICONOGRAPHY,
  P_MOB_OVR, P_RESPONSIVE, P_TOUCH, P_MOB_NAV, P_FAB_PLAT,
  P_AVATAR, P_BADGE, P_BTM_SHEET, P_BTM_TAB, P_BREADCRUMB, P_BUTTON, P_CARD, P_CHECKBOX,
  P_DROPDOWN, P_FAB, P_INPUT, P_MOB_HEADER, P_MODAL, P_NUMPAD, P_PAGINATION, P_PRIORITY,
  P_SCANNER, P_SELECT, P_TAB, P_TABLE, P_TASK_CARD, P_TOAST, P_TOGGLE, P_TOOLTIP,
  P_CHARTS, P_DATA_TABLES, P_FORMS, P_NAVIGATION, P_TEMPLATES,
  P_FIGMA, P_EXPORT, P_CHANGELOG
} from './icons.js';

export const NAV = [
  {
    label: 'Get Started',
    items: [
      { id: 'overview',     label: 'Overview',        icon: nav(P_OVERVIEW),    page: 'overview' },
      { id: 'principles',   label: 'Principles',      icon: nav(P_PRINCIPLES),  page: 'principles' },
      { id: 'architecture', label: 'Architecture',    icon: nav(P_ARCH),        page: 'architecture' },
      { id: 'accessibility',label: 'Accessibility',   icon: nav(P_ACCESS),      page: 'accessibility' },
    ]
  },
  {
    label: 'Tokens',
    items: [
      { id: 'primitives',   label: 'Primitives',      icon: nav(P_PRIMITIVES),  page: 'primitives' },
      { id: 'colors',       label: 'Colors',          icon: nav(P_COLORS),      page: 'colors',      badge: '191' },
      { id: 'typography',   label: 'Typography',      icon: nav(P_TYPO),        page: 'typography',  badge: '9' },
      { id: 'spacing',      label: 'Spacing',         icon: nav(P_SPACING),     page: 'spacing',     badge: '22' },
      { id: 'sizing',       label: 'Sizing',          icon: nav(P_SIZING),      page: 'sizing',      badge: '225' },
      { id: 'radius',       label: 'Border Radius',   icon: nav(P_RADIUS),      page: 'radius',      badge: '8' },
      { id: 'elevation',    label: 'Elevation',       icon: nav(P_ELEVATION),   page: 'elevation',   badge: '4' },
      { id: 'iconography',  label: 'Iconography',     icon: nav(P_ICONOGRAPHY), page: 'iconography', badge: '86' },
    ]
  },
  {
    label: 'Platform',
    items: [
      { id: 'mobile-overview',   label: 'Mobile Overview',     icon: nav(P_MOB_OVR),    page: 'mobile-overview' },
      { id: 'responsive',        label: 'Responsive Strategy', icon: nav(P_RESPONSIVE), page: 'responsive' },
      { id: 'touch-targets',     label: 'Touch Targets',       icon: nav(P_TOUCH),      page: 'touch-targets' },
      { id: 'mobile-navigation', label: 'Mobile Navigation',   icon: nav(P_MOB_NAV),    page: 'mobile-navigation' },
      { id: 'mobile-fab',        label: 'Floating Action Btn', icon: nav(P_FAB_PLAT),   page: 'mobile-fab' },
    ]
  },
  {
    label: 'Components',
    items: [
      { id: 'avatar',          label: 'Avatar',          icon: nav(P_AVATAR),     page: 'avatar' },
      { id: 'badge',           label: 'Badge',           icon: nav(P_BADGE),      page: 'badge' },
      { id: 'bottom-sheet',    label: 'Bottom Sheet',    icon: nav(P_BTM_SHEET),  page: 'bottom-sheet' },
      { id: 'bottom-tab-nav',  label: 'Bottom Tab Nav',  icon: nav(P_BTM_TAB),    page: 'bottom-tab-nav' },
      { id: 'breadcrumb',      label: 'Breadcrumb',      icon: nav(P_BREADCRUMB), page: 'breadcrumb' },
      { id: 'button',          label: 'Button',          icon: nav(P_BUTTON),     page: 'button' },
      { id: 'card-comp',       label: 'Card',            icon: nav(P_CARD),       page: 'card-comp' },
      { id: 'checkbox',        label: 'Checkbox',        icon: nav(P_CHECKBOX),   page: 'checkbox' },
      { id: 'dropdown',        label: 'Dropdown',        icon: nav(P_DROPDOWN),   page: 'dropdown' },
      { id: 'fab',             label: 'FAB',             icon: nav(P_FAB),        page: 'fab' },
      { id: 'input',           label: 'Input',           icon: nav(P_INPUT),      page: 'input' },
      { id: 'mobile-header',   label: 'Mobile Header',   icon: nav(P_MOB_HEADER), page: 'mobile-header' },
      { id: 'modal',           label: 'Modal',           icon: nav(P_MODAL),      page: 'modal-comp' },
      { id: 'numeric-keypad',  label: 'Numeric Keypad',  icon: nav(P_NUMPAD),     page: 'numeric-keypad' },
      { id: 'pagination',      label: 'Pagination',      icon: nav(P_PAGINATION), page: 'pagination' },
      { id: 'priority-tag',    label: 'Priority Tag',    icon: nav(P_PRIORITY),   page: 'priority-tag' },
      { id: 'scanner-overlay', label: 'Scanner Overlay', icon: nav(P_SCANNER),    page: 'scanner-overlay' },
      { id: 'select',          label: 'Select',          icon: nav(P_SELECT),     page: 'select' },
      { id: 'tab',             label: 'Tab',             icon: nav(P_TAB),        page: 'tab' },
      { id: 'table',           label: 'Table',           icon: nav(P_TABLE),      page: 'table' },
      { id: 'task-card',       label: 'Task Card',       icon: nav(P_TASK_CARD),  page: 'task-card' },
      { id: 'toast',           label: 'Toast',           icon: nav(P_TOAST),      page: 'toast' },
      { id: 'toggle',          label: 'Toggle',          icon: nav(P_TOGGLE),     page: 'toggle' },
      { id: 'tooltip',         label: 'Tooltip',         icon: nav(P_TOOLTIP),    page: 'tooltip' },
    ]
  },
  {
    label: 'Patterns',
    items: [
      { id: 'charts',      label: 'Charts',         icon: nav(P_CHARTS),      page: 'charts' },
      { id: 'data-tables', label: 'Data Tables',    icon: nav(P_DATA_TABLES), page: 'data-tables' },
      { id: 'forms',       label: 'Forms',          icon: nav(P_FORMS),       page: 'forms' },
      { id: 'navigation',  label: 'Navigation',     icon: nav(P_NAVIGATION),  page: 'navigation' },
      { id: 'templates',   label: 'Templates',      icon: nav(P_TEMPLATES),   page: 'templates' },
    ]
  },
  {
    label: 'Resources',
    items: [
      { id: 'figma',       label: 'Figma Library',  icon: nav(P_FIGMA),       page: 'figma',     tag: 'soon' },
      { id: 'export',      label: 'CSS Export',     icon: nav(P_EXPORT),      page: 'export',    tag: 'soon' },
      { id: 'changelog',   label: 'Changelog',      icon: nav(P_CHANGELOG),   page: 'changelog', tag: 'soon' },
    ]
  },
];
