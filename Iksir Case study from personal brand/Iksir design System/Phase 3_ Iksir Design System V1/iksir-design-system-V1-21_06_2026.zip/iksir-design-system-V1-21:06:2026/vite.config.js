import { defineConfig } from 'vite'

export default defineConfig({
  root: '.',
  base: '/dms-iksir-design-library/',
  build: {
    outDir: 'dist',
  },
})
