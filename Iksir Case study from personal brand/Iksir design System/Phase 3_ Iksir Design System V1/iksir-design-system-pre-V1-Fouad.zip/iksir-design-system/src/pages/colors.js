import { pageHeader } from '../utils/render.js';
import { PRIM, COLORS } from '../data/colors.js';

export default function colors() {
  const groups = [
    { id: 'brand',      label: 'Brand',      items: COLORS.brand },
    { id: 'content',    label: 'Content',    items: COLORS.content },
    { id: 'icon',       label: 'Icon',       items: COLORS.icon },
    { id: 'background', label: 'Background', items: COLORS.background },
    { id: 'border',     label: 'Border',     items: COLORS.border },
    { id: 'status',   label: 'Status',   items: COLORS.status },
    { id: 'input',    label: 'Input',    items: COLORS.input },
    { id: 'tooltip',  label: 'Tooltip',  items: COLORS.tooltip },
    { id: 'checkbox', label: 'Checkbox', items: COLORS.checkbox },
    { id: 'divider',  label: 'Divider',  items: COLORS.divider },
    { id: 'badge',    label: 'Badge',    items: COLORS.badge },
    { id: 'select',   label: 'Select',   items: COLORS.select },
    { id: 'dropdown', label: 'Dropdown', items: COLORS.dropdown },
    { id: 'toggle',      label: 'Toggle',      items: COLORS.toggle },
    { id: 'breadcrumb',  label: 'Breadcrumb',  items: COLORS.breadcrumb },
    { id: 'toast',       label: 'Toast',       items: COLORS.toast },
    { id: 'tab-badge',   label: 'Tab Badge',   items: COLORS['tab-badge'] },
    { id: 'tab-underline', label: 'Tab Underline', items: COLORS['tab-underline'] },
    { id: 'tab-line',    label: 'Tab Line',    items: COLORS['tab-line'] },
    { id: 'tab-button',  label: 'Tab Button',  items: COLORS['tab-button'] },
    { id: 'pagination',  label: 'Pagination',  items: COLORS.pagination },
    { id: 'modal',       label: 'Modal',       items: COLORS.modal },
    { id: 'table',       label: 'Table',       items: COLORS.table },
  ];
  const allItems = groups.flatMap(g => g.items.map(c => ({...c, group: g.id})));

  function colorRow(c, groupId) {
    return '<div class="ctoken-row" data-group="' + groupId + '" onclick="copyColorHex(this)" data-hex-light="' + c.light + '" data-hex-dark="' + c.dark + '" title="Click to copy hex">' +
      '<div class="ctoken-swatch-wrap">' +
        '<div class="ctoken-swatch light-swatch' + (c.border ? ' swatch-bordered' : '') + '" style="background:' + (c.alpha ? c.light : c.light) + '"></div>' +
        '<div class="ctoken-swatch dark-swatch' + (['#FFFFFF','#FAFAFA','#F7F4FB','#F7F0FF','#F2FDF6','#FEFBF6','#FFF2F4','#ECE6F5','#E7D1FF','#F0F0F0','#E1E1E1','#FDFDFD','#F6F6F6'].includes(c.dark) ? ' swatch-bordered' : '') + '" style="background:' + c.dark + ';display:none"></div>' +
      '</div>' +
      '<div class="ctoken-name">' +
        '<div class="ctoken-token">' + c.token + '</div>' +
        '<div class="ctoken-label">' + c.label + '</div>' +
      '</div>' +
      '<div class="ctoken-hex light-hex">' +
        '<div class="ctoken-prim-main">' + (PRIM[c.light] || c.light) + '</div>' +
        '<div class="ctoken-hex-sub">' + (PRIM[c.light] ? c.light : '') + '</div>' +
      '</div>' +
      '<div class="ctoken-hex dark-hex" style="display:none">' +
        '<div class="ctoken-prim-main">' + (PRIM[c.dark] || c.dark) + '</div>' +
        '<div class="ctoken-hex-sub">' + (PRIM[c.dark] ? c.dark : '') + '</div>' +
      '</div>' +
      '<div class="ctoken-use">' + (c.use || '') + '</div>' +
    '</div>';
  }

  return pageHeader('Tokens', 'Colors', 'Semantic tokens that reference primitives. Each token has Light and Dark mode values. Never use raw hex values in components.', [{val:'191',label:'Semantic tokens'},{val:'85',label:'Primitive colors'},{val:'2',label:'Modes'}]) +
  '<div class="page-body">' +

  '<div class="doc-section">' +

  // Tab bar + mode toggle
  '<div class="ctoken-toolbar">' +
    '<div class="ctoken-tabs" id="ctoken-tabs">' +
      '<button class="ctoken-tab active" data-group="all" onclick="setColorTab(this.dataset.group,this)">All <span class="ctoken-tab-count">' + allItems.length + '</span></button>' +
      groups.map(g => '<button class="ctoken-tab" data-group="' + g.id + '" onclick="setColorTab(this.dataset.group,this)">' + g.label + ' <span class="ctoken-tab-count">' + g.items.length + '</span></button>').join('') +
    '</div>' +
    '<div class="ctoken-mode-toggle" id="ctoken-mode-toggle">' +
      '<button class="ctoken-mode-btn active" data-mode="light" onclick="setColorMode(this.dataset.mode)">Light</button>' +
      '<button class="ctoken-mode-btn" data-mode="dark" onclick="setColorMode(this.dataset.mode)">Dark</button>' +
    '</div>' +
  '</div>' +

  // Table header
  '<div class="ctoken-table-head">' +
    '<div></div>' +
    '<div>Token</div>' +
    '<div>Value</div>' +
    '<div>Usage</div>' +
  '</div>' +

  // All rows
  '<div class="ctoken-table" id="ctoken-table">' +
    allItems.map(c => colorRow(c, c.group)).join('') +
  '</div>' +

  '</div>' +
  '</div>';
}
