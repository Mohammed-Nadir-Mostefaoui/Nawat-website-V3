import { pageHeader } from '../utils/render.js';
import { SIZING } from '../data/sizing.js';

const CHEV = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>`;
const SRCH = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>`;
const BOX  = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>`;
const CHK  = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12l5 5L20 7"/></svg>`;
const ALRT = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;

// Option row — pass section to make it interactive (click selects value), omit for static demos
function optRow(label, { icon=false, sub='', selected=false, disabled=false, hover=false, section=null } = {}) {
  const tc  = disabled ? 'var(--content-disabled)' : 'var(--select-option-text-default)';
  const sc  = disabled ? 'var(--content-disabled)' : 'var(--content-secondary)';
  const cur = disabled ? 'not-allowed' : 'pointer';
  const pad = sub ? 'padding:8px 12px;' : 'padding:0 12px;height:36px;';
  const esc = label.replace(/'/g, "\\'");

  let dataAttrs = '';
  let hev = '';
  let clk = '';
  let bgStyle = hover ? 'background:var(--select-option-bg-hover);' : '';
  // Check icon: interactive rows get a hidden .sel-opt-chk; static rows render immediately if selected=true
  let chkEl = selected ? `<span style="color:var(--select-option-check-icon-default);display:flex;flex-shrink:0;">${CHK}</span>` : '';

  if (section && !disabled) {
    dataAttrs = `data-val="${label}" data-selected="false"`;
    // Hover restores selected-bg on mouseleave instead of always clearing
    hev = `onmouseenter="this.style.background='var(--select-option-bg-hover)'" onmouseleave="this.style.background=this.dataset.selected==='true'?'var(--select-option-bg-hover)':''"`;
    clk = `onclick="selSelect('${section}','${esc}')"`;
    chkEl = `<span class="sel-opt-chk" style="display:none;color:var(--select-option-check-icon-default);flex-shrink:0;">${CHK}</span>`;
  } else if (!disabled && !hover) {
    hev = `onmouseenter="this.style.background='var(--select-option-bg-hover)'" onmouseleave="this.style.background=''"`;
  }

  return `<div ${dataAttrs} style="${bgStyle}display:flex;align-items:${sub ? 'flex-start' : 'center'};gap:8px;${pad}cursor:${cur};" ${hev} ${clk}>` +
    (icon ? `<span style="color:${disabled ? 'var(--content-disabled)' : 'var(--select-option-icon-default)'};display:flex;flex-shrink:0;${sub ? 'margin-top:2px;' : ''}">${BOX}</span>` : '') +
    `<span class="sel-opt-label" style="flex:1;font-size:14px;color:${tc};font-family:var(--font-body);line-height:1.4">${label}${sub ? `<br><span style="font-size:12px;color:${sc}">${sub}</span>` : ''}</span>` +
    chkEl +
    `</div>`;
}

function swatch(color, name, label, border = false) {
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${color};${border ? 'border:1px solid #E1E1E1;' : ''}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${label}</div></div></div>`;
}

function tRow({ token, ref, val, use }, i) {
  const bg = i % 2 === 0 ? 'background:var(--background-subtle);' : '';
  const vc = val + 'px';
  return `<tr style="${bg}border-bottom:1px solid var(--border-subtle)">` +
    `<td style="padding:10px 16px"><code class="tok-name">${token}</code></td>` +
    `<td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'${vc}')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">${ref}<span class="tok-alias-copied">${vc}</span></span></td>` +
    `<td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${use}</td>` +
    `</tr>`;
}

// Shared field and dropdown inline styles
const FS = 'display:flex;align-items:center;gap:8px;height:36px;padding:0 12px;background:var(--select-field-bg-default);border:1px solid var(--select-field-border-default);border-radius:8px;cursor:pointer;width:100%;user-select:none;transition:border-color .15s,box-shadow .15s;';
const DS = 'display:none;position:absolute;top:calc(100% + 4px);left:0;right:0;background:var(--select-dropdown-bg);border:1px solid var(--select-dropdown-border);border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.1);padding:4px 0;z-index:100;';

export default function select() {
  return pageHeader('Components', 'Select', 'A custom dropdown control with label, supporting text, leading icon, and search variants. Click to open — fully interactive. 4 types × 4 field states × 3 sizes — bound to <code>select/*</code> and <code>component/select/*</code> tokens.', [
    { val: '4',  label: 'Types' },
    { val: '4',  label: 'States' },
    { val: '3',  label: 'Sizes' },
    { val: '87', label: 'Tokens' },
  ]) + `<div class="page-body">

    <!-- DEFAULT -->
    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Default</h2></div>
      <p class="doc-section-desc">The baseline select field. Click the field to open the dropdown and pick an option. Use the State control to jump to a specific state including Disabled.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Default select — click to interact</span>
          <div class="inp-demo-controls">
            <span class="inp-demo-meta">State</span>
            <select class="inp-state-select" onchange="selState('default',this.value)">
              <option selected>Placeholder</option><option>Filled</option><option>Opened</option><option>Disabled</option>
            </select>
          </div>
        </div>
        <div class="inp-demo-stage" style="min-height:260px;align-items:flex-start;padding-top:40px">
          <div class="inp-demo-preview">
            <div style="position:relative;width:100%">
              <div id="sel-field-default" style="${FS}" onclick="selToggle('default'); event.stopPropagation()">
                <span id="sel-val-default" style="flex:1;font-size:14px;color:var(--select-field-placeholder-default);font-family:var(--font-body);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">Select an option</span>
                <span id="sel-chev-default" style="color:var(--select-chevron-default);display:flex;flex-shrink:0;transition:color .15s,transform .15s">${CHEV}</span>
              </div>
              <div id="sel-drop-default" style="${DS}" onclick="event.stopPropagation()">
                ${optRow('Design System',  { section:'default' })}
                ${optRow('Components',     { section:'default' })}
                ${optRow('Tokens',         { section:'default' })}
                ${optRow('Patterns',       { section:'default' })}
                ${optRow('Resources',      { section:'default' })}
              </div>
            </div>
          </div>
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#FFFFFF','select/field/bg/default','Background', true)}
          ${swatch('#E6E6E6','select/field/border/default','Border')}
          ${swatch('#A3A3A3','select/field/placeholder/default','Placeholder')}
          ${swatch('#C7B3E0','select/field/border/focus','Focus border')}
        </div>
      </div>
    </div>

    <!-- WITH LABEL & SUPPORTING TEXT -->
    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">With label & supporting text</h2></div>
      <p class="doc-section-desc">A visible label sits above the field, supporting text sits below. Always include a label for accessibility — placeholder text disappears once an option is selected.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Label + supporting text — click to interact</span>
          <div class="inp-demo-controls">
            <span class="inp-demo-meta">State</span>
            <select class="inp-state-select" onchange="selState('label',this.value)">
              <option selected>Placeholder</option><option>Filled</option><option>Opened</option><option>Disabled</option>
            </select>
          </div>
        </div>
        <div class="inp-demo-stage" style="min-height:280px;align-items:flex-start;padding-top:40px">
          <div class="inp-demo-preview">
            <div style="width:100%">
              <label id="sel-lbl-label" style="display:block;font-size:14px;font-weight:500;color:var(--select-field-label-default);margin-bottom:6px;line-height:1.4">Category</label>
              <div style="position:relative;width:100%">
                <div id="sel-field-label" style="${FS}" onclick="selToggle('label'); event.stopPropagation()">
                  <span id="sel-val-label" style="flex:1;font-size:14px;color:var(--select-field-placeholder-default);font-family:var(--font-body)">Select a category</span>
                  <span id="sel-chev-label" style="color:var(--select-chevron-default);display:flex;flex-shrink:0;transition:color .15s,transform .15s">${CHEV}</span>
                </div>
                <div id="sel-drop-label" style="${DS}" onclick="event.stopPropagation()">
                  ${optRow('Design System', { section:'label' })}
                  ${optRow('Components',    { section:'label' })}
                  ${optRow('Tokens',        { section:'label' })}
                  ${optRow('Patterns',      { section:'label' })}
                </div>
              </div>
              <div id="sel-hint-label" style="font-size:12px;color:var(--select-field-hint-default);margin-top:6px">Choose the category that best describes your project.</div>
            </div>
          </div>
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#5E5E5E','select/field/label/default','Label')}
          ${swatch('#A3A3A3','select/field/hint/default','Hint')}
          ${swatch('#D8192C','select/field/hint/error','Error hint')}
        </div>
      </div>
    </div>

    <!-- LEADING ICON -->
    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Leading icon</h2></div>
      <p class="doc-section-desc">An icon before the value aids recognition — a folder for categories, a globe for languages. The icon color transitions from <code>select/icon/default</code> to <code>select/icon/focus</code> when the field opens.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Icon leading — click to interact</span>
          <div class="inp-demo-controls">
            <span class="inp-demo-meta">State</span>
            <select class="inp-state-select" onchange="selState('icon',this.value)">
              <option selected>Placeholder</option><option>Filled</option><option>Opened</option><option>Disabled</option>
            </select>
          </div>
        </div>
        <div class="inp-demo-stage" style="min-height:260px;align-items:flex-start;padding-top:40px">
          <div class="inp-demo-preview">
            <div style="position:relative;width:100%">
              <div id="sel-field-icon" style="${FS}" onclick="selToggle('icon'); event.stopPropagation()">
                <span id="sel-icon-icon" style="color:var(--select-icon-default);display:flex;flex-shrink:0;transition:color .15s">${BOX}</span>
                <span id="sel-val-icon" style="flex:1;font-size:14px;color:var(--select-field-placeholder-default);font-family:var(--font-body)">Select a type</span>
                <span id="sel-chev-icon" style="color:var(--select-chevron-default);display:flex;flex-shrink:0;transition:color .15s,transform .15s">${CHEV}</span>
              </div>
              <div id="sel-drop-icon" style="${DS}" onclick="event.stopPropagation()">
                ${optRow('Design System', { icon:true, section:'icon' })}
                ${optRow('Components',    { icon:true, section:'icon' })}
                ${optRow('Tokens',        { icon:true, section:'icon' })}
                ${optRow('Patterns',      { icon:true, section:'icon' })}
              </div>
            </div>
          </div>
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#757575','select/icon/default','Icon default')}
          ${swatch('#474747','select/icon/focus','Icon focus')}
          ${swatch('#D1D1D1','select/icon/disabled','Icon disabled')}
        </div>
      </div>
    </div>

    <!-- SEARCH -->
    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Search</h2></div>
      <p class="doc-section-desc">When opened, the field switches to a live filter input. Use for long option lists — countries, timezones, users. The search icon is always visible as a leading indicator. Click to open and type to filter.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar">
          <span class="inp-demo-title">Search select — click to open, type to filter</span>
          <div class="inp-demo-controls">
            <span class="inp-demo-meta">State</span>
            <select class="inp-state-select" onchange="selState('search',this.value)">
              <option selected>Placeholder</option><option>Opened</option><option>Filled</option>
            </select>
          </div>
        </div>
        <div class="inp-demo-stage" style="min-height:280px;align-items:flex-start;padding-top:40px">
          <div class="inp-demo-preview">
            <div style="position:relative;width:100%">
              <div id="sel-field-search" style="${FS}" onclick="selOpenSearch(); event.stopPropagation()">
                <span id="sel-srch-search" style="color:var(--select-icon-default);display:flex;flex-shrink:0;transition:color .15s">${SRCH}</span>
                <span id="sel-val-search" style="flex:1;font-size:14px;color:var(--select-field-placeholder-default);font-family:var(--font-body)">Search options…</span>
                <input id="sel-search-input" style="display:none;border:none;outline:none;background:transparent;font-family:var(--font-body);font-size:14px;color:var(--select-field-value-default);flex:1;min-width:0;padding:0" placeholder="Type to filter…" oninput="selFilterOpts(this.value)" onclick="event.stopPropagation()" />
                <span id="sel-chev-search" style="color:var(--select-chevron-default);display:flex;flex-shrink:0;transition:color .15s,transform .15s">${CHEV}</span>
              </div>
              <div id="sel-drop-search" style="${DS}" onclick="event.stopPropagation()">
                <div data-opt="Design System">${optRow('Design System',  { section:'search' })}</div>
                <div data-opt="Components">${optRow('Components',         { section:'search' })}</div>
                <div data-opt="Tokens">${optRow('Tokens',                 { section:'search' })}</div>
                <div data-opt="Patterns">${optRow('Patterns',             { section:'search' })}</div>
                <div data-opt="Resources">${optRow('Resources',           { section:'search' })}</div>
              </div>
            </div>
          </div>
        </div>
        <div class="inp-state-strip">
          <div class="inp-state-item"><div class="inp-state-dot" style="background:var(--content-tertiary)"></div>Placeholder — search icon + hint</div>
          <div class="inp-state-item"><div class="inp-state-dot" style="background:var(--select-field-border-focus)"></div>Opened — live filter input</div>
          <div class="inp-state-item"><div class="inp-state-dot" style="background:var(--content-primary)"></div>Filled — shows selected value</div>
        </div>
      </div>
    </div>

    <!-- ERROR STATE -->
    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Error</h2></div>
      <p class="doc-section-desc">Applied after failed form validation. Red border and an inline error message signal the problem. Always pair with an actionable message — never rely on color alone.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar"><span class="inp-demo-title">Error state</span></div>
        <div class="inp-demo-stage">
          <div class="inp-demo-preview">
            <div style="width:100%">
              <label style="display:block;font-size:14px;font-weight:500;color:var(--select-field-label-default);margin-bottom:6px">Category</label>
              <div style="display:flex;align-items:center;gap:8px;height:36px;padding:0 12px;background:var(--select-field-bg-default);border:1px solid var(--select-field-border-error);border-radius:8px;cursor:pointer;width:100%">
                <span style="flex:1;font-size:14px;color:var(--select-field-placeholder-default);font-family:var(--font-body)">Select an option</span>
                <span style="color:var(--select-chevron-default);display:flex;flex-shrink:0">${CHEV}</span>
              </div>
              <div style="font-size:12px;color:var(--select-field-hint-error);margin-top:6px;display:flex;align-items:center;gap:4px">${ALRT} Please select a category to continue.</div>
            </div>
          </div>
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#E87580','select/field/border/error','Error border')}
          ${swatch('#D8192C','select/field/hint/error','Error message')}
        </div>
      </div>
    </div>

    <!-- SIZES -->
    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Sizes</h2></div>
      <p class="doc-section-desc">Three sizes matching the input and button scale. SM for compact UIs, MD as the default, LG for prominent form areas. Heights: 32/36/40px. Click any field to open it.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar"><span class="inp-demo-title">All sizes — click each field to open</span></div>
        <div class="inp-multi-stage">
          <div class="inp-multi-cell">
            <div style="position:relative;width:100%;max-width:180px">
              <div id="sel-field-sm" style="display:flex;align-items:center;gap:6px;height:32px;padding:0 10px;background:var(--select-field-bg-default);border:1px solid var(--select-field-border-default);border-radius:8px;cursor:pointer;width:100%;user-select:none;transition:border-color .15s,box-shadow .15s" onclick="selToggle('sm'); event.stopPropagation()">
                <span id="sel-val-sm" style="flex:1;font-size:12px;color:var(--select-field-placeholder-default);font-family:var(--font-body)">Select…</span>
                <span id="sel-chev-sm" style="color:var(--select-chevron-default);display:flex;flex-shrink:0;transition:color .15s,transform .15s">${CHEV}</span>
              </div>
              <div id="sel-drop-sm" style="${DS}" onclick="event.stopPropagation()">
                ${optRow('Small A', { section:'sm' })}${optRow('Small B', { section:'sm' })}${optRow('Small C', { section:'sm' })}
              </div>
            </div>
            <span class="inp-multi-label">SM — 32px · 12px</span>
          </div>
          <div class="inp-multi-cell">
            <div style="position:relative;width:100%;max-width:200px">
              <div id="sel-field-md" style="display:flex;align-items:center;gap:8px;height:36px;padding:0 12px;background:var(--select-field-bg-default);border:1px solid var(--select-field-border-default);border-radius:8px;cursor:pointer;width:100%;user-select:none;transition:border-color .15s,box-shadow .15s" onclick="selToggle('md'); event.stopPropagation()">
                <span id="sel-val-md" style="flex:1;font-size:14px;color:var(--select-field-placeholder-default);font-family:var(--font-body)">Select…</span>
                <span id="sel-chev-md" style="color:var(--select-chevron-default);display:flex;flex-shrink:0;transition:color .15s,transform .15s">${CHEV}</span>
              </div>
              <div id="sel-drop-md" style="${DS}" onclick="event.stopPropagation()">
                ${optRow('Medium A', { section:'md' })}${optRow('Medium B', { section:'md' })}${optRow('Medium C', { section:'md' })}
              </div>
            </div>
            <span class="inp-multi-label">MD — 36px · 14px (default)</span>
          </div>
          <div class="inp-multi-cell">
            <div style="position:relative;width:100%;max-width:220px">
              <div id="sel-field-lg" style="display:flex;align-items:center;gap:8px;height:40px;padding:0 16px;background:var(--select-field-bg-default);border:1px solid var(--select-field-border-default);border-radius:8px;cursor:pointer;width:100%;user-select:none;transition:border-color .15s,box-shadow .15s" onclick="selToggle('lg'); event.stopPropagation()">
                <span id="sel-val-lg" style="flex:1;font-size:16px;color:var(--select-field-placeholder-default);font-family:var(--font-body)">Select…</span>
                <span id="sel-chev-lg" style="color:var(--select-chevron-default);display:flex;flex-shrink:0;transition:color .15s,transform .15s">${CHEV}</span>
              </div>
              <div id="sel-drop-lg" style="${DS}" onclick="event.stopPropagation()">
                ${optRow('Large A', { section:'lg' })}${optRow('Large B', { section:'lg' })}${optRow('Large C', { section:'lg' })}
              </div>
            </div>
            <span class="inp-multi-label">LG — 40px · 16px</span>
          </div>
        </div>
      </div>
    </div>

    <!-- MENU OPTIONS -->
    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Menu options</h2></div>
      <p class="doc-section-desc">Each option row supports a leading icon, supporting subtext, and a trailing check for the selected state. Disabled options are fully non-interactive. Mix types only when the pattern is consistent across all rows.</p>
      <div class="inp-section-demo">
        <div class="inp-demo-toolbar"><span class="inp-demo-title">Option variants — hover each row</span></div>
        <div class="inp-demo-stage" style="align-items:flex-start">
          <div style="display:flex;gap:20px;flex-wrap:wrap;align-items:flex-start;width:100%">
            <div style="flex:1;min-width:180px">
              <div style="font-size:11px;font-weight:600;color:var(--content-tertiary);letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px;padding:0 4px">Default</div>
              <div style="background:var(--select-dropdown-bg);border:1px solid var(--select-dropdown-border);border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.08);padding:4px 0;overflow:hidden">
                ${optRow('Design System')}
                ${optRow('Components', {hover:true})}
                ${optRow('Tokens', {selected:true})}
                ${optRow('Patterns', {disabled:true})}
              </div>
            </div>
            <div style="flex:1;min-width:200px">
              <div style="font-size:11px;font-weight:600;color:var(--content-tertiary);letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px;padding:0 4px">Icon leading</div>
              <div style="background:var(--select-dropdown-bg);border:1px solid var(--select-dropdown-border);border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.08);padding:4px 0;overflow:hidden">
                ${optRow('Design System', {icon:true})}
                ${optRow('Components', {icon:true, hover:true})}
                ${optRow('Tokens', {icon:true, selected:true})}
                ${optRow('Patterns', {icon:true, disabled:true})}
              </div>
            </div>
            <div style="flex:1;min-width:220px">
              <div style="font-size:11px;font-weight:600;color:var(--content-tertiary);letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px;padding:0 4px">Supporting text</div>
              <div style="background:var(--select-dropdown-bg);border:1px solid var(--select-dropdown-border);border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.08);padding:4px 0;overflow:hidden">
                ${optRow('Design System', {sub:'Tokens & guidelines'})}
                ${optRow('Components', {sub:'UI building blocks', hover:true})}
                ${optRow('Tokens', {sub:'Design variables', selected:true})}
                ${optRow('Patterns', {sub:'Usage templates', disabled:true})}
              </div>
            </div>
          </div>
        </div>
        <div class="btn-tokens-strip">
          ${swatch('#474747','select/option-text/default','Option text')}
          ${swatch('#191919','select/option-text/hover','Hover text')}
          ${swatch('#430098','select/option-check-icon/default','Check icon')}
          ${swatch('#D1D1D1','select/option-text/disabled','Disabled text')}
        </div>
      </div>
    </div>

    <!-- COMPONENT TOKENS -->
    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
      <p class="doc-section-desc">All sizing tokens from the <code>Components</code> collection — semantic aliases of <code>Spacing</code> primitives. Hover to preview the value, click to copy.</p>
      <div class="card" style="overflow:hidden;margin-bottom:16px">
        <table class="tok-table">
          <thead><tr><th>Token</th><th>Alias → (hover for value, click to copy)</th><th>Usage</th></tr></thead>
          <tbody>${SIZING.select.map(tRow).join('')}</tbody>
        </table>
      </div>
    </div>

    <!-- PROPS -->
    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
      <table class="prop-table">
        <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
        <tbody>
          <tr><td><span class="prop-name">type</span></td><td><span class="prop-type">"default"|"icon-leading"|"avatar-leading"|"search"</span></td><td><span class="prop-default">"default"</span></td><td>Leading element displayed before the value text.</td></tr>
          <tr><td><span class="prop-name">state</span></td><td><span class="prop-type">"placeholder"|"filled"|"opened"|"disabled"</span></td><td><span class="prop-default">"placeholder"</span></td><td>Controls field appearance and dropdown visibility.</td></tr>
          <tr><td><span class="prop-name">size</span></td><td><span class="prop-type">"sm"|"md"|"lg"</span></td><td><span class="prop-default">"md"</span></td><td>Height, padding, and font size scale.</td></tr>
          <tr><td><span class="prop-name">label</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Text label displayed above the field.</td></tr>
          <tr><td><span class="prop-name">mandatory</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Appends a required indicator to the label.</td></tr>
          <tr><td><span class="prop-name">supportingText</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Hint text shown below the field.</td></tr>
          <tr><td><span class="prop-name">placeholder</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">"Select an option"</span></td><td>Displayed when no value is selected.</td></tr>
          <tr><td><span class="prop-name">value</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>The currently selected option value.</td></tr>
          <tr><td><span class="prop-name">options</span></td><td><span class="prop-type">Option[]</span></td><td><span class="prop-default">[]</span></td><td>Array of <code>{ label, value, icon?, supporting?, disabled? }</code>.</td></tr>
          <tr><td><span class="prop-name">error</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Error message shown below. Also applies error border styling.</td></tr>
          <tr><td><span class="prop-name">onChange</span></td><td><span class="prop-type">(value: string) => void</span></td><td><span class="prop-default">—</span></td><td>Called when the user selects a new option.</td></tr>
        </tbody>
      </table>
    </div>

    <!-- DO / DON'T -->
    <div class="doc-section">
      <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
      <div class="do-dont">
        <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use a Select for 5 or more options when space is limited. For 2–4 mutually exclusive options with visible context, radio buttons are faster to scan.</div></div>
        <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use a Select for binary choices. A toggle or radio pair is faster and more discoverable than opening a dropdown for yes/no.</div></div>
        <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Enable the Search variant for lists over 10 items. Letting users type filters reduces cognitive load significantly and prevents endless scrolling.</div></div>
        <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't omit the label. Placeholder text disappears once an option is selected, leaving no visible context for what the field represents.</div></div>
        <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Match the Select size to adjacent inputs and buttons — SM with SM, MD with MD. Mismatched sizes create visual tension in forms.</div></div>
        <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't load options asynchronously without a loading state. An empty dropdown with no feedback is a dead end — show a spinner or skeleton rows.</div></div>
      </div>
    </div>

  </div>`;
}
