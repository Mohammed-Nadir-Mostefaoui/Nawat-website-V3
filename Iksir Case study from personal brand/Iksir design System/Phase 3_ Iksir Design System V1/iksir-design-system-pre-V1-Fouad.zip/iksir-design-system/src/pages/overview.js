import { pageHeader } from '../utils/render.js';

export default function overview() {
  return pageHeader('Get Started', 'Design foundation for everything.', 'A scalable token-first design system built for Iksir — from primitive values to components to full product patterns.', [{val:'231',label:'Variables'},{val:'6',label:'Collections'},{val:'2',label:'Modes'},{val:'60',label:'Button variants'}]) + `<div class="page-body">
    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">What's in the system</h2>
      </div>
      <p class="doc-section-desc">The system is organized in three layers — primitives, semantic tokens, and components. Everything builds on the layer below it.</p>
      <div class="overview-grid">
        <a class="overview-card" onclick="navigate('colors')">
          <div class="overview-card-icon">🎨</div>
          <div class="overview-card-title">Colors</div>
          <div class="overview-card-desc">41 semantic tokens across brand, content, background, border, icon, and status groups.</div>
          <div class="overview-card-meta">41 tokens · Light + Dark</div>
        </a>
        <a class="overview-card" onclick="navigate('typography')">
          <div class="overview-card-icon">✏️</div>
          <div class="overview-card-title">Typography</div>
          <div class="overview-card-desc">9 semantic text roles derived from real screen usage. Size, weight, line-height, letter-spacing.</div>
          <div class="overview-card-meta">9 roles · Inter + Montserrat</div>
        </a>
        <a class="overview-card" onclick="navigate('spacing')">
          <div class="overview-card-icon">📐</div>
          <div class="overview-card-title">Spacing</div>
          <div class="overview-card-desc">22-step 4pt grid. Every padding, gap, and margin value in the product.</div>
          <div class="overview-card-meta">22 steps · 0–160px</div>
        </a>
        <a class="overview-card" onclick="navigate('radius')">
          <div class="overview-card-icon">⬜</div>
          <div class="overview-card-title">Border Radius</div>
          <div class="overview-card-desc">8 semantic aliases with scale names — not component names — for maximum reusability.</div>
          <div class="overview-card-meta">8 aliases · none → full</div>
        </a>
        <a class="overview-card" onclick="navigate('elevation')">
          <div class="overview-card-icon">🌑</div>
          <div class="overview-card-title">Elevation</div>
          <div class="overview-card-desc">4 levels matching surface hierarchy — Card, Dropdown, Modal, Toast.</div>
          <div class="overview-card-meta">4 levels · Effect Styles</div>
        </a>
        <a class="overview-card" onclick="navigate('button')">
          <div class="overview-card-icon">▣</div>
          <div class="overview-card-title">Button</div>
          <div class="overview-card-desc">4 variants × 3 sizes × 5 states. The first fully token-bound component.</div>
          <div class="overview-card-meta">60 variants · Figma ready</div>
        </a>
      </div>
    </div>

    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">How to use this system</h2>
      </div>
      <div class="grid-2">
        <div class="rule-card accent">
          <div class="rule-card-title">Always use semantic tokens</div>
          <div class="rule-card-body">Never reference raw hex values or primitive tokens in components. Use <code>brand/primary</code> not <code>#430098</code>. This is what makes the system maintainable and mode-switchable.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Follow the primitive → semantic chain</div>
          <div class="rule-card-body">Primitives define the raw values. Semantics define the intent. Components consume semantics. Never skip a layer — it breaks the single-source-of-truth principle.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Light + Dark is built in</div>
          <div class="rule-card-body">Every semantic token has both Light and Dark values. Use the Semantic collection's mode switcher in Figma — never maintain two separate color sets.</div>
        </div>
        <div class="rule-card accent">
          <div class="rule-card-title">Build components from this doc</div>
          <div class="rule-card-body">Every component page includes exact token references, prop tables, states, and do/don't guidance. These are the requirements — not suggestions.</div>
        </div>
      </div>
    </div>
  </div>`;
}
