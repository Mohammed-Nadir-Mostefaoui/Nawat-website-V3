import { pageHeader } from '../utils/render.js';
import { SIZING } from '../data/sizing.js';

const SEP    = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>`;
const HOME   = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>`;
const FOLDER = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>`;
const FILE   = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>`;

function bcSep() {
  return `<span style="display:inline-flex;align-items:center;color:var(--breadcrumb-separator);flex-shrink:0">${SEP}</span>`;
}

function bcItem(label, { id, active, icon } = {}) {
  const color  = active ? 'var(--breadcrumb-text-active)' : 'var(--breadcrumb-text-default)';
  const weight = active ? '600' : '500';
  const cursor = active ? 'default' : 'pointer';
  const idAttr = id ? ` id="${id}"` : '';
  const iconHtml = icon ? `<span style="display:inline-flex;align-items:center;color:inherit">${icon}</span>` : '';
  const hover = active ? '' : ` onmouseenter="bcHover(this,true)" onmouseleave="bcHover(this,false)"`;
  return `<span${idAttr} style="display:inline-flex;align-items:center;gap:4px;font-family:Inter,sans-serif;font-size:14px;font-weight:${weight};color:${color};cursor:${cursor};user-select:none;transition:color .12s"${hover}>${iconHtml}${label}</span>`;
}

function bcEllipsis() {
  return `<button onclick="bcSetView('Expanded')"
    style="display:inline-flex;align-items:center;justify-content:center;width:28px;height:20px;border-radius:4px;font-size:13px;font-weight:600;color:var(--breadcrumb-text-default);cursor:pointer;background:transparent;border:1px solid var(--border-subtle);letter-spacing:2px;padding:0"
    onmouseenter="this.style.background='var(--background-subtle)'"
    onmouseleave="this.style.background='transparent'">···</button>`;
}

function bcTrail(items) {
  return `<nav style="display:inline-flex;align-items:center;gap:4px">${
    items.map(it => bcItem(it.label, { id: it.id, active: it.active, icon: it.icon })).join(bcSep())
  }</nav>`;
}

function tRow(t, i) {
  const bg = i % 2 === 0 ? 'background:var(--background-subtle);' : '';
  const vc = t.val >= 9999 ? '9999px' : t.val + 'px';
  return `<tr style="${bg}border-bottom:1px solid var(--border-subtle)">
    <td style="padding:10px 16px"><code class="tok-name">${t.token}</code></td>
    <td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'${vc}')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">${t.ref}<span class="tok-alias-copied">${vc}</span></span></td>
    <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${t.use}</td>
  </tr>`;
}

export default function breadcrumb() {
  return pageHeader('Components', 'Breadcrumb', "Hierarchical navigation trail showing the user's current location. Ancestor items are clickable links; the rightmost item is the non-interactive current page.", [
    { val: '1',  label: 'Size' },
    { val: String(SIZING.breadcrumb.length), label: 'Size tokens' },
    { val: '7',  label: 'Color tokens' },
  ]) + `<div class="page-body">

  <!-- DEFAULT -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Default</h2></div>
    <p class="doc-section-desc">Text-only trail. Hover any ancestor link to see the hover color. The rightmost item uses the brand active color and is not clickable.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">Breadcrumb — hover links to preview state</span>
      </div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:72px">
        ${bcTrail([
          { label: 'Home' },
          { label: 'Products' },
          { label: 'Current Page', active: true },
        ])}
      </div>
      <div class="btn-tokens-strip">
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#8C8C8C;"></div><div><div class="btn-token-name">breadcrumb/text/default</div><div class="btn-token-label">Link — default</div></div></div>
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#474747;"></div><div><div class="btn-token-name">breadcrumb/text/hover</div><div class="btn-token-label">Link — hover</div></div></div>
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#430098;"></div><div><div class="btn-token-name">breadcrumb/text/active</div><div class="btn-token-label">Current page</div></div></div>
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#E1E1E1;border:1px solid #D1D1D1;"></div><div><div class="btn-token-name">breadcrumb/separator</div><div class="btn-token-label">Separator chevron</div></div></div>
      </div>
    </div>
  </div>

  <!-- WITH ICON -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">With icon</h2></div>
    <p class="doc-section-desc">Each item can carry a 14px leading icon. The icon uses <code>currentColor</code> and transitions through default → hover → active states automatically — no separate icon color token is needed in usage.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">With leading icons — hover to preview</span>
      </div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:72px">
        ${bcTrail([
          { label: 'Home',         icon: HOME },
          { label: 'Products',     icon: FOLDER },
          { label: 'Current Page', icon: FILE, active: true },
        ])}
      </div>
      <div class="btn-tokens-strip">
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#8C8C8C;"></div><div><div class="btn-token-name">breadcrumb/icon/default</div><div class="btn-token-label">Icon — default</div></div></div>
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#474747;"></div><div><div class="btn-token-name">breadcrumb/icon/hover</div><div class="btn-token-label">Icon — hover</div></div></div>
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#430098;"></div><div><div class="btn-token-name">breadcrumb/icon/active</div><div class="btn-token-label">Icon — active</div></div></div>
      </div>
    </div>
  </div>

  <!-- COLLAPSED -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Collapsed</h2></div>
    <p class="doc-section-desc">When a trail exceeds <code>maxItems</code>, middle items collapse behind a <code>···</code> button. Root and current page are always visible. Click the ellipsis — or switch state — to expand.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">5-item trail — click ··· to expand</span>
        <div class="inp-demo-controls">
          <span class="inp-demo-meta">State</span>
          <select class="inp-state-select" onchange="bcSetView(this.value)">
            <option>Collapsed</option>
            <option>Expanded</option>
          </select>
        </div>
      </div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:72px">
        <div id="bc-collapsed" style="display:inline-flex;align-items:center;gap:4px">
          ${bcItem('Home')}
          ${bcSep()}
          ${bcEllipsis()}
          ${bcSep()}
          ${bcItem('Current Page', { active: true })}
        </div>
        <div id="bc-expanded" style="display:none">
          ${bcTrail([
            { label: 'Home' },
            { label: 'Products' },
            { label: 'Electronics' },
            { label: 'Accessories' },
            { label: 'Current Page', active: true },
          ])}
        </div>
      </div>
    </div>
  </div>

  <!-- STATES -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">States</h2></div>
    <p class="doc-section-desc">Three visual states — Default (ancestor link at rest), Hover (pointer over), and Active (the non-interactive current page item).</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">All states</span></div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:48px;min-height:80px;padding:24px 16px">
        <div style="display:flex;flex-direction:column;align-items:center;gap:10px">
          <span style="font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:var(--breadcrumb-text-default);cursor:pointer;user-select:none">Products</span>
          <span style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-secondary)">Default</span>
        </div>
        <div style="display:flex;flex-direction:column;align-items:center;gap:10px">
          <span style="font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:var(--breadcrumb-text-hover);cursor:pointer;user-select:none">Products</span>
          <span style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-secondary)">Hover</span>
        </div>
        <div style="display:flex;flex-direction:column;align-items:center;gap:10px">
          <span style="font-family:Inter,sans-serif;font-size:14px;font-weight:600;color:var(--breadcrumb-text-active);cursor:default;user-select:none">Current Page</span>
          <span style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-secondary)">Active</span>
        </div>
      </div>
    </div>
  </div>

  <!-- COMPONENT TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <p class="doc-section-desc">All sizing values bound to the <code>Components</code> collection. Hover to preview the value, click to copy.</p>
    <div class="card" style="overflow:hidden;margin-bottom:16px">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Aliases → (hover for value, click to copy)</th><th>Usage</th></tr></thead>
        <tbody>${SIZING.breadcrumb.map(tRow).join('')}</tbody>
      </table>
    </div>
  </div>

  <!-- PROPS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
    <table class="prop-table">
      <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
      <tbody>
        <tr><td><span class="prop-name">items</span></td><td><span class="prop-type">BreadcrumbItem[]</span></td><td><span class="prop-default">—</span></td><td>Array of <code>{ label, href, icon? }</code>. The last item is always treated as the current page — it renders as non-interactive.</td></tr>
        <tr><td><span class="prop-name">separator</span></td><td><span class="prop-type">ReactNode</span></td><td><span class="prop-default">ChevronRight</span></td><td>Custom separator rendered between items. Uses <code>breadcrumb/separator</code> color by default.</td></tr>
        <tr><td><span class="prop-name">maxItems</span></td><td><span class="prop-type">number</span></td><td><span class="prop-default">—</span></td><td>Max items to show before collapsing. When exceeded, middle items collapse to <code>···</code>.</td></tr>
        <tr><td><span class="prop-name">itemsBeforeCollapse</span></td><td><span class="prop-type">number</span></td><td><span class="prop-default">1</span></td><td>How many items to show before the ellipsis when collapsed.</td></tr>
        <tr><td><span class="prop-name">itemsAfterCollapse</span></td><td><span class="prop-type">number</span></td><td><span class="prop-default">1</span></td><td>How many items to show after the ellipsis when collapsed.</td></tr>
        <tr><td><span class="prop-name">onExpand</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Called when the user clicks the ellipsis to reveal the full trail.</td></tr>
        <tr><td><span class="prop-name">aria-label</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">"Breadcrumb"</span></td><td>Accessible label for the wrapping <code>&lt;nav&gt;</code> landmark element.</td></tr>
      </tbody>
    </table>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Show breadcrumbs on every page that is more than one level deep. Users should always know where they are and how to navigate up the hierarchy.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't show a breadcrumb on the root page or on top-level sections where there's no parent — a single-item trail adds noise without helping orientation.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Collapse trails longer than 4 items using the ellipsis pattern. This keeps the header stable and predictable regardless of how deep the hierarchy goes.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't make the last (current page) item a link — the user is already there. A self-referential link is redundant and fails WCAG 2.4.4.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Match breadcrumb labels exactly to page titles. If the sidebar says "Analytics", the breadcrumb should say "Analytics" — not "Reports" or "Data".</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use breadcrumbs as a back button in wizards or step flows. Use a dedicated Back / Cancel control — steps aren't the same as a location hierarchy.</div></div>
    </div>
  </div>

  </div>`;
}
