import { pageHeader } from '../utils/render.js';

export default function() {
  return pageHeader('Get Started', 'Architecture', 'How the three-layer token system is structured — from raw primitive values to semantic decisions to components. Understanding this chain is essential for developers integrating the system.') + `<div class="page-body">

    <!-- ── THREE LAYERS ─────────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">The three layers</h2></div>
      <p class="doc-section-desc">Every value in the system flows through three layers. Each layer has a distinct responsibility. Skipping a layer breaks the single-source-of-truth principle.</p>

      <div style="display:flex;flex-direction:column;gap:0;border:1px solid var(--border-subtle);border-radius:var(--radius-xl);overflow:hidden;margin-bottom:24px">
        ${[
          { layer: '1', name: 'Primitives', color: '#F7F0FF', text: '#430098', border: '#E8D5FF', icon: '⬡', desc: 'Raw values with no semantic meaning. Colors as ramps (Purple-100), spacing as numbers (16), radii as pixels (8px). These are the atoms — they never appear in component code.', example: 'Purple-100 = #430098' },
          { layer: '2', name: 'Tokens',     color: '#F2FDF6', text: '#148F47', border: '#C3EDD3', icon: '◈', desc: 'Semantic aliases that reference primitives. They answer "what is this for?" — brand/primary, content/secondary, border/focus. These are what designers and developers use daily.', example: 'brand/primary → Purple-100' },
          { layer: '3', name: 'Components', color: '#F7F4FB', text: '#6933AD', border: '#D9CCEA', icon: '▣', desc: 'UI elements that consume tokens. A Button references brand/primary for its background — never #430098. Component spacing is defined via the Components collection, which aliases from Spacing primitives.', example: 'Button.bg → brand/primary' },
        ].map((l, i) => `
          <div style="display:flex;gap:0;${i < 2 ? 'border-bottom:1px solid var(--border-subtle)' : ''}">
            <div style="width:6px;background:${l.color};border-right:1px solid ${l.border};flex-shrink:0"></div>
            <div style="padding:20px 24px;flex:1">
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
                <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:var(--radius-full);background:${l.color};color:${l.text};border:1px solid ${l.border}">Layer ${l.layer}</span>
                <span style="font-size:15px;font-weight:600;color:var(--content-primary)">${l.name}</span>
              </div>
              <p style="font-size:13px;color:var(--content-secondary);line-height:1.7;margin-bottom:10px">${l.desc}</p>
              <code style="font-size:11px;background:var(--background-subtle);padding:4px 10px;border-radius:var(--radius-md);color:var(--brand-primary);border:1px solid var(--border-subtle)">${l.example}</code>
            </div>
          </div>`).join('')}
      </div>

      <div style="background:var(--brand-primary-muted);border-left:3px solid var(--brand-primary);border-radius:0 var(--radius-lg) var(--radius-lg) 0;padding:14px 16px">
        <div style="font-size:13px;font-weight:600;color:var(--content-primary);margin-bottom:4px">The golden rule</div>
        <div style="font-size:13px;color:var(--content-secondary);line-height:1.7">Components only reference <strong>tokens</strong>. Tokens only reference <strong>primitives</strong>. Nothing skips a layer. This is what makes the system maintainable — change a primitive once and everything above updates automatically.</div>
      </div>
    </div>

    <!-- ── FIGMA COLLECTIONS ─────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Figma collections</h2></div>
      <p class="doc-section-desc">The system is organized into 7 variable collections in Figma. Each collection has a single responsibility and a specific mode structure.</p>

      <div class="card" style="overflow:hidden">
        <div style="display:grid;grid-template-columns:180px 80px 1fr;padding:8px 16px;background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)">
          <span style="font-size:9px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary)">Collection</span>
          <span style="font-size:9px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary)">Modes</span>
          <span style="font-size:9px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary)">Purpose</span>
        </div>
        ${[
          { name:'Primitives',    layer:'1', modes:'Value',          desc:'Raw color ramps — Purple, Light Purple, Dark Purple, Red, Green, Amber, Black, Grey. Hidden from component pickers (scopes=[]).' },
          { name:'Tokens',        layer:'2', modes:'Light · Dark',   desc:'Semantic color decisions — brand, content, icon, background, border, status, focus. These are what your components reference.' },
          { name:'Spacing',       layer:'1', modes:'Value',          desc:'4pt grid scale from 0 to 160px. 22 steps. Used for padding, gap, and margin across all components.' },
          { name:'Typography',    layer:'2', modes:'Latin · Arabic', desc:'Font size, weight, line-height, letter-spacing for 9 semantic roles. Arabic mode applies the +2px sizing rule.' },
          { name:'Border Radius', layer:'1', modes:'Value',          desc:'8 semantic aliases (none → full) built on 8 primitive values. Scale names only — never component names.' },
          { name:'Elevation',     layer:'2', modes:'Light · Dark',   desc:'4 shadow levels as STRING tokens for CSS handoff. Applied as Effect Styles in Figma (Elevation/Card, etc.).' },
          { name:'Icons',         layer:'2', modes:'Value',          desc:'Size tokens (16/20/24px), stroke weight (1.5px), library name, and RTL mirroring rule for Lucide Icons.' },
          { name:'Components',    layer:'3', modes:'Value',          desc:'Semantic spacing tokens for each component — padding, height, gap, icon size, radius, focus offset. Aliases from Spacing primitives.' },
        ].map((c, i) => `
          <div style="display:grid;grid-template-columns:180px 80px 1fr;padding:12px 16px;${i%2===0?'background:var(--background-subtle)':''};border-bottom:1px solid var(--border-subtle);align-items:start">
            <div>
              <div style="font-size:12px;font-weight:600;color:var(--content-primary)">${c.name}</div>
              <span style="font-size:9px;font-weight:700;padding:1px 6px;border-radius:3px;${c.layer==='1'?'background:#F7F0FF;color:#430098':'background:#F2FDF6;color:#148F47'}">Layer ${c.layer}</span>
            </div>
            <div style="font-size:11px;font-family:monospace;color:var(--content-tertiary);padding-top:2px">${c.modes}</div>
            <div style="font-size:12px;color:var(--content-secondary);line-height:1.5">${c.desc}</div>
          </div>`).join('')}
        <div style="display:grid;grid-template-columns:180px 80px 1fr;padding:12px 16px;background:var(--background-subtle);align-items:start">
          <div style="font-size:12px;font-weight:600;color:var(--content-primary)">8 collections total</div>
          <div></div>
          <div style="font-size:12px;color:var(--content-tertiary)">3 primitive · 4 semantic · 1 component</div>
        </div>
      </div>
    </div>

    <!-- ── ALIAS CHAIN ───────────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">The alias chain</h2></div>
      <p class="doc-section-desc">Every token is an alias — it points to another value rather than storing a raw value directly. This chain is what makes dark mode and theming automatic.</p>

      <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:24px">
        ${[
          { label: 'Component uses',  value: 'brand/primary',   arrow: true,  style: 'background:var(--brand-primary-muted);color:var(--brand-primary);border:1px solid #D9CCEA' },
          { label: 'Token aliases',   value: 'Purple-100',      arrow: true,  style: 'background:#F2FDF6;color:#148F47;border:1px solid #C3EDD3' },
          { label: 'Primitive value', value: '#430098',         arrow: false, style: 'background:var(--background-subtle);color:var(--content-primary);border:1px solid var(--border-subtle)' },
        ].map((r, i) => `
          <div style="display:flex;align-items:center;gap:12px">
            <div style="width:130px;font-size:11px;color:var(--content-tertiary);text-align:right;flex-shrink:0">${r.label}</div>
            <code style="font-size:12px;font-weight:600;padding:6px 14px;border-radius:var(--radius-lg);${r.style}">${r.value}</code>
            ${r.arrow ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#A3A3A3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>' : ''}
          </div>`).join('')}
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px">
        <div class="card" style="padding:20px">
          <div style="font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary);margin-bottom:12px">Light mode</div>
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
            <div style="width:28px;height:28px;border-radius:6px;background:#430098;flex-shrink:0"></div>
            <div>
              <div style="font-size:12px;font-weight:600;color:var(--content-primary)">brand/primary</div>
              <div style="font-size:11px;font-family:monospace;color:var(--content-tertiary)">→ Purple-100 → #430098</div>
            </div>
          </div>
        </div>
        <div class="card" style="padding:20px;background:#1A1A2E;border-color:#2E2E42">
          <div style="font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#6B6B8A;margin-bottom:12px">Dark mode</div>
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
            <div style="width:28px;height:28px;border-radius:6px;background:#BF84FF;flex-shrink:0"></div>
            <div>
              <div style="font-size:12px;font-weight:600;color:#FFFFFF">brand/primary</div>
              <div style="font-size:11px;font-family:monospace;color:#6B6B8A">→ Light-Purple-80 → #BF84FF</div>
            </div>
          </div>
        </div>
      </div>

      <div style="font-size:13px;color:var(--content-secondary);line-height:1.7;padding:14px 16px;background:var(--background-subtle);border-radius:var(--radius-xl);border:1px solid var(--border-subtle)">
        Same token name <code style="font-size:11px;background:var(--background-surface);padding:1px 6px;border-radius:3px">brand/primary</code>, two different values depending on mode. When Figma switches to Dark mode — or when a developer changes the CSS variable — every component using that token updates instantly. No manual search, no hardcoded overrides.
      </div>
    </div>

    <!-- ── CSS MAP ───────────────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">From Figma to code</h2></div>
      <p class="doc-section-desc">Every token maps directly to a CSS custom property. Developers never reference hex values in component code — they reference the CSS variable, which is always in sync with the Figma token.</p>

      <div class="grid-2">
        <div class="card" style="padding:20px">
          <div style="font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary);margin-bottom:12px">Figma token</div>
          <div style="display:flex;flex-direction:column;gap:6px">
            ${[
              ['brand/primary','#430098'],
              ['content/primary','#191919'],
              ['border/focus','#6933AD'],
              ['radius/lg','8px'],
              ['focus/width','2px'],
            ].map(([token, val]) =>
              '<div style="display:flex;align-items:center;justify-content:space-between;padding:6px 10px;background:var(--background-subtle);border-radius:6px">' +
              '<code style="font-size:11px;color:var(--brand-primary)">' + token + '</code>' +
              '<span style="font-size:11px;font-family:monospace;color:var(--content-tertiary)">' + val + '</span>' +
              '</div>'
            ).join('')}
          </div>
        </div>
        <div class="card" style="padding:20px">
          <div style="font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary);margin-bottom:12px">CSS variable</div>
          <div style="display:flex;flex-direction:column;gap:6px">
            ${[
              ['--brand-primary','var(--brand-primary)'],
              ['--content-primary','var(--content-primary)'],
              ['--border-focus','var(--border-focus)'],
              ['--radius-lg','var(--radius-lg)'],
              ['--focus-width','var(--focus-width)'],
            ].map(([prop, usage]) =>
              '<div style="display:flex;align-items:center;justify-content:space-between;padding:6px 10px;background:var(--background-subtle);border-radius:6px">' +
              '<code style="font-size:11px;color:#148F47">' + prop + '</code>' +
              '<span style="font-size:11px;font-family:monospace;color:var(--content-tertiary)">' + usage + '</span>' +
              '</div>'
            ).join('')}
          </div>
        </div>
      </div>
    </div>

  </div>`;
}
