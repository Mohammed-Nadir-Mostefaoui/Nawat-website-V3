import { pageHeader } from '../utils/render.js';
import { SIZING } from '../data/sizing.js';

function track(id, checked, size = 'md') {
  const w  = size === 'sm' ? 36 : 48;
  const h  = size === 'sm' ? 20 : 24;
  const ts = size === 'sm' ? 16 : 20;
  const tl = checked ? (w - ts - 2) + 'px' : '2px';
  const bg = checked ? 'var(--toggle-track-bg-on)' : 'var(--toggle-track-bg-off)';
  const sh = 'none';
  return `<div id="tgl-track-${id}" data-checked="${checked}" data-size="${size}"
    onclick="tglToggle('${id}');event.stopPropagation()"
    style="position:relative;width:${w}px;height:${h}px;border-radius:9999px;background:${bg};box-shadow:${sh};cursor:pointer;flex-shrink:0;transition:background .15s,box-shadow .15s">
    <div id="tgl-thumb-${id}" style="position:absolute;top:2px;left:${tl};width:${ts}px;height:${ts}px;border-radius:50%;background:var(--toggle-thumb-bg-default);box-shadow:0 1px 3px rgba(0,0,0,.18);transition:left .15s;pointer-events:none"></div>
  </div>`;
}

function staticTrack(checked, { focused, disabled, size = 'md' } = {}) {
  const w  = size === 'sm' ? 36 : 48;
  const h  = size === 'sm' ? 20 : 24;
  const ts = size === 'sm' ? 16 : 20;
  const tl = checked ? (w - ts - 2) + 'px' : '2px';
  const bg = checked ? 'var(--toggle-track-bg-on)' : 'var(--toggle-track-bg-off)';
  const sh = focused ? '0 0 0 4px var(--toggle-focus-ring)' : 'none';
  const op = disabled ? '.5' : '1';
  const cur = disabled ? 'not-allowed' : 'default';
  return `<div style="position:relative;width:${w}px;height:${h}px;border-radius:9999px;background:${bg};box-shadow:${sh};flex-shrink:0;opacity:${op};cursor:${cur}">
    <div style="position:absolute;top:2px;left:${tl};width:${ts}px;height:${ts}px;border-radius:50%;background:var(--toggle-thumb-bg-default);box-shadow:0 1px 3px rgba(0,0,0,.18)"></div>
  </div>`;
}

function stateCell(label, checked, opts) {
  return `<div style="display:flex;flex-direction:column;align-items:center;gap:10px">
    ${staticTrack(checked, opts)}
    <span style="font-family:Inter,sans-serif;font-size:12px;color:var(--content-secondary);white-space:nowrap">${label}</span>
  </div>`;
}

function tRow(t, i) {
  const bg = i % 2 === 0 ? 'background:var(--background-subtle);' : '';
  const vc = t.val >= 9999 ? '9999px' : t.val + 'px';
  return `<tr style="${bg}border-bottom:1px solid var(--border-subtle)">
    <td style="padding:10px 16px"><code class="tok-name">${t.token}</code></td>
    <td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'${vc}')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">${t.ref}<span class="tok-alias-copied">${vc}</span></span></td>
    <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${t.use}</td>
  </tr>`;
}

export default function toggle() {
  return pageHeader('Components', 'Toggle', 'Binary on/off switch for settings that take immediate effect. 2 sizes, label and supporting text variants.', [
    { val: '2',  label: 'Sizes' },
    { val: String(SIZING.toggle.length), label: 'Size tokens' },
    { val: '15', label: 'Color tokens' },
  ]) + `<div class="page-body">

  <!-- DEFAULT -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Default</h2></div>
    <p class="doc-section-desc">Click the track to toggle. The thumb slides with a 150ms transition. Use the state selector to preview all interactive states.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">Toggle — click to switch</span>
        <div class="inp-demo-controls">
          <span class="inp-demo-meta">State</span>
          <select class="inp-state-select" onchange="tglState('default',this.value)">
            <option>Off</option>
            <option>On</option>
            <option>Focused Off</option>
            <option>Focused On</option>
            <option>Disabled Off</option>
            <option>Disabled On</option>
          </select>
        </div>
      </div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:80px">
        ${track('default', false)}
      </div>
      <div class="btn-tokens-strip">
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#430098;"></div><div><div class="btn-token-name">toggle/track-bg/on</div><div class="btn-token-label">Track — on state</div></div></div>
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#FFFFFF;border:1.5px solid #D1D1D1;"></div><div><div class="btn-token-name">toggle/track-bg/off</div><div class="btn-token-label">Track — off state</div></div></div>
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#FFFFFF;border:1px solid #E1E1E1;"></div><div><div class="btn-token-name">toggle/thumb-bg/default</div><div class="btn-token-label">Thumb fill</div></div></div>
      </div>
    </div>
  </div>

  <!-- WITH LABEL -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">With label</h2></div>
    <p class="doc-section-desc">Label sits to the right of the track with an 8px (SM) or 12px (MD) gap. Clicking the label also toggles the control — do not wrap in a <code>&lt;label&gt;</code> manually, the component handles this.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">Label — click track or text to toggle</span>
        <div class="inp-demo-controls">
          <span class="inp-demo-meta">State</span>
          <select class="inp-state-select" onchange="tglState('label',this.value)">
            <option>Off</option><option>On</option><option>Focused Off</option><option>Focused On</option><option>Disabled Off</option><option>Disabled On</option>
          </select>
        </div>
      </div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:80px">
        <div id="tgl-wrap-label" style="display:inline-flex;align-items:center;gap:12px;cursor:pointer" onclick="tglToggle('label')">
          ${track('label', false)}
          <span id="tgl-lbl-label" style="font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:var(--toggle-text-label);user-select:none">Enable notifications</span>
        </div>
      </div>
      <div class="btn-tokens-strip">
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#191919;"></div><div><div class="btn-token-name">toggle/text/label</div><div class="btn-token-label">Label text</div></div></div>
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#D1D1D1;"></div><div><div class="btn-token-name">content/disabled</div><div class="btn-token-label">Label — disabled</div></div></div>
      </div>
    </div>
  </div>

  <!-- WITH SUPPORTING TEXT -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">With supporting text</h2></div>
    <p class="doc-section-desc">A short description below the label using the supporting text token. Use to clarify what enabling the toggle does, not to repeat the label.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">Label + supporting — click to toggle</span>
        <div class="inp-demo-controls">
          <span class="inp-demo-meta">State</span>
          <select class="inp-state-select" onchange="tglState('support',this.value)">
            <option>Off</option><option>On</option><option>Focused Off</option><option>Focused On</option><option>Disabled Off</option><option>Disabled On</option>
          </select>
        </div>
      </div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:100px">
        <div id="tgl-wrap-support" style="display:inline-flex;align-items:flex-start;gap:12px;cursor:pointer" onclick="tglToggle('support')">
          <div style="padding-top:2px">${track('support', false)}</div>
          <div>
            <div id="tgl-lbl-support" style="font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:var(--toggle-text-label);line-height:1.4;user-select:none">Email notifications</div>
            <div id="tgl-sub-support" style="font-family:Inter,sans-serif;font-size:13px;color:var(--toggle-text-supporting);margin-top:4px;line-height:1.4;user-select:none">Receive a daily summary of your project activity.</div>
          </div>
        </div>
      </div>
      <div class="btn-tokens-strip">
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#191919;"></div><div><div class="btn-token-name">toggle/text/label</div><div class="btn-token-label">Label text</div></div></div>
        <div class="btn-token-item"><div class="btn-token-swatch" style="background:#757575;"></div><div><div class="btn-token-name">toggle/text/supporting</div><div class="btn-token-label">Supporting text</div></div></div>
      </div>
    </div>
  </div>

  <!-- SIZES -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Sizes</h2></div>
    <p class="doc-section-desc">SM (36×20px) for dense settings panels or inline controls. MD (48×24px) as the default for standalone settings. Both sizes are interactive.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">SM and MD — click to toggle</span></div>
      <div class="inp-multi-stage" style="align-items:center">
        <div class="inp-multi-cell">
          ${track('size-sm', false, 'sm')}
          <span class="inp-multi-label">SM — 36×20px · thumb 16px</span>
        </div>
        <div class="inp-multi-cell">
          ${track('size-md', false, 'md')}
          <span class="inp-multi-label">MD — 48×24px · thumb 20px</span>
        </div>
      </div>
    </div>
  </div>

  <!-- ALL STATES -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">States</h2></div>
    <p class="doc-section-desc">All six states at a glance. Disabled applies 50% opacity to the entire control — no separate disabled color token is needed.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">All states — MD</span></div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:32px;min-height:100px;padding:24px 16px">
        ${stateCell('Off',          false, {})}
        ${stateCell('On',           true,  {})}
        ${stateCell('Focused Off',  false, { focused: true })}
        ${stateCell('Focused On',   true,  { focused: true })}
        ${stateCell('Disabled Off', false, { disabled: true })}
        ${stateCell('Disabled On',  true,  { disabled: true })}
      </div>
    </div>
  </div>

  <!-- COMPONENT TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <p class="doc-section-desc">All sizing values bound to the <code>Components</code> collection. Hover to preview the value, click to copy.</p>
    <div class="card" style="overflow:hidden;margin-bottom:16px">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Aliases → (hover for value, click to copy)</th><th>Usage</th></tr></thead>
        <tbody>${SIZING.toggle.map(tRow).join('')}</tbody>
      </table>
    </div>
  </div>

  <!-- PROPS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
    <table class="prop-table">
      <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
      <tbody>
        <tr><td><span class="prop-name">checked</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Controlled on/off state.</td></tr>
        <tr><td><span class="prop-name">defaultChecked</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Uncontrolled initial state.</td></tr>
        <tr><td><span class="prop-name">onChange</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Called with the new boolean value when the user toggles.</td></tr>
        <tr><td><span class="prop-name">size</span></td><td><span class="prop-type">"sm"|"md"</span></td><td><span class="prop-default">"md"</span></td><td>Track and thumb size (SM 36×20 / MD 48×24).</td></tr>
        <tr><td><span class="prop-name">label</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Label shown to the right of the track. Clicking it also toggles.</td></tr>
        <tr><td><span class="prop-name">supportingText</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Helper description shown below the label.</td></tr>
        <tr><td><span class="prop-name">disabled</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Applies 50% opacity and removes pointer events.</td></tr>
        <tr><td><span class="prop-name">id</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Forwarded to the underlying <code>&lt;input type="checkbox"&gt;</code>.</td></tr>
      </tbody>
    </table>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use Toggle for settings that apply immediately — wifi, dark mode, feature flags. Changes should not require a Save button.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use Toggle inside a form that requires submission. Use a Checkbox instead — it only commits on submit.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Keep the label short and action-oriented — "Enable emails", "Show grid". The user should know what turning it on does.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't write labels as questions ("Send emails?") — it makes the on/off meaning ambiguous. State the feature, not the question.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use SM toggles in dense settings panels or data tables where space is at a premium. Use MD as the default elsewhere.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't mix SM and MD toggles on the same settings screen. Pick one size and apply it consistently across the whole view.</div></div>
    </div>
  </div>

  </div>`;
}
