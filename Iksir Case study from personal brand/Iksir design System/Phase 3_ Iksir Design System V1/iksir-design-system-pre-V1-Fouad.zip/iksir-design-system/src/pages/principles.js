import { pageHeader } from '../utils/render.js';

export default function() {
  return pageHeader('Get Started', 'Principles', 'The decisions behind every token, component, and pattern in the Iksir design system.') + `<div class="page-body">
    <div class="doc-section">
      <div class="grid-2">
        ${[
          ['Token-first','Every visual decision — color, spacing, radius — is a named token. Components never hardcode values. This makes the system maintainable, themeable, and safe to refactor.'],
          ['Semantic over primitive','Use brand/primary, not #430098. Semantic names express intent. When the brand color changes, one primitive update ripples everywhere. Hardcoded values require a manual search.'],
          ['Two modes from day one','Light and Dark are not an afterthought. Every semantic token has both values. The moment a component uses brand/primary instead of a hex value, it automatically supports both modes.'],
          ['Speed over perfection','Small team. The system must enable fast execution. Tokens are designed to cover 95% of cases clearly, with escape hatches for the 5% that need deviation — not a rigid rule for every edge case.'],
          ['Scale names over component names','radius/lg not radius/button. Scale names stay neutral and reusable. Component names create coupling and proliferate tokens unnecessarily.'],
          ['Document everything','Every token has a description. Every component has a prop table, token map, and do/dont. Undocumented decisions get reinvented incorrectly by the next designer or developer who encounters them.'],
        ].map(([t,d]) => `<div class="rule-card"><div class="rule-card-title">${t}</div><div class="rule-card-body">${d}</div></div>`).join('')}
      </div>
    </div>
  </div>`;
}
