import { pageHeader } from '../utils/render.js';
import { SIZING } from '../data/sizing.js';

/* ── icons ────────────────────────────────────────────────── */
const SORT_ICO  = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m7 15 5 5 5-5M7 9l5-5 5 5"/></svg>`;
const SORT_ASC  = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6"/></svg>`;
const SORT_DESC = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>`;
const MORE_ICO  = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>`;
const EDIT_ICO  = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`;
const DUPE_ICO  = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`;
const TRASH_ICO = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>`;
const PREV_ICO  = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>`;
const NEXT_ICO  = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>`;
const CHEV_D    = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>`;

/* ── sample data ──────────────────────────────────────────── */
const AVATAR_PAL = [
  { bg: '#F7F4FB', text: '#430098' },
  { bg: '#F2FDF6', text: '#148F47' },
  { bg: '#FEFBF6', text: '#AE7004' },
  { bg: '#FFF2F4', text: '#D8192C' },
  { bg: '#F7F0FF', text: '#AF65FF' },
];

const ROWS = [
  { name: 'Sofia Miller',  role: 'Product Designer',  status: 'Active',   email: 'sofia@company.io',  date: 'Jan 12, 2024' },
  { name: 'Lucas Chen',    role: 'Frontend Engineer', status: 'Active',   email: 'lucas@company.io',  date: 'Mar 8, 2024'  },
  { name: 'Amara Osei',    role: 'Design Lead',       status: 'Pending',  email: 'amara@company.io',  date: 'Apr 2, 2024'  },
  { name: 'James Reid',    role: 'Backend Engineer',  status: 'Inactive', email: 'james@company.io',  date: 'Nov 19, 2023' },
  { name: 'Elena Vasquez', role: 'Project Manager',   status: 'Active',   email: 'elena@company.io',  date: 'Feb 27, 2024' },
];

/* ── atoms ────────────────────────────────────────────────── */
function avatar(name, idx) {
  const p = AVATAR_PAL[idx % 5];
  const ini = name.split(' ').map(n => n[0]).join('').toUpperCase();
  return `<div style="display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:32px;height:32px;border-radius:50%;background:${p.bg};font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:${p.text}">${ini}</div>`;
}

function statusBadge(status) {
  const S = {
    Active:   { bg: '#F2FDF6', text: '#148F47', dot: '#148F47' },
    Pending:  { bg: '#FEFBF6', text: '#AE7004', dot: '#AE7004' },
    Inactive: { bg: '#F6F6F6', text: '#757575', dot: '#A3A3A3' },
  }[status] || { bg: '#F6F6F6', text: '#757575', dot: '#A3A3A3' };
  return `<span style="display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:9999px;background:${S.bg};font-family:Inter,sans-serif;font-size:12px;font-weight:500;color:${S.text}">
    <span style="width:6px;height:6px;border-radius:50%;background:${S.dot};flex-shrink:0"></span>${status}
  </span>`;
}

/* ── checkbox component (SM — 16 px) ─────────────────────── */
const CB_CHECK = `<svg width="11" height="11" viewBox="0 0 14 14" fill="none" stroke="#430098" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.0 7.0 L5.6 10.6 L12.0 3.4"/></svg>`;
const CB_DASH  = `<span class="cb-dash" style="display:none;width:8px;height:2px;background:#430098;border-radius:1px"></span>`;

function mkCb(id, checked, onchangeAttr) {
  return `<div class="cb-box-wrap" style="width:16px;height:16px">
    <input class="cb-input" type="checkbox" id="${id}" ${checked ? 'checked' : ''} ${onchangeAttr}>
    <div class="cb-box" style="width:16px;height:16px;border-radius:4px">
      <span class="cb-icon" style="width:11px;height:11px">${CB_CHECK}</span>
      ${CB_DASH}
    </div>
  </div>`;
}

/* ── header cells ─────────────────────────────────────────── */
function thSort(tableId, colIdx, label, width) {
  const w = width ? `width:${width};` : '';
  return `<th data-sort-col="${colIdx}" data-sort-dir="none"
    onclick="tblSort('${tableId}',${colIdx})"
    style="${w}height:40px;padding:0 12px;background:var(--table-header-bg);border-bottom:1px solid var(--table-header-border);text-align:left;white-space:nowrap;cursor:pointer;user-select:none">
    <div style="display:inline-flex;align-items:center;gap:4px;font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--table-header-text)">
      ${label}<span data-sort-icon style="display:inline-flex;align-items:center;color:var(--table-header-icon)">${SORT_ICO}</span>
    </div>
  </th>`;
}

function thStatic(label, width) {
  const w = width ? `width:${width};` : '';
  return `<th style="${w}height:40px;padding:0 12px;background:var(--table-header-bg);border-bottom:1px solid var(--table-header-border);text-align:left;white-space:nowrap">
    <div style="font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--table-header-text)">${label}</div>
  </th>`;
}

function thCheckbox(tableId) {
  return `<th style="width:48px;padding:0 12px;background:var(--table-header-bg);border-bottom:1px solid var(--table-header-border)">
    ${mkCb(`${tableId}-header-cb`, false, `onchange="tblSelectAll('${tableId}',this)"`)}
  </th>`;
}

/* ── data row ─────────────────────────────────────────────── */
function tdRow(tableId, row, idx, isLast, opts = {}) {
  const { checkbox = false, selected = false, disabled = false, striped = false, actions = false, interactive = true } = opts;
  const bd = isLast ? 'none' : '1px solid var(--table-border-row)';
  const state = disabled ? 'disabled' : selected ? 'selected' : (striped && idx % 2 !== 0) ? 'striped' : 'default';
  const bg = selected  ? 'var(--table-row-bg-selected)'
           : disabled  ? 'var(--table-row-bg-default)'
           : (striped && idx % 2 !== 0) ? 'var(--table-row-bg-striped)'
           :              'var(--table-row-bg-default)';
  const tc = disabled ? 'var(--table-row-text-disabled)' : 'var(--table-row-text-default)';
  const sc = disabled ? 'var(--table-row-text-disabled)' : 'var(--table-row-text-secondary)';
  const ic = disabled ? 'var(--table-row-icon-disabled)' : 'var(--table-row-icon)';
  const hov = interactive && !disabled
    ? ` onmouseenter="tblRowHover(this,true)" onmouseleave="tblRowHover(this,false)"` : '';

  const cbCell = checkbox ? `<td style="width:48px;padding:0 12px;border-bottom:${bd}">
    <div data-row-cb>${mkCb(`${tableId}-row-cb-${idx}`, selected, `onchange="tblSelectRow('${tableId}',${idx},this)"`)}</div>
  </td>` : '';

  const _sid = `tbl-act-${tableId}-${idx}`;
  const _HVR = `onmouseenter="this.style.background='#FAFAFA'" onmouseleave="this.style.background=''"`;
  const _actMenu = `
    <div ${_HVR} onclick="ddClose('${_sid}')" style="display:flex;align-items:center;gap:8px;height:36px;padding:0 12px;cursor:pointer;user-select:none">
      <span style="color:#757575;flex-shrink:0;display:flex;align-items:center">${EDIT_ICO}</span>
      <span style="font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:#474747">Edit</span>
    </div>
    <div ${_HVR} onclick="ddClose('${_sid}')" style="display:flex;align-items:center;gap:8px;height:36px;padding:0 12px;cursor:pointer;user-select:none">
      <span style="color:#757575;flex-shrink:0;display:flex;align-items:center">${DUPE_ICO}</span>
      <span style="font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:#474747">Duplicate</span>
    </div>
    <div style="height:1px;background:#E8E8E8;margin:4px 0"></div>
    <div ${_HVR} onclick="ddClose('${_sid}')" style="display:flex;align-items:center;gap:8px;height:36px;padding:0 12px;cursor:pointer;user-select:none">
      <span style="color:#D8192C;flex-shrink:0;display:flex;align-items:center">${TRASH_ICO}</span>
      <span style="font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:#D8192C">Delete</span>
    </div>`;
  const actCell = actions ? `<td style="width:48px;padding:0 12px;border-bottom:${bd};text-align:right">
    ${disabled
      ? `<button style="display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:6px;border:1px solid transparent;background:transparent;color:${ic};cursor:not-allowed">${MORE_ICO}</button>`
      : `<button id="dd-trigger-${_sid}"
          onclick="tblActToggle('${_sid}',this);event.stopPropagation()"
          style="display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:6px;border:1px solid transparent;background:transparent;color:${ic};cursor:pointer"
          onmouseenter="this.style.background='var(--table-row-bg-hover)';this.style.borderColor='var(--table-border-row)'"
          onmouseleave="if(document.getElementById('dd-panel-${_sid}').style.display==='none'){this.style.background='transparent';this.style.borderColor='transparent'}"
          >${MORE_ICO}</button>
        <div id="dd-panel-${_sid}" onclick="event.stopPropagation()"
          style="display:none;position:fixed;min-width:160px;background:#FFFFFF;border:1px solid #E8E8E8;border-radius:8px;box-shadow:0 4px 8px rgba(0,0,0,.08),0 2px 4px rgba(0,0,0,.06);padding:4px 0;z-index:9999">
          ${_actMenu}
        </div>`}
  </td>` : '';

  return `<tr id="${tableId}-row-${idx}" data-state="${state}" data-striped="${striped && idx % 2 !== 0}"
    style="background:${bg};transition:background .1s"${hov}>
    ${cbCell}
    <td style="padding:0 12px;border-bottom:${bd}">
      <div style="display:flex;align-items:center;gap:12px;height:48px">
        ${avatar(row.name, idx)}
        <div style="display:flex;flex-direction:column;gap:2px">
          <span style="font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:${tc};white-space:nowrap">${row.name}</span>
          <span style="font-family:Inter,sans-serif;font-size:12px;color:${sc};white-space:nowrap">${row.role}</span>
        </div>
      </div>
    </td>
    <td style="padding:0 12px;border-bottom:${bd}">
      ${disabled ? `<span style="font-family:Inter,sans-serif;font-size:13px;color:${tc}">${row.status}</span>` : statusBadge(row.status)}
    </td>
    <td style="padding:0 12px;border-bottom:${bd}">
      <span style="font-family:Inter,sans-serif;font-size:13px;color:${tc}">${row.email}</span>
    </td>
    <td style="padding:0 12px;border-bottom:${bd}">
      <span style="font-family:Inter,sans-serif;font-size:13px;color:${sc}">${row.date}</span>
    </td>
    ${actCell}
  </tr>`;
}

/* ── table builders ───────────────────────────────────────── */
function tblTable(tableId, opts = {}) {
  const { checkbox = false, striped = false, selectedRows = [], disabledRows = [], actions = false, interactive = true } = opts;
  const hdrs = [
    checkbox ? thCheckbox(tableId) : '',
    thSort(tableId, 0, 'Name'),
    thSort(tableId, 1, 'Status', '120px'),
    thSort(tableId, 2, 'Email'),
    thSort(tableId, 3, 'Date', '140px'),
    actions  ? thStatic('', '48px') : '',
  ].filter(Boolean).join('');

  const rows = ROWS.map((row, idx) => tdRow(tableId, row, idx, idx === ROWS.length - 1, {
    checkbox, striped,
    selected:    selectedRows.includes(idx),
    disabled:    disabledRows.includes(idx),
    actions,
    interactive: interactive && !disabledRows.includes(idx),
  })).join('');

  return `<div style="width:100%;border:1px solid var(--table-border-outline);border-radius:8px;overflow:hidden">
    <table id="${tableId}" style="width:100%;border-collapse:collapse">
      <thead><tr>${hdrs}</tr></thead>
      <tbody>${rows}</tbody>
    </table>
  </div>`;
}

function tblStatesTable() {
  const STATES = [
    { state: 'Default',  bg: 'var(--table-row-bg-default)',        tc: 'var(--table-row-text-default)',  sc: 'var(--table-row-text-secondary)' },
    { state: 'Hover',    bg: 'var(--table-row-bg-hover)',          tc: 'var(--table-row-text-default)',  sc: 'var(--table-row-text-secondary)' },
    { state: 'Selected', bg: 'var(--table-row-bg-selected)',       tc: 'var(--table-row-text-default)',  sc: 'var(--table-row-text-secondary)' },
    { state: 'Disabled', bg: 'var(--table-row-bg-default)',        tc: 'var(--table-row-text-disabled)', sc: 'var(--table-row-text-disabled)'  },
  ];
  const hdrs = [thStatic('State', '96px'), thStatic('Name'), thStatic('Status', '120px'), thStatic('Email'), thStatic('Date', '140px')].join('');
  const rows = STATES.map(({ state, bg, tc, sc }, idx) => {
    const row = ROWS[idx];
    const bd  = idx === STATES.length - 1 ? 'none' : '1px solid var(--table-border-row)';
    return `<tr style="background:${bg}">
      <td style="padding:0 12px;border-bottom:${bd};border-right:1px solid var(--table-border-row)">
        <span style="font-family:Inter,sans-serif;font-size:11px;font-weight:600;color:var(--content-tertiary);text-transform:uppercase;letter-spacing:.05em">${state}</span>
      </td>
      <td style="padding:0 12px;border-bottom:${bd}">
        <div style="display:flex;align-items:center;gap:12px;height:48px">
          ${avatar(row.name, idx)}
          <div style="display:flex;flex-direction:column;gap:2px">
            <span style="font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:${tc};white-space:nowrap">${row.name}</span>
            <span style="font-family:Inter,sans-serif;font-size:12px;color:${sc};white-space:nowrap">${row.role}</span>
          </div>
        </div>
      </td>
      <td style="padding:0 12px;border-bottom:${bd}">
        ${state === 'Disabled'
          ? `<span style="font-family:Inter,sans-serif;font-size:13px;color:${tc}">${row.status}</span>`
          : statusBadge(row.status)}
      </td>
      <td style="padding:0 12px;border-bottom:${bd}">
        <span style="font-family:Inter,sans-serif;font-size:13px;color:${tc}">${row.email}</span>
      </td>
      <td style="padding:0 12px;border-bottom:${bd}">
        <span style="font-family:Inter,sans-serif;font-size:13px;color:${sc}">${row.date}</span>
      </td>
    </tr>`;
  }).join('');

  return `<div style="width:100%;border:1px solid var(--table-border-outline);border-radius:8px;overflow:hidden">
    <table style="width:100%;border-collapse:collapse">
      <thead><tr>${hdrs}</tr></thead>
      <tbody>${rows}</tbody>
    </table>
  </div>`;
}

function tblFooter(cid, page, total, perPage, totalItems) {
  const ppOpts = [10, 20, 50, 100].map(v => {
    const isSel = v === perPage;
    return `<div data-val="${v}" onclick="pgSetPerPage('${cid}',${v})"
      style="padding:8px 12px;font-family:Inter,sans-serif;font-size:13px;color:${isSel ? '#430098' : '#474747'};cursor:pointer;background:${isSel ? '#F7F4FB' : ''}"
      onmouseenter="this.style.background='#F7F4FB'" onmouseleave="this.style.background='${isSel ? '#F7F4FB' : ''}'">
      ${v} per page</div>`;
  }).join('');

  function navBtn(dir, disabled) {
    const isPrev = dir === 'prev';
    const ico = isPrev ? PREV_ICO : NEXT_ICO;
    const lbl = isPrev ? 'Previous' : 'Next';
    const tc = disabled ? 'var(--pagination-button-text-disabled)' : 'var(--table-footer-text)';
    const bc = disabled ? 'var(--pagination-button-border-disabled)' : 'var(--table-border-row)';
    const hov = !disabled ? ` onmouseenter="pgHover(this,true)" onmouseleave="pgHover(this,false)"` : '';
    const clk = !disabled ? ` onclick="${isPrev ? `pgPrev('${cid}')` : `pgNext('${cid}')`}"` : '';
    const inner = isPrev ? `${ico}<span>${lbl}</span>` : `<span>${lbl}</span>${ico}`;
    return `<button data-pg="${dir}" data-state="${disabled ? 'disabled' : 'default'}"
      style="display:inline-flex;align-items:center;gap:6px;padding:7px 14px;border-radius:8px;border:1px solid ${bc};background:var(--pagination-button-bg-default);font-family:Inter,sans-serif;font-size:13px;font-weight:500;color:${tc};cursor:${disabled ? 'not-allowed' : 'pointer'};transition:background .12s,border-color .12s,color .12s"${hov}${clk}>${inner}</button>`;
  }

  return `<div id="${cid}" data-page="${page}" data-total="${total}" data-per-page="${perPage}" data-total-items="${totalItems}"
    style="display:flex;align-items:center;justify-content:space-between;height:56px;padding:0 16px;background:var(--table-footer-bg);border-top:1px solid var(--table-footer-border)">
    <div style="display:flex;align-items:center;gap:12px">
      <span id="${cid}-info" style="font-family:Inter,sans-serif;font-size:13px;color:var(--table-footer-text)">Page ${page} of ${total}</span>
      <div style="position:relative">
        <button id="${cid}-pp-btn" onclick="pgPerPageToggle('${cid}',event)"
          style="display:inline-flex;align-items:center;gap:8px;padding:0 10px;height:32px;border-radius:8px;border:1px solid var(--table-border-row);background:var(--table-row-bg-default);font-family:Inter,sans-serif;font-size:13px;color:var(--table-footer-text);cursor:pointer">
          <span id="${cid}-pp-label">${perPage} per page</span>${CHEV_D}
        </button>
        <div id="${cid}-pp-drop"
          style="display:none;position:absolute;bottom:calc(100% + 4px);left:0;min-width:140px;background:#FFFFFF;border:1px solid #E6E6E6;border-radius:8px;box-shadow:0 -4px 16px rgba(0,0,0,.08);z-index:100;overflow:hidden">
          ${ppOpts}
        </div>
      </div>
    </div>
    <div style="display:flex;align-items:center;gap:8px">
      ${navBtn('prev', page <= 1)}
      ${navBtn('next', page >= total)}
    </div>
  </div>`;
}

/* ── doc helpers ──────────────────────────────────────────── */
function tRow(t, i) {
  const bg = i % 2 === 0 ? 'background:var(--background-subtle);' : '';
  const vc = t.val + 'px';
  return `<tr style="${bg}border-bottom:1px solid var(--border-subtle)">
    <td style="padding:10px 16px"><code class="tok-name">${t.token}</code></td>
    <td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'${vc}')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">${t.ref}<span class="tok-alias-copied">${vc}</span></span></td>
    <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${t.use}</td>
  </tr>`;
}

/* ── page ─────────────────────────────────────────────────── */
export default function tables() {
  return pageHeader('Components', 'Table', 'Displays structured data in rows and columns with sortable headers, row selection, striped rows, and an optional footer with pagination.', [
    { val: '5',  label: 'Variants' },
    { val: String(SIZING.table.length), label: 'Size tokens' },
    { val: '23', label: 'Color tokens' },
  ]) + `<div class="page-body">

  <!-- DEFAULT -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Default</h2></div>
    <p class="doc-section-desc">Basic table with sortable column headers and row hover. Click any header to cycle through ascending, descending, and unsorted states. The sort icon turns brand purple when active.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Click headers to sort — hover rows</span></div>
      <div class="inp-demo-stage" style="padding:0;min-height:auto;display:block">
        ${tblTable('tbl-default', { actions: true })}
      </div>
    </div>
  </div>

  <!-- WITH SELECTION -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">With selection</h2></div>
    <p class="doc-section-desc">Checkbox column with select-all in the header. Selecting a row applies the brand-tinted background. The header checkbox becomes indeterminate when only some rows are checked.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Click checkboxes to select rows</span></div>
      <div class="inp-demo-stage" style="padding:0;min-height:auto;display:block">
        ${tblTable('tbl-checkbox', { checkbox: true })}
      </div>
    </div>
  </div>

  <!-- STRIPED -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Striped</h2></div>
    <p class="doc-section-desc">Alternating row background to help the eye track across wide tables. Odd rows get <code>--table-row-bg-striped</code>; even rows stay default white.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Alternating row colors</span></div>
      <div class="inp-demo-stage" style="padding:0;min-height:auto;display:block">
        ${tblTable('tbl-striped', { striped: true })}
      </div>
    </div>
  </div>

  <!-- ROW STATES -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Row states</h2></div>
    <p class="doc-section-desc">All four row-level states shown together. Disabled rows suppress text, hide badges, and block pointer events — never just grey out with opacity alone.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Default / Hover / Selected / Disabled</span></div>
      <div class="inp-demo-stage" style="padding:0;min-height:auto;display:block">
        ${tblStatesTable()}
      </div>
    </div>
  </div>

  <!-- WITH FOOTER -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">With footer</h2></div>
    <p class="doc-section-desc">A 56px footer bar attaches below the table and carries the pagination controls: page info, per-page select, and Previous / Next. Change per-page to recalculate total pages (50 items in this demo).</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">50 items — navigate and change per page</span></div>
      <div class="inp-demo-stage" style="padding:0;min-height:auto;display:block">
        <div style="width:100%;border:1px solid var(--table-border-outline);border-radius:8px;overflow:hidden">
          <table id="tbl-footer" style="width:100%;border-collapse:collapse">
            <thead><tr>
              ${thSort('tbl-footer', 0, 'Name')}
              ${thSort('tbl-footer', 1, 'Status', '120px')}
              ${thSort('tbl-footer', 2, 'Email')}
              ${thSort('tbl-footer', 3, 'Date', '140px')}
            </tr></thead>
            <tbody>${ROWS.map((row, idx) => tdRow('tbl-footer', row, idx, idx === ROWS.length - 1, { interactive: true })).join('')}</tbody>
          </table>
          ${tblFooter('tbl-footer-pg', 1, 5, 10, 50)}
        </div>
      </div>
    </div>
  </div>

  <!-- COMPONENT TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <p class="doc-section-desc">All sizing values bound to the <code>Components</code> collection. Hover to preview the value, click to copy.</p>
    <div class="card" style="overflow:hidden;margin-bottom:16px">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Aliases → (hover for value, click to copy)</th><th>Usage</th></tr></thead>
        <tbody>${SIZING.table.map(tRow).join('')}</tbody>
      </table>
    </div>
  </div>

  <!-- PROPS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
    <table class="prop-table">
      <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
      <tbody>
        <tr><td><span class="prop-name">columns</span></td><td><span class="prop-type">Column[]</span></td><td><span class="prop-default">—</span></td><td>Column definitions: <code>{ key, label, sortable?, width?, render? }</code>. Required.</td></tr>
        <tr><td><span class="prop-name">data</span></td><td><span class="prop-type">object[]</span></td><td><span class="prop-default">—</span></td><td>Array of row objects keyed by column <code>key</code>. Required.</td></tr>
        <tr><td><span class="prop-name">selectable</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Adds a checkbox column and enables row selection.</td></tr>
        <tr><td><span class="prop-name">selectedRows</span></td><td><span class="prop-type">string[]</span></td><td><span class="prop-default">[]</span></td><td>Controlled array of selected row IDs.</td></tr>
        <tr><td><span class="prop-name">onSelectionChange</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Called with the new selected-row ID array when selection changes.</td></tr>
        <tr><td><span class="prop-name">striped</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Applies alternating row background colors.</td></tr>
        <tr><td><span class="prop-name">sortKey</span></td><td><span class="prop-type">string</span></td><td><span class="prop-default">—</span></td><td>Controlled sort column key. Pass <code>null</code> to clear.</td></tr>
        <tr><td><span class="prop-name">sortDir</span></td><td><span class="prop-type">"asc" | "desc"</span></td><td><span class="prop-default">—</span></td><td>Controlled sort direction.</td></tr>
        <tr><td><span class="prop-name">onSortChange</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Called with <code>{ key, dir }</code> when the user clicks a sortable header.</td></tr>
        <tr><td><span class="prop-name">footer</span></td><td><span class="prop-type">ReactNode</span></td><td><span class="prop-default">—</span></td><td>Renders inside the 56px footer bar. Typically a <code>&lt;Pagination&gt;</code> component.</td></tr>
      </tbody>
    </table>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use the footer pagination for datasets larger than one page. Attaching it directly to the table keeps navigation in the same visual context as the data.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't put more than 6–7 columns in a single table without considering horizontal scroll. Overflowing tables force users to scroll sideways and lose column headers.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use striped rows on wide or dense tables to help users track across rows. Skip them on compact tables — the extra contrast adds visual noise without benefit.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use just opacity to communicate a disabled row. Apply <code>--table-row-text-disabled</code> to text and hide badges — purely dimming the row is ambiguous and fails accessibility contrast checks.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Make the header sticky on tall tables so users retain column context while scrolling. Use <code>position: sticky; top: 0</code> on <code>thead</code>.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't show an empty table shell when data is loading. Use a skeleton or spinner overlay instead — an empty table with headers implies there is genuinely no data, not that it is loading.</div></div>
    </div>
  </div>

  </div>`;
}
