import { pageHeader, typeRows } from '../utils/render.js';
import { TYPE_ROLES } from '../data/tokens.js';

export default function typography() {
  return pageHeader('Tokens', 'Typography', '9 semantic roles · 2 modes (Latin + Arabic) · 18 Figma text styles. Latin: Montserrat + Inter. Arabic: Alexandria + Inter.', [{val:'9',label:'Roles'},{val:'2',label:'Modes'},{val:'18',label:'Text styles'}]) + `<div class="page-body">

    <!-- ── FONT FAMILIES ─────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Font families</h2></div>
      <div class="grid-2">
        <div class="card" style="padding:24px">
          <div style="font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--content-tertiary);margin-bottom:16px">Latin mode</div>
          <div style="margin-bottom:14px">
            <div style="font-family:'Montserrat',sans-serif;font-size:28px;font-weight:700;color:var(--content-primary);letter-spacing:-0.03em;margin-bottom:4px">Montserrat</div>
            <div style="font-size:11px;color:var(--brand-primary);font-family:monospace">font/family/primary — display & headings</div>
          </div>
          <div>
            <div style="font-family:'Inter',sans-serif;font-size:20px;font-weight:400;color:var(--content-primary);margin-bottom:4px">Inter</div>
            <div style="font-size:11px;color:var(--brand-primary);font-family:monospace">font/family/secondary — body & UI</div>
          </div>
        </div>
        <div class="card" style="padding:24px;direction:rtl;text-align:right">
          <div style="font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--content-tertiary);margin-bottom:16px">Arabic mode</div>
          <div style="margin-bottom:14px">
            <div style="font-family:'Alexandria',sans-serif;font-size:28px;font-weight:700;color:var(--content-primary);margin-bottom:4px">الإسكندرية</div>
            <div style="font-size:11px;color:var(--brand-primary);font-family:monospace">font/family/primary — display & headings</div>
          </div>
          <div>
            <div style="font-family:'Inter',sans-serif;font-size:20px;font-weight:400;color:var(--content-primary);margin-bottom:4px">Inter</div>
            <div style="font-size:11px;color:var(--brand-primary);font-family:monospace">font/family/secondary — body & UI</div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── SEMANTIC ROLES ──────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Semantic roles</h2><span class="doc-section-badge">9 tokens</span></div>
      <p class="doc-section-desc">Each role has /size, /weight, /line-height, /letter-spacing properties. Line-height is <code>auto</code> on all roles. Arabic uses Alexandria for headings, Inter for body — with a +2px size bump.</p>
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0;padding-bottom:12px;border-bottom:1px solid var(--border-subtle)">
        <div style="font-size:12px;color:var(--content-tertiary)">Toggle to compare specs between scripts</div>
        <div class="ctoken-mode-toggle">
          <button class="ctoken-mode-btn active" data-script="latin" onclick="setTypeScript(this.dataset.script,this)">Latin</button>
          <button class="ctoken-mode-btn" data-script="arabic" onclick="setTypeScript(this.dataset.script,this)">العربية</button>
        </div>
      </div>
      <div class="type-table">
        <div class="type-table-head">
          <div class="type-col-label">Token</div>
          <div class="type-col-label">Specs</div>
          <div class="type-col-label">Preview</div>
          <div class="type-col-label">Usage</div>
        </div>
        <div id="type-rows-container">${typeRows('latin')}</div>
      </div>
    </div>

    <!-- ── TEXT STYLES ─────────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Text styles</h2><span class="doc-section-badge">18 styles</span></div>
      <p class="doc-section-desc">18 Figma text styles created from the semantic roles — 11 Latin (<code>Text/*</code>) and 9 Arabic (<code>Text/AR/*</code>). Size, line-height, and letter-spacing are bound to Typography variables.</p>
      <div class="grid-2">
        <div class="card" style="overflow:hidden">
          <div style="padding:12px 16px;background:var(--background-subtle);border-bottom:1px solid var(--border-subtle);font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--content-tertiary)">Latin — Text/*</div>
          <div style="display:grid;grid-template-columns:1fr auto auto auto;padding:8px 16px;background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)">
            <span style="font-size:9px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary)">Style</span>
            <span style="font-size:9px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary);text-align:right;padding-left:16px">Size</span>
            <span style="font-size:9px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary);text-align:right;padding-left:16px">Weight</span>
            <span style="font-size:9px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary);text-align:right;padding-left:16px">Font</span>
          </div>
          ${[
            { name: 'Text/Page Title',           font: 'Montserrat', size: '20px', weight: '800', ls: '-4%' },
            { name: 'Text/Section Title Active',  font: 'Montserrat', size: '18px', weight: '600', ls: '-4%' },
            { name: 'Text/Section Title',         font: 'Montserrat', size: '18px', weight: '500', ls: '-4%' },
            { name: 'Text/Label',                 font: 'Inter',      size: '14px', weight: '500', ls: '-4%' },
            { name: 'Text/Body SM',               font: 'Inter',      size: '14px', weight: '400', ls: '-4%' },
            { name: 'Text/Button',                font: 'Inter',      size: '14px', weight: '600', ls: '-4%' },
            { name: 'Text/Helper',                font: 'Inter',      size: '14px', weight: '400', ls: '-4%', italic: true },
            { name: 'Text/Caption',               font: 'Inter',      size: '12px', weight: '400', ls: '-4%' },
            { name: 'Text/Caption Active',        font: 'Inter',      size: '12px', weight: '500', ls: '-4%' },
            { name: 'Text/Label MD', font: 'Inter', size: '16px', weight: '500', ls: '-4%' },
            { name: 'Text/Body MD',  font: 'Inter', size: '16px', weight: '400', ls: '-4%' },
            { name: 'Text/Label MD', font: 'Inter', size: '16px', weight: '500', ls: '-4%' },
            { name: 'Text/Body MD',  font: 'Inter', size: '16px', weight: '400', ls: '-4%' },
          ].map((s,i) => `
            <div style="display:grid;grid-template-columns:1fr auto auto auto;padding:10px 16px;${i%2===0?'background:var(--background-subtle)':''};border-bottom:1px solid var(--border-subtle);align-items:center">
              <span style="font-size:12px;color:var(--content-primary);font-weight:500">${s.name}${s.italic ? ' <span style="font-size:10px;color:var(--content-tertiary);font-style:italic">italic</span>' : ''}</span>
              <span style="font-size:11px;font-family:monospace;color:var(--content-secondary);text-align:right;padding-left:16px">${s.size}</span>
              <span style="font-size:11px;font-family:monospace;color:var(--content-secondary);text-align:right;padding-left:16px">${s.weight}</span>
              <span style="font-size:11px;font-family:monospace;color:var(--brand-primary);text-align:right;padding-left:16px">${s.font}</span>
            </div>`).join('')}
        </div>
        <div class="card" style="overflow:hidden">
          <div style="padding:12px 16px;background:var(--background-subtle);border-bottom:1px solid var(--border-subtle);font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--content-tertiary)">Arabic — Text/AR/*</div>
          <div style="display:grid;grid-template-columns:1fr auto auto auto;padding:8px 16px;background:var(--background-subtle);border-bottom:1px solid var(--border-subtle)">
            <span style="font-size:9px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary)">Style</span>
            <span style="font-size:9px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary);text-align:right;padding-left:16px">Size</span>
            <span style="font-size:9px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary);text-align:right;padding-left:16px">Weight</span>
            <span style="font-size:9px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary);text-align:right;padding-left:16px">Font</span>
          </div>
          ${[
            { name: 'Text/AR/Page Title',          font: 'Alexandria', size: '20px', weight: '800', bump: false },
            { name: 'Text/AR/Section Title Active', font: 'Alexandria', size: '18px', weight: '600', bump: false },
            { name: 'Text/AR/Section Title',        font: 'Alexandria', size: '18px', weight: '500', bump: false },
            { name: 'Text/AR/Label',                font: 'Inter',      size: '16px', weight: '500', bump: true  },
            { name: 'Text/AR/Body SM',              font: 'Inter',      size: '16px', weight: '400', bump: true  },
            { name: 'Text/AR/Button',               font: 'Inter',      size: '16px', weight: '600', bump: true  },
            { name: 'Text/AR/Helper',               font: 'Inter',      size: '16px', weight: '400', bump: true  },
            { name: 'Text/AR/Caption',              font: 'Inter',      size: '14px', weight: '400', bump: true  },
            { name: 'Text/AR/Caption Active',       font: 'Inter',      size: '14px', weight: '500', bump: true  },
          ].map((s,i) => `
            <div style="display:grid;grid-template-columns:1fr auto auto auto;padding:10px 16px;${i%2===0?'background:var(--background-subtle)':''};border-bottom:1px solid var(--border-subtle);align-items:center">
              <span style="font-size:12px;color:var(--content-primary);font-weight:500">${s.name}</span>
              <span style="font-size:11px;font-family:monospace;color:${s.bump ? '#430098' : 'var(--content-secondary)'};font-weight:${s.bump ? '600' : '400'};text-align:right;padding-left:16px">${s.size}</span>
              <span style="font-size:11px;font-family:monospace;color:var(--content-secondary);text-align:right;padding-left:16px">${s.weight}</span>
              <span style="font-size:11px;font-family:monospace;color:var(--brand-primary);text-align:right;padding-left:16px">${s.font}</span>
            </div>`).join('')}
          <div style="padding:10px 16px;background:#F7F0FF;border-top:1px solid var(--border-subtle);font-size:11px;color:#430098">
            <strong>↑ Purple size</strong> = +2px Arabic bump vs Latin equivalent
          </div>
        </div>
      </div>
    </div>

    <!-- ── FONT WEIGHTS ────────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Font weights</h2></div>
      <div class="weight-table">
        ${[['regular','400',400],['medium','500',500],['semibold','600',600],['bold','700',700],['extrabold','800',800]].map(([n,v,w]) => `
          <div class="weight-row">
            <div class="weight-meta">
              <div class="weight-token-name">font/weight/${n}</div>
              <div class="weight-val">${v}</div>
            </div>
            <div class="weight-demo" style="font-weight:${w}">Iksir Design System ${v}</div>
          </div>`).join('')}
      </div>
    </div>

    <!-- ── PLAYGROUND ──────────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header">
        <h2 class="doc-section-title">Type tester</h2>
        <span class="doc-section-badge">Interactive</span>
      </div>

      <div class="playground" id="type-playground">

        <!-- Top toolbar -->
        <div class="pg-toolbar">

          <!-- Script toggle -->
          <div class="pg-toolbar-group">
            <button class="pg-tab active" id="pg-latin-btn" onclick="setScript('latin',this)">Latin</button>
            <button class="pg-tab" id="pg-arabic-btn" onclick="setScript('arabic',this)">العربية</button>
          </div>

          <!-- Size slider -->
          <div class="pg-toolbar-group pg-toolbar-size">
            <span class="pg-toolbar-label">Size</span>
            <input type="range" id="pg-size" min="10" max="80" value="20" step="1" oninput="updatePlayground()">
            <span class="pg-val" id="pg-size-val">20px</span>
          </div>

          <!-- Weight -->
          <div class="pg-toolbar-group">
            <span class="pg-toolbar-label">Weight</span>
            <select id="pg-weight-select" onchange="setWeightFromSelect(this.value)" style="font-family:var(--font-body);font-size:12px;padding:5px 8px;border:1px solid var(--border-default);border-radius:var(--radius-lg);background:var(--background-surface);color:var(--content-primary);cursor:pointer;outline:none">
              ${[['Regular','400'],['Medium','500'],['SemiBold','600'],['Bold','700'],['ExtraBold','800']].map(([n,v]) =>
                `<option value="${v}" ${v==='600'?'selected':''}>${n}</option>`
              ).join('')}
            </select>
          </div>

          <!-- Letter spacing -->
          <div class="pg-toolbar-group pg-toolbar-size">
            <span class="pg-toolbar-label">Spacing</span>
            <input type="range" id="pg-ls" min="-8" max="8" value="-4" step="1" oninput="updatePlayground()">
            <span class="pg-val" id="pg-ls-val">-4%</span>
          </div>

          <!-- Color -->
          <div class="pg-toolbar-group">
            <span class="pg-toolbar-label">Color</span>
            <div class="pg-color-dots">
              ${[
                ['#191919','Primary','content/primary'],
                ['#757575','Secondary','content/secondary'],
                ['#430098','Brand','brand/primary'],
                ['#FFFFFF','White','content/inverse'],
              ].map(([hex, label, token], i) =>
                `<button class="pg-color-dot-btn ${i===0?'active':''}" onclick="setColor('${hex}','${token}',this)" title="${label}" style="background:${hex};${hex==='#FFFFFF'?'border:2px solid #E1E1E1':'border:2px solid transparent'}"></button>`
              ).join('')}
            </div>
          </div>

          <!-- Background -->
          <div class="pg-toolbar-group">
            <span class="pg-toolbar-label">Canvas</span>
            <div class="pg-color-dots">
              ${[
                ['#FFFFFF','Page','#191919'],
                ['#F7F4FB','Brand subtle','#430098'],
                ['#430098','Brand','#FFFFFF'],
                ['#111118','Dark','#FFFFFF'],
              ].map(([hex, label, tc], i) =>
                `<button class="pg-color-dot-btn ${i===0?'active':''}" onclick="setBg('${hex}','${tc}',this)" title="${label}" style="background:${hex};${hex==='#FFFFFF'?'border:2px solid #E1E1E1':'border:2px solid transparent'}"></button>`
              ).join('')}
            </div>
          </div>

        </div>

        <!-- Large preview canvas -->
        <div class="pg-canvas" id="pg-canvas">
          <div class="pg-text" id="pg-text" contenteditable="true" spellcheck="false" oninput="this.dataset.edited='1'">The quick brown fox jumps over the lazy dog</div>
        </div>

        <!-- Token role chips -->
        <div class="pg-roles-bar">
          <span class="pg-roles-label">Token role</span>
          <div class="pg-presets" id="pg-presets">
            ${TYPE_ROLES.map((r, i) => `
              <button class="pg-preset ${i === 0 ? 'active' : ''}" onclick="applyPreset(${i})" data-idx="${i}">
                ${r.token.replace('text/','')}
              </button>`).join('')}
            <button class="pg-preset" onclick="applyPreset(-1)" data-idx="-1">custom</button>
          </div>
        </div>

      </div>
    </div>

  </div>`;
}
