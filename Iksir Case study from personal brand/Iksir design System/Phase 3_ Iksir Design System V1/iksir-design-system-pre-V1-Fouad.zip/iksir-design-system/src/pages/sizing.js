import { pageHeader } from '../utils/render.js';
import { SIZING } from '../data/sizing.js';

export default function sizing() {
  const groups = [
    { id: 'button',     label: 'Button',     items: SIZING.button },
    { id: 'input',      label: 'Input',      items: SIZING.input },
    { id: 'checkbox',   label: 'Checkbox',   items: SIZING.checkbox },
    { id: 'badge',      label: 'Badge',      items: SIZING.badge },
    { id: 'select',     label: 'Select',     items: SIZING.select },
    { id: 'dropdown',   label: 'Dropdown',   items: SIZING.dropdown },
    { id: 'toggle',     label: 'Toggle',     items: SIZING.toggle },
    { id: 'breadcrumb', label: 'Breadcrumb', items: SIZING.breadcrumb },
    { id: 'table',      label: 'Table',      items: SIZING.table },
    { id: 'tab',        label: 'Tab',        items: SIZING.tab },
    { id: 'counter',    label: 'Counter',    items: SIZING.counter },
    { id: 'toast',      label: 'Toast',      items: SIZING.toast },
    { id: 'modal',      label: 'Modal',      items: SIZING.modal },
    { id: 'avatar',     label: 'Avatar',     items: SIZING.avatar },
    { id: 'pagination', label: 'Pagination', items: SIZING.pagination },
    { id: 'sidebar',    label: 'Sidebar',    items: SIZING.sidebar },
  ];

  const total = groups.reduce((s, g) => s + g.items.length, 0);
  const allItems = groups.flatMap(g => g.items.map(t => ({ ...t, group: g.id })));

  function visual(t) {
    if (t.type === 'radius') {
      const r = t.val >= 9999 ? 12 : Math.min(t.val, 12);
      return '<div class="sz-radius-preview" style="border-radius:' + r + 'px"></div>';
    }
    if (t.type === 'border') {
      const h = Math.min(Math.max(t.val, 1), 4);
      return '<div class="sz-border-preview"><div class="sz-border-line" style="height:' + h + 'px"></div></div>';
    }
    if (t.type === 'large') {
      return '<div class="sz-large-preview"><span class="sz-large-val">' + t.val + '</span></div>';
    }
    // space + icon: proportional bar capped at 64px display width
    const MAX_DISPLAY = 64;
    const MAX_VAL = 64;
    const bw = t.val === 0 ? 2 : Math.max(3, Math.round((Math.min(t.val, MAX_VAL) / MAX_VAL) * MAX_DISPLAY));
    const accent = t.type === 'icon' ? '#8E66C1' : '#430098';
    return '<div class="sz-bar-preview"><div class="sz-bar" style="width:' + bw + 'px;background:' + accent + '"></div></div>';
  }

  function sizingRow(t, groupId) {
    return '<div class="ctoken-row" data-group="' + groupId + '">' +
      '<div class="sz-visual">' + visual(t) + '</div>' +
      '<div class="ctoken-name">' +
        '<div class="ctoken-token">' + t.token + '</div>' +
        '<div class="ctoken-label">' + t.label + '</div>' +
      '</div>' +
      '<div class="ctoken-hex">' +
        '<div class="ctoken-prim-main">' + t.ref + '</div>' +
        '<div class="ctoken-hex-sub">' + (t.val >= 9999 ? '9999px' : t.val + 'px') + '</div>' +
      '</div>' +
      '<div class="ctoken-use">' + (t.use || '') + '</div>' +
    '</div>';
  }

  return pageHeader('Tokens', 'Sizing', 'Component-specific dimensions from the Figma Components collection. Heights, padding, gaps, radii and border widths per component and size variant.', [
    { val: String(total),  label: 'Sizing tokens' },
    { val: String(groups.length), label: 'Components' },
    { val: '3',            label: 'Size variants' },
  ]) +
  '<div class="page-body">' +
  '<div class="doc-section">' +

  '<div class="ctoken-toolbar">' +
    '<div class="ctoken-tabs" id="sz-tabs">' +
      '<button class="ctoken-tab active" data-group="all" onclick="setSizingTab(this.dataset.group,this)">All <span class="ctoken-tab-count">' + total + '</span></button>' +
      groups.map(g =>
        '<button class="ctoken-tab" data-group="' + g.id + '" onclick="setSizingTab(this.dataset.group,this)">' +
          g.label + ' <span class="ctoken-tab-count">' + g.items.length + '</span>' +
        '</button>'
      ).join('') +
    '</div>' +
  '</div>' +

  '<div class="ctoken-table-head">' +
    '<div></div>' +
    '<div>Token</div>' +
    '<div>Value</div>' +
    '<div>Usage</div>' +
  '</div>' +

  '<div class="ctoken-table" id="sz-table">' +
    allItems.map(t => sizingRow(t, t.group)).join('') +
  '</div>' +

  '</div>' +
  '</div>';
}
