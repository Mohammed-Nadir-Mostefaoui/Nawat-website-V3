import { pageHeader, radiusCards } from '../utils/render.js';

export default function radius() {
  return pageHeader('Tokens', 'Border Radius', '8 semantic aliases with scale names — not component names. radius/lg works on buttons, inputs, and toggles without coupling.', [{val:'8',label:'Semantic tokens'}]) + `<div class="page-body">
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Semantic aliases</h2></div>
      <div class="grid-4">${radiusCards()}</div>
    </div>
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Scale vs component names</h2></div>
      <div class="grid-2">
        <div class="rule-card accent">
          <div class="rule-card-title">Scale names stay neutral</div>
          <div class="rule-card-body"><code>radius/lg</code> (8px) works on buttons, inputs, selects, toggles, and search bars — without any feeling semantically wrong. Change it once, every component updates.</div>
        </div>
        <div class="rule-card">
          <div class="rule-card-title">Component names create coupling</div>
          <div class="rule-card-body">If you name it <code>radius/button</code>, you can't reuse it on an input without confusion. Every new component spawns a new token. The system grows faster than it should.</div>
        </div>
      </div>
    </div>
  </div>`;
}
