import { comingSoon } from '../utils/render.js';

export default function() {
  return comingSoon('Figma Library', 'How to enable and use the Iksir library in your Figma file.');
}
