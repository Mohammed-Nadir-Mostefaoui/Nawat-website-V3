import { pageHeader } from '../utils/render.js';

export default function() {
  return pageHeader('Resources', 'Changelog', 'A version history of the Iksir design system — token decisions, component additions, and breaking changes.') + `<div class="page-body">

    <div class="doc-section">

      ${[
        {
          version: 'v1.5',
          date: 'March 2026',
          badge: 'latest',
          items: [
            { type: 'new',      text: 'Components collection — semantic spacing layer aliasing from Spacing primitives. 13 button tokens covering height, padding, gap, icon size, radius, and focus ring.' },
            { type: 'new',      text: 'Button component rebuilt — 4 properties (Hierarchy, Size, Icon, State), 450 variants. All spacing bound to Components collection tokens.' },
            { type: 'new',      text: 'Button hierarchies renamed — Primary, Secondary color, Secondary gray, Tertiary color, Tertiary gray, Destructive, Link color, Link gray.' },
            { type: 'improved', text: 'Focus ring on all Focused variants — 2px OUTSIDE stroke with 2px offset. Destructive uses status/danger-border instead of border/focus.' },
            { type: 'new',      text: '4 new status/danger tokens — danger-bg-hover, danger-bg-active, danger-border-hover, danger-border-active. Applied to Destructive button Hover and Active states.' },
            { type: 'improved', text: 'Per-section dark mode toggle on Button page — each variant section has its own toggle using Figma dark mode tokens.' },
            { type: 'fixed',    text: 'background/subtle Light updated to Grey-20 (#F6F6F6) — was identical to background/page after page changed to #FAFAFA.' },
            { type: 'fixed',    text: 'background/raised Dark updated to Black-70 (#5E5E5E) — was identical to background/subtle in dark mode.' },
          ]
        },
        {
          version: 'v1.4',
          date: 'March 2026',
          badge: '',
          items: [
            { type: 'new',      text: 'Documentation platform restructured — compact page headers, right rail "On this page" navigation, full-width on empty pages' },
            { type: 'new',      text: 'Colors page — tabbed by group (Brand/Content/Icon/Background/Border/Status), Light/Dark mode toggle, click-to-copy hex' },
            { type: 'new',      text: 'Primitives page — same row structure as Colors, tabbed by ramp, click-to-copy' },
            { type: 'new',      text: 'Typography page — Latin/Arabic toggle on semantic roles table, full specs in Text Styles cards' },
            { type: 'new',      text: 'Button page — restructured per Untitled UI pattern, each variant as own section, dark mode toggle using Figma dark tokens' },
            { type: 'improved', text: 'All purple hero banners removed — replaced with compact page headers across all pages' },
            { type: 'improved', text: 'Sidebar badges removed, cleaner nav' },
          ]
        },
        {
          version: 'v1.3',
          date: 'March 2026',
          badge: '',
          items: [
            { type: 'new',      text: 'Iconography system — Lucide Icons, 86 icons across 7 categories, RTL/LTR mirroring rules documented' },
            { type: 'new',      text: 'Icons collection in Figma — icon/size/sm (16), icon/size/md (20), icon/size/lg (24), icon/stroke/weight (1.5px)' },
            { type: 'new',      text: 'Icon browser with tabs by category and Directional-only filter' },
          ]
        },
        {
          version: 'v1.2',
          date: 'March 2026',
          badge: '',
          items: [
            { type: 'new',      text: 'Accessibility page — Contrast ratios, Brand background rule, Focus ring, Touch targets, Dual-script typography, Color independence, Screen reader guidelines' },
            { type: 'new',      text: 'focus/width (2px) and focus/offset (2px) tokens added to Tokens collection' },
            { type: 'new',      text: 'Dual-script sizing rule implemented — Arabic body text +2px larger than Latin (label/body-sm/button/helper: 16px, caption: 14px)' },
            { type: 'new',      text: 'Brand background contrast rule documented — content/secondary fails on background/brand (1.8:1), use content/on-brand instead' },
            { type: 'fixed',    text: 'Arabic secondary font corrected to Inter — only display/headings use Alexandria' },
            { type: 'fixed',    text: 'font/family/secondary in Typography collection Arabic mode updated to Inter' },
          ]
        },
        {
          version: 'v1.1',
          date: 'February 2026',
          badge: '',
          items: [
            { type: 'new',      text: 'Button component — 60 variants (Primary/Secondary/Ghost/Destructive × SM/MD/LG × 5 states), fully token-bound' },
            { type: 'new',      text: 'Arabic typography mode — Alexandria for display/headings, Inter for body/UI, 0% letter-spacing' },
            { type: 'new',      text: 'Typography collection — 18 text styles (9 Latin Text/*, 9 Arabic Text/AR/*), semantic roles with size/weight/line-height/letter-spacing' },
            { type: 'new',      text: 'Figma library published — team can now use Iksir tokens and components in their files' },
          ]
        },
        {
          version: 'v1.0',
          date: 'February 2026',
          badge: 'initial',
          items: [
            { type: 'new', text: 'Primitives collection — 8 color ramps (Purple, Light Purple, Dark Purple, Red, Green, Amber, Black, Grey), 85 total stops' },
            { type: 'new', text: 'Tokens collection — 41 semantic color tokens across brand, content, icon, background, border, status groups. Light + Dark modes' },
            { type: 'new', text: 'Spacing collection — 22-step 4pt grid, 0–160px' },
            { type: 'new', text: 'Border Radius collection — 8 semantic aliases (radius/none → radius/full)' },
            { type: 'new', text: 'Elevation collection — 4 levels (Card/Dropdown/Modal/Toast) as STRING tokens + Effect Styles. Light + Dark modes' },
            { type: 'new', text: 'Documentation platform launched — single HTML file with all token documentation' },
          ]
        },
      ].map(v => `
        <div style="display:flex;gap:24px;padding-bottom:32px;border-bottom:1px solid var(--border-subtle);margin-bottom:32px">
          <div style="width:100px;flex-shrink:0">
            <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
              <span style="font-size:13px;font-weight:700;color:var(--content-primary)">${v.version}</span>
              ${v.badge === 'latest' ? '<span style="font-size:9px;font-weight:700;padding:1px 6px;border-radius:3px;background:#430098;color:#fff">Latest</span>' : v.badge === 'initial' ? '<span style="font-size:9px;font-weight:700;padding:1px 6px;border-radius:3px;background:var(--background-subtle);color:var(--content-tertiary);border:1px solid var(--border-subtle)">Initial</span>' : ''}
            </div>
            <div style="font-size:11px;color:var(--content-tertiary)">${v.date}</div>
          </div>
          <div style="flex:1;display:flex;flex-direction:column;gap:6px">
            ${v.items.map(item => {
              const colors = {
                new:      { bg:'#F2FDF6', text:'#148F47', label:'New' },
                improved: { bg:'#F7F0FF', text:'#430098', label:'Improved' },
                fixed:    { bg:'#FFF2F4', text:'#D8192C', label:'Fixed' },
                breaking: { bg:'#FEFBF6', text:'#AE7004', label:'Breaking' },
              };
              const c = colors[item.type] || colors.new;
              return '<div style="display:flex;align-items:flex-start;gap:8px">' +
                '<span style="font-size:9px;font-weight:700;padding:2px 6px;border-radius:3px;background:' + c.bg + ';color:' + c.text + ';flex-shrink:0;margin-top:1px">' + c.label + '</span>' +
                '<span style="font-size:13px;color:var(--content-secondary);line-height:1.5">' + item.text + '</span>' +
                '</div>';
            }).join('')}
          </div>
        </div>`).join('')}

    </div>
  </div>`;
}
