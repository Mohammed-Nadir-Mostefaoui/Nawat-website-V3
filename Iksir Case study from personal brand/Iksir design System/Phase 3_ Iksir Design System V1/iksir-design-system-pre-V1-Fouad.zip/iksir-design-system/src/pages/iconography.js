import { pageHeader, iconSvg } from '../utils/render.js';

const ICON_CATEGORIES = [
  {
    name: 'Navigation & Actions',
    icons: [
      { name: 'ArrowRight',    rtl: true,  use: 'Next, forward, proceed',         path: '<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>' },
      { name: 'ArrowLeft',     rtl: true,  use: 'Back, previous, return',         path: '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>' },
      { name: 'ArrowUp',       rtl: false, use: 'Sort ascending, scroll up',      path: '<line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/>' },
      { name: 'ArrowDown',     rtl: false, use: 'Sort descending, scroll down',   path: '<line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>' },
      { name: 'ChevronRight',  rtl: true,  use: 'Expand, breadcrumb, nav item',   path: '<polyline points="9 18 15 12 9 6"/>' },
      { name: 'ChevronLeft',   rtl: true,  use: 'Collapse, previous page',        path: '<polyline points="15 18 9 12 15 6"/>' },
      { name: 'ChevronUp',     rtl: false, use: 'Collapse section, accordion',    path: '<polyline points="18 15 12 9 6 15"/>' },
      { name: 'ChevronDown',   rtl: false, use: 'Expand section, dropdown',       path: '<polyline points="6 9 12 15 18 9"/>' },
      { name: 'ChevronsRight', rtl: true,  use: 'Skip forward, last page',        path: '<polyline points="13 17 18 12 13 7"/><polyline points="6 17 11 12 6 7"/>' },
      { name: 'ChevronsLeft',  rtl: true,  use: 'Skip back, first page',          path: '<polyline points="11 17 6 12 11 7"/><polyline points="18 17 13 12 18 7"/>' },
      { name: 'ExternalLink',  rtl: true,  use: 'Open in new tab',                path: '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>' },
      { name: 'LogOut',        rtl: true,  use: 'Sign out of account',            path: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>' },
      { name: 'LogIn',         rtl: true,  use: 'Sign in',                        path: '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/>' },
      { name: 'Menu',          rtl: false, use: 'Hamburger menu, open nav',       path: '<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>' },
      { name: 'Home',          rtl: false, use: 'Dashboard, home page',           path: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>' },
      { name: 'MoveRight',     rtl: true,  use: 'Move item, drag indicator',      path: '<path d="M18 8L22 12L18 16"/><path d="M2 12H22"/>' },
    ]
  },
  {
    name: 'Editing & Content',
    icons: [
      { name: 'Plus',          rtl: false, use: 'Add, create new',                path: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>' },
      { name: 'Minus',         rtl: false, use: 'Remove, subtract',               path: '<line x1="5" y1="12" x2="19" y2="12"/>' },
      { name: 'X',             rtl: false, use: 'Close, dismiss, remove tag',     path: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>' },
      { name: 'Check',         rtl: false, use: 'Confirm, success, done',         path: '<polyline points="20 6 9 17 4 12"/>' },
      { name: 'Pencil',        rtl: false, use: 'Edit, rename',                   path: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>' },
      { name: 'Trash2',        rtl: false, use: 'Delete, remove permanently',     path: '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/>' },
      { name: 'Copy',          rtl: false, use: 'Duplicate, copy to clipboard',   path: '<rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>' },
      { name: 'Save',          rtl: false, use: 'Save, persist data',             path: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/>' },
      { name: 'Send',          rtl: true,  use: 'Send message, submit form',      path: '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>' },
      { name: 'Reply',         rtl: true,  use: 'Reply to message or comment',    path: '<polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 0 0-4-4H4"/>' },
      { name: 'Scissors',      rtl: false, use: 'Cut, remove section',            path: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/>' },
      { name: 'ClipboardList', rtl: false, use: 'Form, checklist, task list',     path: '<rect x="8" y="2" width="8" height="4" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><line x1="12" y1="11" x2="16" y2="11"/><line x1="12" y1="16" x2="16" y2="16"/><line x1="8" y1="11" x2="8.01" y2="11"/><line x1="8" y1="16" x2="8.01" y2="16"/>' },
      { name: 'Tags',          rtl: false, use: 'Labels, categories, tags',       path: '<path d="M9 5H2v7l6.29 6.29c.94.94 2.48.94 3.42 0l3.58-3.58c.94-.94.94-2.48 0-3.42L9 5Z"/><path d="M6 9.01V9"/><path d="m15 5 6.3 6.3a2.4 2.4 0 0 1 0 3.4L17 19"/>' },
    ]
  },
  {
    name: 'Data & Files',
    icons: [
      { name: 'Search',        rtl: false, use: 'Search, find, filter',           path: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>' },
      { name: 'Filter',        rtl: false, use: 'Filter data, narrow results',    path: '<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>' },
      { name: 'SortAsc',       rtl: false, use: 'Sort ascending (A→Z, 0→9)',      path: '<path d="m3 8 4-4 4 4"/><path d="M7 4v16"/><path d="M11 12h4"/><path d="M11 16h7"/><path d="M11 20h10"/>' },
      { name: 'SortDesc',      rtl: false, use: 'Sort descending (Z→A, 9→0)',     path: '<path d="m3 16 4 4 4-4"/><path d="M7 20V4"/><path d="M11 4h10"/><path d="M11 8h7"/><path d="M11 12h4"/>' },
      { name: 'Download',      rtl: false, use: 'Export, download file',          path: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>' },
      { name: 'Upload',        rtl: false, use: 'Import, upload file',            path: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>' },
      { name: 'FileText',      rtl: false, use: 'Document, report, invoice',      path: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/>' },
      { name: 'Folder',        rtl: false, use: 'Folder, file group',             path: '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>' },
      { name: 'Table',         rtl: false, use: 'Data table, grid view',          path: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M3 15h18"/><path d="M9 3v18"/><path d="M15 3v18"/>' },
      { name: 'BarChart2',     rtl: false, use: 'Analytics, reports, stats',      path: '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>' },
      { name: 'PieChart',      rtl: false, use: 'Chart, distribution, share',     path: '<path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/>' },
      { name: 'RefreshCw',     rtl: false, use: 'Refresh, reload, sync',          path: '<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>' },
      { name: 'Database',      rtl: false, use: 'Database, storage, data source', path: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/>' },
      { name: 'Package',       rtl: false, use: 'Product, item, inventory',       path: '<line x1="16.5" y1="9.4" x2="7.5" y2="4.21"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>' },
    ]
  },
  {
    name: 'Status & Feedback',
    icons: [
      { name: 'AlertTriangle', rtl: false, use: 'Warning, caution',              path: '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>' },
      { name: 'AlertCircle',   rtl: false, use: 'Error, danger, critical alert', path: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>' },
      { name: 'CheckCircle2',  rtl: false, use: 'Success, completed, valid',     path: '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>' },
      { name: 'Info',          rtl: false, use: 'Info, help, tooltip trigger',   path: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>' },
      { name: 'Clock',         rtl: false, use: 'Time, pending, scheduled',      path: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>' },
      { name: 'Loader2',       rtl: false, use: 'Loading, processing, spinner',  path: '<path d="M21 12a9 9 0 1 1-6.219-8.56"/>' },
      { name: 'Ban',           rtl: false, use: 'Blocked, forbidden, cancelled', path: '<circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/>' },
      { name: 'Bell',          rtl: false, use: 'Notifications, alerts',         path: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>' },
      { name: 'BellOff',       rtl: false, use: 'Mute notifications',            path: '<path d="M13.73 21a2 2 0 0 1-3.46 0"/><path d="M18.63 13A17.89 17.89 0 0 1 18 8"/><path d="M6.26 6.26A5.86 5.86 0 0 0 6 8c0 7-3 9-3 9h14"/><path d="M18 8a6 6 0 0 0-9.33-5"/><line x1="1" y1="1" x2="23" y2="23"/>' },
    ]
  },
  {
    name: 'User & Account',
    icons: [
      { name: 'User',          rtl: false, use: 'User profile, account',         path: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>' },
      { name: 'Users',         rtl: false, use: 'Team, group, customers',        path: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>' },
      { name: 'UserPlus',      rtl: false, use: 'Add user, invite',              path: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/>' },
      { name: 'Settings',      rtl: false, use: 'Settings, configuration',       path: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>' },
      { name: 'Lock',          rtl: false, use: 'Locked, secure, restricted',    path: '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>' },
      { name: 'Unlock',        rtl: false, use: 'Unlocked, accessible',          path: '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>' },
      { name: 'Shield',        rtl: false, use: 'Security, permissions, roles',  path: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>' },
      { name: 'Key',           rtl: false, use: 'API key, password, access',     path: '<path d="m21 2-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0 3 3L22 7l-3-3m-3.5 3.5L19 4"/>' },
      { name: 'Mail',          rtl: false, use: 'Email, message, contact',       path: '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>' },
      { name: 'Phone',         rtl: false, use: 'Phone, call, contact',          path: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.35A2 2 0 0 1 3.6 1h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.6a16 16 0 0 0 6 6l.92-.92a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>' },
    ]
  },
  {
    name: 'Commerce & ERP',
    icons: [
      { name: 'ShoppingBag',   rtl: false, use: 'Order, purchase, cart',         path: '<path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/>' },
      { name: 'CreditCard',    rtl: false, use: 'Payment, billing, invoice',     path: '<rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>' },
      { name: 'Truck',         rtl: true,  use: 'Delivery, shipping, logistics', path: '<rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>' },
      { name: 'Warehouse',     rtl: false, use: 'Warehouse, stock, inventory',   path: '<path d="m2 3 20 0"/><path d="M3 3v14"/><path d="M21 3v14"/><path d="M6 21V3"/><path d="M18 21V3"/><path d="m2 21 20 0"/><path d="M9 21V9h6v12"/>' },
      { name: 'Receipt',       rtl: false, use: 'Receipt, transaction, record',  path: '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1-2-1z"/><line x1="8" y1="9" x2="16" y2="9"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="11" y1="17" x2="16" y2="17"/>' },
      { name: 'Building2',     rtl: false, use: 'Company, organization, client', path: '<path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"/><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"/><path d="M10 6h4"/><path d="M10 10h4"/><path d="M10 14h4"/><path d="M10 18h4"/>' },
      { name: 'Calendar',      rtl: false, use: 'Date, deadline, schedule',      path: '<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>' },
      { name: 'DollarSign',    rtl: false, use: 'Price, revenue, budget',        path: '<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>' },
      { name: 'TrendingUp',    rtl: false, use: 'Growth, increase, positive KPI',path: '<polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>' },
      { name: 'TrendingDown',  rtl: false, use: 'Decline, decrease, loss',       path: '<polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/>' },
      { name: 'Boxes',         rtl: false, use: 'Products, stock, inventory',    path: '<path d="M2.97 12.92A2 2 0 0 0 2 14.63v3.24a2 2 0 0 0 .97 1.71l3 1.8a2 2 0 0 0 2.06 0L12 19v-5.5l-5-3-4.03 2.42Z"/><path d="m7 16.5-4.74-2.85"/><path d="m7 16.5 5-3"/><path d="M7 16.5v5.17"/><path d="M12 13.5V19l3.97 2.38a2 2 0 0 0 2.06 0l3-1.8a2 2 0 0 0 .97-1.71v-3.24a2 2 0 0 0-.97-1.71L17 10.5l-5 3Z"/><path d="m17 16.5-5-3"/><path d="m17 16.5 4.74-2.85"/><path d="M17 16.5v5.17"/><path d="M7.97 4.42A2 2 0 0 0 7 6.13v4.37l5 3 5-3V6.13a2 2 0 0 0-.97-1.71l-3-1.8a2 2 0 0 0-2.06 0l-3 1.8Z"/><path d="M12 8 7.26 5.15"/><path d="m12 8 4.74-2.85"/><path d="M12 13.5V8"/>' },
      { name: 'ClipboardCheck',rtl: false, use: 'Validated form, approved task', path: '<rect x="8" y="2" width="8" height="4" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/>' },
    ]
  },
  {
    name: 'UI & Layout',
    icons: [
      { name: 'Eye',           rtl: false, use: 'View, preview, show password',  path: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>' },
      { name: 'EyeOff',        rtl: false, use: 'Hide, mask, hide password',     path: '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>' },
      { name: 'Star',          rtl: false, use: 'Favourite, rating, bookmark',   path: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>' },
      { name: 'Bookmark',      rtl: false, use: 'Save for later, pin item',      path: '<path d="m19 21-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>' },
      { name: 'Grid',          rtl: false, use: 'Grid view, card layout',        path: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>' },
      { name: 'List',          rtl: false, use: 'List view, table layout',       path: '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>' },
      { name: 'MoreHorizontal',rtl: false, use: 'More actions, overflow menu',   path: '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>' },
      { name: 'MoreVertical',  rtl: false, use: 'More actions (vertical)',       path: '<circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/>' },
      { name: 'Maximize2',     rtl: false, use: 'Expand, fullscreen',            path: '<polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/>' },
      { name: 'Minimize2',     rtl: false, use: 'Collapse, exit fullscreen',     path: '<polyline points="4 14 10 14 10 20"/><polyline points="20 10 14 10 14 4"/><line x1="10" y1="14" x2="3" y2="21"/><line x1="21" y1="3" x2="14" y2="10"/>' },
      { name: 'Columns',       rtl: false, use: 'Column layout, split view',     path: '<rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="12" y1="3" x2="12" y2="21"/>' },
      { name: 'Sidebar',       rtl: true,  use: 'Toggle sidebar',               path: '<rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="9" y1="3" x2="9" y2="21"/>' },
      { name: 'PanelLeft',     rtl: true,  use: 'Open left panel',              path: '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><line x1="9" y1="3" x2="9" y2="21"/>' },
      { name: 'Printer',       rtl: false, use: 'Print document',               path: '<polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>' },
      { name: 'Monitor',       rtl: false, use: 'Desktop, screen, display',     path: '<rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>' },
      { name: 'Smartphone',    rtl: false, use: 'Mobile device, app',           path: '<rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/>' },
    ]
  },
];

export default function() {
  return pageHeader('Tokens', 'Iconography', 'Lucide Icons — the official icon library for Shadcn/UI. 1.5px stroke, three standard sizes, full RTL/LTR mirroring rules.', [{val:'86',label:'Icons'},{val:'3',label:'Sizes'},{val:'1.5px',label:'Stroke weight'}]) + `<div class="page-body">

    <!-- ── LIBRARY & SIZES ────────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Library & sizes</h2></div>
      <div class="grid-2" style="margin-bottom:24px">
        <div class="card" style="padding:24px">
          <div style="font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary);margin-bottom:16px">Library</div>
          <div style="font-size:20px;font-weight:700;color:var(--content-primary);margin-bottom:6px">Lucide Icons</div>
          <div style="font-size:13px;color:var(--content-secondary);line-height:1.7;margin-bottom:16px">Ships with Shadcn/UI — zero extra setup for web. Consistent 24×24 grid, 1.5px stroke, rounded caps.</div>
          <div style="display:flex;flex-direction:column;gap:6px">
            ${[
              ['React / Shadcn', 'npm install lucide-react', 'import { Search } from "lucide-react"'],
              ['Flutter', 'lucide_flutter: ^0.x', 'Icon(LucideIcons.search)'],
            ].map(([platform, install, usage]) =>
              '<div style="background:var(--background-subtle);border-radius:8px;padding:10px 12px">' +
              '<div style="font-size:11px;font-weight:600;color:var(--content-primary);margin-bottom:4px">' + platform + '</div>' +
              '<div style="font-family:monospace;font-size:10px;color:var(--brand-primary)">' + install + '</div>' +
              '<div style="font-family:monospace;font-size:10px;color:var(--content-tertiary)">' + usage + '</div>' +
              '</div>'
            ).join('')}
          </div>
        </div>
        <div class="card" style="padding:24px">
          <div style="font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--content-tertiary);margin-bottom:16px">Three standard sizes</div>
          <div style="display:flex;flex-direction:column;gap:16px">
            ${[
              { token: 'icon/size/sm', size: 16, desc: 'Inline text, badges, dense tables' },
              { token: 'icon/size/md', size: 20, desc: 'Default — buttons, inputs, nav' },
              { token: 'icon/size/lg', size: 24, desc: 'Headers, empty states, emphasis' },
            ].map(s =>
              '<div style="display:flex;align-items:center;gap:16px">' +
              '<div style="width:44px;height:44px;border-radius:8px;background:var(--background-subtle);border:1px solid var(--border-subtle);display:flex;align-items:center;justify-content:center;flex-shrink:0">' +
              iconSvg('<circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>', s.size, '#430098') +
              '</div>' +
              '<div>' +
              '<div style="font-family:monospace;font-size:11px;color:var(--brand-primary);margin-bottom:2px">' + s.token + ' — ' + s.size + 'px</div>' +
              '<div style="font-size:12px;color:var(--content-secondary)">' + s.desc + '</div>' +
              '</div>' +
              '</div>'
            ).join('')}
          </div>
        </div>
      </div>
    </div>

    <!-- ── RTL / LTR SECTION ──────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">LTR & RTL mirroring</h2><span class="doc-section-badge">Arabic support</span></div>
      <p class="doc-section-desc">Icons are classified into two groups. <strong>Directional</strong> icons imply movement or reading order — they must flip horizontally in Arabic (RTL) mode. <strong>Universal</strong> icons represent objects or symmetrical concepts — they look the same in both directions.</p>

      <div class="grid-2" style="margin-bottom:24px">

        <div class="card" style="overflow:hidden">
          <div style="padding:12px 16px;background:#F7F0FF;border-bottom:1px solid #E8D5FF;display:flex;align-items:center;justify-content:space-between">
            <div>
              <span style="font-size:11px;font-weight:700;color:#430098;letter-spacing:.05em;text-transform:uppercase">Directional</span>
              <span style="font-size:10px;color:#8E66C1;margin-left:8px">${ICON_CATEGORIES.reduce((a,c) => a + c.icons.filter(i => i.rtl).length, 0)} icons — flip in RTL</span>
            </div>
            <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:4px;background:#430098;color:#fff">↔ Flips</span>
          </div>
          <div style="padding:20px">
            <div style="font-size:12px;color:var(--content-secondary);line-height:1.7;margin-bottom:16px">These icons imply direction or reading order. In LTR (French, English) they point right. In RTL (Arabic) they must mirror to point left.</div>
            <div style="display:flex;gap:24px;align-items:flex-start;margin-bottom:16px">
              <div style="flex:1">
                <div style="font-size:10px;font-weight:600;color:var(--content-tertiary);letter-spacing:.06em;text-transform:uppercase;margin-bottom:10px">LTR — French / English</div>
                <div style="display:flex;gap:12px;align-items:center;padding:12px;background:var(--background-subtle);border-radius:8px;border:1px solid var(--border-subtle)">
                  ${['<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>',
                     '<polyline points="9 18 15 12 9 6"/>',
                     '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
                     '<polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 0 0-4-4H4"/>',
                     '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
                  ].map(p => iconSvg(p, 20, '#430098')).join('')}
                </div>
                <div style="font-size:10px;color:var(--content-tertiary);margin-top:6px;font-family:monospace">Normal orientation →</div>
              </div>
              <div style="flex:1">
                <div style="font-size:10px;font-weight:600;color:var(--content-tertiary);letter-spacing:.06em;text-transform:uppercase;margin-bottom:10px">RTL — Arabic</div>
                <div style="display:flex;gap:12px;align-items:center;padding:12px;background:#F7F0FF;border-radius:8px;border:1px solid #E8D5FF;direction:rtl">
                  ${['<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>',
                     '<polyline points="9 18 15 12 9 6"/>',
                     '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
                     '<polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 0 0-4-4H4"/>',
                     '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
                  ].map(p => '<span style="transform:scaleX(-1);display:inline-block">' + iconSvg(p, 20, '#430098') + '</span>').join('')}
                </div>
                <div style="font-size:10px;color:var(--content-tertiary);margin-top:6px;font-family:monospace;direction:rtl;text-align:right">← Mirrored orientation</div>
              </div>
            </div>
            <div style="background:var(--background-subtle);border-radius:8px;padding:12px;font-size:12px;color:var(--content-secondary);line-height:1.7">
              <strong style="color:var(--content-primary)">Tailwind:</strong> <code style="font-size:11px;background:var(--background-surface);padding:1px 5px;border-radius:3px">className="rtl:scale-x-[-1]"</code><br>
              <strong style="color:var(--content-primary)">Flutter:</strong> <code style="font-size:11px;background:var(--background-surface);padding:1px 5px;border-radius:3px">Transform.flip(flipX: Directionality.of(context) == TextDirection.rtl)</code>
            </div>
          </div>
        </div>

        <div class="card" style="overflow:hidden">
          <div style="padding:12px 16px;background:var(--background-subtle);border-bottom:1px solid var(--border-subtle);display:flex;align-items:center;justify-content:space-between">
            <div>
              <span style="font-size:11px;font-weight:700;color:var(--content-primary);letter-spacing:.05em;text-transform:uppercase">Universal</span>
              <span style="font-size:10px;color:var(--content-tertiary);margin-left:8px">${ICON_CATEGORIES.reduce((a,c) => a + c.icons.filter(i => !i.rtl).length, 0)} icons — same in all languages</span>
            </div>
            <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:4px;background:var(--background-surface);color:var(--content-secondary);border:1px solid var(--border-default)">= Always same</span>
          </div>
          <div style="padding:20px">
            <div style="font-size:12px;color:var(--content-secondary);line-height:1.7;margin-bottom:16px">These icons represent objects, states, or symmetrical concepts with no implied direction. They render identically in French, English, and Arabic.</div>
            <div style="display:flex;gap:24px;align-items:flex-start;margin-bottom:16px">
              <div style="flex:1">
                <div style="font-size:10px;font-weight:600;color:var(--content-tertiary);letter-spacing:.06em;text-transform:uppercase;margin-bottom:10px">LTR — French / English</div>
                <div style="display:flex;gap:12px;align-items:center;padding:12px;background:var(--background-subtle);border-radius:8px;border:1px solid var(--border-subtle)">
                  ${['<circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>',
                     '<polyline points="20 6 9 17 4 12"/>',
                     '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>',
                     '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/>',
                     '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
                  ].map(p => iconSvg(p, 20, '#474747')).join('')}
                </div>
              </div>
              <div style="flex:1">
                <div style="font-size:10px;font-weight:600;color:var(--content-tertiary);letter-spacing:.06em;text-transform:uppercase;margin-bottom:10px">RTL — Arabic</div>
                <div style="display:flex;gap:12px;align-items:center;padding:12px;background:var(--background-subtle);border-radius:8px;border:1px solid var(--border-subtle)">
                  ${['<circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>',
                     '<polyline points="20 6 9 17 4 12"/>',
                     '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>',
                     '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/>',
                     '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
                  ].map(p => iconSvg(p, 20, '#474747')).join('')}
                </div>
              </div>
            </div>
            <div style="background:var(--background-subtle);border-radius:8px;padding:12px;font-size:12px;color:var(--content-secondary);line-height:1.7">
              <strong style="color:var(--content-primary)">No code needed</strong> — just use the icon directly. No <code style="font-size:11px;background:var(--background-surface);padding:1px 5px;border-radius:3px">rtl:</code> modifier, no <code style="font-size:11px;background:var(--background-surface);padding:1px 5px;border-radius:3px">Transform.flip</code>.
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ── TABBED ICON BROWSER ────────────────────── -->
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">Icon browser</h2><span class="doc-section-badge">${ICON_CATEGORIES.reduce((a,c) => a + c.icons.length, 0)} icons</span></div>

      <div class="icon-tabs-bar" id="icon-tabs-bar">
        <button class="icon-tab active" onclick="switchIconTab(0, this)">All</button>
        ${ICON_CATEGORIES.map((cat, i) =>
          '<button class="icon-tab" onclick="switchIconTab(' + (i+1) + ', this)">' + cat.name + '<span class="icon-tab-count">' + cat.icons.length + '</span></button>'
        ).join('')}
        <button class="icon-tab" onclick="switchIconTab(-1, this)" style="margin-left:auto">
          <span style="color:#430098">◈</span> Directional only
        </button>
      </div>

      <div id="icon-browser-grid" class="icon-library-grid" style="margin-top:16px">
        ${ICON_CATEGORIES.map(cat =>
          cat.icons.map(icon =>
            '<div class="icon-lib-cell" data-category="' + cat.name + '" data-rtl="' + icon.rtl + '">' +
            '<div class="icon-lib-preview">' + iconSvg(icon.path, 24, 'currentColor') + '</div>' +
            '<div class="icon-lib-name">' + icon.name + '</div>' +
            '<div class="icon-lib-use">' + icon.use + '</div>' +
            '<span class="icon-lib-badge ' + (icon.rtl ? 'badge-dir' : 'badge-uni') + '">' + (icon.rtl ? '↔ Directional' : '= Universal') + '</span>' +
            '</div>'
          ).join('')
        ).join('')}
      </div>
    </div>

  </div>
`;
}
