import { pageHeader } from '../utils/render.js';

export default function() {
  return pageHeader('Resources', 'CSS Export', 'Ready-to-use CSS custom properties generated from all semantic tokens. Import and reference directly in component styles.') + `<div class="page-body">
    <div class="doc-section">
      <div class="doc-section-header"><h2 class="doc-section-title">CSS Custom Properties</h2><span class="doc-section-badge">Light mode</span></div>
      <div class="code-block">
        <button class="code-copy" onclick="copyCode(this)">Copy</button>
        <pre><span class="cc">/* Iksir Design System — CSS Custom Properties
   Source: Figma variables · Iksir Design Library
   Mode: Light (default)                          */</span>

:root {
  <span class="cc">/* ── Brand ────────────────────────────────── */</span>
  <span class="ck">--brand-primary</span>:              <span class="cv">#430098</span>; <span class="cc">/* brand/primary */</span>
  <span class="ck">--brand-primary-hover</span>:        <span class="cv">#561AA2</span>; <span class="cc">/* brand/primary-hover */</span>
  <span class="ck">--brand-primary-active</span>:       <span class="cv">#6933AD</span>; <span class="cc">/* brand/primary-active */</span>
  <span class="ck">--brand-focus</span>:        <span class="cv">#8E66C1</span>; <span class="cc">/* brand/primary-focus */</span>
  <span class="ck">--brand-primary-disabled</span>:     <span class="cv">#B499D6</span>; <span class="cc">/* brand/primary-disabled */</span>
  <span class="ck">--brand-primary-muted</span>:        <span class="cv">#ECE6F5</span>; <span class="cc">/* brand/primary-muted */</span>
  <span class="ck">--brand-primary-subtle</span>:       <span class="cv">#F7F4FB</span>; <span class="cc">/* brand/primary-subtle */</span>
  <span class="ck">--brand-secondary</span>:    <span class="cv">#190046</span>; <span class="cc">/* brand/secondary */</span>

  <span class="cc">/* ── Content ───────────────────────────────── */</span>
  <span class="ck">--content-primary</span>:       <span class="cv">#191919</span>; <span class="cc">/* content/primary */</span>
  <span class="ck">--content-secondary</span>:     <span class="cv">#757575</span>; <span class="cc">/* content/secondary */</span>
  <span class="ck">--content-tertiary</span>:      <span class="cv">#A3A3A3</span>; <span class="cc">/* content/tertiary */</span>
  <span class="ck">--content-disabled</span>:      <span class="cv">#BABABA</span>; <span class="cc">/* content/disabled */</span>
  <span class="ck">--content-inverse</span>:       <span class="cv">#FFFFFF</span>; <span class="cc">/* content/inverse */</span>
  <span class="ck">--content-on-brand</span>:      <span class="cv">#FFFFFF</span>; <span class="cc">/* content/on-brand */</span>

  <span class="cc">/* ── Background ────────────────────────────── */</span>
  <span class="ck">--background-page</span>:            <span class="cv">#FFFFFF</span>; <span class="cc">/* background/page */</span>
  <span class="ck">--background-surface</span>:         <span class="cv">#FFFFFF</span>; <span class="cc">/* background/surface */</span>
  <span class="ck">--background-subtle</span>:          <span class="cv">#FAFAFA</span>; <span class="cc">/* background/subtle */</span>
  <span class="ck">--background-raised</span>:          <span class="cv">#FFFFFF</span>; <span class="cc">/* background/raised */</span>
  <span class="ck">--background-overlay</span>:         <span class="cv">rgba(0,0,0,.5)</span>; <span class="cc">/* background/overlay */</span>
  <span class="ck">--background-brand</span>:           <span class="cv">#430098</span>; <span class="cc">/* background/brand */</span>
  <span class="ck">--background-brand-subtle</span>:    <span class="cv">#F7F4FB</span>; <span class="cc">/* background/brand-subtle */</span>

  <span class="cc">/* ── Border ─────────────────────────────────── */</span>
  <span class="ck">--border-default</span>:             <span class="cv">#E1E1E1</span>; <span class="cc">/* border/default */</span>
  <span class="ck">--border-subtle</span>:      <span class="cv">#F0F0F0</span>; <span class="cc">/* border/subtle */</span>
  <span class="ck">--border-strong</span>:      <span class="cv">#A3A3A3</span>; <span class="cc">/* border/strong */</span>
  <span class="ck">--border-brand</span>:       <span class="cv">#430098</span>; <span class="cc">/* border/brand */</span>
  <span class="ck">--border-focus</span>:       <span class="cv">#6933AD</span>; <span class="cc">/* border/focus */</span>
  <span class="ck">--border-danger</span>:      <span class="cv">#E04756</span>; <span class="cc">/* border/danger */</span>
  <span class="ck">--focus-width</span>:        <span class="cv">2px</span>;      <span class="cc">/* focus/width — WCAG 2.4.11 minimum */</span>
  <span class="ck">--focus-offset</span>:       <span class="cv">2px</span>;      <span class="cc">/* focus/offset — gap between element and ring */</span>

  <span class="cc">/* ── Status ──────────────────────────────────── */</span>
  <span class="ck">--status-success-content</span>:    <span class="cv">#148F47</span>;  <span class="ck">--status-success-bg</span>: <span class="cv">#F2FDF6</span>;  <span class="ck">--status-success-border</span>: <span class="cv">#21C063</span>;
  <span class="ck">--status-warning-content</span>:    <span class="cv">#AE7004</span>;  <span class="ck">--status-warning-bg</span>: <span class="cv">#FEFBF6</span>;  <span class="ck">--status-warning-border</span>: <span class="cv">#E19614</span>;
  <span class="ck">--status-danger-content</span>:     <span class="cv">#D8192C</span>;  <span class="ck">--status-danger-bg</span>:  <span class="cv">#FFF2F4</span>;  <span class="ck">--status-danger-border</span>:  <span class="cv">#E04756</span>;
  <span class="ck">--status-info-content</span>:       <span class="cv">#430098</span>;  <span class="ck">--status-info-bg</span>:    <span class="cv">#F7F4FB</span>;  <span class="ck">--status-info-border</span>:    <span class="cv">#8E66C1</span>;

  <span class="cc">/* ── Button · Primary ───────────────────────────────────── */</span>
  <span class="ck">--button-primary-bg-default</span>:      <span class="cv">#430098</span>; <span class="cc">/* button/primary/bg/default */</span>
  <span class="ck">--button-primary-bg-hover</span>:        <span class="cv">#561AA2</span>; <span class="cc">/* button/primary/bg/hover */</span>
  <span class="ck">--button-primary-bg-active</span>:       <span class="cv">#6933AD</span>; <span class="cc">/* button/primary/bg/active */</span>
  <span class="ck">--button-primary-bg-focused</span>:      <span class="cv">#430098</span>; <span class="cc">/* button/primary/bg/focused */</span>
  <span class="ck">--button-primary-bg-disabled</span>:     <span class="cv">#C7B3E0</span>; <span class="cc">/* button/primary/bg/disabled */</span>
  <span class="ck">--button-primary-text-default</span>:    <span class="cv">#FFFFFF</span>; <span class="cc">/* button/primary/text/default */</span>
  <span class="ck">--button-primary-text-disabled</span>:   <span class="cv">#FFFFFF</span>; <span class="cc">/* button/primary/text/disabled */</span>
  <span class="ck">--button-primary-icon-hover</span>:      <span class="cv">#FFFFFF</span>; <span class="cc">/* button/primary/icon/hover */</span>
  <span class="ck">--button-primary-icon-active</span>:     <span class="cv">#FFFFFF</span>; <span class="cc">/* button/primary/icon/active */</span>
  <span class="ck">--button-primary-border-focused</span>:  <span class="cv">#6933AD</span>; <span class="cc">/* button/primary/border/focused */</span>
  <span class="cc">/* ── Button · Destructive ───────────────────────────────── */</span>
  <span class="ck">--button-destructive-bg-default</span>:     <span class="cv">#FFF2F4</span>; <span class="cc">/* button/destructive/bg/default */</span>
  <span class="ck">--button-destructive-border-default</span>: <span class="cv">#F3BAC0</span>; <span class="cc">/* button/destructive/border/default */</span>
  <span class="cc">/* ── Button · Sizes ─────────────────────────────────────── */</span>
  <span class="ck">--component-button-radius</span>:        <span class="cv">8px</span>;  <span class="cc">/* component/button/radius */</span>
  <span class="ck">--component-button-gap</span>:           <span class="cv">6px</span>;  <span class="cc">/* component/button/gap */</span>
  <span class="ck">--component-button-height-sm</span>:     <span class="cv">32px</span>; <span class="cc">/* component/button/height/sm */</span>
  <span class="ck">--component-button-height-lg</span>:     <span class="cv">40px</span>; <span class="cc">/* component/button/height/lg */</span>
  <span class="ck">--component-button-padding-x-sm</span>:  <span class="cv">12px</span>; <span class="cc">/* component/button/padding-x/sm */</span>
  <span class="ck">--component-button-padding-x-lg</span>:  <span class="cv">20px</span>; <span class="cc">/* component/button/padding-x/lg */</span>
  <span class="ck">--component-button-icon-size-lg</span>:  <span class="cv">24px</span>; <span class="cc">/* component/button/icon-size/lg */</span>

  <span class="cc">/* ── Spacing ─────────────────────────────────── */</span>
  <span class="ck">--spacing-0</span>:<span class="cv">0px</span>; <span class="ck">--spacing-2</span>:<span class="cv">2px</span>; <span class="ck">--spacing-4</span>:<span class="cv">4px</span>; <span class="ck">--spacing-6</span>:<span class="cv">6px</span>; <span class="ck">--spacing-8</span>:<span class="cv">8px</span>; <span class="ck">--spacing-10</span>:<span class="cv">10px</span>;
  <span class="ck">--spacing-12</span>:<span class="cv">12px</span>; <span class="ck">--spacing-14</span>:<span class="cv">14px</span>; <span class="ck">--spacing-16</span>:<span class="cv">16px</span>; <span class="ck">--spacing-20</span>:<span class="cv">20px</span>; <span class="ck">--spacing-24</span>:<span class="cv">24px</span>;
  <span class="ck">--spacing-32</span>:<span class="cv">32px</span>; <span class="ck">--spacing-40</span>:<span class="cv">40px</span>; <span class="ck">--spacing-48</span>:<span class="cv">48px</span>; <span class="ck">--spacing-64</span>:<span class="cv">64px</span>; <span class="ck">--spacing-80</span>:<span class="cv">80px</span>;
  <span class="ck">--spacing-96</span>:<span class="cv">96px</span>; <span class="ck">--spacing-120</span>:<span class="cv">120px</span>; <span class="ck">--spacing-160</span>:<span class="cv">160px</span>;

  <span class="cc">/* ── Border Radius (primitives) ──────────────── */</span>
  <span class="ck">--radius-0</span>:<span class="cv">0px</span>; <span class="ck">--radius-2</span>:<span class="cv">2px</span>; <span class="ck">--radius-4</span>:<span class="cv">4px</span>; <span class="ck">--radius-6</span>:<span class="cv">6px</span>; <span class="ck">--radius-8</span>:<span class="cv">8px</span>;
  <span class="ck">--radius-12</span>:<span class="cv">12px</span>; <span class="ck">--radius-16</span>:<span class="cv">16px</span>; <span class="ck">--radius-20</span>:<span class="cv">20px</span>; <span class="ck">--radius-24</span>:<span class="cv">24px</span>; <span class="ck">--radius-32</span>:<span class="cv">32px</span>;
  <span class="cc">/* ── Border Radius (semantic) ────────────────── */</span>
  <span class="ck">--radius-xs</span>:<span class="cv">var(--radius-2)</span>; <span class="ck">--radius-sm</span>:<span class="cv">var(--radius-4)</span>; <span class="ck">--radius-md</span>:<span class="cv">var(--radius-6)</span>;
  <span class="ck">--radius-lg</span>:<span class="cv">var(--radius-8)</span>; <span class="ck">--radius-xl</span>:<span class="cv">var(--radius-12)</span>; <span class="ck">--radius-full</span>:<span class="cv">9999px</span>;
  <span class="cc">/* ── Icon Sizes ───────────────────────────────── */</span>
  <span class="ck">--icon-size-sm</span>:<span class="cv">16px</span>; <span class="ck">--icon-size-md</span>:<span class="cv">20px</span>; <span class="ck">--icon-size-lg</span>:<span class="cv">24px</span>;

  <span class="cc">/* ── Elevation ────────────────────────────────── */</span>
  <span class="ck">--elevation-1</span>:     <span class="cs">0 1px 2px rgba(0,0,0,.06), 0 1px 3px rgba(0,0,0,.04)</span>;
  <span class="ck">--elevation-2</span>: <span class="cs">0 4px 8px rgba(0,0,0,.08), 0 2px 4px rgba(0,0,0,.06)</span>;
  <span class="ck">--elevation-3</span>:    <span class="cs">0 8px 24px rgba(0,0,0,.10), 0 4px 8px rgba(0,0,0,.08)</span>;
  <span class="ck">--elevation-4</span>:    <span class="cs">0 16px 40px rgba(0,0,0,.14), 0 6px 12px rgba(0,0,0,.10)</span>;

  <span class="cc">/* ── Typography ──────────────────────────────── */</span>
  <span class="cc">/* Latin mode */</span>
  <span class="ck">--font-display</span>: <span class="cs">'Montserrat', sans-serif</span>; <span class="cc">/* font/family/primary */</span>
  <span class="ck">--font-body</span>:    <span class="cs">'Inter', sans-serif</span>;       <span class="cc">/* font/family/secondary */</span>
  <span class="cc">/* Arabic mode */</span>
  <span class="ck">--font-arabic-display</span>: <span class="cs">'Alexandria', sans-serif</span>; <span class="cc">/* font/family/primary — headings only */</span>
  <span class="ck">--font-arabic-body</span>:    <span class="cs">'Inter', sans-serif</span>;       <span class="cc">/* font/family/secondary — body &amp; UI */</span>
  <span class="cc">/* ── Input ── */</span>
  <span class="ck">--inp-bg</span>:<span class="cs">#FFFFFF</span>;<span class="ck">--inp-border</span>:<span class="cs">#E1E1E1</span>;<span class="ck">--inp-border-focus</span>:<span class="cs">#C7B3E0</span>;
  <span class="ck">--inp-height-sm</span>:<span class="cs">32px</span>;<span class="ck">--inp-height-md</span>:<span class="cs">36px</span>;<span class="ck">--inp-height-lg</span>:<span class="cs">40px</span>;
  <span class="cc">/* ── Tooltip ── */</span>
  <span class="ck">--tooltip-bg</span>:<span class="cs">#1C1C22</span>;<span class="ck">--tooltip-title</span>:<span class="cs">#FFFFFF</span>;<span class="ck">--tooltip-radius</span>:<span class="cs">8px</span>;
  <span class="cc">/* ── Checkbox ── */</span>
  <span class="ck">--cb-bg</span>:<span class="cs">#FFFFFF</span>;<span class="ck">--cb-bg-checked</span>:<span class="cs">#F7F4FB</span>;<span class="ck">--cb-bg-circle</span>:<span class="cs">#430098</span>;
  <span class="ck">--cb-border</span>:<span class="cs">#E9EAEB</span>;<span class="ck">--cb-border-checked</span>:<span class="cs">#8E66C1</span>;<span class="ck">--cb-icon</span>:<span class="cs">#430098</span>;
  <span class="ck">--cb-size-sm</span>:<span class="cs">16px</span>;<span class="ck">--cb-size-md</span>:<span class="cs">20px</span>;<span class="ck">--cb-gap</span>:<span class="cs">12px</span>;
}</pre>
      </div>
    </div>
  </div>`;
}
