import { pageHeader } from '../utils/render.js';
import { SIZING } from '../data/sizing.js';

const CHK = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`;
const DOT = `<svg width="6" height="6" viewBox="0 0 6 6" fill="currentColor"><circle cx="3" cy="3" r="3"/></svg>`;

const V = {
  default:     { bg: 'var(--badge-default-bg)',     text: 'var(--badge-default-text)',   border: 'var(--badge-default-border)' },
  secondary:   { bg: 'var(--badge-secondary-bg)',   text: 'var(--badge-secondary-text)', border: 'var(--badge-secondary-border)' },
  destructive: { bg: 'var(--badge-destructive-bg)', text: 'var(--badge-destructive-text)', border: 'var(--badge-destructive-border)' },
  outline:     { bg: 'var(--badge-outline-bg)',     text: 'var(--badge-outline-text)',   border: 'var(--badge-outline-border)' },
  ghost:       { bg: 'var(--badge-ghost-bg)',       text: 'var(--badge-ghost-text)',     border: 'var(--badge-ghost-border)' },
};

function bdg(variant, content, id, size) {
  const v = V[variant];
  const h  = size === 'sm' ? '20px' : '24px';
  const px = size === 'sm' ? '6px'  : '8px';
  const fs = size === 'sm' ? '11px' : '12px';
  const idAttr = id ? ` id="${id}"` : '';
  return `<span${idAttr} style="display:inline-flex;align-items:center;gap:4px;padding:0 ${px};height:${h};border-radius:9999px;font-size:${fs};font-weight:500;font-family:Inter,sans-serif;line-height:1;background:${v.bg};color:${v.text};border:1px solid ${v.border};white-space:nowrap;cursor:default;user-select:none">${content}</span>`;
}

function swatch(color, name, label) {
  const isTransparent = color === 'transparent';
  const isWhite = color === '#FFFFFF';
  const style = isTransparent
    ? 'background:repeating-linear-gradient(45deg,#E1E1E1 0,#E1E1E1 2px,#FFF 2px,#FFF 6px);border:1px solid #E1E1E1;'
    : `background:${color};${isWhite ? 'border:1px solid #E1E1E1;' : ''}`;
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="${style}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${label}</div></div></div>`;
}

function variantSection(id, title, desc, label, tokens, ghostBg) {
  const stageStyle = ghostBg ? 'display:flex;align-items:center;justify-content:center;min-height:60px;background:var(--brand-primary-subtle)' : 'display:flex;align-items:center;justify-content:center;min-height:60px';
  return `
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">${title}</h2></div>
    <p class="doc-section-desc">${desc}</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar">
        <span class="inp-demo-title">${title} badge</span>
        <div class="inp-demo-controls">
          <span class="inp-demo-meta">State</span>
          <select class="inp-state-select" onchange="badgeState('${id}',this.value)">
            <option>Default</option><option>Hover</option><option>Disabled</option>
          </select>
        </div>
      </div>
      <div class="inp-demo-stage" style="${stageStyle}">
        ${bdg(id, label, 'badge-' + id, 'md')}
      </div>
      <div class="btn-tokens-strip">${tokens.map(([c, n, l]) => swatch(c, n, l)).join('')}</div>
    </div>
  </div>`;
}

function tRow(t, i) {
  const bg = i % 2 === 0 ? 'background:var(--background-subtle);' : '';
  const vc = t.val >= 9999 ? '9999px' : t.val + 'px';
  return `<tr style="${bg}border-bottom:1px solid var(--border-subtle)">
    <td style="padding:10px 16px"><code class="tok-name">${t.token}</code></td>
    <td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'${vc}')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">${t.ref}<span class="tok-alias-copied">${vc}</span></span></td>
    <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${t.use}</td>
  </tr>`;
}

export default function badge() {
  return pageHeader('Components', 'Badge', 'Compact label for status, category, or count. 5 variants × 2 sizes with pill shape and optional icon or dot indicator.', [
    { val: '5',  label: 'Variants' },
    { val: '2',  label: 'Sizes' },
    { val: String(SIZING.badge.length), label: 'Size tokens' },
  ]) + `<div class="page-body">

  ${variantSection(
    'default', 'Default',
    'Highest emphasis. Solid brand fill with white text. Use for primary status, active state, or the most important categorization.',
    'New',
    [
      ['#430098', 'badge/default/bg',     'Background'],
      ['#FFFFFF', 'badge/default/text',   'Text'],
      ['#430098', 'badge/default/border', 'Border'],
    ]
  )}

  ${variantSection(
    'secondary', 'Secondary',
    'Medium emphasis. Light purple fill with brand text. Use for secondary tags, supplementary labels, or neutral status.',
    'Featured',
    [
      ['#F7F4FB', 'badge/secondary/bg',     'Background'],
      ['#430098', 'badge/secondary/text',   'Text'],
      ['#D9CCEA', 'badge/secondary/border', 'Border'],
    ]
  )}

  ${variantSection(
    'destructive', 'Destructive',
    'Error or danger state. Soft red fill with danger-content text. Use for warnings, failed status, or critical indicators.',
    'Error',
    [
      ['#FFF2F4', 'badge/destructive/bg',     'Background'],
      ['#D8192C', 'badge/destructive/text',   'Text'],
      ['#E87580', 'badge/destructive/border', 'Border'],
    ]
  )}

  ${variantSection(
    'outline', 'Outline',
    'Subtle bordered badge with no fill. Use when a badge must not compete with primary content, or on white surfaces.',
    'Draft',
    [
      ['#FFFFFF', 'badge/outline/bg',     'Background'],
      ['#430098', 'badge/outline/text',   'Text'],
      ['#C7B3E0', 'badge/outline/border', 'Border'],
    ]
  )}

  ${variantSection(
    'ghost', 'Ghost',
    'No background, no border — text and icon only. Use inline in prose, inside table cells, or on brand-colored surfaces.',
    'Beta',
    [
      ['transparent', 'badge/ghost/bg',     'Background'],
      ['#430098',     'badge/ghost/text',   'Text'],
      ['transparent', 'badge/ghost/border', 'Border'],
    ],
    true
  )}

  <!-- SIZES -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Sizes</h2></div>
    <p class="doc-section-desc">Two sizes — SM (20px height) for dense UIs and lists, MD (24px height) as the default. Keep size consistent within a layout layer.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">All sizes are live</span></div>
      <div class="inp-multi-stage">
        <div class="inp-multi-cell">
          ${bdg('default', 'Label', '', 'sm')}
          <span class="inp-multi-label">SM — 20px · 11px · px 6</span>
        </div>
        <div class="inp-multi-cell">
          ${bdg('default', 'Label', '', 'md')}
          <span class="inp-multi-label">MD — 24px · 12px · px 8</span>
        </div>
      </div>
    </div>
  </div>

  <!-- WITH ICON -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">With icon</h2></div>
    <p class="doc-section-desc">12px leading icon before the label. Icon color inherits the variant's text token. Use icons that reinforce the badge meaning — status checks, alerts, or category indicators.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Leading icon — all variants</span></div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:10px;min-height:70px;padding:16px">
        ${bdg('default',     CHK + 'Active',   '', 'md')}
        ${bdg('secondary',   CHK + 'Verified', '', 'md')}
        ${bdg('destructive', CHK + 'Failed',   '', 'md')}
        ${bdg('outline',     CHK + 'Draft',    '', 'md')}
        ${bdg('ghost',       CHK + 'Beta',     '', 'md')}
      </div>
    </div>
  </div>

  <!-- WITH DOT -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">With dot</h2></div>
    <p class="doc-section-desc">Small 6px (SM) or 8px (MD) dot indicator before the label. Ideal for online/offline presence, pipeline states, or any binary condition.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Leading dot — all variants</span></div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:10px;min-height:70px;padding:16px">
        ${bdg('default',     DOT + 'Online',   '', 'md')}
        ${bdg('secondary',   DOT + 'Pending',  '', 'md')}
        ${bdg('destructive', DOT + 'Offline',  '', 'md')}
        ${bdg('outline',     DOT + 'Inactive', '', 'md')}
        ${bdg('ghost',       DOT + 'Beta',     '', 'md')}
      </div>
    </div>
  </div>

  <!-- COMPONENT TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <p class="doc-section-desc">All sizing values bound to the <code>Components</code> collection. Hover to preview the value, click to copy.</p>
    <div class="card" style="overflow:hidden;margin-bottom:16px">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Aliases → (hover for value, click to copy)</th><th>Usage</th></tr></thead>
        <tbody>${SIZING.badge.map(tRow).join('')}</tbody>
      </table>
    </div>
  </div>

  <!-- PROPS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
    <table class="prop-table">
      <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
      <tbody>
        <tr><td><span class="prop-name">variant</span></td><td><span class="prop-type">"default"|"secondary"|"destructive"|"outline"|"ghost"</span></td><td><span class="prop-default">"default"</span></td><td>Visual style and color intent.</td></tr>
        <tr><td><span class="prop-name">size</span></td><td><span class="prop-type">"sm"|"md"</span></td><td><span class="prop-default">"md"</span></td><td>Height (20px or 24px) and horizontal padding scale.</td></tr>
        <tr><td><span class="prop-name">icon</span></td><td><span class="prop-type">ReactNode</span></td><td><span class="prop-default">—</span></td><td>12px icon rendered before the label. Color inherits from variant text token.</td></tr>
        <tr><td><span class="prop-name">dot</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Renders a small filled circle before the label. Size follows the size prop.</td></tr>
        <tr><td><span class="prop-name">disabled</span></td><td><span class="prop-type">boolean</span></td><td><span class="prop-default">false</span></td><td>Reduces opacity to 50%. Use when the associated content is inactive.</td></tr>
        <tr><td><span class="prop-name">children</span></td><td><span class="prop-type">ReactNode</span></td><td><span class="prop-default">—</span></td><td>Badge label text.</td></tr>
      </tbody>
    </table>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Keep badge labels short — 1 to 2 words. They signal status at a glance and are not descriptions.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use more than 2–3 badge variants on the same view. Too many color signals create noise instead of clarity.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Reserve Default (purple) for the primary or most positive status — Active, Live, Verified.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use Destructive for non-critical states like Archived or Inactive — use Outline or Secondary instead.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Use Ghost when a badge sits on a brand-colored surface or inside a dense table where a filled badge is too heavy.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't rely on color alone to convey meaning — always pair with a text label. Icons and dots are supplementary signals only.</div></div>
    </div>
  </div>

  </div>`;
}
