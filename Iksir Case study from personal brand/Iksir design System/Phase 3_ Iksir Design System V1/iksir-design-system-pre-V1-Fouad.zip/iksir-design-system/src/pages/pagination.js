import { pageHeader } from '../utils/render.js';
import { SIZING } from '../data/sizing.js';

const ARROW_L = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>`;
const ARROW_R = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>`;
const CHEV_D  = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>`;

/* ── shared atoms ─────────────────────────────────────────── */

function pgNumBtn(cid, num, isActive) {
  const tc = isActive ? 'var(--pagination-button-text-active)'   : 'var(--pagination-button-text-default)';
  const bc = isActive ? 'var(--pagination-button-border-active)' : 'transparent';
  const bg = isActive ? 'var(--pagination-button-bg-active)'     : 'transparent';
  const hov = cid && !isActive ? ` onmouseenter="pgHover(this,true)" onmouseleave="pgHover(this,false)"` : '';
  const clk = cid && !isActive ? ` onclick="pgGo('${cid}',${num})"` : '';
  return `<button data-pg="${num}" data-type="num" data-state="${isActive ? 'active' : 'default'}"
    style="display:inline-flex;align-items:center;justify-content:center;min-width:28px;height:28px;padding:0 4px;border-radius:6px;border:1px solid ${bc};background:${bg};font-family:Inter,sans-serif;font-size:13px;font-weight:500;color:${tc};cursor:${isActive ? 'default' : 'pointer'};transition:background .12s,border-color .12s,color .12s"${hov}${clk}>${num}</button>`;
}

function pgDot() {
  return `<span style="display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;font-family:Inter,sans-serif;font-size:13px;color:var(--pagination-ellipsis)">...</span>`;
}

function pgInitNums(cid, total, active) {
  // 1 2 3 ... total  (first page active by default)
  const win = [];
  for (let p = Math.max(2, active - 1); p <= Math.min(total - 1, active + 1); p++) win.push(p);
  let html = pgNumBtn(cid, 1, active === 1);
  if (!win.length || win[0] > 2) html += pgDot();
  win.forEach(p => { html += pgNumBtn(cid, p, p === active); });
  if (!win.length || win[win.length - 1] < total - 1) html += pgDot();
  if (total > 1) html += pgNumBtn(cid, total, active === total);
  return `<div id="${cid}-nums" style="display:inline-flex;align-items:center;gap:2px">${html}</div>`;
}

function pgNavBtn(cid, dir, disabled) {
  const isPrev = dir === 'prev';
  const tc = disabled ? 'var(--pagination-button-text-disabled)' : 'var(--pagination-button-text-default)';
  const bc = disabled ? 'var(--pagination-button-border-disabled)' : 'var(--pagination-button-border-default)';
  const state  = disabled ? 'disabled' : 'default';
  const cursor = disabled ? 'not-allowed' : 'pointer';
  const hov = cid && !disabled ? ` onmouseenter="pgHover(this,true)" onmouseleave="pgHover(this,false)"` : '';
  const clk = cid && !disabled
    ? ` onclick="${isPrev ? `pgPrev('${cid}')` : `pgNext('${cid}')`}"`
    : '';
  const inner = isPrev ? `${ARROW_L}<span>Previous</span>` : `<span>Next</span>${ARROW_R}`;
  return `<button data-pg="${dir}" data-state="${state}"
    style="display:inline-flex;align-items:center;gap:6px;padding:7px 14px;border-radius:8px;border:1px solid ${bc};background:var(--pagination-button-bg-default);font-family:Inter,sans-serif;font-size:13px;font-weight:500;color:${tc};cursor:${cursor};transition:background .12s,border-color .12s,color .12s"${hov}${clk}>${inner}</button>`;
}

function pgPerPageSelect(cid, selected, opts) {
  const options = opts.map(v => {
    const isSel = v === selected;
    return `<div data-val="${v}"
      onclick="pgSetPerPage('${cid}',${v})"
      style="padding:8px 12px;font-family:Inter,sans-serif;font-size:13px;color:${isSel ? '#430098' : '#474747'};cursor:pointer;background:${isSel ? '#F7F4FB' : ''}"
      onmouseenter="this.style.background='#F7F4FB'"
      onmouseleave="this.style.background='${isSel ? '#F7F4FB' : ''}'"
    >${v} per page</div>`;
  }).join('');
  return `<div style="position:relative">
    <button id="${cid}-pp-btn" onclick="pgPerPageToggle('${cid}',event)"
      style="display:inline-flex;align-items:center;gap:8px;padding:0 10px;height:34px;border-radius:8px;border:1px solid #E6E6E6;background:#FFFFFF;font-family:Inter,sans-serif;font-size:13px;color:#474747;cursor:pointer">
      <span id="${cid}-pp-label">${selected} per page</span>${CHEV_D}
    </button>
    <div id="${cid}-pp-drop"
      style="display:none;position:absolute;top:calc(100% + 4px);left:0;min-width:140px;background:#FFFFFF;border:1px solid #E6E6E6;border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.1);z-index:100;overflow:hidden">
      ${options}
    </div>
  </div>`;
}

/* ── layout variants ──────────────────────────────────────── */

// Variant 1: ← Previous | 1 2 3 … n | Next →
function pgRowSimple(cid, total, active) {
  return `<div id="${cid}" data-page="${active}" data-total="${total}"
    style="display:inline-flex;align-items:center;gap:8px">
    ${pgNavBtn(cid, 'prev', active <= 1)}
    ${pgInitNums(cid, total, active)}
    ${pgNavBtn(cid, 'next', active >= total)}
  </div>`;
}

// Variant 2: [Page X of Y] [N per page ▾] … [← Previous] [Next →]  (container bar)
function pgBar(cid, page, totalPages, perPage, totalItems) {
  return `<div id="${cid}" data-page="${page}" data-total="${totalPages}" data-per-page="${perPage}" data-total-items="${totalItems}"
    style="display:flex;align-items:center;justify-content:space-between;width:100%;height:56px;padding:0 16px;background:var(--pagination-container-bg);border:1px solid var(--pagination-container-border);border-radius:8px;box-sizing:border-box">
    <div style="display:flex;align-items:center;gap:12px">
      <span id="${cid}-info" style="font-family:Inter,sans-serif;font-size:13px;color:var(--pagination-info-text)">Page ${page} of ${totalPages}</span>
      ${pgPerPageSelect(cid, perPage, [10, 20, 50, 100])}
    </div>
    <div style="display:flex;align-items:center;gap:8px">
      ${pgNavBtn(cid, 'prev', page <= 1)}
      ${pgNavBtn(cid, 'next', page >= totalPages)}
    </div>
  </div>`;
}

// Variant 3: [N per page ▾] | 1 2 3 … n | [← Previous] [Next →]  (container bar)
function pgRowFull(cid, total, active, perPage, totalItems) {
  return `<div id="${cid}" data-page="${active}" data-total="${total}" data-per-page="${perPage}" data-total-items="${totalItems}"
    style="display:flex;align-items:center;justify-content:space-between;width:100%;height:56px;padding:0 16px;background:var(--pagination-container-bg);border:1px solid var(--pagination-container-border);border-radius:8px;box-sizing:border-box">
    ${pgPerPageSelect(cid, perPage, [10, 20, 50, 100])}
    ${pgInitNums(cid, total, active)}
    <div style="display:flex;align-items:center;gap:8px">
      ${pgNavBtn(cid, 'prev', active <= 1)}
      ${pgNavBtn(cid, 'next', active >= total)}
    </div>
  </div>`;
}

// Static bar for States section
function pgStaticBar(page, total, perPage, label) {
  return `<div style="width:100%">
    <p style="font-family:Inter,sans-serif;font-size:12px;font-weight:600;color:var(--content-secondary);margin:0 0 8px">${label}</p>
    <div style="display:flex;align-items:center;justify-content:space-between;width:100%;height:56px;padding:0 16px;background:var(--pagination-container-bg);border:1px solid var(--pagination-container-border);border-radius:8px;box-sizing:border-box">
      <div style="display:flex;align-items:center;gap:12px">
        <span style="font-family:Inter,sans-serif;font-size:13px;color:var(--pagination-info-text)">Page ${page} of ${total}</span>
        <button style="display:inline-flex;align-items:center;gap:8px;padding:0 10px;height:34px;border-radius:8px;border:1px solid #E6E6E6;background:#FFFFFF;font-family:Inter,sans-serif;font-size:13px;color:#474747;cursor:default">
          <span>${perPage} per page</span>${CHEV_D}
        </button>
      </div>
      <div style="display:flex;align-items:center;gap:8px">
        ${pgNavBtn(null, 'prev', page <= 1)}
        ${pgNavBtn(null, 'next', page >= total)}
      </div>
    </div>
  </div>`;
}

/* ── doc helpers ──────────────────────────────────────────── */

function swatch(hex, name, label, bordered) {
  const b = bordered ? 'border:1px solid #E1E1E1;' : '';
  return `<div class="btn-token-item"><div class="btn-token-swatch" style="background:${hex};${b}"></div><div><div class="btn-token-name">${name}</div><div class="btn-token-label">${label}</div></div></div>`;
}

function tRow(t, i) {
  const bg = i % 2 === 0 ? 'background:var(--background-subtle);' : '';
  const vc = t.val + 'px';
  return `<tr style="${bg}border-bottom:1px solid var(--border-subtle)">
    <td style="padding:10px 16px"><code class="tok-name">${t.token}</code></td>
    <td style="padding:10px 16px"><span class="tok-alias" onclick="tokCopy(this,'${vc}')" onmouseenter="this.classList.add('show-tip')" onmouseleave="this.classList.remove('show-tip')">${t.ref}<span class="tok-alias-copied">${vc}</span></span></td>
    <td style="padding:10px 16px;font-size:12px;color:var(--content-secondary)">${t.use}</td>
  </tr>`;
}

/* ── page ─────────────────────────────────────────────────── */

export default function pagination() {
  return pageHeader('Components', 'Pagination', 'Splits large datasets across multiple pages. Three layouts: numbered pages only, info bar with per-page select, or a full bar combining both.', [
    { val: '3',  label: 'Layouts' },
    { val: String(SIZING.pagination.length), label: 'Size tokens' },
    { val: '16', label: 'Color tokens' },
  ]) + `<div class="page-body">

  <!-- VARIANT 1: NUMBERED -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Numbered</h2></div>
    <p class="doc-section-desc">Previous and Next flanking a numbered page strip with ellipsis collapse. Use when vertical space is limited and row count isn't surfaced elsewhere.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">10 pages — click to navigate</span></div>
      <div class="inp-demo-stage" style="display:flex;align-items:center;justify-content:center;min-height:72px">
        ${pgRowSimple('pg-simple', 10, 1)}
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#FFFFFF','pagination/button/bg/default','Button bg — default',true)}
        ${swatch('#FDFDFD','pagination/button/bg/hover','Button bg — hover',true)}
        ${swatch('#F7F4FB','pagination/button/bg/active','Button bg — active')}
        ${swatch('#5E5E5E','pagination/button/text/default','Button text — default')}
        ${swatch('#191919','pagination/button/text/hover','Button text — hover')}
        ${swatch('#430098','pagination/button/text/active','Button text — active')}
        ${swatch('#D9CCEA','pagination/button/border/active','Button border — active')}
        ${swatch('#A3A3A3','pagination/ellipsis','Ellipsis color')}
      </div>
    </div>
  </div>

  <!-- VARIANT 2: INFO BAR -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">With info and per page</h2></div>
    <p class="doc-section-desc">A 56px container bar with page info on the left, a per-page Select next to it, and Previous / Next on the right. Use at the bottom of data tables where exact row counts matter.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">100 items — navigate and change per page</span></div>
      <div class="inp-demo-stage" style="padding:16px;min-height:auto">
        ${pgBar('pg-bar', 1, 10, 10, 100)}
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#FDFDFD','pagination/container/bg','Container bg',true)}
        ${swatch('#F0F0F0','pagination/container/border','Container border')}
        ${swatch('#8C8C8C','pagination/info/text','Info text')}
        ${swatch('#F0F0F0','pagination/button/border/default','Button border — default')}
        ${swatch('#E6E6E6','pagination/button/border/hover','Button border — hover')}
      </div>
    </div>
  </div>

  <!-- VARIANT 3: FULL -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Full</h2></div>
    <p class="doc-section-desc">Combines all controls in one bar: per-page select on the left, numbered pages in the centre, and Previous / Next on the right. The most complete layout for large datasets that need both density and direct page access.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">100 items — navigate and change per page</span></div>
      <div class="inp-demo-stage" style="padding:16px;min-height:auto">
        ${pgRowFull('pg-full', 10, 1, 10, 100)}
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#FDFDFD','pagination/container/bg','Container bg',true)}
        ${swatch('#F0F0F0','pagination/container/border','Container border')}
        ${swatch('#F7F4FB','pagination/button/bg/active','Active page bg')}
        ${swatch('#430098','pagination/button/text/active','Active page text')}
        ${swatch('#D9CCEA','pagination/button/border/active','Active page border')}
      </div>
    </div>
  </div>

  <!-- STATES -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">States</h2></div>
    <p class="doc-section-desc">Previous disables on the first page and Next disables on the last. Both are always visible to preserve layout stability.</p>
    <div class="inp-section-demo">
      <div class="inp-demo-toolbar"><span class="inp-demo-title">Navigation button states</span></div>
      <div class="inp-demo-stage" style="display:flex;flex-direction:column;align-items:stretch;gap:16px;padding:20px 16px;min-height:auto">
        ${pgStaticBar(1,  10, 10, 'First page — Previous disabled')}
        ${pgStaticBar(5,  10, 10, 'Middle page — both enabled')}
        ${pgStaticBar(10, 10, 10, 'Last page — Next disabled')}
      </div>
      <div class="btn-tokens-strip">
        ${swatch('#E6E6E6','pagination/button/text/disabled','Button text — disabled')}
        ${swatch('#FAFAFA','pagination/button/border/disabled','Button border — disabled',true)}
        ${swatch('#FFFFFF','pagination/button/bg/disabled','Button bg — disabled',true)}
      </div>
    </div>
  </div>

  <!-- COMPONENT TOKENS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Component tokens</h2></div>
    <p class="doc-section-desc">All sizing values bound to the <code>Components</code> collection. Hover to preview the value, click to copy.</p>
    <div class="card" style="overflow:hidden;margin-bottom:16px">
      <table class="tok-table">
        <thead><tr><th>Token</th><th>Aliases → (hover for value, click to copy)</th><th>Usage</th></tr></thead>
        <tbody>${SIZING.pagination.map(tRow).join('')}</tbody>
      </table>
    </div>
  </div>

  <!-- PROPS -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Props</h2></div>
    <table class="prop-table">
      <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
      <tbody>
        <tr><td><span class="prop-name">variant</span></td><td><span class="prop-type">"numbered" | "info-bar" | "full"</span></td><td><span class="prop-default">"numbered"</span></td><td>Layout variant. <code>info-bar</code> adds the container with page info and per-page select; <code>full</code> also adds numbered pages.</td></tr>
        <tr><td><span class="prop-name">page</span></td><td><span class="prop-type">number</span></td><td><span class="prop-default">1</span></td><td>Current page (1-indexed, controlled).</td></tr>
        <tr><td><span class="prop-name">totalItems</span></td><td><span class="prop-type">number</span></td><td><span class="prop-default">—</span></td><td>Total record count. Used to compute total pages. Required.</td></tr>
        <tr><td><span class="prop-name">perPage</span></td><td><span class="prop-type">number</span></td><td><span class="prop-default">10</span></td><td>Rows per page. Controls the per-page Select default.</td></tr>
        <tr><td><span class="prop-name">perPageOptions</span></td><td><span class="prop-type">number[]</span></td><td><span class="prop-default">[10,20,50,100]</span></td><td>Options shown in the per-page Select dropdown.</td></tr>
        <tr><td><span class="prop-name">siblingCount</span></td><td><span class="prop-type">number</span></td><td><span class="prop-default">1</span></td><td>Pages to show on each side of the active page before collapsing to ellipsis.</td></tr>
        <tr><td><span class="prop-name">onPageChange</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Called with the new page number when Previous, Next, or a page button is clicked.</td></tr>
        <tr><td><span class="prop-name">onPerPageChange</span></td><td><span class="prop-type">function</span></td><td><span class="prop-default">—</span></td><td>Called with the new per-page value. Component resets to page 1 automatically.</td></tr>
      </tbody>
    </table>
  </div>

  <!-- DO / DON'T -->
  <div class="doc-section">
    <div class="btn-section-toolbar"><h2 class="doc-section-title">Do / Don't</h2></div>
    <div class="do-dont">
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Reset to page 1 whenever the per-page value changes. Staying on page 3 when switching from 10 to 50 per page may leave the user beyond the new page boundary.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't use pagination when the whole dataset fits on one screen. Paginating fewer than 20 items adds friction — show everything inline instead.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Reflect page and per-page in the URL (<code>?page=3&perPage=20</code>). This makes filtered views shareable and restores state on browser back-navigation.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't mix this pagination component with infinite scroll on the same list — pick one pattern. Hybrid layouts break keyboard navigation and browser history.</div></div>
      <div class="do-card"><div class="do-card-head">✓ Do</div><div class="do-card-body">Disable Previous on page 1 and Next on the last page. Keep both buttons visible at all times so the layout doesn't shift at the boundaries.</div></div>
      <div class="dont-card"><div class="dont-card-head">✗ Don't</div><div class="dont-card-body">Don't offer more than 4–5 per-page options. Extra choices (25, 75, 200…) increase cognitive load without meaningful benefit for most use cases.</div></div>
    </div>
  </div>

  </div>`;
}
