import { pageHeader } from '../utils/render.js';
import { PRIM } from '../data/colors.js';

const RAMPS = [
  { name:'Purple',       prefix:'Purple',       stops: [['5','#F7F4FB'],['10','#ECE6F5'],['20','#D9CCEA'],['30','#C7B3E0'],['40','#B499D6'],['50','#A180CC'],['60','#8E66C1'],['70','#7B4DB7'],['80','#6933AD'],['90','#561AA2'],['100','#430098']] },
  { name:'Light Purple', prefix:'Light-Purple', stops: [['5','#FBF7FF'],['10','#F7F0FF'],['20','#EFE0FF'],['30','#E7D1FF'],['40','#DFC1FF'],['50','#D7B2FF'],['60','#CFA3FF'],['70','#C793FF'],['80','#BF84FF'],['90','#B774FF'],['100','#AF65FF']] },
  { name:'Dark Purple',  prefix:'Dark-Purple',  stops: [['5','#F4F3F6'],['10','#E8E6ED'],['20','#D1CCDA'],['30','#BAB3C8'],['40','#A399B5'],['50','#8C80A3'],['60','#756690'],['70','#5E4D7E'],['80','#47336B'],['90','#301A59'],['100','#190046']] },
  { name:'Red',          prefix:'Red',          stops: [['5','#FFF2F4'],['10','#FBE8EA'],['20','#F7D1D5'],['30','#F3BAC0'],['40','#EFA3AB'],['50','#EC8C96'],['60','#E87580'],['70','#E45E6B'],['80','#E04756'],['90','#DC3041'],['100','#D8192C']] },
  { name:'Green',        prefix:'Green',        stops: [['5','#F2FDF6'],['10','#D8F8E5'],['20','#BAF3D1'],['30','#9BEDBE'],['40','#7CE9A9'],['50','#5EE495'],['60','#43DF84'],['70','#25DA70'],['80','#21C063'],['90','#1BA755'],['100','#148F47']] },
  { name:'Amber',        prefix:'Amber',        stops: [['5','#FEFBF6'],['10','#FCF3E3'],['20','#FAE9CC'],['30','#F8DDB0'],['40','#F5D194'],['50','#F2C373'],['60','#EFB652'],['70','#EBA62D'],['80','#E19614'],['90','#C5810D'],['100','#AE7004']] },
  { name:'Black',        prefix:'Black',        stops: [['0','#FFFFFF'],['5','#F5F5F5'],['10','#E8E8E8'],['20','#D1D1D1'],['30','#BABABA'],['40','#A3A3A3'],['50','#8C8C8C'],['60','#757575'],['70','#5E5E5E'],['80','#474747'],['90','#303030'],['100','#191919']] },
  { name:'Grey',         prefix:'Grey',         stops: [['5','#FDFDFD'],['10','#FAFAFA'],['20','#F6F6F6'],['30','#F0F0F0'],['40','#E6E6E6'],['50','#E9EAEB'],['60','#E1E1E1']] },
];

const lightHexes = new Set(['#FFFFFF','#FDFDFD','#FAFAFA','#F6F6F6','#F5F5F5','#F4F3F6','#F2FDF6','#F0F0F0','#FFF2F4','#FBF7FF','#F7F4FB','#FEFBF6','#FBE8EA','#FCF3E3','#F7F0FF','#E8E8E8','#E6E6E6','#E9EAEB','#E1E1E1','#D1D1D1','#D9CCEA','#C7B3E0','#EFE0FF','#E7D1FF','#DFC1FF','#D7B2FF','#D8F8E5','#BAF3D1','#9BEDBE','#FAE9CC','#F8DDB0','#F5D194','#BABABA','#D1CCDA','#BAB3C8','#A399B5']);

const totalStops = RAMPS.reduce((a, r) => a + r.stops.length, 0);

function primRow(rampId, prefix, stop, hex) {
  const isLight = parseInt(stop) <= 20 || lightHexes.has(hex);
  const border = isLight ? ' swatch-bordered' : '';
  const primName = prefix + '-' + stop;
  return '<div class="ctoken-row" data-group="' + rampId + '" data-hex-light="' + hex + '" data-hex-dark="' + hex + '" onclick="copyPrimHex(this)" title="Click to copy hex">' +
    '<div class="ctoken-swatch-wrap"><div class="ctoken-swatch' + border + '" style="background:' + hex + '"></div></div>' +
    '<div class="ctoken-name">' +
      '<div class="ctoken-token">' + primName + '</div>' +
      '<div class="ctoken-label">' + prefix + '</div>' +
    '</div>' +
    '<div class="ctoken-hex">' +
      '<div class="ctoken-prim-main">' + hex + '</div>' +
    '</div>' +
    '<div class="ctoken-use" style="font-size:11px;color:var(--content-tertiary)">' +
      (parseInt(stop) >= 80 ? 'Dark surfaces, text on light bg' :
       parseInt(stop) >= 60 ? 'Borders, icons, muted elements' :
       parseInt(stop) >= 40 ? 'Secondary elements, disabled states' :
       parseInt(stop) >= 20 ? 'Subtle backgrounds, hover states' :
       'Lightest tints, page backgrounds') +
    '</div>' +
  '</div>';
}

export default function() {
  const allRows = RAMPS.flatMap(r => r.stops.map(([stop, hex]) => primRow(r.name, r.prefix, stop, hex)));

  return pageHeader('Tokens', 'Primitives', 'Raw color ramps. These are the source values — semantic tokens alias from here. Never use primitives directly in components.', [{val: RAMPS.length + '', label:'Ramps'},{val: totalStops + '', label:'Color stops'}]) +
  '<div class="page-body">' +
  '<div class="callout danger" style="margin-bottom:24px">' +
    '<div class="callout-icon">⚠</div>' +
    '<div><strong>Never use primitive tokens in components.</strong> They exist for the semantic layer to alias from. If you find yourself reaching for <code>Purple-100</code> in a component, use <code>brand/primary</code> instead.</div>' +
  '</div>' +
  '<div class="doc-section">' +
  '<div class="ctoken-toolbar">' +
    '<div class="ctoken-tabs">' +
      '<button class="ctoken-tab active" data-group="all" onclick="setPrimTab(this.dataset.group,this)">All <span class="ctoken-tab-count">' + totalStops + '</span></button>' +
      RAMPS.map(r => '<button class="ctoken-tab" data-group="' + r.name + '" onclick="setPrimTab(this.dataset.group,this)">' + r.name + ' <span class="ctoken-tab-count">' + r.stops.length + '</span></button>').join('') +
    '</div>' +
  '</div>' +
  '<div class="ctoken-table-head"><div></div><div>Name</div><div>Value</div><div>Typical use</div></div>' +
  '<div class="ctoken-table" id="prim-table">' + allRows.join('') + '</div>' +
  '</div></div>';
}
