import { PRIM, COLORS } from '../data/colors.js';
import { SPACING, RADII, TYPE_ROLES } from '../data/tokens.js';

export function colorChip(c) {
  const bordered = c.border ? 'bordered' : '';
  const darkIsLight = ['#FFFFFF','#FAFAFA','#F7F4FB','#F7F0FF','#F2FDF6','#FEFBF6','#FFF2F4','#EDE8F5','#ECE6F5','#E7D1FF','#F0F0F0','#E1E1E1','#FDFDFD','#F6F6F6','#E6E6E6','#E9EAEB'].includes(c.dark);
  const darkTextColor = darkIsLight ? '#191919' : '#FFFFFF';
  const lightPrim = PRIM[c.light] || '';
  const darkPrim  = PRIM[c.dark]  || '';
  return `
    <div class="color-chip">
      <div class="color-swatch ${bordered}" style="background:${c.light}"></div>
      <div class="color-meta">
        <div class="color-label">${c.label}</div>
        <div class="color-token">${c.token}</div>
        <div class="color-hex-row">
          <span class="color-hex">${c.alpha ? c.light : c.light}</span>
          ${lightPrim ? `<span class="color-prim">${lightPrim}</span>` : ''}
        </div>
        <div class="color-dark-label">Dark mode</div>
        <div class="color-dark" style="background:${c.dark};border:1px solid rgba(0,0,0,0.08)">
          <div class="color-dark-inner">
            <span class="color-dark-val" style="color:${darkTextColor}">${c.dark}</span>
            ${darkPrim ? `<span class="color-dark-prim" style="color:${darkTextColor};opacity:.6">${darkPrim}</span>` : ''}
          </div>
        </div>
      </div>
    </div>`;
}

export function colorSection(title, items) {
  return `
    <div class="subsection">
      <div class="subsection-label">${title}</div>
      <div class="grid-auto">
        ${items.map(colorChip).join('')}
      </div>
    </div>`;
}

/* Compact page header replacing the hero on token/resource pages */
export function pageHeader(eyebrow, title, desc, meta) {
  return '<div class="page-header">' +
    '<div class="page-header-eyebrow"><div class="page-header-dot"></div>' + eyebrow + '</div>' +
    '<h1 class="page-header-title">' + title + '</h1>' +
    '<p class="page-header-desc">' + desc + '</p>' +
    '</div>';
}

export function spacingRows() {
  const MAX = 360;
  return SPACING.map((s, i) => {
    const bw = s.val === 0 ? 0 : Math.max(4, Math.round((s.val / 160) * MAX));
    const bg = i % 2 === 0 ? 'background:#FAFAFA' : '';
    return `
      <div class="spacing-row" style="${bg}">
        <div class="sp-token">spacing/${s.val}</div>
        <div class="sp-value">${s.val}px</div>
        <div class="sp-bar-wrap">
          ${bw > 0 ? `<div class="sp-bar" style="width:${bw}px"></div>` : '<div style="width:4px;height:7px;background:#E1E1E1;border-radius:2px"></div>'}
        </div>
        <div class="sp-use">${s.use}</div>
      </div>`;
  }).join('');
}

export function radiusCards() {
  return RADII.map(r => {
    const cr = Math.min(r.css, 24);
    return `
      <div class="radius-card">
        <div class="radius-preview" style="border-radius:${cr}px"></div>
        <div class="radius-name">${r.name}</div>
        <div class="radius-val">${r.val}</div>
        <div class="radius-prim">→ ${r.prim}</div>
        <div class="radius-use">${r.use}</div>
      </div>`;
  }).join('');
}

export const WEIGHT_NAMES = { 400: 'Regular', 500: 'Medium', 600: 'SemiBold', 700: 'Bold', 800: 'ExtraBold' };

export function typeRows(script) {
  return TYPE_ROLES.map(r => {
    const color = r.brand ? '#430098' : r.muted ? '#757575' : '#191919';
    const arFw = r.arFw || r.fw;

    if (script === 'arabic') {
      const arFont = r.arFs >= 18 ? 'Alexandria' : 'Inter';
      const arabicStyle = 'font-family:' + arFont + ',sans-serif;font-size:' + r.arFs + 'px;font-weight:' + arFw + ';letter-spacing:0%;color:' + color + ';direction:rtl;text-align:right;';
      const sizeTag = '<span class="type-spec-val">' + r.arFs + 'px</span>';
      return '<div class="type-row">' +
        '<div><span class="type-token-pill">' + r.token + '</span></div>' +
        '<div class="type-specs-col">' +
          '<div class="type-spec-item">' + sizeTag + '<span class="type-spec-key">size</span></div>' +
          '<div class="type-spec-item"><span class="type-spec-val">' + WEIGHT_NAMES[arFw] + '</span><span class="type-spec-key">weight</span></div>' +
          '<div class="type-spec-item"><span class="type-spec-val">' + arFont + '</span><span class="type-spec-key">font</span></div>' +
        '</div>' +
        '<div class="type-preview"><span style="' + arabicStyle + '">' + r.arPreview + '</span></div>' +
        '<div class="type-usage">' + r.use + '</div>' +
        '</div>';
    } else {
      const latinFont = r.fs >= 18 ? 'Montserrat' : 'Inter';
      const latinStyle = 'font-family:' + latinFont + ',sans-serif;font-size:' + r.fs + 'px;font-weight:' + r.fw + ';letter-spacing:' + r.ls + '%;color:' + color + ';' + (r.italic ? 'font-style:italic' : '');
      return '<div class="type-row">' +
        '<div><span class="type-token-pill">' + r.token + '</span></div>' +
        '<div class="type-specs-col">' +
          '<div class="type-spec-item"><span class="type-spec-val">' + r.fs + 'px</span><span class="type-spec-key">size</span></div>' +
          '<div class="type-spec-item"><span class="type-spec-val">' + WEIGHT_NAMES[r.fw] + '</span><span class="type-spec-key">weight</span></div>' +
          '<div class="type-spec-item"><span class="type-spec-val">' + latinFont + '</span><span class="type-spec-key">font</span></div>' +
          (r.italic ? '<div class="type-spec-item"><span class="type-spec-val">italic</span><span class="type-spec-key">style</span></div>' : '') +
        '</div>' +
        '<div class="type-preview"><span style="' + latinStyle + '">' + r.preview + '</span></div>' +
        '<div class="type-usage">' + r.use + '</div>' +
        '</div>';
    }
  }).join('');
}

export function iconSvg(path, size, color) {
  return '<svg width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="' + color + '" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' + path + '</svg>';
}

export function comingSoon(title, desc) {
  return pageHeader('Coming soon', title, desc) +
    `<div class="page-body">
      <div class="coming-soon">
        <div class="coming-soon-icon">🚧</div>
        <div class="coming-soon-title">In progress</div>
        <div class="coming-soon-desc">This page is being built. The component will be documented with variants, props, token map, and do/don't guidelines.</div>
      </div>
    </div>`;
}
