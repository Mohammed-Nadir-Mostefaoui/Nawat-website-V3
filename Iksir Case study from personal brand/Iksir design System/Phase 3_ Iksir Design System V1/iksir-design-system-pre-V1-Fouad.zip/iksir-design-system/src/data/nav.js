export const NAV = [
  {
    label: 'Get Started',
    items: [
      { id: 'overview',    label: 'Overview',       icon: '⬡', page: 'overview' },
      { id: 'principles',  label: 'Principles',     icon: '◈', page: 'principles' },
      { id: 'architecture',label: 'Architecture',   icon: '⬡', page: 'architecture' },
    ]
  },
  {
    label: 'Tokens',
    items: [
      { id: 'primitives',  label: 'Primitives',     icon: '⬡', page: 'primitives' },
      { id: 'colors',      label: 'Colors',         icon: '◉', page: 'colors',      badge: '191' },
      { id: 'typography',  label: 'Typography',     icon: '◈', page: 'typography',  badge: '9' },
      { id: 'spacing',     label: 'Spacing',        icon: '⬡', page: 'spacing',     badge: '22' },
      { id: 'sizing',      label: 'Sizing',         icon: '⬡', page: 'sizing',       badge: '225' },
      { id: 'radius',      label: 'Border Radius',  icon: '◌', page: 'radius',      badge: '8' },
      { id: 'elevation',   label: 'Elevation',      icon: '◎', page: 'elevation',   badge: '4' },
      { id: 'iconography', label: 'Iconography',    icon: '◈', page: 'iconography',  badge: '86' },
    ]
  },
  {
    label: 'Components',
    items: [
      { id: 'button',      label: 'Button',         icon: '▣', page: 'button',      tag: 'new' },
      { id: 'input',       label: 'Input',          icon: '▣', page: 'input' },
      { id: 'tooltip',     label: 'Tooltip',        icon: '▣', page: 'tooltip' },
      { id: 'checkbox',    label: 'Checkbox',        icon: '▣', page: 'checkbox' },
      { id: 'select',     label: 'Select',          icon: '▣', page: 'select' },
      { id: 'badge',       label: 'Badge',          icon: '▣', page: 'badge' },
      { id: 'toggle',      label: 'Toggle',         icon: '▣', page: 'toggle' },
      { id: 'breadcrumb',  label: 'Breadcrumb',     icon: '▣', page: 'breadcrumb' },
      { id: 'tab',         label: 'Tab',            icon: '▣', page: 'tab' },
      { id: 'card-comp',   label: 'Card',           icon: '▣', page: 'card-comp',   tag: 'soon' },
      { id: 'modal',       label: 'Modal',          icon: '▣', page: 'modal-comp' },
      { id: 'dropdown',    label: 'Dropdown',       icon: '▣', page: 'dropdown' },
      { id: 'toast',       label: 'Toast',          icon: '▣', page: 'toast' },
      { id: 'pagination',  label: 'Pagination',     icon: '▣', page: 'pagination' },
      { id: 'table',       label: 'Table',          icon: '▣', page: 'table' },
    ]
  },
  {
    label: 'Patterns',
    items: [
      { id: 'forms',       label: 'Forms',          icon: '◈', page: 'forms',       tag: 'soon' },
      { id: 'data-tables', label: 'Data Tables',    icon: '◈', page: 'data-tables', tag: 'soon' },
      { id: 'navigation',  label: 'Navigation',     icon: '◈', page: 'navigation',  tag: 'soon' },
    ]
  },
  {
    label: 'Resources',
    items: [
      { id: 'export',      label: 'CSS Export',     icon: '⬡', page: 'export' },
      { id: 'figma',       label: 'Figma Library',  icon: '⬡', page: 'figma' },
      { id: 'accessibility',label: 'Accessibility',  icon: '◈', page: 'accessibility' },
      { id: 'changelog',   label: 'Changelog',      icon: '⬡', page: 'changelog' },
    ]
  },
];
